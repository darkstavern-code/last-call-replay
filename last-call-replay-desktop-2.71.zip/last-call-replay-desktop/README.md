## 2.71

- Improved the bottom-right Working/progress indicator so completed, failed, canceled, and dismissed jobs clear safely.
- Added explicit Cancel / Dismiss / Keep waiting actions to the progress UI.
- Added stale-job detection after a long period without progress updates.
- Cancel requests now flow through a safe import-job IPC path and stop chunked jobs at safe progress checkpoints.
- Added clearer job names for processing logs, syncing match data, indexing videos, and repairing app data.
- Prevented duplicate maintenance and video-indexing jobs from stacking while one is already running.
- Updated latest.json and latest.example.json for the GitHub release.
- No addon files changed.

## 2.70

- Set the manual update checker to use the official GitHub repo by default.
- Default latest.json URL is now:

```txt
https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json
```

- Default release page is now:

```txt
https://github.com/darkstavern-code/last-call-replay/releases
```

- Updated latest.example.json and added latest.json for publishing to the repo.
- Still manual only: no auto-install, no replacement, no storage changes, and no user-data changes.

## 2.69

- Implemented Option 1 manual update checker.
- Settings → Updates now checks a hosted latest.json file.
- Shows current installed version, latest version, release date, release notes, installer download, and zip download when provided.
- Failed checks show a friendly non-blocking message.
- Update links open in the browser only. No auto-install, auto-replacement, folder moves, or user-data changes.


Example latest.json is included at:

```txt
latest.example.json
```

## 2.68
- Added a replay-video loading/buffering overlay so the viewer tells users when the linked video is still waking up.
- Made the first post-render replay rail update calmer so opening a video does not immediately force log-rail work during playback startup.
- Switched linked replay videos to preload enough data for smoother first play.
- Made synced Log Data amounts larger and easier to scan, with critical hits called out using a clear CRIT tag.
- Added a Settings > Updates tab for manual update checks, current/latest version display, official release page links, and optional JSON manifest checks.
- Added safe update IPC plumbing that never replaces files automatically and never touches recordings, mappings, SavedVariables paths, local state, or addon packages.

## 2.67

- Fixed result authority after combat-log parsing and PvPHelper scoreboard merge.
- A confident combat-log result now wins when own team and winner team are known.
- PvPHelper scoreboards can still fill missing results, but no longer silently flip a combat-log Win/Loss.
- Added result conflict metadata and a visible Needs review badge when combat log and addon result sources disagree.
- Added combat-log result metadata from the parser: resultSource, resultAuthority, combatLogResult, combatLogOwnTeam, combatLogWinnerTeam, and combatLogWinnerTeamSource.
- Repaired stored/stale matches during normalization when existing ownTeam/winnerTeam evidence proves the saved result is wrong.
- Bumped parser version to force stale result rows to be reconsidered.
- No addon files changed.

## 2.66

- Added Windows taskbar recording cue through a safe renderer-to-main IPC call. While an actual recording is active, the app sets a small red taskbar overlay and an indeterminate taskbar progress cue, then clears both when recording stops, fails, or saves.
- Made recorder Start/Stop transitions immediate with Starting… and Stopping and saving… states.
- Added duplicate-click guards for recorder start/stop so rapid clicks cannot stack capture requests.
- Improved bottom-left recorder pill feedback for folder, source, settings, pending start, active recording, and save states.
- Kept existing recorder IPC/API names stable and added only the new safe taskbar-indicator IPC.
- No addon files changed.

## 2.65

- Fixed Solo Shuffle selected-round replay context so round views no longer carry the parent lobby event feed cache as their trusted source.
- Added round-specific event feed cache hydration for nested Solo Shuffle rounds.
- Preserved round-specific event feeds, raw-event counts, health timeline, deaths, cooldowns, CC, interrupts, chart data, metrics, and small diagnostic fields when switching rounds.
- Hardened arena display classification so combat-log arena matches do not inherit stale Random BG/BG labels from weaker or older metadata.
- Filtered stale battleground display tags from arena rows.

## 2.64

- Fixed Solo Shuffle selected-round context so the detail rail can use round-specific event/log data instead of reusing the parent lobby feed.
- Added round-scoped event derivation from the parent lobby event feed when individual round feeds are missing.
- Rebased derived round events so each selected round starts near 0 seconds in the rail.
- Added selected round/start/end fields to the rail cache key so changing rounds cannot reuse the same cached parent feed.
- Preserved round rawEvents/eventFeed row metadata in Solo Shuffle round payloads.
- Tuned the Important rail filter to include more useful arena/Solo events such as deaths, CC, interrupts, purges/dispels, trinket/cooldown text, and cast success indicators.
- Kept IPC/API names stable.
- No addon files changed.

## 2.63

- Repaired incomplete Solo Shuffle lobbies from full-log evidence instead of freezing active-tail partial lobbies.
- Solo Shuffle annotation now runs before general dedupe and again after dedupe, so raw round rows survive long enough to build or repair the canonical parent lobby.
- Increased focused Solo Shuffle repair-window limits so a noisy 6-round lobby keeps all round starts instead of trimming down to the later 5:45 tail.
- Increased live Solo Shuffle buffer safety limits for long/noisy shuffles.
- 5/17 Tol’Viron repair test now upgrades a stale 5:45 partial lobby back to the full 17:39:09 to 17:51:57 six-round parent.
- Kept IPC/API names stable.
- No addon files changed.

## 2.61

- Reworked Solo Shuffle duplicate-parent cleanup at the state/model layer.
- Solo Shuffle parent lobbies now merge by stable lobby identity: Solo Shuffle, same map, same/overlapping six-player lobby, and nearby or overlapping session time.
- Round teams/results/duration no longer create separate parent lobby identity.
- Partial Solo Shuffle parent lobbies now merge their rounds, scoreboard data, VOD fields, timing, and preserved user fields into one canonical parent.
- Duplicate parent IDs are returned through the existing removed/remap plumbing so stale visible rows can be cleared instead of appended.
- No addon files changed.

## 2.60

- Reworked Solo Shuffle cleanup at the data/model layer, not just frontend filtering.
- Parser now keeps repeated Solo Shuffle `ARENA_MATCH_START` rows in one lobby segment and slices rounds from the actual start markers.
- State resolver now stores one canonical Solo Shuffle parent lobby and consumes child round/source rows into `soloRounds`.
- One-round Solo Shuffle shells merge into the parent lobby or become one incomplete parent if no full lobby exists yet.
- Empty generic Arena addon snapshots near a Solo Shuffle lobby are suppressed and cannot overwrite the good lobby.
- Removed child/shell IDs are remapped to the parent lobby for stale UI clicks, VOD links, and delta updates.
- Kept IPC/API names stable.
- No addon code changes.

## 2.59

- Strengthened Solo Shuffle cleanup so old one-round lobby shells are removed once the full parent lobby exists.
- Preserves VOD/favorite fields from stale Solo Shuffle shells onto the rebuilt parent lobby.
- Sends removed match IDs for old Solo Shuffle shells, child rows, and merged PvPHelper snapshots so the frontend stops appending stale rows.
- Added frontend Solo Shuffle safety filtering so Matches, Dashboard, Favorites, and Search hide child rows and duplicate one-round shells.
- Clicking a stale child/round row now opens the parent Solo Shuffle lobby detail.
- Fixed match detail navigation for newest-first sorting: left is Next/newer, right is Previous/older, with matching actions.
- Kept IPC/API names stable.
- No addon code changes.

## 2.58

- Fixed live Solo Shuffle session handling so repeated `ARENA_MATCH_START` rows stay in one watched arena session until the final end.
- Increased live Solo Shuffle arena buffering so long, noisy shuffles do not trim away middle round starts.
- Added active-log Solo Shuffle repair during sync so a visible one-round Solo row can be rebuilt from the nearby full log window.
- Improved watcher chunk deltas so removed child/duplicate match IDs reach the frontend and stale round rows can disappear.
- Kept IPC/API names stable.
- No addon code changes.

## 2.57

- Fixed Solo Shuffle lobby grouping/merge behavior for the 5/17 Tol’Viron Arena session.
- Keeps the six log-derived rounds as one parent lobby and hides child rounds from the main match list.
- Merges the good PvPHelper Solo Shuffle scoreboard snapshot into the lobby instead of creating a separate one-round row.
- Ignores empty/generic arena snapshots from becoming visible duplicate matches.
- Sends removed match IDs for hidden Solo Shuffle child/duplicate rows so the frontend clears stale visible rows after sync.

## 2.56
- Fixed Characters page bracket normalization so PvPHelper arena values like `2` and `3` become `2v2` and `3v3`.
- Lightwidow rated 2v2 and 3v3 PvPHelper rating snapshots now appear in the rating timeline.
- Hid Random BGs and unrated modes from rating bracket filters/cards.
- Replaced unreliable character bracket W/L and K/D cards with rated rating-source cards.
- Kept Recent Matches, but only shows matches confidently tied to the selected character by own character/player identity.
- Added source badges for Recent Matches such as Log, Scoreboard, VOD, and Inferred end.
- No addon files changed.

## 2.55

- Fixed arena log fallback so arenas with `ARENA_MATCH_START` but no `ARENA_MATCH_END` are finalized from zone-out/file-end instead of being dropped.
- Added inferred arena end metadata: `endInferred`, `inferredEndTime`, `inferredEndMs`, and `captureReason`.
- Improved targeted arena window sync so zone-out inferred segments can be selected instead of a shorter fallback slice.
- Preserved full combat-log timing when merging with scoreboard/video-only matches so richer log matches are not replaced by shorter shells.
- Fixed sync progress behavior: completion reaches 100%, auto-dismisses, and can be clicked to hide.
- Updated empty-sync copy to say `No new matches found` or `Already up to date`.
- Kept IPC/API names stable.
- No addon files were changed.

## 2.54

- Added visible startup/big-sync progress state.
- Added backend import-job progress events and renderer overlay updates without full re-rendering the app shell.
- Strengthened heavy log job guards so active sync, selected-match sync, repair, and previous-log import cannot stack over each other.
- Added chunk progress for large combat-log imports and targeted match-window scans.
- Reduced log chunk size to keep giant parsing passes lighter.
- Improved renderer caching by sharing performance-cache namespaces across modules.
- Made state saves safer with unchanged-state skip and atomic temp-file replacement.

## 2.53

- Focused performance pass.
- Added safer log offset restoration from the log registry so active sync and changed-log sweeps can resume from already-scanned bytes after restart instead of reprocessing whole unchanged files.
- Added backend duplicate-job coalescing for refresh, active log sync, selected-match sync, repair, and manual log import. Double-clicks now join the existing job instead of stacking another heavy parse.
- Added bounded parser summary caching for repeated match metric builds. The cache is size-limited so huge BG matches do not turn into a memory gremlin.
- Added renderer-side metric row and health death caches so tab/view switching does less repeated damage/healing/CC/death/timeline preparation.
- Added UI busy guards for Sync Active Log, Repair Missing Logs, selected-match log sync, and Match History refresh.
- Kept IPC/API channel names stable.
- No CSS files were changed.
- Updated visible app version plumbing to 2.53.
- No addon files were changed.

## 2.51

- Refactored VOD/video IPC handlers out of `electron/main.cjs` into `electron/modules/vodIpcHandlers.cjs`.
- Kept the existing desktop API channel names for VOD import, VOD linking, VOD deletion, video section updates, and VOD export.
- Kept the shared VOD helper wrappers in place for startup payloads and VOD auto-linking.
- No CSS files were changed.
- Updated visible app version plumbing to 2.51.
- No addon files were changed.

## 2.50

- Refactored PvPHelper setup/import actions into `app/modules/pvpHelperSetupActions.js`.
- Kept `app/modules/setupActions.js` as the main setup-action wrapper, with PvPHelper behavior delegated to the focused module.
- Added `pvpHelperSetupActions.js` to `app/index.html` before `setupActions.js`.
- Kept existing button names, renderer wrappers, and desktop API calls unchanged.
- No CSS files were changed.
- Updated visible app version plumbing to 2.50.
- No addon files were changed.

## 2.49

- Refactored import/setup rendering out of `app/renderer.js` into `app/modules/importCenterView.js`.
- Kept the same renderer wrapper function names so Settings, Characters, import preview, and setup buttons keep calling the same helpers.
- Added `importCenterView.js` to `app/index.html` before `renderer.js`.
- Reduced `app/renderer.js` from about 2,904 lines to 2,647 lines without changing CSS in this pass.
- Left existing CSS files alone for this update.
- Updated visible app version plumbing to 2.49.
- No addon files were changed.

## 2.48

- Refactored replay timeline helpers out of `app/renderer.js` into `app/modules/replayTimelineHelpers.js`.
- Refactored health timeline/death-window rendering out of `app/modules/replayView.js` into `app/modules/replayHealthTimeline.js`.
- Split replay layout and rail feed base CSS into `app/styles/replay-layout.css`.
- Kept replay buttons, IPC names, VOD timing behavior, health timeline behavior, and log parsing behavior unchanged.
- Re-tested the 5/16 uploaded combat log through the live log session path: still detects 7 BG matches.
- No addon files were changed.

## 2.47

- Refactored recorder/source helper logic out of `app/renderer.js` into `app/modules/recorderSourceHelpers.js`.
- Kept the renderer wrapper function names the same so recorder view, dashboard, setup actions, and recording actions continue calling the same helpers.
- Added `recorderSourceHelpers.js` to `app/index.html` before `renderer.js`.
- Split `app/styles/metrics.css` into focused metric style files while preserving load order:
  - `app/styles/metric-inspector.css`
  - `app/styles/metric-modal.css`
  - `app/styles/metric-timeline.css`
- Reduced `app/renderer.js` by about 158 lines and reduced `app/styles/metrics.css` from about 814 lines to 393 lines.
- Updated visible app version plumbing to 2.47.
- No addon files were changed.

## 2.46

- Refactored match display, result, filter, map-name, timestamp, and match-dedupe helpers out of `app/renderer.js` into `app/modules/matchDisplayHelpers.js`.
- Kept the renderer wrapper function names the same so existing view/action modules continue calling the same helpers.
- Added `matchDisplayHelpers.js` to `app/index.html` before `renderer.js`.
- Split base/global layout CSS into `app/styles/base-layout.css` and loaded it before `styles.css` so CSS order stays the same.
- Kept recent BG map display coverage together with the helper module, including Warsong Gulch `2106`, Deepwind Gorge `2245`, and Deephaul Ravine `2656`.
- Updated visible app version plumbing to 2.46.
- No addon files were changed.

## 2.45

- Switched the dev/runtime window icon to the bundled Windows `.ico`, so Windows should stop falling back to the Electron logo in source runs.
- Kept the Last Call Replay logo as the sidebar brand, favicon, build icon, and packaged app icon source.
- Added Deepwind Gorge combat-log map ID `2245`; the 5/16 log uses this ID, so those BGs can now be detected from logs instead of relying only on addon scoreboards.
- Improved large active-log catch-up after startup-light sync. Manual refresh can now do a chunked first backfill up to 1 GB instead of only reading the newest tail slice.
- Refactored live log session tracking out of `electron/main.cjs` into `electron/modules/liveLogSessions.cjs`.
- Optimized live log scanning so it only fully parses marker rows while collecting active match lines. This keeps big logs safer and faster without changing match output.
- Re-tested the 5/16 uploaded log: the log parser now sees 7 BG matches from that file, including Deepwind Gorge, Deephaul Ravine, Twin Peaks, Eye of the Storm, Temple of Kotmogu, and both Silvershard Mines games.
- Re-tested the 5/12 arena sample: still parses 12 matches.
- No addon files were changed.

## 2.44

- Added the new Last Call Replay logo to the sidebar brand card, browser/app favicon, BrowserWindow icon, and Windows build icon source.
- Moved the sidebar recorder/video control above the app/addon version strip so the version text stays visible at the bottom-left.
- Refactored player meeting dedupe/merge helpers into `app/modules/playerMeetingHelpers.js`.
- Split sidebar/brand styles into `app/styles/brand-sidebar.css` so `styles.css` keeps shrinking instead of becoming the next swamp file.

## 2.43

- Refactored Solo Shuffle UI/session helper logic out of `app/renderer.js` into `app/modules/soloShuffleUi.js`.
- Kept the existing renderer wrapper function names so current modules and event handlers still call the same helpers.
- Added `soloShuffleUi.js` to `app/index.html` before `renderer.js` so round selection, lobby context, VOD round bounds, and enemy identity helpers are loaded before the main renderer runs.
- Updated the visible app version plumbing from 2.42 to 2.43.
- Reviewed current style pressure. The next style cleanup targets are still `app/styles.css`, `app/styles/metrics.css`, and `app/styles/vod-recorder.css`; no CSS behavior was changed in this pass.
- Re-ran parser checks on the 5/12 arena sample and confirmed it still parses 12 matches.
- No addon files were changed.

## 2.42

- Split `electron/modules/pvpHelperImport.cjs` into focused PvPHelper bridge modules so the importer is no longer a future mega-file.
- Added `electron/modules/pvpHelperCore.cjs` for shared bracket, number, boolean, timestamp, clone, and player-realm helpers.
- Added `electron/modules/pvpHelperLuaParser.cjs` for Lua SavedVariables parsing.
- Added `electron/modules/pvpHelperInput.cjs` for PvPHelper.lua and zip input detection.
- Added `electron/modules/pvpHelperCharacters.cjs` for rating/character snapshot parsing.
- Added `electron/modules/pvpHelperSnapshots.cjs` for scoreboard snapshot normalization.
- Added `electron/modules/pvpHelperStatus.cjs` for addon bridge/logging readiness status extraction.
- Added `electron/modules/pvpHelperMerge.cjs` for scoreboard preview, dedupe, merge, and import behavior.
- Kept `electron/modules/pvpHelperImport.cjs` as the compatibility wrapper so existing backend calls still use `createPvPHelperImportTools()` and all previous helper names are still returned.
- Compared the old importer to the new modular importer on the current `PvPHelper.lua` sample: both parsed the same 49 scoreboard matches, 41 character/rating snapshots, schema 3 status, and identical match summaries.
- Reviewed the current style-file sizes for the next UI cleanup pass. Main style pressure is now `app/styles.css`, `app/styles/metrics.css`, and `app/styles/vod-recorder.css`.
- No addon files were changed.

## 2.41

- Split the combat-log parser into smaller modules without changing the public parser exports used by `electron/main.cjs`.
- Added `electron/modules/combatLogCore.cjs` for raw combat-log line parsing, combat event classification, map-key normalization, name cleanup, and shared time/format helpers.
- Added `electron/modules/combatLogMetrics.cjs` for damage/healing/taken rows, CC/interrupt/purge/dispel meters, death recap rows, event feed building, health timelines, and final match summary construction.
- Added `electron/modules/combatLogSegments.cjs` for arena/BG segment detection, Solo Shuffle round slicing, BG sub-zone handling, and match extraction.
- Kept `electron/modules/combatLogParser.cjs` as the compatibility wrapper so existing backend calls still use `createCombatLogParserTools()` and `processRawText()` the same way.
- Re-tested the 5/12 arena sample against the previous parser and confirmed both versions still parse the same 12 arena matches with the same maps, match types, and durations.
- No addon files were changed.

## 2.40

- Did a modularization sweep after the log-sync refactors and confirmed the recent backend extractions are still wired through compatibility wrappers, so existing IPC names and UI buttons stay intact.
- Refactored app storage and portable/external-drive storage logic out of `electron/main.cjs` into `electron/modules/appStorageBackend.cjs`.
- Kept the existing storage behavior for local app data, portable storage pointer files, archive folders, recordings folders, and app-storage connect/migrate flows.
- Confirmed `addon-packages` is still included and no addon files were changed.
- Re-ran parser checks: the 5/12 arena sample still parses all 12 arena matches, and the 5/13 trimmed BG segments still parse as 10 matches.
- Ran an app-storage smoke test covering default storage, portable pointer creation, external storage migration, and connect-only storage mapping.

## 2.39

- Refactored the `scan-logs-folder` backend flow out of `electron/main.cjs` and into `electron/modules/logSyncBackend.cjs`.
- Kept the same IPC name and button behavior for Refresh Match History, Startup Light Log Catch-Up, and Sync Active Log.
- Improved changed older-log sweep ordering so the most recently touched rotated logs are checked first when the scan has to cap work. This should reduce missed matches after WoW rotates or writes into a different log.
- Improved missing-log repair ordering so the newest unlinked matches get checked first during limited refresh passes.
- Fixed a duplicated update counter in missing-log repair.
- Added updated-match counts to live log tail sync results, so refresh/status messages better distinguish new imports from existing matches that were enriched.
- Re-tested the 5/12 arena sample: all 12 arena matches still parse.
- Re-tested the 5/13 trimmed large-BG segments: skirmish plus 9 BGs still parse as 10 matches.
- No addon files were changed.

## 2.38

- Refactored log-match sync planning into `electron/modules/logSyncBackend.cjs` without changing IPC names or user-facing buttons.
- Kept selected-match sync, missing-log repair, changed-log sweep, and log-file scoring behind the same backend wrappers so existing UI behavior stays intact.
- Improved battleground segment detection so sub-zone `ZONE_CHANGE` rows inside the same BG do not split one real match into tiny fragments.
- Changed long BG trimming to preserve the original BG/arena start marker plus the tail, instead of tail-only trimming that could make large BGs invisible to the parser.
- Added known combat-log instance IDs for Warsong Gulch (`2106`) and Deephaul Ravine (`2656`) so those maps resolve more reliably from logs.
- Reviewed the catch-up path: Refresh stays light and safe, while Sync Active Log continues draining larger backlogs in chunks so huge logs do not need to be loaded all at once.
- Tested the 5/12 arena log sample and confirmed all 12 arena starts/end pairs parse as 12 matches.
- Tested the 5/13 large BG log with the new anchor-plus-tail trimming and confirmed the skirmish plus 9 BG segments still parse as 10 matches without loading the full 453 MB file at once.
- No addon files were changed.

## 2.37

- Fixed the remaining helper-refactor misses behind the `getSoloShuffleTools` / `processRawText` errors. Version 2.36 already restored the missing bridges, and 2.37 keeps those paths covered.
- Made the Match History `Refresh` button use a safer light-sync path instead of running the same heavier deep sync every time.
- Capped refresh work so it drains smaller active-log slices, checks fewer changed older logs per click, and limits automatic missing-log repair during refresh.
- Kept the heavier `Sync Active Log` / repair flows available for deliberate catch-up work.
- Added extra memory pressure guards before saving state so huge match history, metric events, health points, or event previews get compacted before V8 can run out of heap.
- Tightened live BG/arena session memory limits so long combat logs do not keep ballooning in memory while the app catches up.
- Refactored import job queue handling into `electron/modules/importJobQueue.cjs` without changing IPC names or UI behavior.
- No addon files were changed.

## 2.36

- Fixed auto-locate setup crash caused by missing `normalizeMatchType` wiring after the backend refactor.
- Fixed PvPHelper auto-find crash caused by the same missing combat parser helper bridge.
- Restored combat parser helper wrappers used by log sync, PvPHelper import, match dedupe, purge detection, and Solo Shuffle linking.
- Added the missing auto-locate summary helper so Auto-Locate Setup returns a normal user message instead of throwing after finishing.
- Restored the missing archive folder helper used by startup payloads, exports, and settings saves.
- Smoke-tested startup, auto-locate, PvPHelper auto-find, settings save, and setup handlers with mocked Electron.
- No addon files were changed.

## 2.35

- Refactored match action backend handlers into `electron/modules/matchActions.cjs`.
- Moved scoreboard linking, match deletion, Solo Shuffle child deletion cleanup, and hidden-player saves out of `electron/main.cjs`.
- Kept existing IPC names and response shapes so current UI buttons should keep working.
- No intentional behavior changes.
- No addon files were changed.

## 2.34

- Refactored Favorites actions into `app/modules/favoritesActions.js`.
- Moved favorite toggle, folder create/delete, folder assignment, notes, and favorite metadata saves out of `app/renderer.js`.
- Refactored Favorite backend IPC handlers into `electron/modules/favoriteBackend.cjs`.
- Moved favorite match/folder save logic out of `electron/main.cjs`, since it is now the largest remaining logic file.
- Kept compatibility wrappers so existing favorite buttons, folders, notes, and protected favorite actions should still work.
- No intentional behavior changes.
- No addon files were changed.

## 2.33

- Refactored renderer-side recording actions into `app/modules/recordingActions.js`.
- Moved recording start/stop controls, capture source refresh/selection, recording scan/delete/unlink, manual video linking, and recording-to-match suggestion attachment out of `app/renderer.js`.
- Kept compatibility wrappers in `app/renderer.js` so existing buttons and event wiring still call the same helper names.
- No intentional behavior changes.

## 2.32

- Refactored setup and settings actions into `app/modules/setupActions.js`.
- Moved log mapping, auto-locate setup, PvPHelper sync/import, character snapshot import, storage maintenance, repair tools, and settings save helpers out of `app/renderer.js`.
- Added the new module to `app/index.html` before event wiring.
- Kept compatibility wrappers in `app/renderer.js`, so existing buttons and startup calls still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.31

- Refactored VOD action handling into `app/modules/vodActions.js`.
- Moved VOD import, drop/paste handling, timing save/linking, VOD delete, export folder choice, clip export, clip trim controls, and VOD section save helpers out of `app/renderer.js`.
- Kept compatibility wrappers in `app/renderer.js`, so existing buttons and event wiring still call the same helper names.
- No intentional behavior changes.

## 2.30

- Refactored VOD and recorder CSS into `app/styles/vod-recorder.css`.
- Moved VOD tab layout, VOD import/drop zone, VOD candidates, export panel, clip range editor, recorder console, source picker, sidebar recorder pill, recording history, and recording attachment/suggestion styles out of the main stylesheet.
- Added the new stylesheet to `app/index.html` after Dashboard styles and before replay controls.
- No intentional behavior changes.
- No addon files were changed.

## 2.29

- Refactored Metrics CSS into `app/styles/metrics.css`.
- Moved meter tabs, metric panels, ability drilldowns, CC/interrupt cards, death-strip styling, pet breakdown rows, and metric modal styles out of the main stylesheet.
- Added the new stylesheet to `app/index.html` right after the base stylesheet so existing later overrides keep their order.
- No intentional behavior changes.
- No addon files were changed.

## 2.28

- Refactored Dashboard CSS into `app/styles/dashboard.css`.
- Moved dashboard hero/status cards, quick recording card, win-rate hover panel, recent-history filters, Most Seen Enemy card, and dashboard setup/status styling out of the main stylesheet.
- Added the new stylesheet to `app/index.html` after match styles and before replay/Solo Shuffle styles.
- No intentional behavior changes.
- No addon files were changed.

## 2.26

- Refactored Solo Shuffle and match navigation styles into `app/styles/solo-shuffle.css`.
- Moved Solo Shuffle lobby rows, round dots, round rail, compact lobby layout, and match detail navigation CSS out of the main stylesheet.
- Added the new stylesheet to `app/index.html` after the replay controls stylesheet.
- No intentional behavior changes.

## 2.25

- Refactored replay control CSS into `app/styles/replay-controls.css`.
- Moved the fragile replay transport, seek slider, volume slider, and deterministic slider reset rules out of the giant `app/styles.css`.
- Added the replay controls stylesheet to `app/index.html` after the base stylesheet so it loads last.
- No intentional behavior changes.
- No addon files were changed.

## 2.24

- Refactored global search and match-filter helpers into `app/modules/searchView.js`.
- Moved match filtering, sort labels, visible-limit helpers, class filter labels, Toon/Day/Match Type options, and search caret preservation out of `app/renderer.js`.
- Added the new Search View module to `app/index.html` before renderer startup.
- No intentional behavior changes.
- No addon files were changed.

## 2.23

- Refactored renderer event wiring into `app/modules/appEvents.js`.
- Moved click/change/paste/drop handlers, modal button wiring, tab switching, recorder controls, VOD actions, favorite actions, scoreboard actions, settings actions, and replay control bindings out of `app/renderer.js`.
- Kept a small `bindEvents()` wrapper in `app/renderer.js`, so existing render flow still calls the same helper name.
- No intentional behavior changes.
- No addon files were changed.

## 2.21

- Refactored recording backend logic into `electron/modules/recordingBackend.cjs`.
- Moved capture-source IPC, recording creation/chunk/finish handling, recording-folder scanning, manual video linking, recording dedupe/delete/unlink actions, recording picker helpers, and recording response compaction out of `electron/main.cjs`.
- Kept compatibility wrappers in `electron/main.cjs`, so existing recorder, VOD, startup, and match-linking paths still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.20

- Refactored PvPHelper SavedVariables import into `electron/modules/pvpHelperImport.cjs`.
- Moved Lua SavedVariables parsing, addon scoreboard snapshot parsing, character rating snapshot import, preview/import merge logic, and PvPHelper status extraction out of `electron/main.cjs`.
- Kept compatibility wrappers in `electron/main.cjs`, so existing Import Center, auto-sync, rating cards, and scoreboard merge actions still use the same helper names.
- Fixed the wrong-zip error path so choosing an addon package zip should return the friendly SavedVariables guidance instead of risking a crash.
- No addon files were changed.

## 2.19

- Refactored state storage into `electron/modules/stateStorage.cjs`.
- Moved state paths, backups, state read/write, settings defaults, event-feed cache helpers, state sanitizing, and heavy save compaction out of `electron/main.cjs`.
- Kept compatibility wrappers in `electron/main.cjs`, so existing startup, refresh, import, and save calls still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.18

- Refactored Metrics/Meter rendering into `app/modules/metricsView.js`.
- Moved meter tabs, metric rows, ability breakdowns, ability modal, CC/interrupt/death cards, and death health-strip rendering out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so existing match detail wiring, meter buttons, and Solo Shuffle selected-round toggles still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.17

- Refactored shared UI helpers into `app/modules/uiHelpers.js`.
- Moved small formatting/helper utilities out of `app/renderer.js`: escaped HTML, pills, file/path labels, time formatting, byte formatting, UI prefs, and class-color helpers.
- Kept compatibility wrappers in `app/renderer.js`, so existing modules and click handlers still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.16

- Refactored Favorites rendering into `app/modules/favoritesView.js`.
- Moved favorite folders, favorite cards, folder options, favorite markers, comments, and Favorite Matches page rendering out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so favorite stars, folders, notes, and protected favorite actions still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.15

- Refactored Dashboard rendering into `app/modules/dashboardView.js`.
- Moved dashboard recent matches, character scope, win-rate summaries, Most Seen Enemy card, quick recording card, and compact dashboard status cards out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so existing dashboard filters, match clicks, recorder buttons, and status actions still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.14

- Refactored Characters tab rendering into `app/modules/charactersView.js`.
- Moved character profile building, bracket cards, rating timeline rendering, current rating selection, and character filters out of the giant renderer file.
- Fixed character rating cards so the latest non-rating-only snapshot no longer hides the latest usable CR for a bracket.
- Rating timeline now still renders a time axis with one rated snapshot instead of showing no chart until two points exist.
- Added raw PvPHelper rating/MMR fallbacks from scoreboard `playerScore` snapshots.
- Fixed numeric normalization so null/blank PvPHelper fields no longer become fake `0` CR/MMR values.
- No addon files were changed.

## 2.13

- Refactored Settings view rendering into `app/modules/settingsView.js`.
- Moved setup center, logs mapping, PvPHelper bridge, video/folder settings, connection audit, storage cards, and performance audit rendering out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so existing Settings buttons and toggles still use the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.12

- Refactored Players tab rendering into `app/modules/playersView.js`.
- Moved player cards, player filters, sort controls, meeting history modal, player meeting rows, Solo rounds display, and class-colored player UI out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so existing Players tab buttons and history clicks still use the same names.
- No intentional behavior changes.

## 2.11

- Refactored recorder rendering helpers into `app/modules/recorderView.js`.
- Moved the Recorder tab shell, source picker, quick source modal, recording settings modal, recording history filters, recording-session cards, and recommended match cards out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so current recorder buttons, source picking, history filters, attach buttons, and recording-session link tools still call the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.09

- Refactored the VOD tab rendering helpers into `app/modules/vodView.js`.
- Moved VOD timing, imported VOD library cards, candidate rows, filename time suggestions, and candidate overlap math out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so existing VOD import, delete, timing save, and link buttons still call the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.08

- Refactored replay/video rendering helpers into `app/modules/replayView.js`.
- Moved the replay card, transport controls, VOD scope/export panel, health timeline rendering, Log Data rail rows, and replay sync update helpers out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so current buttons, slider events, health clicks, and VOD jump wiring still call the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.07

- Refactored scoreboard rendering/linking helpers into `app/modules/scoreboardView.js`.
- Moved the inline scoreboard panel, scoreboard modal, candidate rows, team grouping, class-colored player rows, rating/MMR text, and PvPHelper scoreboard action buttons out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so existing scoreboard buttons and match-detail wiring still call the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.06

- Refactored the match detail page and Solo Shuffle round panel into `app/modules/matchDetailView.js`.
- Moved the match-detail shell, Solo Shuffle round rail, Selected Round / Full Lobby scope card, and replay/metrics/scoreboard wiring out of the giant renderer file.
- Kept compatibility wrappers in `app/renderer.js`, so existing click handlers and detail-page behavior still call the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.05

- Refactored live combat-log watching and active-log tail processing into `electron/modules/liveLogSync.cjs`.
- Moved the watcher/tail sync flow out of `electron/main.cjs`, including folder watching, active-tail catch-up, initial backfill routing, watcher status events, and live chunk notifications.
- Lazy-loads the live-log sync module only when watching or syncing logs is needed, keeping app boot a little lighter.
- Kept compatibility wrappers in `electron/main.cjs`, so existing app code still calls the same helper names.
- No intentional behavior changes.
- No addon files were changed.

## 2.03

- Refactored the combat-log parser into `electron/modules/combatLogParser.cjs`.
- Moved the combat-log parsing helpers, event parsing, metrics builders, health timeline builder, battleground segment cleanup, and bracket match extraction out of `electron/main.cjs`.
- Kept compatibility wrappers in `electron/main.cjs`, so existing app code still calls the same helper names.
- Lazy-loads the combat-log parser module on first parse instead of loading that whole parser cave during initial app boot.
- Startup light active-log tail reads are capped lower to reduce early app-open blocking on giant logs.
- No intentional behavior changes.
- No addon files were changed.

## 2.02

- Refactored combat-log discovery and log-folder scanning helpers into `electron/modules/combatLogDiscovery.cjs`.
- Moved the WoW Logs folder detection, combat-log filename parsing, log roster/index helpers, and log picker defaults out of `electron/main.cjs`.
- Startup light catch-up now skips tail parsing entirely when the active log is already caught up, instead of doing an extra no-op pass during app open.
- This should reduce one more early startup blocking point, especially when the app opens with an unchanged giant active log.
- No addon files were changed.

## 2.01

- Refactored startup payload and performance-diagnostics building into `electron/modules/startupPayload.cjs`.
- Initial `get-state` now uses a lighter startup payload so the window can paint before slower folder/addon diagnostics run.
- Deferred startup diagnostics now refresh log suggestions, performance audit, PvPHelper install status, and SavedVariables discovery after the UI is already open.
- Startup background tasks are staggered so addon checks, PvPHelper auto-sync, log catch-up, and capture-source scanning do not all dogpile the first paint.
- Startup light log catch-up now favors the already mapped active log instead of scanning every detected Logs folder first.
- Startup light tail reads are capped lower, so a giant active log is less likely to make Windows show the app as not responding during the first few seconds.
- No addon files were changed.

## 2.00

- Moved the Solo Shuffle win/loss and round dots out from under the arena name.
- Matches tab Solo Shuffle rows now place lobby players first, with the compact record and six round markers to the right.
- Dashboard history Solo Shuffle rows use the same layout, so the sixth marker stays on the row instead of dropping underneath.
- Solo rows still show `Solo` only and do not show BG team-size tags.
- No addon files were changed.

## 1.99

- Refactored match-library response/delta helpers into `electron/modules/matchLibrary.cjs`.
- Startup and watcher log sync now send visible match rows back to the UI instead of hidden Solo Shuffle round children.
- Fixed a Solo Shuffle display issue where imported rounds could exist in state, but the visible lobby row could be missing from Matches and Dashboard history after startup catch-up.
- Recent match responses now skip hidden Solo Shuffle child rounds and include the lobby parent instead.
- No addon files were changed.

## 1.98

- Refactored the PvPHelper bridge/install/discovery helpers into `electron/modules/pvpHelper.cjs`.
- Kept compatibility wrappers in `electron/main.cjs`, so existing app code still calls the same helper names.
- Moved the addon-version check, local addon package discovery, SavedVariables mapping search, WoW `_retail_` root detection, and install-status math out of the main backend file.
- No intentional behavior changes. This is a safety refactor to make addon/app handshake work easier to maintain.
- No addon files were changed.

## 1.97

- Refactored Players tab profile math into `app/modules/playerProfiles.js`.
- Kept `buildPlayerProfiles()` as the renderer compatibility wrapper, so the UI still calls the same function while the counting logic lives in its own module.
- This keeps player Seen counts, Solo Shuffle With/Against records, rating samples, related matches, and common comp math easier to maintain without digging through the full renderer.
- No intentional behavior changes. This is a safety refactor.
- No addon files were changed.

## 1.96

- Refactored VOD linking/recording-session matching helpers into `electron/modules/vodLinking.cjs`.
- Kept compatibility wrappers in `electron/main.cjs` so existing IPC handlers and UI calls continue to use the same helper names.
- No intentional behavior changes. This is a safety refactor for easier future VOD/Solo Shuffle fixes.

## 1.95

- Moved the Solo Shuffle backend logic into `electron/modules/soloShuffle.cjs` so lobby grouping, round children, round winner inference, VOD bounds, and Solo player counting are easier to maintain safely.
- Kept compatibility wrapper functions in `electron/main.cjs`, so existing app code still calls the same Solo Shuffle helpers while the implementation lives in the new module.
- No functional Solo Shuffle behavior was intentionally changed in this pass. This is a safety refactor before more round/VOD/log work.
- No addon files were changed.

## 1.94

- Cleaned up Solo Shuffle lobby rows in Matches: they now show one `Solo` tag, no BG team-size tag, and the six lobby players instead of first-round comps.
- Added left/right Solo Shuffle round arrows beside the round icons on the match detail page.
- Round changes now keep using that round's VOD jump point, combat-log context, meters, and scoreboard context when available.
- Solo Shuffle detection now wins over stale addon/scoreboard bracket labels so a shuffle does not show as Random BG or BG 3/3.
- No addon files were changed.

## 1.93

- Reworked Solo Shuffle into one lobby match with round children instead of cluttering the Matches tab with separate round rows.
- Solo Shuffle lobby rows now show win/loss summary, detected round count, incomplete/leaver status, and six round dots.
- Match detail now has a Solo Shuffle round rail. Round buttons switch the replay context, teams, round ending, and selected-round stats.
- Added a Stats toggle for Solo Shuffle: Selected Round or Full Lobby. Selected Round is the default.
- VOD candidates now present Solo Shuffle as a lobby with detected rounds and W/L summary, while the linked VOD stays attached to the parent lobby.
- Players tab keeps Seen as one lobby encounter while With/Against records still use the per-round team relationships.
- No addon files were changed.

## 1.92

- Fixed the VOD tab candidate preview so it uses the same timing rules as the desktop backend before showing an Apply button. If a match would fail backend linking, it should no longer be shown as a candidate in the preview list.
- Added clearer VOD timing context to the VOD alignment card, including the VOD start time, end time when known, and sync offset.
- Added richer candidate rows with match real time, VOD real time covered, VOD clip time, and whether the section is a Solo Shuffle lobby window or a normal match window.
- No addon files were changed.

## 1.91

- Improved Solo Shuffle round handling from combat logs. If a round has no `ARENA_MATCH_END`, the parser now uses the first real player death to infer the round winner from that round's COMBATANT_INFO team map.
- Solo Shuffle sessions can still be shorter than six rounds if someone leaves early. The app keeps the rounds it can prove instead of inventing missing rounds.
- Players tab now counts a Solo Shuffle lobby as one Seen meeting per player, while still tracking per-round Solo Shuffle records for With/Against.
- Dashboard Most Seen Enemy also avoids counting the same Solo Shuffle lobby repeatedly.
- No addon files were changed.

## 1.90

- Found the replay slider issue: the visible line and circle could still come from different range-control layers, so the circle was sitting low while the rail stayed centered.
- Added a final deterministic slider layer reset for the replay seek and volume controls. The app now draws the rail and circle from the same shell and keeps the native range input invisible/clickable only.
- This is a CSS-only replay control alignment fix.
- Did not touch state, favorites, recordings, match links, scoreboard logic, combat logs, or addon files.

## 1.89

- Rebuilt the replay seek and volume sliders with a custom drawn track and knob instead of relying on Chromium's native range thumb alignment.
- The native range inputs stay clickable but invisible, so the visible circles now stay vertically centered on the slider line.
- CSS-only replay control alignment fix.
- Did not touch state, favorites, recordings, match links, scoreboard logic, combat logs, or addon files.

## 1.88

- CSS-only replay slider correction: nudged the seek and volume handles upward so the circles sit centered on their lines instead of below them.
- No state, favorites, recordings, match links, scoreboard logic, combat-log parsing, or addon files were changed.

## 1.87

- Fixed scoreboard linking so attaching a PvPHelper scoreboard is additive and cannot wipe combat-log meters, event feed rows, death recap, health timeline, favorites, recordings, or VOD links.
- Dedupe now favors combat-log-backed matches over scoreboard-only shells when the two describe the same game.
- Manual scoreboard linking still copies the final scoreboard/result data onto the selected match, then safely removes disposable addon-only shells.
- Addon was not changed or bundled.

## 1.86

- Fixed a crash where very large combat logs could make `state.json` too large during watched-file processing.
- Live folder watching now skips automatic deep backfill on large existing logs; use Sync Active Log for deliberate deep catch-up.
- Removed heavy health-timeline raw points before saving state while keeping compact playback points.
- Added emergency state compaction if JSON save detects oversized match data.
- Addon was not changed or bundled.

## 1.85

- Fixed the bottom-left app version strip so it uses the backend app version returned by Electron instead of staying stuck on the renderer default.
- Updated the renderer fallback version, package version, and `run-app.bat` launcher text to 1.85.
- No state, favorites, recordings, match links, combat logs, or addon files were changed.

## 1.84

- Centered the replay seek and volume slider handles vertically on the slim track.
- Kept the smaller transport sizing from 1.82/1.83 without widening the controls again.
- This is a CSS-only replay control alignment pass.
- No state, favorites, recordings, match linking, combat-log parsing, or addon files were changed.

## 1.83

- Added first-write state backups for safer updates. The app now creates a backup copy of `state.json` before the first state write each run and keeps recent backups in the app storage backups folder.
- Added a manual Backup Now button in Settings > Storage.
- Added Settings > Connections with a library audit table for matches, recordings, VODs, logs, scoreboards, and favorites.
- Added Repair Library Links to re-run match/video/recording link resolution without touching addon code.
- Recorder audio now defaults to on for new installs and missing recorder settings; users can still turn it off in recorder settings.
- README updated for this release.
- Addon was not changed or bundled.

## 1.82

- Tightened the replay transport strip so the seek and volume controls are visually shorter.
- Rebuilt the seek and volume sliders with slim aligned rails so the handle sits on the true 0 position instead of floating inward.
- Changed Sound On/Off into an icon button beside the volume control.
- Moved Full View into the replay transport beside volume and changed it to an icon-only button.
- Removed the duplicate Full View button from the lower replay action row.
- Addon was not changed or bundled.

## 1.81

- Cleaned up the replay control strip so the video seek bar is slimmer and the handle is smaller/aligned instead of looking like a loose random bubble.
- Fixed muted audio behavior so Sound Off drives the volume to true zero visually and functionally, while unmuting restores the previous volume.
- Added a 3-point VOD scope toggle: Match start, Starting room, and Full VOD. Match start is the default playback/download scope.
- Starting room begins about 45 seconds before the match start without changing the saved match trim.
- Full VOD unlocks the whole linked video for browsing between games; the log rail and meter are dimmed so it is clear that those data panels still belong to the selected match.
- Renamed Video Sync to Timing Tools so the button explains itself better while keeping the deeper link/timing tools available.
- VOD download now respects the selected scope mode instead of always exporting the saved clip start/end.
- README updated for this release.
- Addon was not changed or bundled.

## 1.80

- Changed startup log behavior so the app opens first, starts watching the log folder quickly, and only runs a lightweight catch-up after the window is already usable.
- Startup catch-up now reads at most one active-log slice and skips older changed-log sweeps plus missing-log repair until the user clicks Sync Active Log.
- Added a safe startup-light mode for large active logs: if a brand-new active log is huge, startup samples the newest tail slice instead of full-reading/chunking the whole file before the UI is ready.
- Kept manual Sync Active Log as the deeper catch-up path with the 1.78/1.79 multi-log sweep and repair behavior.
- Startup status now tells the user when deep catch-up is parked, so Windows should look less like the app crashed while logs are catching up.
- README updated for this release.
- Addon was not changed or bundled.

## 1.79

- Added log-only match discovery for older/closed combat logs. If a log contains a real arena start with combat evidence but no final arena end, the app can now create a clearly marked log-only match shell instead of letting the game disappear.
- Active/live arena logs still stay conservative so an in-progress match is not saved early just because the current file stopped mid-write.
- Startup changed-log sweep and Import Previous Combat Log now allow those log-only shells, so games without video or PvPHelper snapshots can still appear in Matches.
- Focused selected-match log sync can now use an unfinished but valid arena segment to attach combat-log data to an existing match.
- BG detection in the live chunk scanner now checks battleground instance IDs and subzone names, not only the raw zone text.
- Match source pills now show `Log-only` when a match was created from combat logs but still needs scoreboard/video help.
- README updated for this release.
- Addon was not changed or bundled.

## 1.78

- Startup and Sync Active Log now scan more than just the newest log file. After draining the active log, the app sweeps up to 8 older log files that changed since their last scan and reads through the existing offset tracker, so games that happened across rotated logs while the app was closed can get picked up automatically.
- Raised the targeted match-repair caps on Sync Active Log from 6 matches / 1 file each to 20 matches / 2 files each, so a backlog of offline games can attach combat-log data in fewer manual passes.
- Log file registry now records changed-sweep status (`changed-log-sweep-partial` / `changed-log-sweep-scanned`) per file so future syncs can tell what was already re-read.
- Sync status text now mentions how many older changed logs were re-scanned and how many were queued for the next sync.
- Windows launcher text updated for v1.78.
- README updated for this release.
- Addon was not changed or bundled.

## 1.77

- Set the app name and Windows app identity to Last Call Replay so built installs should stop showing generic Electron branding in the title/taskbar identity where Windows honors app metadata.
- Added a Windows executable name for packaged builds: Last Call Replay.
- Changed the fallback video link window default to 0 minutes. Finished recordings now rely on exact overlap from video time and match/log time unless the user intentionally raises the fallback.
- Renamed current replay export wording away from clip language. The replay button now uses a download/VOD label, and the export folder now uses VOD export wording.
- Removed the visible high/medium match confidence pill from replay match details.
- Normalized 2's and 3's style labels to 2v2 and 3v3 in match display paths.
- Hardened active and historical log parsing so arena start-only rows are not finalized just because the current log chunk/file ended. The app waits for ARENA_MATCH_END or a later scoreboard/log merge.
- Fixed the deliberate previous-log chunk scanner so it uses a safe sequential chunk scan again instead of referencing match-window variables.
- README updated for this release.
- Addon was not changed or bundled.

## 1.76

- Restored the replay export tools as their own obvious Download VOD button instead of hiding them inside the Video Sync drawer.
- Added a nicer export panel with VOD start/end, length, trim handles, Include sound, Jump to Section, and Download VOD actions.
- Added a VOD export folder chooser so users can save exports somewhere specific instead of only using the default VOD exports folder.
- Added Open Folder and Show File actions for exported VOD sections.
- Kept Video Sync focused on linking/timing work, while export now has its own cleaner UX.
- README updated for this release.
- Addon was not changed or bundled.

## 1.75

- Added the next efficiency chunk: compact backend mutation payloads.
- Video, VOD, recording, favorite, scoreboard, selected-match video edits, and delete/link actions now send smaller changed-item payloads instead of full libraries where possible.
- Added renderer-side collection delta merging so changed matches, changed recordings, changed VODs, and removed IDs update the local UI without forcing a giant state refresh.
- Kept initial app load as a full state load for compatibility, while everyday buttons now move less data through Electron IPC.
- Continued reducing Invalid string length risk by avoiding full match/video/recording payloads on high-frequency actions.
- README updated for this release.
- Addon was not changed or bundled.

## 1.74

- Added the next efficiency chunk: long-list rendering in smaller chunks instead of loading every large history list at once.
- Match History now renders an initial chunk and adds Load More, while filters still search the full local match library.
- Recording History now renders visible rows only and adds Load More for larger local recording libraries.
- VOD library and VOD candidate preview now load in chunks so long sessions and months of matches stay smoother.
- Log monitor now keeps the latest log quick and loads older indexed logs incrementally.
- Kept the replay rail's existing per-filter caps and cached/hydrated event-feed behavior so timeline tools still work without dragging giant state payloads through the UI.
- README updated for this release.
- Addon was not changed or bundled.

## 1.73

- Added the next efficiency chunk: heavy event feeds can now split into per-match cache files instead of living entirely inside the main `state.json`.
- Match rows now keep a smaller replay preview while selected matches can hydrate the larger cached feed only when needed.
- Added backend support for loading one match's cached event feed on demand.
- Compact App Data now prunes orphaned event-feed cache files while preserving favorites, notes, video links, and user-added data.
- Performance audit now shows event preview rows, event cache file count, and event cache size so we can monitor whether the split storage is working.
- README updated for this release.
- Addon was not changed or bundled.

## 1.72

- Added a lightweight import job queue so heavy actions run one at a time instead of stacking on top of each other.
- Queued the highest-risk actions first: Sync Active Log, Sync Selected Match Logs, Repair Missing Logs, Import Previous Combat Log, Scan Videos, and Compact App Data.
- Added an Import Queue status card under Settings → Performance showing the current job, queued work, and recent jobs from the session.
- Kept log repair and selected-match sync on focused windows. This update is about safer orchestration, not broad full-log parsing.
- Reduced the manual previous-log import response so it sends compact changed-match data instead of handing the renderer the full match library.
- README updated for this release.
- Addon was not changed or bundled.

## 1.71

- Started the efficiency cleanup in small chunks instead of one giant risky rewrite.
- Added a shared match resolver path so combat-log imports, PvPHelper scoreboard merges, and recording scans use the same duplicate cleanup rules. This helps completed matches replace partial/broken starts instead of creating extra rows.
- Added a Performance maintenance action: Compact App Data. It runs the match resolver, trims oversized import history lists, prunes old log-index rows, compacts event-feed storage, and keeps user data like favorites, notes, and video links.
- Kept startup fast: the new maintenance work only runs when the user clicks the button, not automatically on app open.
- README updated for this release.
- Addon was not changed or bundled.

## 1.70

- Split Settings into categories: Logs, PvPHelper, Video & Folders, Storage, and Performance. Same controls, less duplicate/confusing layout.
- Added a Logs category with a log monitor that shows the latest processed/discovered combat log first, plus a Show Rest button for older indexed logs.
- Hardened missing-log repair for very large log libraries by avoiding full historical log parsing from the active sync button. Older missing matches now repair through focused match windows.
- Added focused-window size guards so match repair does not build giant raw strings that can trigger Invalid string length.
- Reduced saved match bloat by keeping one compact event-feed copy instead of duplicating it into both eventFeed and rawEvents.
- Kept README maintenance current for this release.
- Addon was not changed or bundled.

## 1.69

- Fixed Selected Match Sync Logs so it no longer finalizes unfinished arena segments into broken partial matches. It now waits for the matching `ARENA_MATCH_END` segment before importing.
- Made selected-match log sync more truly match-specific by extracting the closest arena segment around the open match instead of sending a broad one-hour window through the live parser.
- Added stronger near-duplicate combat-log merging so a completed match updates/replaces the earlier broken partial row instead of creating a second copy.
- Tightened Repair Missing Logs payloads and saved import history so old oversized entries are stripped before saving/responding.
- Kept the addon untouched and did not bundle addon code.

## 1.68

- Fixed the Selected Match Sync Logs flow so it reads only a focused time window around the open match instead of scanning/returning an entire giant log.
- Fixed Repair Missing Logs so it repairs missing links in small match-specific windows instead of trying to full-parse every likely historical log at once.
- Reduced IPC payload size after log repair/sync by returning only the changed selected/repaired matches instead of the entire match library.
- Pruned stored event-feed raw text before saving state so large logs do not trigger `Invalid string length` from oversized JSON/string payloads.
- Kept log indexing and filename-start-time matching from 1.67.
- Addon was not changed or bundled.

## 1.67

- Updated README maintenance so the desktop package changelog starts at the current release again.
- Changed the replay-page Sync Logs button to target the selected match instead of only syncing the newest active log.
- Added lightweight combat-log indexing using filename start times plus first/last timestamps when available.
- Added a Repair Missing Logs action in Settings to scan likely historical logs and attach combat-log data to addon-only matches.
- Raised the selected-match historical log scan limit to 1 GB so large previous logs do not fail at the older active-sync guardrail.
- Stored basic log registry data so the app can remember which combat logs were indexed/scanned and which files were used for targeted repair.
- Addon was not changed or bundled.

## 1.66

- Added a working custom fullscreen button over the replay video.
- Hid the broken native fullscreen control where Chromium supports it, so the app's own fullscreen button is the one to use.
- Added match favorites in the match detail view and match list.
- Favorited matches are protected from deletion on both the renderer and desktop backend side.
- Addon was not changed or bundled.

## 1.63

- Cleaned replay player controls and removed the broken native/fullscreen buttons from the video surface.
- Added a visible custom playback timeline that updates while the replay plays.
- Allowed mapped recording/VOD sections to include pre-roll before match start so starting-room footage is not clamped away.
- Fixed recorder audio-track detection being reset before the finished recording was saved.

## 1.61

- Simplified the match detail view so the replay video is the first real content on the page.
- Moved the map title, result, match type, duration, player, and data-source pills directly above the video.
- Removed the extra hero summary card and match-notes card from the top of the match detail page.
- Kept the back, favorite, and delete controls in a smaller sticky toolbar.

## 1.60

- Fixed recording/VOD section mapping so addon-only scoreboard matches no longer open at only the final scoreboard second.
- VOD linking now estimates a fuller match window when PvPHelper has a scoreboard snapshot but no exact match duration, then bounds it against the recording/VOD window and nearby matches.
- VOD sections now prefer load-in/game start timing over first-combat timing when available, so starting-room footage is included more often.
- Added a subtle sidebar version strip above the recorder controls showing the app version and PvPHelper version/status.
- Addon was not changed or bundled.

## 1.59

- Cleaned Recording History row actions: removed per-row Remove and Delete File buttons, and removed Open Linked Match because multi-match recordings are better opened from the attached match chips.
- Added Attach window for a recording so every confident in-window match can be attached in one click.
- Added Attach selected for checked recommended matches.
- Added a bulk action for selected recordings: Attach in-window matches.
- Reduced repeated date/file-name noise in Recording History rows.
- Added clearer sound status labels and saved whether the finished recording actually had an audio track.
- Addon was not changed or bundled.

## 1.58

- Tightened recorder-session auto-linking so long recordings attach to every match confidently inside that recording window, while fuzzy edge cases stay manual.
- Kept manual mapping as the backup through Recording History → Recommended Matches → Map.
- Cleaned Recording History rows so the start time and generated filename are not repeated in the same line.
- Fixed a duplicate Stop Recording button in the Recorder controls.
- Addon was not changed or bundled.

## 1.57

- Updated the Windows launcher text so `run-app.bat` shows the current app version instead of the old `v8` label.
- Fixed the Dashboard / Match History mismatch where addon-only PvPHelper scoreboard fallback matches could appear on the Dashboard but stay hidden from Match History.
- Recorder and VOD auto-linking can now attach videos to addon-only fallback matches when the combat log missed the game.
- PvPHelper fallback matches now use captured duration when available, so long recording VOD sections line up closer to the actual game instead of starting at the final scoreboard moment.
- Addon was not changed or bundled.

## 1.56

- Loosened saved-match loading so real matches do not disappear from Match History after restart/logout just because older saved rows are missing newer source flags.
- Recording History now has an `All` filter and shows more recent rows before hiding older videos behind filters.
- Replaced the vague `Use` button with `Recommended Matches`. It opens suggested matches for that VoD and gives each suggestion a clear `Map` button.
- Mapping from Recording History now prepares the recording as a VOD when needed, then attaches it to the chosen match section.

## 1.55

- Simplified the Match History header. It now shows one `Refresh` button instead of separate log, PvPHelper, and video buttons.
- `Refresh` checks the active log, PvPHelper scoreboards, and mapped recordings when those paths are available.
- Kept the detailed mapping and scan controls in Settings and the relevant setup areas so Match History stays cleaner.

## 1.54

- Added one-click local setup: auto-locates the common WoW Retail Logs folder, connects the active combat log when found, sets a safe default recordings folder when missing, and auto-maps the likely PvPHelper.lua when possible.
- Moved setup warnings into the sidebar: Matches shows a logs badge, Recorder shows the first missing recorder step, and Characters flags PvPHelper.lua mapping.
- Simplified the top utility buttons so PvPHelper addon install/mapping stay up top while logs and recorder setup live where users expect them.
- Added a visual PvPHelper path guide: choose account → SavedVariables → PvPHelper.lua.

## 1.53

Changed:
- Added a quiet startup catch-up for the active WoW combat log, so matches written while the app was closed can be pulled in before live watching starts.
- Active log sync now reads multiple pending tail chunks in one pass when there is backlog instead of only one chunk.
- Fixed the active-log imported count so the sync status reflects newly finalized matches correctly.
- Reduced meter flicker by updating the meter panel in place instead of rebuilding the full match replay view when switching Damage, Healing, CC, Purges, etc.
- Addon was not changed or bundled.

## 1.52

Changed:
- Added an Include sound checkbox to match VOD export, so users can save exported VOD sections with or without audio.
- No-sound exports now get a `_no-sound` filename suffix so they do not silently replace the normal export.
- Recording History now defaults to newest-first ordering and adds an Order dropdown for Newest first / Oldest first.
- Recording History now shows Suggested matches for recordings when nearby or overlapping matches are not attached yet.
- Suggested match chips can open the match, and recorder-session suggestions can be applied directly when a session VOD bridge exists.
- New recordings store whether sound was requested, and the history row shows sound on / no sound / sound unknown.
- Addon was not changed or bundled.

## 1.50

Changed:
- Removed the advanced auto-stop recording option that tried to stop recordings from combat-log match-end detection.
- Recorder now keeps the safer manual stop flow and supports long-session recordings that can be mapped across multiple matches.
- Updated recorder/settings copy so users understand one long VOD can cover many matches.
- User-facing app version now displays as `1.50` instead of a three-part version label.
- Addon was not changed or bundled.

## 1.49

Changed:
- Desktop now reads the new top-level `PvPHelperDB.appStatus` bridge from PvPHelper 0.12.8+.
- App status is now preferred for Advanced Combat Logging, active Blizzard combat logging state, enabled logging targets, manual mode, recording reminder, scoreboard capture, and current PvP context.
- Older SavedVariables locations still work as fallbacks if appStatus is not available yet.
- Added Settings status cards for the appStatus bridge and live combat log state.
- Addon was not changed or bundled.

## 1.48

Changed:
- PvPHelper mapping now lets users choose a folder instead of requiring the exact PvPHelper.lua file.
- The app can resolve PvPHelper.lua from SavedVariables, account, WTF\Account, _retail_, or WoW root folders.
- Mapping buttons now say Map PvPHelper Folder / Change Folder so the flow matches what users are actually doing.
- Preview now shows the actual PvPHelper.lua file found inside the selected folder before syncing.
- Addon was not changed or bundled.

## 1.47
- Fixed PvPHelper SavedVariables sync crashing when a matchHistory entry is partial or missing scoreboard player data.
- PvPHelper sync now skips malformed/empty snapshots and still maps the file so status pills can report setup issues.
- Hardened Solo Shuffle session grouping against saved matches with missing player sets.
- Addon was not changed or bundled.

## 1.46

- Fixed Solo Shuffle combat-log imports where one shuffle writes multiple `ARENA_MATCH_START` rows but only one final `ARENA_MATCH_END`.
- Solo Shuffle now imports each round instead of only the last round.
- Fixed Solo Shuffle session annotation so groups of rounds do not crash when the first round has no previous round to compare against.
- Verified against `WoWCombatLog-051126_214956.txt`: 6 Solo Shuffle rounds were detected from 6 start markers and 1 final end marker.

## 1.45

Changed:
- Fixed the Last 10s Before Death health timeline so it can still draw a visible strip when the log only has sparse samples around the death window.
- Improved death-window matching by using short player-name matching, so names with/without realms line up better.
- Low-health red markers now cluster nearby events instead of stacking a pile of tiny circles.
- Clustered health markers pick the most useful event in that group, preferring deaths, lowest health, damage events, crits, and larger hits.
- Health marker hover text now shows nearby event details so dense moments are easier to inspect.
- Addon was not changed or bundled.

## 1.44

Changed:
- Added portable app storage for external-drive use across computers.
- Settings now has Use Portable Folder, which moves app data into LastCallReplayData beside the app and writes a portable pointer beside the app.
- Settings now has Connect Existing Storage for using an already-created external storage folder on another computer without overwriting it.
- The app now prefers the portable pointer beside the app before the Windows app-data pointer, so running from the same external drive can reuse the same library/settings.
- Change Storage Folder still migrates current data, and now tries to write a portable pointer when possible.
- Addon was not changed or bundled.

## 1.43

Changed:
- Added editable App Storage for Local Files so the local library, settings file, reports, archives, and default recording folder can live on an external drive.
- Added a Change Storage Folder button in Settings under App storage / Local Files.
- Moving app storage copies the current data to the selected folder and writes a tiny pointer file in the normal Windows app-data folder so the app can find it next launch.
- Archive/default recording folders move to the new storage folder when they were still using the old local defaults.
- Addon was not changed or bundled.

## 1.42

Changed:
- Kept the health-over-time timeline synced to the replay video clock during playback, pause, and seeking.
- Added a lightweight video-time sync loop so the health cursor moves with the video instead of waiting on slower browser timeupdate events.
- Seeking from the video controls, health timeline clicks, trim handles, or death-window jumps now refreshes the health cursor and rail immediately.
- Addon was not changed or bundled.

## 1.41

Changed:
- Made PvPHelper.lua SavedVariables mapping easier to find and map.
- The file picker now opens closer to the likely WTF\Account SavedVariables location when logs are connected.
- Added Auto-find PvPHelper.lua, Rescan folders, Browse manually, and Show file/Open WTF Account helper actions.
- The app now scans likely WoW account SavedVariables folders and suggests the newest valid PvPHelper.lua.
- Clicking the top PvPHelper not mapped pill now tries Auto-find first, then falls back to manual mapping if needed.
- Addon was not changed or bundled.

## 1.40

Changed:
- Improved video handling for Solo Shuffle sessions.
- Solo Shuffle rounds are now grouped into one detected shuffle session when the app sees up to 6 nearby rounds with the same player set.
- Long recorder sessions and VOD alignment now use the full Solo Shuffle session window instead of trimming to only the selected round.
- The trim/export panel now notes when a selected Solo Shuffle row is one round inside a multi-round shuffle.
- Round start stays available for log sync while the export window can cover the full shuffle.
- Addon was not changed or bundled.

## 1.39

Changed:
- Renamed **Download VOD** to **Download VOD** on the match replay tools.
- Renamed **Save Section** to **Export selected part of match** and made it save the selected trim before exporting.
- Moving the match trim start/end sliders now seeks the video to that timestamp so the selected section is visible immediately.
- VOD start/end number fields now say they are seconds and show the matching video time beside them.
- Trim enforcement now respects the live slider selection while editing instead of snapping back to the old saved VOD window.
- Addon was not changed or bundled.

## 1.38

Changed:
- PvPHelper.lua mapping is no longer blocked just because scoreboards, ratings, or readiness settings have not been written yet.
- The preview modal now lets the user map the file anyway, then the top PvPHelper status reports any missing addon settings afterward.
- Removed the heavy data-readiness checklist from the mapping preview so setup warnings do not look like requirements before mapping.
- Clicking the top **PvPHelper not mapped** pill now opens the mapping picker directly instead of sending the user to Settings first.
- Addon was not changed or bundled.

## 1.37

Changed:
- Top bar PvPHelper addon pill now installs or updates directly when the WoW path and local addon package are available.
- Clicking the addon pill no longer dumps the user into Settings when the app can already do the install.
- If the WoW path is missing, the addon pill opens the log-folder picker.
- If the local PvPHelper package is missing, the addon pill opens the package folder so the user can drop the unzipped addon there.
- The app now prefers the project/distro addon-packages folder as the visible drop spot when running from source.
- Addon was not changed or bundled.

## 1.36

Changed:
- Added PvPHelper data-readiness checks for the settings the app depends on.
- Top bar PvPHelper status now warns as **PvPHelper needs setup** when required addon data settings are off.
- App now reads Save scoreboard snapshots from PvPHelper SavedVariables and warns when it is disabled.
- App now reads Advanced Combat Logging when the addon exposes it through profile/logging metadata or recent scoreboard snapshots.
- If Advanced Combat Logging cannot be verified, the app now says unknown instead of pretending it is ready.
- Addon was not changed or bundled.

## 1.35

Changed:
- Player meeting history now dedupes likely duplicate games before counting Seen, records, and View all meetings totals.
- Character history uses the same safer match dedupe key so duplicate imports do not inflate recorded game totals.
- View all meetings rows now show explicit start time and duration, making accidental duplicate games easier to spot.
- Backend match cleanup now also catches same-start/same-map duplicate imports when combat log and PvPHelper copies disagree on participant details.
- Addon was not changed or bundled.

## 1.34

Changed:
- Removed the separate favorite star marker from match list rows.
- Favorited matches now use a gold outline around the Video / No video chip instead.
- Dashboard recent match video chips use the same gold favorite outline.
- Characters tab now makes Blizzard Season clearer when PvPHelper has rating-only data but no season played/win/loss totals.
- Addon was not changed or bundled.

## 1.33

Changed:
- Removed the large-team roster hover section from Players cards.
- Player meeting rows now show a **Scoreboard** action when that match has a linked final scoreboard.
- Scoreboards now group players by side with clear **Your team** / **Enemy team** dividers.
- Scoreboard player names now use class colors from PvPHelper/combat-log metadata when available.
- Scoreboard rows now use short player names while keeping full names in the hover title.
- Cleaned up a duplicate match-list render fallback.
- Addon was not changed or bundled.

## 1.32

Changed:
- Final scoreboard card now says **Final Scoreboard near the Meter** so its placement is clearer.
- Removed the extra Forensics Death Recap card from the match report. Death recap stays in Meter Tools where the health-strip version belongs.
- CC and Interrupt cards now show event time and use short player names without server names.
- Trim / Export sliders are locked to the mapped game window instead of expanding to the entire VOD after video metadata loads.
- VOD start/end number boxes now obey the same game-window bounds as the sliders.
- Addon was not changed or bundled.

## 1.31

Changed:
- Export / trim tools on the match replay page are now collapsed by default so the replay area stays cleaner.
- The collapsed export row is still visible and easy to open when a VOD section needs trimming or exporting.
- Added video trim sliders for VOD start and VOD end so sections can be grabbed visually instead of only typed into number boxes.
- Slider changes stay synced with the numeric fields and the export start/end/length readout.
- Addon was not changed or bundled.

## 1.30

Changed:
- Added more space between the VOD setup cards and the combat-log preview section below.
- Meter tools now use the full width of the section so the buttons stay on one row on normal desktop widths.
- Moved the pet/totem/object damage-healing filter into the Meter tools section.
- Renamed that filter to: Hide dmg and healing done to pets, totems, guardians, and objects.
- Addon was not changed or bundled.

## 1.29

Changed:
- Split the VOD page into three cleaner cards: Drop VOD files, Imported VODs, and Alignment.
- The three VOD setup cards now resize together instead of making the drop zone and library feel glued into one section.
- Kept the combat-log section preview below the setup cards.
- Fixed recorder setup text wrapping in the sidebar and dashboard so long messages like "Choose World of Warcraft or a screen to record" stay inside the box.
- Addon was not changed or bundled.

## 1.28
- Moved Purges back into the normal Meter tools row between Interrupts and Dispels.
- Fixed purge parsing for successful offensive buff removals such as Tranquilizing Shot.
- The parser now uses the removed aura type from combat logs, so removed BUFF events count as Purges and removed DEBUFF events stay as friendly Dispels/CC Dispels.
- Addon files are still not bundled or changed.

## 1.27

Changed:
- Dashboard Quick Recording now uses one setup action instead of showing both Choose Source and Pick Source to Enable Recording.
- If Quick Recording is ready, it shows Change Source and Start Recording. If setup is missing, it shows the one thing to fix.
- Choosing a source from the dashboard picker now closes the quick picker after selection.
- Players tab now replaces the usually-empty With box with a Rating box from scoreboard data when available.
- BG and other large-team player cards no longer advertise a hidden comp summary. They now show a Large-team roster note with hoverable team preview.
- Player cards merge name/server variants better so duplicate player echoes should be reduced.
- Addon was not changed or bundled.

## 1.26

Changed:
- Battleground labels now display as **RBG's** for rated battlegrounds and **Random BG's** for random battlegrounds across the app UI.
- Dashboard top row now places recording on the left and Most Seen Enemy on the right.
- Most Seen Enemy now merges name/server variants so the same player does not show as duplicate entries.
- Addon was not changed or bundled.

## 1.25

Changed:
- Split offensive Purges from friendly Dispels in the meter tools.
- Purges now track buffs removed from opposing targets, while Dispels and CC Dispels track friendly cleanses.
- Removed the redundant View Final Scoreboard button from the inline scoreboard card.
- Added health-bar style last-hit strips to the Deaths meter detail panel.
- Addon was not changed or bundled.

# Last Call Replay Desktop

Local-first World of Warcraft PvP log and recording hub.

## 1.24

- Dashboard no longer repeats combat-log or PvPHelper install/mapping cards because those statuses now live in the top bar.
- Top bar log/addon status pills are clickable and route to Settings for setup or fixes.
- Dashboard keeps the centered **Start Recording** command card.
- Most Seen Enemy now shows useful context: class/spec when known, seen count, record against them, most common mode, most common map, and last seen match.
- Fixed a stray duplicate dashboard history card wrapper from the previous dashboard cleanup.

## 1.23

- Fixed another path where raw combat-log map IDs could still survive into match rows.
- Existing saved matches with numeric-only maps now clean to readable map names on load, not just during fresh import.
- Battleground subzones such as Warsong Lumber Mill now collapse back to the parent map, such as Warsong Gulch.
- PvPHelper scoreboard snapshots now clean map IDs/subzones before creating or merging match rows.
- Addon files are still not bundled or changed.

## 1.22

- Arena match rows now translate combat-log instance IDs into readable map names.
- Fixed rows showing raw arena IDs such as `2547` where the map name should appear.
- Existing imported matches with numeric-only map names are normalized on load when the ID is known.
- No addon files are bundled or changed.

## 1.21

- Removed the bundled PvPHelper addon files from the desktop app zip so the app does not ship a stale addon copy.
- The app now treats `addon-packages\PvPHelper` as a local package slot. Drop the newest unzipped PvPHelper folder there when you want the app to install or update it.
- The installer compares the local package version from `PvPHelper.toc` against the user's installed WoW addon version.
- If WoW is missing PvPHelper and a local package exists, the button shows **Install Addon**.
- If WoW has an older PvPHelper than the local app package, the button shows **Update Addon**.
- If WoW already has a newer addon than the local package, the app does not try to downgrade it.
- Added package-folder status/opening so the user can find where to drop the addon folder.

## 1.20

- Added bundled PvPHelper addon install support from `addon-packages/PvPHelper`.
- The app can now detect the user's WoW `_retail_` folder from the connected combat log path.
- Dashboard and Settings show whether PvPHelper is installed in `Interface\AddOns`.
- If PvPHelper is missing, the dashboard can show **Install Addon** and copy the bundled addon folder into WoW automatically.
- If the installed addon is older than the bundled copy, the app can show **Update Addon**.
- PvPHelper SavedVariables mapping remains separate, so install status and data mapping are both visible.
- Addon source files were bundled unchanged.

## 1.19

- Restored one dashboard source control: **Choose Source / Change Source**.
- Removed the confusing double-source dashboard controls without leaving the dashboard recorder stranded.
- Dashboard **Start Recording** now uses the same real readiness checks as Recorder and the top status pill.
- Recorder setup status is more helpful: missing source, missing folder, approval needed, and missing saved source each get clearer wording.
- The top **Recorder needs setup** pill is now clickable and opens the right setup flow.
- If the source is missing, the dashboard hint opens the source picker directly so the user can fix it in place.

## 1.18

- Characters rating timeline now ignores random BGs, skirmishes, and unrated battleground records.
- Rating timeline only charts rated PvP snapshots: 2v2, 3v3, Solo Shuffle, Blitz, and Rated Battleground.
- Character current rating card now shows the highest current rating across rated brackets, plus the bracket/spec it came from.
- Blizzard Season card now follows that same selected best current rated snapshot so it does not show a random/unrated bracket by mistake.

## 1.17

- Cleaned up the dashboard top area so it no longer shows Matches, average game length, fastest win, or win-rate blocks there.
- Dashboard recording now keeps the main action centered and says **Start Recording**.
- Removed the dashboard source dropdown and Sources button. Source setup stays in the Recorder flow.
- Added top status pills for addon installed/not confirmed and PvPHelper mapped/not mapped.
- Added dashboard bridge status for PvPHelper version/mapping plus scoreboard linked/pending counts.
- Kept Most Seen Enemy on the dashboard.
- Moved the dashboard character selector down into Recent matches, where the filtered match list actually lives.

## 1.16

- Long recorder sessions now auto-map to every combat-log match inside the recording window.
- Recorder sessions are also indexed in the VOD library so one recording can behave like one long VOD with many match sections.
- Match replay now includes editable section timing: VOD start, VOD end, match start, and sync adjustment.
- Manual section edits are preserved so automatic re-linking does not stomp user fixes.
- Recording history now shows multi-match links and can unlink the whole long session cleanly.

## 0.98

- Added a Class filter on the Matches page.
- Match list player names are slightly larger again, using the unused space inside the team boxes.

## 0.97

- Match list team/player names are larger and easier to read.
- Reused extra vertical spacing inside team blocks instead of widening rows or changing match data.

## 0.96

- Removed the VOD export file-type selector for now. Export uses the original file type until real remux/transcode support is added.
- Kept the nicer VOD export box, start/end/length details, and FFmpeg export flow.

## 0.95

- VOD export now has a nicer export box inside match replay.
- Settings Import Center now shows only the combat log filename for the most recent combat-log import, with the full path kept on hover.
- Added a CSS/layout sweep to reduce overflow, cramped controls, and sections scrolling over each other.

## 0.94

- VOD page now has a drag/drop/paste import area directly above the VOD Library.
- Users can choose multiple video files, drag files in, or paste copied video files from Explorer.
- VOD Library now shows recent VODs by default with a More / Show Less toggle for the full library.
- Empty VOD state now explains drag, drop, paste, or choose local video files.

## 0.93

- Meter tab now separates regular meter tools from the new Purge section.
- Dispels and CC Dispels now live in their own review lane with clearer helper text and spacing.
- This keeps purge-style plays easier to find without changing the underlying match data.

## 0.92

- VOD export now looks for bundled `ffmpeg-static` first, then falls back to installed FFmpeg / `FFMPEG_PATH`.
- VOD section linking now starts arena VOD sections from the arena load-in / starting room when the combat log exposes that timestamp, instead of only at `ARENA_MATCH_START`.
- VOD preview copy now explains that VOD sections use load-in/start timestamps when available.

## 0.91

- VOD library delete: remove old VODs from the app without deleting the original video file. Linked match sections are safely unlinked.


- VOD preview candidates now have an Apply button for linking one match section at a time.
- Link All Candidates still supports many matches from the same long VOD.
- VOD-linked match playback is locked to that match section and stops at the section end.

## 0.89

- Added a performance pass for replay playback.
- Throttled live log rail updates during video playback.
- Cached log rail feeds so filters/rendering do less repeat work.
- Reduced oversized BG rail DOM lists so large battleground logs feel less sluggish.
- Switched live-follow scrolling to instant scroll instead of smooth animation during playback.

## 0.79

- Added Delete Folder for user-created Favorites folders.
- Folder deletion is only allowed when the folder is empty.
- Built-in Favorites views like All favorites and Unsorted cannot be deleted.

## 0.72

- Added a PvPHelper addon version check to the mapped SavedVariables section.
- The app reads the addon version from `PvPHelper.lua` / `PvPHelperDB` and shows `Addon version OK` or `Addon update recommended`.
- The compatibility floor is currently PvPHelper `0.11.7+`, which matches the sample SavedVariables bridge data.

## 0.71

- Cleaned up the Settings Import Center so it shows the most recent combat-log import and most recent PvPHelper sync instead of listing historical logs.
- Added PvPHelper addon status checks in the app: addon not mapped, mapped file missing, logging modes enabled, scoreboard snapshot capture enabled, and rating/character data found.
- PvPHelper sync now stores addon option status from `PvPHelperDB.profile.combatLog` so users can see when addon logging or scoreboard capture needs to be enabled.
- Added counts for scoreboards found, linked, pending, and rating snapshots.
- Full historical logs are planned for a future dedicated Logs section instead of cluttering Options.

## 0.69

- Scoreboard data is now treated as a match attachment, not a separate main import lane.
- Added View Final Scoreboard inside match detail when a PvPHelper scoreboard is linked.
- Added Link Scoreboard inside match detail for attaching an imported PvPHelper scoreboard snapshot to the right replay match.
- Rating snapshots from PvPHelper.lua continue feeding the Characters tab and rating timeline.

## 0.68

- Simplified imports to two main sources: Combat Logs and one mapped PvPHelper.lua SavedVariables file.
- PvPHelper.lua can sync scoreboard snapshots for matches and character/rating snapshot data for Characters when the addon saves those fields.
- Added persistent PvPHelper.lua mapping, Sync Now, Clear Mapping, and auto-sync-after-startup when the file changes.
- Legacy one-off rating exports are still available, but tucked behind a smaller advanced/legacy control.


## Run from source

```bat
cd /d "D:\More Apps\last-call-replay-desktop"
npm install
npm run electron
```

## Build the normal Windows app

```bat
cd /d "D:\More Apps\last-call-replay-desktop"
npm install
npm run dist:win
```

Then open:

```txt
D:\More Apps\last-call-replay-desktop\dist
```

Use the generated installer or portable `.exe`. That opens like a normal Windows application without a Command Prompt window.

## Recording storage

Before recording, choose a storage folder in the Recorder or Settings section. The app will not start recording until that folder has been selected.

## Local-first behavior

The app stores logs, reports, and recordings locally. It does not use cloud upload or hidden background recording.




## 0.65

- Fixed the PvPHelper.lua import trap on the Characters tab. If a user accidentally picks PvPHelper.lua from Import Rating Snapshot, the app now routes it into the SavedVariables importer instead of returning 0 imported.
- Added an Import PvPHelper.lua button directly on the Characters tab.
- Improved import messages so duplicate/no-new SavedVariables imports explain parsed, merged, created, and skipped counts.
- Added defensive import error handling so a failed import does not leave the character dropdown/page in a weird state.

## 0.63

- Fixed PvPHelper SavedVariables import for zipped samples like `PvPHelper (3).zip`.
- The importer now accepts `.zip` files and extracts `PvPHelper.lua` from inside the archive.
- Verified against the uploaded sample: 5 `PvPHelperDB.matchHistory` snapshots with 20 scoreboard players each were detected.
- Added clearer failure messaging when a zip does not contain readable `PvPHelperDB` data.

## 0.62

- Added stronger Rated Battleground support metadata for combat-log matches and PvPHelper scoreboard imports.
- RBG/BG matches now track battleground flags, expected team size, actual team size, and scoreboard team counts when available.
- Match cards can show RBG/BG team-size badges.
- Settings now separates Combat Log import history from PvPHelper SavedVariables import history.
- PvPHelper.lua imports no longer get mixed into the combat-log history list.

## 0.61

- Added Recording Performance settings: Low impact, Balanced, and High quality.
- Balanced is now the default and reduces capture pressure compared with the previous 60 FPS-first behavior.
- Low impact caps recording lower for smoother gameplay on stressed PCs.
- Recording now uses performance-mode bitrate caps and longer chunk intervals where appropriate.
- The Recorder page shows the active performance mode and a quick stress note.

## 0.60

- Locked the replay Log Data rail height to the left replay column on desktop layouts.
- The combat-log panel beside the health timeline now keeps its bottom edge lined up with the health timeline area.
- Removed the forced rail minimum height that could make the log panel hang lower than the timeline.

## 0.59

- Added PvPHelper SavedVariables import for `PvPHelperDB.matchHistory`.
- Imported addon scoreboard snapshots can merge into existing combat-log matches.
- Addon-only match shells are created when no confident log match exists.
- Match cards now show data-source badges such as Log, Scoreboard, and Video.
- Favorites and linked videos are preserved during import/rebuild flows.
