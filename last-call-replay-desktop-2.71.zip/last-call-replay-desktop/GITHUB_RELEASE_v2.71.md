# Last Call Replay Desktop 2.71

## Changed
- Improved the bottom-right Working/progress indicator so it clears after completed, failed, canceled, or dismissed jobs.
- Added explicit Cancel, Dismiss, and Keep waiting controls to the progress UI.
- Added stale-job detection when a long-running task stops reporting progress.
- Added safe import-job cancel requests. Chunked jobs stop at safe progress checkpoints.
- Improved task labels for log processing, match syncing, video indexing, and app-data repair.
- Prevented duplicate maintenance and video-indexing jobs from stacking while one is already running.
- No addon code changed.

## Assets to upload
- `Last-Call-Replay-Desktop-2.71.exe`
- `last-call-replay-desktop-2.71.zip`
- Update `/latest.json` on the `main` branch.

## latest.json URL
```txt
https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json
```

## Release tag
```txt
v2.71
```
