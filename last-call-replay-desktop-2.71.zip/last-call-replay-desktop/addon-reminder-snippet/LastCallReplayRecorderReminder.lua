-- Last Call Replay recorder reminder snippet
-- Purpose: show a short in-game reminder around the 15-second mark so the player can manually start desktop recording.
-- This snippet does not talk to the desktop app, write external files, read memory, or automate gameplay.

LastCallReplayReminderDB = LastCallReplayReminderDB or {
  neverShowRecorderReminder = false,
  reminderDelaySeconds = 15,
  reminderVisibleSeconds = 5
}

local frame = CreateFrame("Frame", "LastCallReplayRecorderReminderFrame", UIParent)
frame:SetSize(420, 82)
frame:SetPoint("TOP", UIParent, "TOP", 0, -140)
frame:SetFrameStrata("DIALOG")
frame:SetFrameLevel(900)
frame:Hide()

frame.bg = frame:CreateTexture(nil, "BACKGROUND")
frame.bg:SetAllPoints(true)
frame.bg:SetColorTexture(0.03, 0.02, 0.06, 0.92)

frame.border = CreateFrame("Frame", nil, frame, "BackdropTemplate")
frame.border:SetAllPoints(true)
frame.border:SetBackdrop({ edgeFile = "Interface\\Buttons\\WHITE8x8", edgeSize = 1 })
frame.border:SetBackdropBorderColor(0.65, 0.45, 1.0, 0.75)

frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
frame.title:SetPoint("TOPLEFT", frame, "TOPLEFT", 16, -14)
frame.title:SetText("Last Call Replay")

frame.body = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
frame.body:SetPoint("TOPLEFT", frame.title, "BOTTOMLEFT", 0, -8)
frame.body:SetText("Start recording in the desktop app if you want video for this match.")

frame.close = CreateFrame("Button", nil, frame, "UIPanelCloseButton")
frame.close:SetPoint("TOPRIGHT", frame, "TOPRIGHT", 4, 4)
frame.close:SetScript("OnClick", function() frame:Hide() end)

frame.never = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
frame.never:SetSize(120, 24)
frame.never:SetPoint("RIGHT", frame, "RIGHT", -12, -18)
frame.never:SetText("Never show")
frame.never:SetScript("OnClick", function()
  LastCallReplayReminderDB.neverShowRecorderReminder = true
  frame:Hide()
end)

local pendingTimer = nil
local hideTimer = nil
local shownThisMatch = false

local function CancelTimer(timer)
  if timer and timer.Cancel then timer:Cancel() end
end

local function HideReminder()
  CancelTimer(hideTimer)
  hideTimer = nil
  if frame:IsShown() then frame:Hide() end
end

local function ResetReminderState()
  CancelTimer(pendingTimer)
  pendingTimer = nil
  HideReminder()
  shownThisMatch = false
end

local function ShowReminder()
  pendingTimer = nil
  if LastCallReplayReminderDB.neverShowRecorderReminder or shownThisMatch then return end
  shownThisMatch = true
  frame:Show()
  CancelTimer(hideTimer)
  hideTimer = C_Timer.NewTimer(LastCallReplayReminderDB.reminderVisibleSeconds or 5, HideReminder)
end

function LastCallReplay_ScheduleRecorderReminder()
  if LastCallReplayReminderDB.neverShowRecorderReminder or shownThisMatch or pendingTimer then return end
  pendingTimer = C_Timer.NewTimer(LastCallReplayReminderDB.reminderDelaySeconds or 15, ShowReminder)
end

function LastCallReplay_ResetRecorderReminder()
  ResetReminderState()
end

-- Wire LastCallReplay_ScheduleRecorderReminder() into your existing PvP-start detection.
-- Wire LastCallReplay_ResetRecorderReminder() into match-end / zone-left detection.

local eventFrame = CreateFrame("Frame")
eventFrame:RegisterEvent("PVP_MATCH_ACTIVE")
eventFrame:RegisterEvent("PVP_MATCH_COMPLETE")
eventFrame:RegisterEvent("PLAYER_ENTERING_WORLD")
eventFrame:RegisterEvent("PLAYER_DEAD")
eventFrame:SetScript("OnEvent", function(_, event)
  if event == "PVP_MATCH_ACTIVE" then
    LastCallReplay_ScheduleRecorderReminder()
  elseif event == "PVP_MATCH_COMPLETE" or event == "PLAYER_ENTERING_WORLD" then
    ResetReminderState()
  end
end)
