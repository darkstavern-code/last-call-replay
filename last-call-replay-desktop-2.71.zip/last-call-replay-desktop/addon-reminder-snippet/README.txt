This is optional addon-side helper code.

Use it only as a snippet if you want the in-game 15-second reminder:
- Shows a recorder reminder after 15 seconds
- Auto-hides after 5 seconds
- Has a Never Show button
- Does not communicate with the desktop app
- Does not automate gameplay
- Does not read memory or write external files

Best use:
Call ScheduleRecorderReminder() from your existing PvP-start logic.
