-- Optional Toast Tamer hide patch notes/snippet
-- Drop the ideas below into your existing Toast Tamer module rather than loading this as a standalone addon.
-- Goal: if the user chooses "hide", do not only move the toast anchor. Also suppress visible toast frames.

local LCR_TOAST_HIDE_ENABLED = true

local function SafeHideToastFrame(frame)
  if not frame or not LCR_TOAST_HIDE_ENABLED then return end
  -- Some toast frames get reshown by Blizzard code. Hide + alpha + scale keeps them from flashing.
  pcall(function() frame:Hide() end)
  pcall(function() frame:SetAlpha(0) end)
  pcall(function() frame:EnableMouse(false) end)
end

local function HookToast(frameName)
  local frame = _G[frameName]
  if not frame then return end
  SafeHideToastFrame(frame)
  if not frame.LastCallReplayToastHooked then
    frame.LastCallReplayToastHooked = true
    frame:HookScript("OnShow", function(self)
      C_Timer.After(0, function() SafeHideToastFrame(self) end)
    end)
  end
end

local function ApplyToastHide()
  -- Common Retail alert/toast parents. Your addon may have a more exact frame already.
  HookToast("AlertFrame")
  HookToast("BonusRollFrame")
  HookToast("QuickJoinToastButton")
  HookToast("TalkingHeadFrame")
  HookToast("GarrisonLandingPageMinimapButton")
  -- If your Toast Tamer already identifies a specific toast frame, call SafeHideToastFrame(thatFrame) too.
end

local f = CreateFrame("Frame")
f:RegisterEvent("PLAYER_LOGIN")
f:SetScript("OnEvent", function()
  ApplyToastHide()
end)

-- Also call ApplyToastHide() any time the user changes the Toast Tamer setting to Hide.
