@echo off
setlocal
cd /d "%~dp0"
echo.
echo === Last Call Replay v2.64 ===
echo.
if not exist node_modules (
  echo Installing dependencies...
  npm install
  if errorlevel 1 goto failed
)
npm run electron
if errorlevel 1 goto failed
goto end
:failed
echo.
echo Something failed. Copy the error above and send it.
pause
:end
endlocal
