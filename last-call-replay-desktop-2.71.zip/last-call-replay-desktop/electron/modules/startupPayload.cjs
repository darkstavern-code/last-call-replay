'use strict';

function createStartupPayloadTools(deps = {}) {
  const app = deps.app || {};
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const defaultSettings = typeof deps.defaultSettings === 'function' ? deps.defaultSettings : (() => ({}));
  const exists = (filePath) => {
    try { return Boolean(filePath && fs.existsSync(filePath)); } catch (_error) { return false; }
  };
  const safeCall = (fn, fallback, ...args) => {
    try { return typeof fn === 'function' ? fn(...args) : fallback; } catch (_error) { return fallback; }
  };
  const safeObject = (value) => (value && typeof value === 'object' && !Array.isArray(value) ? value : {});

  function stateFileStats() {
    const statePath = safeCall(deps.statePath, '');
    try {
      const stat = fs.statSync(statePath);
      return { bytes: stat.size || 0, updatedAt: stat.mtime ? stat.mtime.toISOString() : '' };
    } catch (_error) {
      return { bytes: 0, updatedAt: '' };
    }
  }

  function estimateStoredEventFeedRows(matches = []) {
    let rows = 0;
    let biggest = 0;
    let previewRows = 0;
    const counter = typeof deps.storedEventFeedCount === 'function' ? deps.storedEventFeedCount : null;
    for (const match of Array.isArray(matches) ? matches : []) {
      const preview = Array.isArray(match && match.eventFeed) ? match.eventFeed.length : 0;
      const count = counter ? counter(match) : preview;
      previewRows += preview;
      rows += count;
      if (count > biggest) biggest = count;
    }
    return { rows, biggest, previewRows };
  }

  function countObjectKeys(value) {
    return value && typeof value === 'object' ? Object.keys(value).length : 0;
  }

  function quickLogSuggestion(state, options = {}) {
    const settings = state && state.settings ? state.settings : {};
    const startupLight = Boolean(options && options.startupLight);
    const savedFile = settings.logFilePath && exists(settings.logFilePath) ? settings.logFilePath : '';
    const savedFolder = settings.logFolderPath && exists(settings.logFolderPath)
      ? settings.logFolderPath
      : (savedFile ? path.dirname(savedFile) : '');

    let detected = [];
    if (savedFile) {
      detected = [savedFile];
    } else if (!startupLight) {
      detected = safeCall(deps.getLogCandidates, [], settings) || [];
    } else if (savedFolder) {
      detected = safeCall(deps.getLogCandidatesFromFolders, [], [savedFolder]) || [];
    } else {
      // Startup should not deep-probe every possible WoW drive before the first paint.
      // The deferred diagnostics pass fills this in after the UI is responsive.
      detected = [];
    }

    const first = detected[0] || savedFile || '';
    const detectedFolders = startupLight
      ? (savedFolder ? [savedFolder] : [])
      : (safeCall(deps.getCandidateLogFolders, [], settings) || []);

    return {
      preferredFolder: savedFolder || (first ? path.dirname(first) : ''),
      preferredFile: savedFile || first,
      preferredExists: Boolean(savedFile || first),
      firstDetectedFile: first,
      firstDetectedFolder: first ? path.dirname(first) : savedFolder,
      detectedFiles: detected.length ? detected : (savedFile ? [savedFile] : []),
      detectedFolders
    };
  }

  function buildPerformanceAudit(state, options = {}) {
    const startupLight = Boolean(options && options.startupLight);
    const settings = state && state.settings ? state.settings : {};
    const activeFile = settings.logFilePath || '';
    const activeFolder = settings.logFolderPath || (activeFile ? path.dirname(activeFile) : '');
    const fileStats = stateFileStats();
    const eventRows = estimateStoredEventFeedRows(state.matches || []);
    const eventCache = safeCall(deps.eventFeedCacheStats, { files: 0, bytes: 0 }) || { files: 0, bytes: 0 };
    let activeFileSize = 0;
    let activeOffset = 0;
    let pendingBytes = 0;
    let activeFileName = '';
    try {
      if (activeFile && exists(activeFile)) {
        const stat = fs.statSync(activeFile);
        activeFileSize = stat.size || 0;
        const watched = state.watchedFiles && state.watchedFiles[activeFile] ? state.watchedFiles[activeFile] : null;
        activeOffset = watched ? Number(watched.offset || 0) : 0;
        pendingBytes = Math.max(0, activeFileSize - activeOffset);
        activeFileName = path.basename(activeFile);
      }
    } catch (_error) {}

    let folderLogCount = 0;
    let folderStatLimited = false;
    if (!startupLight) {
      try {
        if (activeFolder && exists(activeFolder)) {
          const names = fs.readdirSync(activeFolder).filter((name) => safeCall(deps.isCombatLogFileName, false, name));
          folderLogCount = names.length;
          folderStatLimited = names.length > Number(deps.largeLogFolderCount || 800);
        }
      } catch (_error) {}
    }

    const riskFlags = [];
    if (folderLogCount > Number(deps.largeLogFolderCount || 800)) riskFlags.push('Large log folder detected. Active sync avoids full historical scans.');
    if (pendingBytes > Number(deps.maxActiveTailReadBytes || 0)) riskFlags.push('Active log has a backlog. The app will process it in smaller chunks.');
    if (fileStats.bytes > 50 * 1024 * 1024) riskFlags.push('Local app state is getting large. Compact App Data can move heavy event feeds into per-match cache files.');
    if (eventRows.rows > 250000 && eventCache.files < 1) riskFlags.push('Many stored event-feed rows. Compact App Data should split heavy feeds into cache files.');

    return {
      startupOptimized: true,
      startupLight,
      activeTailOnly: true,
      explicitPreviousLogImportOnly: true,
      maxActiveTailReadBytes: Number(deps.maxActiveTailReadBytes || 0),
      largeFolderCountThreshold: Number(deps.largeLogFolderCount || 800),
      activeFileName,
      activeFileSize,
      activeOffset,
      pendingBytes,
      folderLogCount,
      folderStatLimited,
      matchCount: Array.isArray(state.matches) ? state.matches.length : 0,
      recordingCount: Array.isArray(state.recordings) ? state.recordings.length : 0,
      vodCount: Array.isArray(state.vods) ? state.vods.length : 0,
      importedHistoryCount: Array.isArray(state.importedFiles) ? state.importedFiles.length : 0,
      addonHistoryCount: Array.isArray(state.addonImports) ? state.addonImports.length : 0,
      characterSnapshotCount: Array.isArray(state.characterSnapshots) ? state.characterSnapshots.length : 0,
      storedEventRows: eventRows.rows,
      storedEventPreviewRows: eventRows.previewRows,
      biggestMatchEventRows: eventRows.biggest,
      eventFeedCacheFiles: eventCache.files || 0,
      eventFeedCacheBytes: eventCache.bytes || 0,
      stateFileBytes: fileStats.bytes,
      stateFileUpdatedAt: fileStats.updatedAt,
      importJobStatus: safeCall(deps.importJobStatusSnapshot, {}),
      riskFlags
    };
  }

  function buildPvpHelperInstallStatus(state, options = {}) {
    if (options && options.startupLight) {
      return safeObject(state && state.settings && state.settings.pvpHelperAddonInstallStatus);
    }
    return safeCall(deps.buildPvPHelperInstallStatus, {}, (state && state.settings) || {});
  }

  function buildPvpHelperDiscovery(state, options = {}) {
    if (options && options.startupLight) {
      return safeObject(state && state.settings && state.settings.pvpHelperSavedVariablesDiscovery);
    }
    return safeCall(deps.discoverPvPHelperSavedVariables, {}, (state && state.settings) || {});
  }

  function buildAppPaths(state) {
    const storage = safeCall(deps.appStorageInfo, {}) || {};
    const getPath = (name) => safeCall(app.getPath ? app.getPath.bind(app) : null, '', name);
    return {
      userData: getPath('userData'),
      storage: storage.storage,
      defaultStorage: storage.defaultStorage,
      configuredStorage: storage.configuredStorage,
      customStorageActive: storage.customStorageActive,
      portableStorageActive: storage.portableStorageActive,
      storagePointerSource: storage.storagePointerSource,
      storageWarning: storage.storageWarning,
      storagePointer: storage.storagePointer,
      activeStoragePointer: storage.activeStoragePointer,
      portableStoragePointer: storage.portableStoragePointer,
      portableRoot: storage.portableRoot,
      defaultPortableStorage: storage.defaultPortableStorage,
      recordings: safeCall(deps.recordingsRootDir, '', state),
      archives: safeCall(deps.archiveRootDir, '', state),
      clips: safeCall(deps.clipsDir, '', state),
      backups: safeCall(deps.stateBackupsDir, ''),
      state: safeCall(deps.statePath, ''),
      addonPackages: path.join(safeCall(app.getAppPath ? app.getAppPath.bind(app) : null, ''), 'addon-packages'),
      addonPackageDrop: safeCall(deps.localAddonPackageDropDir, '')
    };
  }

  function buildClientStatePayload(state, options = {}) {
    const safeState = state && typeof state === 'object' ? state : {};
    const logSuggestion = quickLogSuggestion(safeState, options);
    return {
      ...safeState,
      appVersion: typeof app.getVersion === 'function' ? app.getVersion() : '',
      startupOptimized: true,
      startupLight: Boolean(options && options.startupLight),
      performanceAudit: buildPerformanceAudit(safeState, options),
      importJobStatus: safeCall(deps.importJobStatusSnapshot, {}),
      defaultLogCandidates: logSuggestion.detectedFiles || [],
      logSuggestion,
      appPaths: buildAppPaths(safeState),
      pvpHelperInstallStatus: buildPvpHelperInstallStatus(safeState, options),
      pvpHelperSavedVariablesDiscovery: buildPvpHelperDiscovery(safeState, options)
    };
  }

  function buildDeferredStartupDiagnostics(state) {
    const safeState = state && typeof state === 'object' ? state : {};
    const logSuggestion = quickLogSuggestion(safeState, { startupLight: false });
    return {
      ok: true,
      startupLight: false,
      performanceAudit: buildPerformanceAudit(safeState, { startupLight: false }),
      importJobStatus: safeCall(deps.importJobStatusSnapshot, {}),
      defaultLogCandidates: logSuggestion.detectedFiles || [],
      logSuggestion,
      pvpHelperInstallStatus: buildPvpHelperInstallStatus(safeState, { startupLight: false }),
      pvpHelperSavedVariablesDiscovery: buildPvpHelperDiscovery(safeState, { startupLight: false })
    };
  }

  return {
    stateFileStats,
    estimateStoredEventFeedRows,
    countObjectKeys,
    quickLogSuggestion,
    buildPerformanceAudit,
    buildClientStatePayload,
    buildDeferredStartupDiagnostics
  };
}

module.exports = { createStartupPayloadTools };
