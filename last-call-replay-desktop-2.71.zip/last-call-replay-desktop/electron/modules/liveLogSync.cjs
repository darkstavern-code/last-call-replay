'use strict';

function createLiveLogSyncTools(deps = {}) {
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const readState = typeof deps.readState === 'function' ? deps.readState : (() => ({}));
  const writeState = typeof deps.writeState === 'function' ? deps.writeState : (() => {});
  const defaultSettings = typeof deps.defaultSettings === 'function' ? deps.defaultSettings : (() => ({}));
  const resetLiveSession = typeof deps.resetLiveSession === 'function' ? deps.resetLiveSession : (() => {});
  const processRawText = typeof deps.processRawText === 'function' ? deps.processRawText : (() => []);
  const importParsedMatchesIntoState = typeof deps.importParsedMatchesIntoState === 'function' ? deps.importParsedMatchesIntoState : (() => []);
  const importLogFileChunkedIntoState = typeof deps.importLogFileChunkedIntoState === 'function' ? deps.importLogFileChunkedIntoState : (() => ({ ok: true, parsed: 0, imported: 0, updated: 0 }));
  const readRange = typeof deps.readRange === 'function' ? deps.readRange : ((filePath, start, end) => {
    const fd = fs.openSync(filePath, 'r');
    try {
      const length = Math.max(0, Number(end || 0) - Number(start || 0));
      const buffer = Buffer.allocUnsafe(length);
      const bytesRead = fs.readSync(fd, buffer, 0, length, Math.max(0, Number(start || 0)));
      return buffer.subarray(0, bytesRead).toString('utf8');
    } finally {
      fs.closeSync(fd);
    }
  });
  const splitCompleteLogLines = typeof deps.splitCompleteLogLines === 'function'
    ? deps.splitCompleteLogLines
    : ((raw, priorTail = '') => {
      const combined = `${String(priorTail || '')}${String(raw || '')}`;
      const parts = combined.split(/\r?\n/);
      const endsWithNewline = /(?:\r?\n)$/.test(combined);
      const tail = endsWithNewline ? '' : (parts.pop() || '');
      return { lines: parts.filter((line) => line.trim().length > 0), tail };
    });
  const processLiveLogLines = typeof deps.processLiveLogLines === 'function' ? deps.processLiveLogLines : (() => []);
  const finalizeLiveSessionAtFileEnd = typeof deps.finalizeLiveSessionAtFileEnd === 'function' ? deps.finalizeLiveSessionAtFileEnd : (() => []);
  const isCombatLogFileName = typeof deps.isCombatLogFileName === 'function' ? deps.isCombatLogFileName : ((name) => /^WoWCombatLog(?:[-_].*)?\.txt$/i.test(String(name || '')));
  const findBestLogFileInFolder = typeof deps.findBestLogFileInFolder === 'function' ? deps.findBestLogFileInFolder : (() => '');
  const sendToRenderer = typeof deps.sendToRenderer === 'function' ? deps.sendToRenderer : (() => {});

  const MAX_ACTIVE_TAIL_READ_BYTES = Number(deps.maxActiveTailReadBytes || (8 * 1024 * 1024));
  const MAX_TARGETED_LOG_SYNC_BYTES = Number(deps.maxTargetedLogSyncBytes || (320 * 1024 * 1024));
  const MAX_ACTIVE_INITIAL_BACKFILL_BYTES = Number(deps.maxActiveInitialBackfillBytes || MAX_TARGETED_LOG_SYNC_BYTES);

  let activeWatcher = null;
  let activeWatchPath = null;
  let watcherDebounce = null;

  function safeSend(channel, payload) {
    try { sendToRenderer(channel, payload); } catch (_error) {}
  }

  function safeStat(filePath) {
    try { return fs.statSync(filePath); } catch (_error) { return null; }
  }

  async function watchLogFile(filePath) {
    if (activeWatcher) activeWatcher.close();
    activeWatcher = null;
    activeWatchPath = filePath;

    const state = readState();
    state.settings = state.settings || {};
    state.settings.logFilePath = filePath;
    state.settings.logFolderPath = path.dirname(filePath);
    state.watchedFiles = state.watchedFiles || {};
    if (!state.watchedFiles[filePath]) {
      state.watchedFiles[filePath] = { offset: 0, fileSize: 0, lineTail: '', startedAt: new Date().toISOString() };
    }
    writeState(state);

    const dir = path.dirname(filePath);
    const base = path.basename(filePath);
    activeWatcher = fs.watch(dir, (_eventType, fileName) => {
      const changedName = fileName ? String(fileName) : '';
      if (changedName && changedName !== base && !isCombatLogFileName(changedName)) return;
      clearTimeout(watcherDebounce);
      watcherDebounce = setTimeout(() => {
        if (changedName && isCombatLogFileName(changedName)) {
          processWatchedFile(path.join(dir, changedName), { reason: 'folder-watch-live-update', skipInitialBackfill: true });
          return;
        }
        const best = findBestLogFileInFolder(dir) || filePath;
        processWatchedFile(best, { reason: 'folder-watch-live-update', skipInitialBackfill: true });
      }, 350);
    });

    safeSend('watcher-status', { state: 'watching folder', filePath, folderPath: dir });
    return { state: 'watching folder', filePath, folderPath: dir };
  }

  async function stopWatching() {
    if (activeWatcher) activeWatcher.close();
    activeWatcher = null;
    if (watcherDebounce) clearTimeout(watcherDebounce);
    watcherDebounce = null;
    const oldPath = activeWatchPath;
    activeWatchPath = null;
    safeSend('watcher-status', { state: 'stopped', filePath: oldPath });
    return { state: 'stopped', filePath: oldPath };
  }

  function processWatchedFile(filePath, options = {}) {
    const returnResult = Boolean(options && options.returnResult);
    if (!fs.existsSync(filePath)) {
      safeSend('watcher-status', { state: 'missing', filePath });
      return returnResult ? { ok: false, reason: 'File missing', bytes: 0, parsed: 0, imported: 0 } : undefined;
    }

    const state = readState();
    state.watchedFiles = state.watchedFiles || {};
    const stat = safeStat(filePath);
    if (!stat) return returnResult ? { ok: false, reason: 'Unable to stat file', bytes: 0, parsed: 0, imported: 0 } : undefined;

    const optionReason = String((options && options.reason) || '');
    const skipInitialBackfill = Boolean(options && options.skipInitialBackfill);
    const maxTailBytes = Math.max(64 * 1024, Math.min(MAX_ACTIVE_TAIL_READ_BYTES, Number(options && options.maxTailBytes) || MAX_ACTIVE_TAIL_READ_BYTES));
    const allowLogOnlyOpenSegments = Boolean(options && options.allowLogOnlyOpenSegments) || /changed-log-sweep|manual-import|previous|historical|offline|closed-log/i.test(optionReason);
    const allowBgAtFileEnd = Boolean(options && options.allowBgAtFileEnd) || allowLogOnlyOpenSegments;
    let record = state.watchedFiles[filePath] || { offset: 0, fileSize: 0, lineTail: '', startedAt: new Date().toISOString() };
    let offset = Number(record.offset) || 0;

    if (stat.size < offset) {
      offset = 0;
      record.lineTail = '';
      resetLiveSession(filePath);
    }

    if (!skipInitialBackfill && (record.autoLocated || record.needsInitialBackfill || record.lightStartupSkippedBackfill) && !record.initialBackfilled && stat.size > 0) {
      offset = 0;
      record.offset = 0;
      record.fileSize = 0;
      record.lineTail = '';
      record.needsInitialBackfill = true;
      resetLiveSession(filePath);
    }

    // For the active/newest log, first sync should catch up from the start of that
    // file. Moderate current logs are parsed once because the full parser is better
    // at reconstructing arena rooms + finished matches than tail-only fragments.
    const initialBackfillBytes = 16 * 1024 * 1024;
    if (skipInitialBackfill && !offset && !record.fileSize && stat.size > maxTailBytes) {
      offset = Math.max(0, stat.size - maxTailBytes);
      record.offset = offset;
      record.fileSize = stat.size;
      record.lineTail = '';
      record.needsInitialBackfill = true;
      record.initialBackfilled = false;
      record.lightStartupSkippedBackfill = true;
      record.lightStartupSkippedAt = new Date().toISOString();
    }
    if (!offset && !record.fileSize && stat.size > 0 && stat.size <= initialBackfillBytes) {
      const raw = fs.readFileSync(filePath, 'utf8');
      const parsedMatches = processRawText(raw, `active:${path.basename(filePath)}:initial-backfill`, { allowLogOnlyOpenSegments, allowBgAtFileEnd, logOnlyReason: 'log-only-initial-backfill' });
      const uniqueMatches = importParsedMatchesIntoState(state, parsedMatches);
      record.offset = stat.size;
      record.fileSize = stat.size;
      record.updatedAt = new Date().toISOString();
      record.lineTail = '';
      record.initialBackfilled = true;
      record.needsInitialBackfill = false;
      state.watchedFiles[filePath] = record;
      state.settings = { ...defaultSettings(), ...(state.settings || {}), logFilePath: filePath, logFolderPath: path.dirname(filePath), logLastSyncAt: record.updatedAt, logLastSyncFilePath: filePath, logLastSyncBytes: stat.size, logLastSyncMode: 'active-log-initial-backfill' };
      writeState(state);
      safeSend('watcher-chunk', { filePath, bytes: stat.size, matches: uniqueMatches, changedMatches: uniqueMatches, removedMatchIds: state._removedDuplicateMatchIds || [], parsed: parsedMatches.length, offset: stat.size, strategy: 'active-log-initial-backfill', hasMoreTail: false });
      return returnResult ? { ok: true, bytes: stat.size, parsed: parsedMatches.length, imported: uniqueMatches.length, updated: Math.max(0, parsedMatches.length - uniqueMatches.length), matches: uniqueMatches, hasMoreTail: false, initialBackfill: true } : undefined;
    }

    if (!offset && !record.fileSize && stat.size > initialBackfillBytes && stat.size <= MAX_ACTIVE_INITIAL_BACKFILL_BYTES) {
      const beforeCount = (state.matches || []).length;
      const scan = importLogFileChunkedIntoState(state, filePath, 'active-log-chunked-initial-backfill', { maxBytes: MAX_ACTIVE_INITIAL_BACKFILL_BYTES, allowLogOnlyOpenSegments, allowBgAtFileEnd });
      record.offset = stat.size;
      record.fileSize = stat.size;
      record.updatedAt = new Date().toISOString();
      record.lineTail = '';
      record.initialBackfilled = true;
      record.needsInitialBackfill = false;
      state.watchedFiles[filePath] = record;
      state.settings = { ...defaultSettings(), ...(state.settings || {}), logFilePath: filePath, logFolderPath: path.dirname(filePath), logLastSyncAt: record.updatedAt, logLastSyncFilePath: filePath, logLastSyncBytes: stat.size, logLastSyncMode: 'active-log-chunked-initial-backfill' };
      writeState(state);
      const uniqueMatches = Array.isArray(scan.changedMatches) && scan.changedMatches.length
        ? scan.changedMatches
        : (state.matches || []).slice(0, Math.max(0, (state.matches || []).length - beforeCount));
      const removedMatchIds = Array.isArray(scan.removedMatchIds) ? scan.removedMatchIds : (state._removedDuplicateMatchIds || []);
      safeSend('watcher-chunk', { filePath, bytes: stat.size, matches: uniqueMatches, changedMatches: uniqueMatches, removedMatchIds, parsed: scan.parsed || 0, offset: stat.size, strategy: 'active-log-chunked-initial-backfill', hasMoreTail: false });
      return returnResult ? { ok: scan.ok !== false, bytes: stat.size, parsed: scan.parsed || 0, imported: scan.imported || 0, updated: scan.updated || Math.max(0, Number(scan.parsed || 0) - Number(scan.imported || 0)), matches: uniqueMatches, removedMatchIds, hasMoreTail: false, initialBackfill: true, chunked: true, reason: scan.reason || '' } : undefined;
    }

    const readEnd = Math.min(stat.size, offset + maxTailBytes);
    const chunk = readRange(filePath, offset, readEnd);
    const hasMoreTail = readEnd < stat.size;
    record.offset = readEnd;
    record.fileSize = stat.size;
    record.updatedAt = new Date().toISOString();

    let parsedMatches = [];
    let uniqueMatches = [];
    if (chunk.length > 0) {
      const split = splitCompleteLogLines(chunk, record.lineTail || '');
      record.lineTail = split.tail || '';
      parsedMatches = processLiveLogLines(filePath, split.lines || [], { allowLogOnlyOpenSegments, allowBgAtFileEnd, logOnlyReason: 'log-only-tail-drain' });
      if (!hasMoreTail && (allowLogOnlyOpenSegments || allowBgAtFileEnd)) {
        parsedMatches.push(...finalizeLiveSessionAtFileEnd(filePath, 'log-only-tail-drain', { allowLogOnlyOpenSegments, allowBgAtFileEnd, logOnlyReason: 'log-only-tail-drain' }));
      }
      uniqueMatches = importParsedMatchesIntoState(state, parsedMatches);
      safeSend('watcher-chunk', { filePath, bytes: chunk.length, matches: uniqueMatches, changedMatches: uniqueMatches, removedMatchIds: state._removedDuplicateMatchIds || [], parsed: parsedMatches.length, offset: stat.size, strategy: allowLogOnlyOpenSegments ? 'changed-log-tail-plus-log-only' : 'active-tail-finalized-segments', hasMoreTail });
    }

    state.watchedFiles[filePath] = record;
    state.settings = { ...defaultSettings(), ...(state.settings || {}), logFilePath: filePath, logFolderPath: path.dirname(filePath), logLastSyncAt: record.updatedAt, logLastSyncFilePath: filePath, logLastSyncBytes: chunk.length, logLastSyncMode: hasMoreTail ? 'active-log-tail-chunked' : 'active-log-tail' };
    writeState(state);

    return returnResult ? { ok: true, bytes: chunk.length, parsed: parsedMatches.length, imported: uniqueMatches.length, updated: Math.max(0, parsedMatches.length - uniqueMatches.length), matches: uniqueMatches, hasMoreTail } : undefined;
  }

  function processActiveLogTail(filePath, options = {}) {
    const maxPasses = Math.max(1, Math.min(48, Number(options.maxPasses || 8)));
    const summary = { ok: true, bytes: 0, parsed: 0, imported: 0, updated: 0, matches: [], hasMoreTail: false, skippedFullRead: false, passes: 0 };
    for (let pass = 0; pass < maxPasses; pass += 1) {
      const result = processWatchedFile(filePath, {
        returnResult: true,
        reason: options.reason || 'active-log-catchup',
        allowLogOnlyOpenSegments: Boolean(options.allowLogOnlyOpenSegments),
        allowBgAtFileEnd: Boolean(options.allowBgAtFileEnd),
        skipInitialBackfill: Boolean(options.skipInitialBackfill),
        maxTailBytes: options.maxTailBytes
      }) || {};
      summary.passes += 1;
      if (result.ok === false) return { ...summary, ...result };
      summary.bytes += Number(result.bytes || 0);
      summary.parsed += Number(result.parsed || 0);
      summary.imported += Number(result.imported || 0);
      summary.updated += Number(result.updated || 0);
      if (Array.isArray(result.matches) && result.matches.length) summary.matches.push(...result.matches);
      summary.hasMoreTail = Boolean(result.hasMoreTail);
      summary.skippedFullRead = Boolean(result.skippedFullRead);
      if (!result.hasMoreTail || result.skippedFullRead || !Number(result.bytes || 0)) break;
    }
    return summary;
  }

  return {
    watchLogFile,
    stopWatching,
    processWatchedFile,
    processActiveLogTail
  };
}

module.exports = { createLiveLogSyncTools };
