'use strict';

function createPvPHelperSnapshotTools(deps = {}) {
  const WOW_CLASS_COLORS = deps.WOW_CLASS_COLORS || {};
  const hashText = typeof deps.hashText === 'function' ? deps.hashText : (value) => String(value || '');
  const normalizeClassKey = typeof deps.normalizeClassKey === 'function' ? deps.normalizeClassKey : (value) => String(value || '');
  const cleanMatchMapName = typeof deps.cleanMatchMapName === 'function' ? deps.cleanMatchMapName : (value) => String(value || 'Unknown map');
  const teamCountsFromPlayers = typeof deps.teamCountsFromPlayers === 'function' ? deps.teamCountsFromPlayers : () => ({});
  const expectedTeamSizeForType = typeof deps.expectedTeamSizeForType === 'function' ? deps.expectedTeamSizeForType : () => 0;
  const maxTeamCount = typeof deps.maxTeamCount === 'function' ? deps.maxTeamCount : () => 0;
  const isRatedBattlegroundType = typeof deps.isRatedBattlegroundType === 'function' ? deps.isRatedBattlegroundType : () => false;
  const isBattlegroundType = typeof deps.isBattlegroundType === 'function' ? deps.isBattlegroundType : () => false;
  const durationSecondsFromValue = typeof deps.durationSecondsFromValue === 'function' ? deps.durationSecondsFromValue : () => 0;
  const formatDuration = typeof deps.formatDuration === 'function' ? deps.formatDuration : (seconds) => String(seconds || '');
  const normalizeMatchDataSources = typeof deps.normalizeMatchDataSources === 'function' ? deps.normalizeMatchDataSources : (match) => match;
  const uniqueList = typeof deps.uniqueList === 'function' ? deps.uniqueList : (items = []) => Array.from(new Set((items || []).filter(Boolean)));
  const cleanBracketName = typeof deps.cleanBracketName === 'function' ? deps.cleanBracketName : (value) => String(value || 'Unknown Bracket');
  const firstDefinedNumber = typeof deps.firstDefinedNumber === 'function' ? deps.firstDefinedNumber : () => null;
  const objectArrayLikeToArray = typeof deps.objectArrayLikeToArray === 'function' ? deps.objectArrayLikeToArray : () => [];
  const firstTextValue = typeof deps.firstTextValue === 'function' ? deps.firstTextValue : () => '';
  const clonePlainValue = typeof deps.clonePlainValue === 'function' ? deps.clonePlainValue : (value) => value;
  const normalizeTimestampToIso = typeof deps.normalizeTimestampToIso === 'function' ? deps.normalizeTimestampToIso : () => new Date().toISOString();
  const splitPlayerRealm = typeof deps.splitPlayerRealm === 'function' ? deps.splitPlayerRealm : (value = '') => ({ name: String(value || 'Unknown'), realm: '', fullName: String(value || 'Unknown') });
  const parseCharacterSnapshotText = typeof deps.parseCharacterSnapshotText === 'function' ? deps.parseCharacterSnapshotText : () => [];

function addonSnapshotIdentity(item = {}) {
  const matchID = firstTextValue(item.matchID, item.matchId);
  const matchFingerprint = firstTextValue(item.matchFingerprint, item.fingerprint);
  const legacyID = firstTextValue(item.id);
  if (matchID) return { kind: 'matchID', raw: matchID, key: `matchID:${hashText(matchID)}` };
  if (matchFingerprint) return { kind: 'matchFingerprint', raw: matchFingerprint, key: `matchFingerprint:${hashText(matchFingerprint)}` };
  if (legacyID) return { kind: 'legacyID', raw: legacyID, key: `legacyID:${hashText(legacyID)}` };
  return { kind: 'fallback', raw: '', key: '' };
}


function normalizeAddonScorePlayer(raw = {}) {
  const item = raw && typeof raw === 'object' ? raw : {};
  const identity = splitPlayerRealm(item.fullName || item.name || item.playerName || item.character || '', item.realm || item.playerRealm || '');
  const className = normalizeClassKey(item.className || item.class || item.classFile || item.classToken || '');
  const stats = objectArrayLikeToArray(item.scoreboardStats || item.stats).map((stat) => ({
    name: stat && stat.name ? String(stat.name) : '',
    value: stat && stat.value !== undefined ? stat.value : (stat && stat.pvpStatValue !== undefined ? stat.pvpStatValue : null),
    orderIndex: stat && stat.orderIndex !== undefined ? stat.orderIndex : null,
    pvpStatID: stat && stat.pvpStatID !== undefined ? stat.pvpStatID : null,
    pvpStatValue: stat && stat.pvpStatValue !== undefined ? stat.pvpStatValue : null,
    iconName: stat && stat.iconName ? String(stat.iconName) : '',
    tooltip: stat && stat.tooltip ? String(stat.tooltip) : '',
    apiFields: stat && stat.apiFields !== undefined ? clonePlainValue(stat.apiFields) : undefined
  })).filter((stat) => stat.name || stat.value !== null || stat.pvpStatID !== null);
  const out = {
    name: identity.name,
    realm: identity.realm,
    fullName: item.fullName || identity.fullName,
    guid: item.guid || item.playerGUID || '',
    team: item.team !== undefined ? item.team : (item.teamID !== undefined ? item.teamID : (item.faction !== undefined ? item.faction : item.factionID)),
    teamID: item.teamID !== undefined ? item.teamID : (item.team !== undefined ? item.team : null),
    faction: item.faction !== undefined ? item.faction : (item.team !== undefined ? item.team : item.teamID),
    className,
    classFile: item.classFile || item.classToken || className || '',
    classToken: item.classToken || item.classFile || '',
    specName: item.specName || item.spec || item.talentSpec || '',
    talentSpec: item.talentSpec || '',
    raceName: item.raceName || '',
    roleAssigned: item.roleAssigned !== undefined ? item.roleAssigned : null,
    honorLevel: firstDefinedNumber(item.honorLevel),
    killingBlows: firstDefinedNumber(item.killingBlows, item.kb),
    honorableKills: firstDefinedNumber(item.honorableKills, item.hk),
    deaths: firstDefinedNumber(item.deaths),
    damageDone: firstDefinedNumber(item.damageDone, item.damage),
    healingDone: firstDefinedNumber(item.healingDone, item.healing),
    honorGained: firstDefinedNumber(item.honorGained, item.honor),
    rating: firstDefinedNumber(item.rating, item.bgRating, item.personalRating),
    ratingChange: firstDefinedNumber(item.ratingChange, item.ratingDelta),
    prematchMMR: firstDefinedNumber(item.prematchMMR, item.preMatchMMR),
    mmrChange: firstDefinedNumber(item.mmrChange, item.mmrDelta),
    postmatchMMR: firstDefinedNumber(item.postmatchMMR, item.postMatchMMR),
    scoreboardStats: stats
  };
  if (item.apiFields !== undefined) out.apiFields = clonePlainValue(item.apiFields);
  out.rawScoreboardFields = clonePlainValue(scalarSnapshotFields(item, ['scoreboardStats', 'stats', 'apiFields']));
  return out;
}

function resultFromAddonSnapshot(item, playerRow) {
  const explicit = item.result || item.winnerResult || item.outcome;
  if (explicit && /win/i.test(String(explicit))) return 'Win';
  if (explicit && /loss|lose|lost/i.test(String(explicit))) return 'Loss';
  const winner = item.winner !== undefined ? item.winner : item.winningTeam;
  if (winner === undefined || winner === null || winner === '' || !playerRow) return 'Parsed';
  const playerTeam = playerRow.team !== undefined && playerRow.team !== null ? playerRow.team : playerRow.faction;
  if (playerTeam === undefined || playerTeam === null || playerTeam === '') return 'Parsed';
  return String(winner) === String(playerTeam) ? 'Win' : 'Loss';
}

function rowsFromScoreboardMetric(players, field) {
  return (players || []).filter((player) => Number(player[field]) > 0).map((player) => ({
    name: player.name || player.fullName || 'Unknown',
    amount: Number(player[field]) || 0,
    count: Number(player[field]) || 0,
    abilities: [],
    percent: 1,
    top: 'Scoreboard total'
  })).sort((a, b) => b.amount - a.amount);
}

function scalarSnapshotFields(item = {}, skip = []) {
  const blocked = new Set(skip || []);
  const out = {};
  for (const [key, value] of Object.entries(item || {})) {
    if (blocked.has(key)) continue;
    if (value === null || ['string', 'number', 'boolean'].includes(typeof value)) out[key] = value;
  }
  return out;
}

function preservedPvPHelperSnapshotFields(item = {}) {
  return {
    scalarFields: scalarSnapshotFields(item, ['scoreboardPlayers', 'scores', 'players', 'playerScore']),
    apiFields: item.apiFields !== undefined ? clonePlainValue(item.apiFields) : null,
    instance: item.instance !== undefined ? clonePlainValue(item.instance) : null,
    queue: item.queue !== undefined ? clonePlainValue(item.queue) : null,
    logging: item.logging !== undefined ? clonePlainValue(item.logging) : null
  };
}

function characterSnapshotsFromMatchHistory(matchHistory = [], sourceFile = '') {
  const out = [];
  for (const raw of matchHistory || []) {
    if (!raw || typeof raw !== 'object') continue;
    const playerScore = raw.playerScore && typeof raw.playerScore === 'object' ? raw.playerScore : null;
    if (!playerScore) continue;
    const identity = splitPlayerRealm(raw.playerFullName || raw.player || playerScore.fullName || playerScore.name || raw.playerName || '', raw.playerRealm || playerScore.realm || '');
    const character = identity.fullName || identity.name;
    if (!character) continue;
    const rating = firstDefinedNumber(playerScore.rating, playerScore.bgRating, playerScore.personalRating, playerScore.rawRating);
    const mmr = firstDefinedNumber(playerScore.postmatchMMR, playerScore.postMatchMMR, playerScore.rawPostmatchMMR, playerScore.prematchMMR, playerScore.preMatchMMR, playerScore.rawPrematchMMR);
    const ratingChange = firstDefinedNumber(playerScore.ratingChange, playerScore.ratingDelta, playerScore.rawRatingChange);
    const mmrChange = firstDefinedNumber(playerScore.mmrChange, playerScore.mmrDelta, playerScore.rawMMRChange);
    if (playerScore.ratingUsable === false && rating == null && ratingChange == null && mmr == null && mmrChange == null) continue;
    if (rating == null && mmr == null && ratingChange == null && mmrChange == null) continue;
    const capturedAt = normalizeTimestampToIso(raw.capturedAt || raw.capturedAtText || raw.capturedAtUTC || raw.capturedAtLocal || raw.capturedAtLocalText || raw.timestamp || raw.date);
    const bracket = cleanBracketName(raw.bracket || raw.matchType || raw.matchLabel || raw.label || raw.instanceType || 'PvP Match');
    const className = normalizeClassKey(playerScore.className || playerScore.classFile || playerScore.classToken || '');
    const specName = playerScore.specName || playerScore.talentSpec || playerScore.spec || '';
    out.push({
      id: hashText(`pvph-scoreboard-rating|${character}|${bracket}|${capturedAt}|${rating}|${mmr}|${ratingChange}|${sourceFile}`),
      character,
      specId: null,
      specName,
      className,
      classColor: className && WOW_CLASS_COLORS[className] ? WOW_CLASS_COLORS[className] : '',
      bracket,
      rating,
      mmr,
      ratingChange,
      mmrChange,
      result: raw.result || '',
      seasonWon: null,
      seasonLost: null,
      seasonPlayed: null,
      capturedAt,
      sourceFile,
      sourceType: 'PvPHelper scoreboard playerScore'
    });
  }
  return out;
}


function normalizedArenaMapKey(value = '') {
  return String(value || '').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim();
}

const ADDON_ARENA_MAP_KEYS = new Set([
  'nagrand arena', 'black rook hold arena', 'mugambala', 'nokhudon proving grounds', "tol'viron arena",
  'tol’viron arena', 'maldraxxus coliseum', 'empyrean domain', 'ruins of lordaeron', "tiger's peak",
  'tiger’s peak', "blade's edge arena", 'blade’s edge arena', 'dalaran sewers', 'enigma arena',
  'enigma crucible', 'the robodrome', 'cage of carnage', "ashamane's fall", 'ashamane’s fall',
  'hook point', 'the hook point', 'the ring of valor'
]);

function isKnownArenaMapName(value = '') {
  const key = normalizedArenaMapKey(value);
  if (!key) return false;
  return ADDON_ARENA_MAP_KEYS.has(key) || /arena|mugambala|nokhudon|maldraxxus|empyrean|lordaeron|tiger'?s peak|tiger’s peak|robodrome|cage of carnage|ashamane|hook point|dalaran sewers|ring of valor/i.test(String(value || ''));
}

function correctAddonArenaBracket(bracket = '', mapName = '', actualTeamSize = 0, playerCount = 0) {
  const normalized = cleanBracketName(bracket);
  if (normalized === 'Solo Shuffle' || normalized === '2v2' || normalized === '3v3' || normalized === 'Skirmish') return normalized;
  const arenaSized = (Number(actualTeamSize) > 0 && Number(actualTeamSize) <= 3) || (Number(playerCount) > 0 && Number(playerCount) <= 6);
  if (!isKnownArenaMapName(mapName) || !arenaSized) return normalized;
  if (Number(playerCount) >= 5 || Number(actualTeamSize) === 3) return '3v3';
  if (Number(actualTeamSize) === 2) return '2v2';
  return '3v3';
}

function normalizeAddonMatchSnapshot(raw = {}, sourceFile = '') {
  const item = raw && typeof raw === 'object' ? raw : {};
  const players = objectArrayLikeToArray(item.scoreboardPlayers || item.scores || item.players).map(normalizeAddonScorePlayer).filter((player) => player.name && player.name !== 'Unknown');
  if (!players.length) return null;
  const identity = addonSnapshotIdentity(item);
  const capturedIso = normalizeTimestampToIso(item.capturedAt || item.capturedAtText || item.capturedAtUTC || item.capturedAtLocal || item.capturedAtLocalText || item.timestamp || item.date || item.updatedAt);
  const capturedMs = Date.parse(capturedIso) || Date.now();
  const playerIdentity = splitPlayerRealm(item.playerFullName || item.player || item.playerName || (item.playerScore && (item.playerScore.fullName || item.playerScore.name)) || '', item.playerRealm || (item.playerScore && item.playerScore.realm) || '');
  const explicitPlayerScore = item.playerScore && typeof item.playerScore === 'object' ? normalizeAddonScorePlayer(item.playerScore) : null;
  const playerRow = explicitPlayerScore || players.find((player) => [player.fullName, player.name].filter(Boolean).map((x) => String(x).toLowerCase()).includes(String(playerIdentity.fullName || playerIdentity.name).toLowerCase())) || players[0];
  const ownTeam = playerRow && (playerRow.team !== undefined && playerRow.team !== null ? playerRow.team : playerRow.faction);
  const friendlyTeam = ownTeam !== undefined && ownTeam !== null && ownTeam !== '' ? players.filter((player) => String(player.team !== undefined && player.team !== null ? player.team : player.faction) === String(ownTeam)).map((player) => player.name) : [playerIdentity.name || playerRow.name].filter(Boolean);
  const enemyTeam = ownTeam !== undefined && ownTeam !== null && ownTeam !== '' ? players.filter((player) => String(player.team !== undefined && player.team !== null ? player.team : player.faction) !== String(ownTeam)).map((player) => player.name) : [];
  const classByName = {};
  for (const player of players) {
    const className = player.className || player.classFile || '';
    classByName[player.name] = {
      className,
      classFile: player.classFile || '',
      classColor: className && WOW_CLASS_COLORS[className] ? WOW_CLASS_COLORS[className] : '',
      specName: player.specName || '',
      team: player.team !== undefined ? String(player.team) : ''
    };
  }
  const damageRows = rowsFromScoreboardMetric(players, 'damageDone');
  const healingRows = rowsFromScoreboardMetric(players, 'healingDone');
  const deathRows = players.filter((player) => Number(player.deaths) > 0).map((player) => ({ name: player.name, amount: Number(player.deaths) || 0, count: Number(player.deaths) || 0, abilities: [], percent: 1, top: 'Scoreboard deaths' })).sort((a, b) => b.amount - a.amount);
  const rawBracket = cleanBracketName(item.bracket || item.matchType || item.matchLabel || item.label || item.instanceType || 'PvP Match');
  const result = resultFromAddonSnapshot(item, playerRow);
  const mapId = firstTextValue(item.mapID, item.mapId, item.instanceID, item.instanceId, item.zoneID, item.zoneId);
  const rawMapName = item.map || item.mapName || item.zone || item.instanceName || item.subzone || item.subZone || 'Unknown map';
  const mapName = cleanMatchMapName(rawMapName, null, mapId);
  const scoreboardTeamCounts = teamCountsFromPlayers(players);
  const actualTeamSize = maxTeamCount(scoreboardTeamCounts);
  const bracket = correctAddonArenaBracket(rawBracket, mapName, actualTeamSize, players.length);
  const expectedTeamSize = expectedTeamSizeForType(bracket, mapName) || (bracket === '2v2' ? 2 : (bracket === '3v3' || bracket === 'Solo Shuffle' || bracket === 'Skirmish' ? 3 : 0));
  const isArena = bracket === '2v2' || bracket === '3v3' || bracket === 'Solo Shuffle' || bracket === 'Skirmish';
  const isRatedBattleground = isArena ? false : isRatedBattlegroundType(bracket);
  const isBattleground = isArena ? false : (isBattlegroundType(bracket) || actualTeamSize >= 6 || players.length >= 12);
  const fallbackSeed = `${capturedIso}|${mapName}|${bracket}|${players.map((player) => player.fullName || player.name).sort().join('|')}`;
  const idSeed = identity.key || fallbackSeed;
  const durationSec = durationSecondsFromValue(item.durationSec ?? item.durationSeconds ?? item.duration ?? item.elapsedSec ?? item.elapsedSeconds ?? item.elapsed ?? item.matchDuration ?? item.matchDurationSec);
  const startMs = durationSec > 0 ? Math.max(0, capturedMs - durationSec * 1000) : capturedMs;
  const startIso = new Date(startMs).toISOString();
  return normalizeMatchDataSources({
    id: `addon_${hashText(String(idSeed)).slice(0, 12)}`,
    result,
    bracket,
    matchType: bracket,
    map: mapName,
    mapID: mapId || item.mapID || item.mapId || '',
    subzone: item.subzone || item.subZone || '',
    instanceType: item.instanceType || '',
    duration: durationSec > 0 ? formatDuration(durationSec) : '',
    durationSec,
    date: new Date(startIso).toLocaleDateString(),
    time: new Date(startIso).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }),
    startIso,
    endIso: capturedIso,
    startMs,
    endMs: capturedMs,
    capturedAt: capturedIso,
    alt: playerIdentity.name && playerIdentity.name !== 'Unknown' ? playerIdentity.name : (playerRow && playerRow.name) || 'Unknown Player',
    playerName: playerIdentity.name,
    playerRealm: playerIdentity.realm,
    playerFullName: playerIdentity.fullName,
    ownTeam: ownTeam !== undefined && ownTeam !== null ? String(ownTeam) : '',
    myComp: friendlyTeam,
    enemyComp: enemyTeam,
    enemies: enemyTeam,
    participants: uniqueList(players.map((player) => player.name)),
    isRatedBattleground,
    isBattleground,
    expectedTeamSize,
    actualTeamSize,
    scoreboardTeamCounts,
    classByName,
    specByName: Object.fromEntries(players.filter((player) => player.specName).map((player) => [player.name, player.specName])),
    spec: playerRow && playerRow.specName ? playerRow.specName : 'Spec unknown',
    summary: `Addon scoreboard: ${players.length} players captured.`,
    danger: 'Imported from PvPHelper scoreboard snapshot.',
    tags: uniqueList([bracket, 'Addon Scoreboard', item.reason || item.captureReason || 'match complete']),
    damage: damageRows,
    healing: healingRows,
    taken: [],
    metrics: { Damage: damageRows, DamagePlayers: damageRows, Healing: healingRows, HealingPlayers: healingRows, Taken: [], TakenPlayers: [], CC: [], Interrupts: [], Purges: [], Dispels: [], 'CC Dispels': [], Deaths: deathRows },
    cooldowns: [],
    ccChains: [],
    interrupts: [],
    death: { victim: 'Not captured by addon scoreboard', at: 'n/a', recap: [], lastHits: [], note: 'Combat-log death details are only available when this match is linked to a parsed log.' },
    chart: [],
    healthTimeline: [],
    eventFeed: [],
    rawEvents: [],
    rawFingerprint: identity.key || `fallback:${hashText(String(idSeed))}`,
    addonDedupeKey: identity.key || `fallback:${hashText(String(idSeed))}`,
    addonDedupeKind: identity.kind || 'fallback',
    addonMatchID: firstTextValue(item.matchID, item.matchId),
    addonLegacyID: firstTextValue(item.id),
    addonMatchFingerprint: firstTextValue(item.matchFingerprint, item.fingerprint),
    sourceLabel: sourceFile,
    createdFromAddon: true,
    createdFromRealLog: false,
    isBracketMatch: true,
    addonScoreboard: {
      schemaVersion: item.schemaVersion || null,
      addonVersion: item.addonVersion || item.version || null,
      matchID: firstTextValue(item.matchID, item.matchId),
      legacyID: firstTextValue(item.id),
      matchFingerprint: firstTextValue(item.matchFingerprint, item.fingerprint),
      dedupeKey: identity.key || `fallback:${hashText(String(idSeed))}`,
      capturedAt: capturedIso,
      capturedAtNumeric: item.capturedAt !== undefined ? item.capturedAt : null,
      capturedAtText: item.capturedAtText || item.capturedAtUTC || '',
      capturedAtUTC: item.capturedAtUTC || item.capturedAtText || '',
      capturedAtLocalText: item.capturedAtLocalText || item.capturedAtLocal || item.localCapturedAtText || '',
      capturedAtLocal: item.capturedAtLocal || item.capturedAtLocalText || '',
      captureReason: item.captureReason || item.reason || '',
      schemaName: item.schemaName || '',
      addonName: item.addonName || '',
      mapID: item.mapID !== undefined ? item.mapID : null,
      playerTeam: item.playerTeam !== undefined ? item.playerTeam : null,
      winner: item.winner !== undefined ? item.winner : null,
      winnerRaw: item.winnerRaw !== undefined ? item.winnerRaw : (item.winner !== undefined ? item.winner : null),
      winnerTeam: item.winnerTeam !== undefined ? item.winnerTeam : (item.winner !== undefined ? item.winner : null),
      duration: item.duration !== undefined ? item.duration : null,
      scoreboardPlayerCount: item.scoreboardPlayerCount !== undefined ? item.scoreboardPlayerCount : players.length,
      label: item.matchLabel || item.label || '',
      result,
      playerScore: explicitPlayerScore || clonePlainValue(item.playerScore || null),
      apiFields: item.apiFields !== undefined ? clonePlainValue(item.apiFields) : null,
      rawFields: preservedPvPHelperSnapshotFields(item),
      sourceFile
    },
    scoreboardPlayers: players,
    dataSources: ['addonScoreboard'],
    addonImportConfidence: 'addon-only',
    soloRounds: []
  });
}


  return {
    addonSnapshotIdentity,
    normalizeAddonScorePlayer,
    resultFromAddonSnapshot,
    rowsFromScoreboardMetric,
    scalarSnapshotFields,
    preservedPvPHelperSnapshotFields,
    characterSnapshotsFromMatchHistory,
    normalizeAddonMatchSnapshot
  };
}

module.exports = { createPvPHelperSnapshotTools };
