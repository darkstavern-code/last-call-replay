function createCombatLogSegmentTools(deps = {}) {
  const {
    core,
    metrics,
    hashText = (value) => String(value || ''),
    uniqueList = (items = []) => Array.from(new Set(items || [])),
    mapNameFromArenaStart = () => '',
    isRawInstanceMapLabel = () => false,
    battlegroundInstanceMapName = () => '',
    battlegroundMapNameFromSubzone = () => '',
    isKnownBattlegroundZone = () => false
  } = deps;
  if (!core) throw new Error('combatLogSegments requires core tools');
  if (!metrics) throw new Error('combatLogSegments requires metric tools');
  const {
    cleanSpellName,
    eventKind,
    isPlayerGuid,
    isUsefulUnitName,
    noteOwnCandidate,
    trimBattlegroundSegmentNoise,
    normalizedMapKey
  } = core;
  const { summarizeBracketMatch } = metrics;

function isRealPlayerDeathEvent(ev) {
  return Boolean(ev && eventKind(ev.event) === 'death' && !ev.isFeignDeath && isPlayerGuid(ev.destGuid) && isUsefulUnitName(ev.destName));
}

function soloShuffleCombatantClusterStarts(segment = []) {
  const clusters = [];
  let current = null;
  for (let i = 0; i < segment.length; i += 1) {
    const ev = segment[i];
    if (!ev || ev.event !== 'COMBATANT_INFO') continue;
    const at = Number(ev.absoluteMs || 0) || 0;
    if (!current || (at && current.lastAt && at - current.lastAt > 8000)) {
      current = { index: i, lastAt: at, count: 0, guids: new Set() };
      clusters.push(current);
    }
    current.lastAt = at || current.lastAt;
    current.count += 1;
    if (ev.fields && ev.fields[1]) current.guids.add(ev.fields[1]);
  }
  return clusters
    .filter((cluster) => cluster.count >= 2 || cluster.guids.size >= 2)
    .map((cluster) => cluster.index);
}

function soloShuffleRoundSlicesFromLobbySegment(segment = []) {
  if (!Array.isArray(segment) || segment.length < 5) return [];
  const startIndex = Math.max(0, segment.findIndex((ev) => ev && ev.event === 'ARENA_MATCH_START'));
  const arenaEndIndex = segment.findIndex((ev, index) => index > startIndex && ev && ev.event === 'ARENA_MATCH_END');
  const hardEnd = arenaEndIndex >= 0 ? arenaEndIndex : segment.length - 1;
  const startMarkers = segment
    .map((ev, index) => ev && ev.event === 'ARENA_MATCH_START' && index >= startIndex && index <= hardEnd ? index : -1)
    .filter((index) => index >= 0)
    .slice(0, 6);

  // Solo Shuffle's cleanest source of truth is the repeated ARENA_MATCH_START row.
  // Earlier versions tried to infer rounds from COMBATANT_INFO clusters, which could
  // miss the first round or collapse nearby rounds when the log got noisy. Use the
  // actual round starts first, then fall back to clusters/deaths only for odd logs.
  let slices = [];
  if (startMarkers.length > 1) {
    slices = startMarkers.map((start, index) => {
      const nextStart = startMarkers[index + 1] || hardEnd + 1;
      return { start, end: Math.max(start, Math.min(nextStart - 1, hardEnd)) };
    });
  } else {
    const clusterStarts = soloShuffleCombatantClusterStarts(segment).filter((index) => index >= startIndex && index <= hardEnd);
    const deathIndexes = segment.map((ev, index) => isRealPlayerDeathEvent(ev) ? index : -1).filter((index) => index >= startIndex && index <= hardEnd);
    const starts = [startIndex];
    for (const cluster of clusterStarts) {
      if (cluster <= startIndex + 2) continue;
      const previous = starts[starts.length - 1];
      if (cluster - previous > 10) starts.push(cluster);
    }
    if (starts.length > 1) {
      for (let i = 0; i < starts.length && i < 6; i += 1) {
        const rawStart = starts[i];
        const nextStart = starts[i + 1] || hardEnd + 1;
        const deathIndex = deathIndexes.find((index) => index >= rawStart && index < nextStart);
        const end = deathIndex !== undefined ? deathIndex : Math.min(nextStart - 1, hardEnd);
        if (end > rawStart) slices.push({ start: rawStart, end });
      }
    } else if (deathIndexes.length > 1) {
      let cursor = startIndex;
      for (const deathIndex of deathIndexes.slice(0, 6)) {
        if (deathIndex > cursor) slices.push({ start: cursor, end: deathIndex });
        cursor = Math.min(hardEnd, deathIndex + 1);
      }
    }
  }

  return slices.filter((slice) => {
    const piece = segment.slice(slice.start, slice.end + 1);
    return piece.some((ev) => ev && ev.event === 'ARENA_MATCH_START')
      || (piece.some((ev) => ev && ev.event === 'COMBATANT_INFO') && piece.some((ev) => ev && ['damage', 'healing', 'death', 'cast', 'aura', 'interrupt', 'dispel'].includes(eventKind(ev.event))));
  }).slice(0, 6);
}

function summarizeSoloShuffleLobbyRoundSegments(segment, sourceLabel, segmentIndex, context = {}) {
  const slices = soloShuffleRoundSlicesFromLobbySegment(segment);
  if (slices.length <= 1) return [];
  const arenaStart = segment.find((ev) => ev && ev.event === 'ARENA_MATCH_START') || null;
  const arenaEnd = [...segment].reverse().find((ev) => ev && ev.event === 'ARENA_MATCH_END') || null;
  const sessionSeed = hashText(`${sourceLabel}|${segmentIndex}|${segment[0] && segment[0].stamp || ''}|${segment[segment.length - 1] && segment[segment.length - 1].stamp || ''}|solo-shuffle`);
  return slices.map((slice, index) => {
    let roundEvents = segment.slice(slice.start, slice.end + 1);
    if (index === 0 && arenaStart && roundEvents[0] !== arenaStart) roundEvents = [arenaStart, ...roundEvents];
    if (index === slices.length - 1 && arenaEnd && !roundEvents.includes(arenaEnd)) roundEvents = [...roundEvents, arenaEnd];
    const summary = summarizeBracketMatch(roundEvents, sourceLabel, `${segmentIndex}-solo-${index + 1}`, {
      ...context,
      bracket: context.bracket || 'Solo Shuffle',
      segmentSource: `solo-shuffle-round-${index + 1}`
    });
    summary.isSoloShuffle = true;
    summary.soloShuffleDerivedRoundNumber = index + 1;
    summary.soloShuffleLobbySeedKey = `solo-segment-${sessionSeed.slice(0, 16)}`;
    summary.soloShuffleDetectedRoundCount = slices.length;
    summary.tags = uniqueList([...(summary.tags || []), `Solo Shuffle round ${index + 1}/${slices.length}`, 'Solo Shuffle lobby split']);
    return summary;
  });
}

function extractBracketMatches(events, sourceLabel, options = {}) {
  const matches = [];
  const allowLogOnlyOpenSegments = Boolean(options && options.allowLogOnlyOpenSegments);
  const logOnlyReason = String((options && options.logOnlyReason) || '');
  const zones = [];
  let active = null;
  let activeBg = null;
  let lastZoneName = '';
  let lastZoneEntry = null;
  let lastOwn = { guid: '', name: '' };

  function finishBattleground(endIndex, reason = 'zone-exit') {
    if (!activeBg) return;
    const safeEnd = Math.max(activeBg.startIndex, Math.min(endIndex, events.length - 1));
    const rawSegment = events.slice(activeBg.startIndex, safeEnd + 1);
    const segment = trimBattlegroundSegmentNoise(rawSegment);
    const nonZoneEvents = segment.filter((item) => item && item.event !== 'ZONE_CHANGE');
    const durationMs = segment.length ? ((segment[segment.length - 1].absoluteMs || 0) - (segment[0].absoluteMs || 0)) : 0;
    const hasRealCombat = nonZoneEvents.some((item) => ['damage', 'healing', 'death', 'cast', 'aura', 'interrupt', 'dispel'].includes(eventKind(item.event)));
    // Avoid turning quick queue pops, loading screens, or empty zone hops into fake BG matches.
    if (segment.length >= 20 && durationMs >= 60 * 1000 && hasRealCombat) {
      const summary = summarizeBracketMatch(segment, sourceLabel, matches.length, {
        zoneName: activeBg.zoneName,
        bracket: activeBg.bracket,
        ownGuid: activeBg.ownGuid || lastOwn.guid || '',
        ownName: activeBg.ownName || lastOwn.name || '',
        segmentSource: `battleground-${reason}`
      });
      summary.detectedFromZoneSegment = true;
      summary.tags = uniqueList([...(summary.tags || []), 'BG zone segment']);
      matches.push(summary);
    }
    activeBg = null;
  }

  function startArena(ev, index) {
    const bracket = cleanSpellName(ev.fields && ev.fields[3] ? ev.fields[3] : 'Arena');
    const isSoloShuffleRound = /shuffle/i.test(bracket);
    const arenaMapName = mapNameFromArenaStart(ev);
    const recentZoneName = lastZoneName && !isRawInstanceMapLabel(lastZoneName) ? lastZoneName : '';
    const zoneLooksRecent = !isSoloShuffleRound && lastZoneEntry && lastZoneEntry.index <= index && ev.absoluteMs && lastZoneEntry.at && (ev.absoluteMs - lastZoneEntry.at) >= 0 && (ev.absoluteMs - lastZoneEntry.at) <= 15 * 60 * 1000;
    active = {
      startIndex: zoneLooksRecent ? lastZoneEntry.index : index,
      zoneName: arenaMapName || (zoneLooksRecent ? recentZoneName : '') || cleanSpellName(ev.fields[1] || 'PvP Arena'),
      bracket,
      isSoloShuffleRound,
      ownGuid: lastOwn.guid || '',
      ownName: lastOwn.name || ''
    };
  }

  function finishArena(endIndex, reason = 'arena-end') {
    if (!active) return;
    const safeEnd = Math.max(active.startIndex, Math.min(endIndex, events.length - 1));
    const segment = events.slice(active.startIndex, safeEnd + 1);
    const hasStart = segment.some((item) => item && item.event === 'ARENA_MATCH_START');
    const hasArenaEnd = segment.some((item) => item && item.event === 'ARENA_MATCH_END');
    const hasRealCombat = segment.some((item) => item && ['damage', 'healing', 'death', 'cast', 'aura', 'interrupt', 'dispel'].includes(eventKind(item.event)));
    const durationMs = segment.length ? ((segment[segment.length - 1].absoluteMs || 0) - (segment[0].absoluteMs || 0)) : 0;
    const inferredEnd = hasStart && !hasArenaEnd && reason !== 'arena-end';
    if (hasStart && (reason === 'arena-end' || inferredEnd || active.isSoloShuffleRound || hasRealCombat || durationMs >= 30 * 1000)) {
      const summaryContext = {
        zoneName: active.zoneName,
        bracket: active.bracket,
        ownGuid: active.ownGuid || lastOwn.guid || '',
        ownName: active.ownName || lastOwn.name || '',
        segmentSource: reason
      };
      if (active.isSoloShuffleRound) {
        const splitRounds = summarizeSoloShuffleLobbyRoundSegments(segment, sourceLabel, matches.length, summaryContext);
        if (splitRounds.length > 1) {
          matches.push(...splitRounds);
          active = null;
          return;
        }
      }
      const summary = summarizeBracketMatch(segment, sourceLabel, matches.length, summaryContext);
      if (inferredEnd) {
        const inferredEvent = segment[segment.length - 1] || null;
        summary.inferredEndTime = inferredEvent && inferredEvent.iso ? inferredEvent.iso : '';
        summary.inferredEndMs = inferredEvent && inferredEvent.absoluteMs ? inferredEvent.absoluteMs : 0;
        summary.endInferred = true;
        summary.captureReason = reason === 'arena-zone-out-without-end' ? 'arena-zone-out-without-end' : reason;
        summary.dataQualityNote = [summary.dataQualityNote, 'Arena was finalized from zone-out/file-end because ARENA_MATCH_END was not present in this log slice.'].filter(Boolean).join(' ');
        summary.tags = uniqueList([...(summary.tags || []), 'Arena end inferred']);
      }
      const isLogOnlyOpenSegment = /^log-only/.test(String(reason || ''));
      if (isLogOnlyOpenSegment) {
        summary.logOnlyDiscovery = true;
        summary.createdFromLogOnly = true;
        summary.logOnlyReason = reason;
        summary.result = summary.result === 'Parsed' ? 'Parsed' : summary.result;
        summary.dataQualityNote = [summary.dataQualityNote, 'Created from combat log only. No final arena end or PvPHelper scoreboard was found yet, so result and final totals may be incomplete.'].filter(Boolean).join(' ');
        summary.danger = summary.dataQualityNote || summary.danger;
        summary.tags = uniqueList([...(summary.tags || []), 'Log-only discovery', 'Needs scoreboard/video']);
      }
      if (active.isSoloShuffleRound) {
        summary.isSoloShuffle = true;
        summary.tags = uniqueList([...(summary.tags || []), 'Solo Shuffle round']);
      }
      matches.push(summary);
    }
    active = null;
  }

  for (let i = 0; i < events.length; i += 1) {
    const ev = events[i];
    lastOwn = noteOwnCandidate(ev, lastOwn);
    if (ev.event === 'ZONE_CHANGE') {
      const nextZoneId = String(ev.fields[1] || '');
      const nextZoneName = cleanSpellName(ev.fields[2] || lastZoneName);
      const bgDisplayName = battlegroundInstanceMapName(nextZoneId) || battlegroundMapNameFromSubzone(nextZoneName) || nextZoneName;
      const nextIsBattleground = Boolean(battlegroundInstanceMapName(nextZoneId)) || isKnownBattlegroundZone(nextZoneName) || isKnownBattlegroundZone(bgDisplayName);
      if (active) {
        finishArena(i, 'arena-zone-out-without-end');
      }
      const sameBattlegroundInstance = Boolean(activeBg && (
        (nextZoneId && nextZoneId !== '0' && String(activeBg.zoneId || '') === nextZoneId)
        || (nextIsBattleground && normalizedMapKey(bgDisplayName) && normalizedMapKey(bgDisplayName) === normalizedMapKey(activeBg.zoneName))
        || (nextIsBattleground && battlegroundMapNameFromSubzone(nextZoneName) && normalizedMapKey(battlegroundMapNameFromSubzone(nextZoneName)) === normalizedMapKey(activeBg.zoneName))
      ));

      // Battleground combat logs often fire ZONE_CHANGE for sub-areas inside the same map
      // such as Warsong Lumber Mill, Arathi nodes, or payload/flag rooms. Those are still
      // the same match. Only end the active BG when the instance/map actually changes or
      // the player leaves to a non-BG zone.
      if (activeBg && !sameBattlegroundInstance) {
        finishBattleground(Math.max(activeBg.startIndex, i - 1), nextIsBattleground ? 'bg-switch' : 'left-zone');
      }

      lastZoneName = nextZoneName;
      zones.push({ index: i, name: nextZoneName, id: nextZoneId, displayName: bgDisplayName });
      lastZoneEntry = { index: i, name: nextZoneName, id: nextZoneId, displayName: bgDisplayName, at: ev.absoluteMs || 0 };
      if (!active && !activeBg && nextIsBattleground) {
        activeBg = {
          startIndex: i,
          zoneId: nextZoneId,
          zoneName: bgDisplayName,
          rawZoneName: nextZoneName,
          bracket: 'Random Battleground',
          ownGuid: lastOwn.guid || '',
          ownName: lastOwn.name || ''
        };
      }
    }

    if (ev.event === 'ARENA_MATCH_START') {
      if (activeBg) finishBattleground(Math.max(activeBg.startIndex, i - 1), 'arena-start');
      const nextIsShuffle = /shuffle/i.test(cleanSpellName(ev.fields && ev.fields[3] ? ev.fields[3] : ''));
      // Solo Shuffle emits ARENA_MATCH_START for every round but usually only one
      // final ARENA_MATCH_END. Keep the full lobby as one segment at the parser layer;
      // round slices are attached to the canonical parent later instead of exposing
      // one row per round.
      if (active && active.isSoloShuffleRound && nextIsShuffle) continue;
      if (active) finishArena(Math.max(active.startIndex, i - 1), nextIsShuffle ? 'solo-shuffle-next-lobby' : 'arena-next-start-without-end');
      startArena(ev, i);
    }

    if (ev.event === 'ARENA_MATCH_END' && active) {
      finishArena(i, 'arena-end');
    }
  }

  // Active/current logs can stop mid-match, so unfinished arenas normally stay pending.
  // For closed/older logs, allow a clearly marked log-only shell so a real game is not invisible
  // just because no video or PvPHelper scoreboard was available yet.
  if (active && allowLogOnlyOpenSegments) finishArena(events.length - 1, logOnlyReason || 'log-only-file-end');
  if (activeBg) finishBattleground(events.length - 1, 'file-end');

  return matches;
}



  return {
    isRealPlayerDeathEvent,
    soloShuffleCombatantClusterStarts,
    soloShuffleRoundSlicesFromLobbySegment,
    summarizeSoloShuffleLobbyRoundSegments,
    extractBracketMatches
  };
}

module.exports = { createCombatLogSegmentTools };
