'use strict';

function createRecordingBackendTools(deps = {}) {
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const crypto = deps.crypto || require('crypto');
  const desktopCapturer = deps.desktopCapturer || null;
  const dialog = deps.dialog || null;
  const ipcMain = deps.ipcMain || null;
  const getMainWindow = typeof deps.getMainWindow === 'function' ? deps.getMainWindow : () => null;
  const readState = typeof deps.readState === 'function' ? deps.readState : () => ({});
  const writeState = typeof deps.writeState === 'function' ? deps.writeState : () => null;
  const defaultSettings = typeof deps.defaultSettings === 'function' ? deps.defaultSettings : () => ({});
  const ensureDir = typeof deps.ensureDir === 'function' ? deps.ensureDir : (dir) => { if (dir) fs.mkdirSync(dir, { recursive: true }); };
  const appStorageDir = typeof deps.appStorageDir === 'function' ? deps.appStorageDir : () => process.cwd();
  const hashText = typeof deps.hashText === 'function' ? deps.hashText : (value) => String(value || '');
  const annotateSoloShuffleSessions = typeof deps.annotateSoloShuffleSessions === 'function' ? deps.annotateSoloShuffleSessions : () => null;
  const linkRecordingSessionToMatches = typeof deps.linkRecordingSessionToMatches === 'function' ? deps.linkRecordingSessionToMatches : () => null;
  const refreshVideoLinkIndexes = typeof deps.refreshVideoLinkIndexes === 'function' ? deps.refreshVideoLinkIndexes : () => null;
  const resolveStateMatchLibrary = typeof deps.resolveStateMatchLibrary === 'function' ? deps.resolveStateMatchLibrary : () => null;
  const compactMutationCollections = typeof deps.compactMutationCollections === 'function' ? deps.compactMutationCollections : () => ({});
  const compactRecentMatchesForResponse = typeof deps.compactRecentMatchesForResponse === 'function' ? deps.compactRecentMatchesForResponse : (state) => state.matches || [];
  const compactVodsForResponse = typeof deps.compactVodsForResponse === 'function' ? deps.compactVodsForResponse : (state) => state.vods || [];
  const runQueuedImportJob = typeof deps.runQueuedImportJob === 'function' ? deps.runQueuedImportJob : async (_id, _label, fn) => fn();

  const activeRecordings = new Map();
  let selectedCaptureSourceId = null;
  let selectedCaptureAudio = true;
  let didRegisterIpcHandlers = false;

  function pad2(value) {
    return String(value).padStart(2, '0');
  }

  function localDateStamp(date = new Date()) {
    const d = date instanceof Date ? date : new Date(date);
    const safe = Number.isNaN(d.getTime()) ? new Date() : d;
    return `${safe.getFullYear()}-${pad2(safe.getMonth() + 1)}-${pad2(safe.getDate())}`;
  }

  function localFileDateTimeStamp(date = new Date()) {
    const d = date instanceof Date ? date : new Date(date);
    const safe = Number.isNaN(d.getTime()) ? new Date() : d;
    return `${localDateStamp(safe)}_${pad2(safe.getHours())}-${pad2(safe.getMinutes())}-${pad2(safe.getSeconds())}`;
  }

  function todayStamp() {
    return localDateStamp(new Date());
  }

  function sanitizeFilePart(value) {
    return String(value || 'recording')
      .replace(/[^a-z0-9-_ ]/gi, '')
      .trim()
      .replace(/\s+/g, '-')
      .slice(0, 60) || 'recording';
  }

  function defaultRecordingsFolderPath() {
    return path.join(appStorageDir(), 'recordings');
  }

  function recordingsRootDir(state = null) {
    const settings = state && state.settings ? state.settings : defaultSettings();
    const root = settings.recordingsDir && settings.recordingsDirConfirmed ? settings.recordingsDir : '';
    if (root) ensureDir(root);
    return root;
  }

  function ensureDefaultRecordingsFolder(state = readState()) {
    const current = state.settings && state.settings.recordingsDir && state.settings.recordingsDirConfirmed ? state.settings.recordingsDir : '';
    if (current) return { ok: true, changed: false, folderPath: current, reason: 'Recording folder already set.' };
    const folderPath = defaultRecordingsFolderPath();
    ensureDir(folderPath);
    state.settings = { ...defaultSettings(), ...(state.settings || {}), recordingsDir: folderPath, recordingsDirConfirmed: true };
    return { ok: true, changed: true, folderPath, reason: 'Default recording folder connected.' };
  }

  function isVideoFileName(fileName) {
    return /\.(webm|mp4|mov|mkv|avi)$/i.test(String(fileName || ''));
  }

  function scanVideoFiles(root, limit = 5000) {
    const found = [];
    if (!root || !fs.existsSync(root)) return found;
    const stack = [root];
    while (stack.length && found.length < limit) {
      const current = stack.pop();
      let entries = [];
      try { entries = fs.readdirSync(current, { withFileTypes: true }); } catch (_error) { continue; }
      for (const entry of entries) {
        const full = path.join(current, entry.name);
        if (entry.isDirectory()) {
          if (/node_modules|dist|win-unpacked|\.git/i.test(entry.name)) continue;
          stack.push(full);
        } else if (entry.isFile() && isVideoFileName(entry.name)) {
          found.push(full);
          if (found.length >= limit) break;
        }
      }
    }
    return found;
  }

  function recordingRecordFromFile(filePath, existing = null) {
    let stat = null;
    try { stat = fs.statSync(filePath); } catch (_error) {}
    const stamp = stat ? new Date(stat.birthtimeMs || stat.mtimeMs) : new Date();
    return {
      id: existing && existing.id ? existing.id : `vid_${hashText(path.normalize(filePath).toLowerCase()).slice(0, 16)}`,
      filePath,
      label: existing && existing.label ? existing.label : 'Local video',
      sourceName: existing && existing.sourceName ? existing.sourceName : 'Local video',
      matchId: existing && existing.matchId ? existing.matchId : '',
      startedAt: existing && existing.startedAt ? existing.startedAt : stamp.toISOString(),
      endedAt: existing && existing.endedAt ? existing.endedAt : '',
      status: existing && existing.status ? existing.status : 'saved',
      bytes: stat ? stat.size : (existing && existing.bytes) || 0,
      chunks: existing && existing.chunks ? existing.chunks : 0,
      scanned: true
    };
  }

  function bestRecordingPickerPath(state = null, preferredDate = null) {
    const root = recordingsRootDir(state);
    if (!root || !fs.existsSync(root)) return appStorageDir();
    const candidates = [];
    const addCandidate = (candidatePath, score = 0) => {
      try {
        if (!candidatePath || !fs.existsSync(candidatePath)) return;
        const stat = fs.statSync(candidatePath);
        candidates.push({ path: candidatePath, mtimeMs: stat.mtimeMs, score });
      } catch (_error) {}
    };
    try {
      const preferred = preferredDate ? localDateStamp(preferredDate) : '';
      if (preferred) addCandidate(path.join(root, preferred), 1000000);
      addCandidate(path.join(root, todayStamp()), 900000);
      const entries = fs.readdirSync(root, { withFileTypes: true });
      for (const entry of entries) {
        const full = path.join(root, entry.name);
        if (entry.isDirectory()) {
          const videos = fs.readdirSync(full).filter(isVideoFileName);
          if (videos.length || /^\d{4}-\d{2}-\d{2}$/.test(entry.name)) addCandidate(full, entry.name === preferred ? 1000000 : 0);
        } else if (entry.isFile() && isVideoFileName(entry.name)) {
          addCandidate(root, 0);
        }
      }
      candidates.sort((a, b) => (b.score - a.score) || (b.mtimeMs - a.mtimeMs));
      return (candidates[0] && candidates[0].path) || root;
    } catch (_error) {
      return root;
    }
  }

  function intervalsOverlap(aStart, aEnd, bStart, bEnd) {
    if (!aStart || !bStart) return false;
    const a2 = aEnd || aStart;
    const b2 = bEnd || bStart;
    return aStart <= b2 && bStart <= a2;
  }

  function confidentRecordingMatchOverlap(recStart, recEnd, matchStart, matchEnd, bufferMs = 90000) {
    if (!recStart || !recEnd || !matchStart || !matchEnd || recEnd <= recStart || matchEnd <= matchStart) return false;
    const bufferedStart = recStart - bufferMs;
    const bufferedEnd = recEnd + bufferMs;
    if (!intervalsOverlap(bufferedStart, bufferedEnd, matchStart, matchEnd)) return false;
    const overlapStart = Math.max(recStart, matchStart);
    const overlapEnd = Math.min(recEnd, matchEnd);
    const overlapMs = Math.max(0, overlapEnd - overlapStart);
    const matchMs = Math.max(1, matchEnd - matchStart);
    return overlapMs >= Math.min(45000, matchMs * 0.25) || (matchStart >= bufferedStart && matchStart <= bufferedEnd);
  }

  function matchRecordingLabel(match) {
    if (!match) return '';
    const d = match.startIso ? new Date(match.startIso) : (match.startMs ? new Date(match.startMs) : new Date());
    const day = Number.isNaN(d.getTime()) ? '' : d.toLocaleDateString();
    const clock = Number.isNaN(d.getTime()) ? '' : d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    const type = match.matchType || match.bracket || 'PvP Match';
    const map = match.map || 'Unknown Map';
    const toon = match.alt || match.ownName || 'Unknown Toon';
    return [day && clock ? `${day} ${clock}` : '', type, map, toon].filter(Boolean).join(' · ');
  }

  function clearVideoFields(match = {}) {
    const clone = { ...match };
    delete clone.videoPath;
    delete clone.videoLabel;
    delete clone.videoLinkedAt;
    delete clone.videoLinkMode;
    delete clone.videoSessionId;
    delete clone.vodId;
    delete clone.vodLinkedAt;
    delete clone.videoClipStartSec;
    delete clone.videoClipEndSec;
    delete clone.videoMatchStartSec;
    delete clone.videoMatchEndSec;
    delete clone.videoShuffleStartSec;
    delete clone.videoShuffleEndSec;
    delete clone.videoClipPreRollSec;
    delete clone.videoClipPostRollSec;
    delete clone.videoSyncAdjustmentSec;
    delete clone.manualVideoSection;
    delete clone.videoSectionUpdatedAt;
    if (Array.isArray(clone.dataSources)) clone.dataSources = clone.dataSources.filter((source) => source !== 'video' && source !== 'vod' && source !== 'recordingSession');
    return clone;
  }

  function autoLinkRecordings(state, newMatches = []) {
    if (!Array.isArray(state.recordings) || !Array.isArray(state.matches)) return state;
    annotateSoloShuffleSessions(state);
    const matches = newMatches.length ? newMatches : state.matches;
    const configuredWindow = Number(state.settings && state.settings.autoLinkWindowMinutes);
    const windowMs = Math.max(0, Number.isFinite(configuredWindow) ? configuredWindow : 0) * 60 * 1000;
    for (const rec of state.recordings) {
      if (!rec || rec.manualLinked || !rec.filePath) continue;
      const recStart = rec.startedAt ? Date.parse(rec.startedAt) : 0;
      const recEnd = rec.endedAt ? Date.parse(rec.endedAt) : 0;
      if (!recStart) continue;

      if (recEnd && recEnd > recStart) {
        linkRecordingSessionToMatches(state, rec, matches);
        continue;
      }

      const alreadyLinked = rec.matchId || (Array.isArray(rec.linkedMatchIds) && rec.linkedMatchIds.length);
      if (alreadyLinked) continue;
      const eligible = matches.filter((match) => match && !match.videoPath).map((match) => {
        const matchStart = match.startIso ? Date.parse(match.startIso) : match.startMs || 0;
        const matchEnd = match.endIso ? Date.parse(match.endIso) : match.endMs || 0;
        if (!matchStart) return null;
        const overlap = recEnd && matchEnd ? confidentRecordingMatchOverlap(recStart, recEnd, matchStart, matchEnd, 0) : false;
        const distance = Math.abs(matchStart - recStart);
        const close = windowMs > 0 && distance <= windowMs;
        if (!overlap && !close) return null;
        return { match, overlap, distance };
      }).filter(Boolean).sort((a, b) => (b.overlap - a.overlap) || (a.distance - b.distance));
      if (!eligible.length) continue;
      const first = eligible[0];
      const second = eligible[1];
      if (second && first.overlap === second.overlap && Math.abs(first.distance - second.distance) < 15000) continue;
      const label = matchRecordingLabel(first.match) || rec.label || rec.sourceName || path.basename(rec.filePath || 'Recording');
      rec.matchId = first.match.id;
      rec.linkedMatchIds = [first.match.id];
      rec.linkedCount = 1;
      rec.autoLinked = true;
      rec.linkedAt = new Date().toISOString();
      rec.label = label;
      first.match.videoPath = rec.filePath || first.match.videoPath || '';
      first.match.videoLabel = label;
      first.match.videoLinkedAt = rec.linkedAt;
      first.match.videoLinkMode = 'auto';
    }
    refreshVideoLinkIndexes(state);
    return state;
  }

  function compactRecordingRecord(item = {}) {
    if (!item || typeof item !== 'object') return null;
    return {
      id: String(item.id || ''),
      filePath: String(item.filePath || ''),
      label: String(item.label || '').slice(0, 140),
      sourceName: String(item.sourceName || '').slice(0, 100),
      matchId: String(item.matchId || ''),
      linkedMatchIds: Array.isArray(item.linkedMatchIds) ? item.linkedMatchIds.slice(0, 80).map((id) => String(id || '')).filter(Boolean) : [],
      linkedCount: Number(item.linkedCount || 0),
      includeAudio: Boolean(item.includeAudio),
      audioTrackCount: Number(item.audioTrackCount || 0),
      audioCaptured: Boolean(item.audioCaptured),
      startedAt: String(item.startedAt || ''),
      endedAt: String(item.endedAt || ''),
      status: String(item.status || ''),
      bytes: Number(item.bytes || 0),
      chunks: Number(item.chunks || 0),
      stopReason: String(item.stopReason || '').slice(0, 120),
      scanned: Boolean(item.scanned),
      externalLink: Boolean(item.externalLink),
      manualLinked: Boolean(item.manualLinked),
      autoLinked: Boolean(item.autoLinked),
      linkedAt: String(item.linkedAt || '')
    };
  }

  function compactRecordingsForResponse(state = {}, limit = 120) {
    const rows = Array.isArray(state.recordings) ? state.recordings : [];
    return rows
      .filter(Boolean)
      .slice()
      .sort((a, b) => {
        const aTime = Date.parse(a && (a.startedAt || a.endedAt || a.linkedAt) || '') || 0;
        const bTime = Date.parse(b && (b.startedAt || b.endedAt || b.linkedAt) || '') || 0;
        return bTime - aTime;
      })
      .slice(0, Math.max(1, Number(limit || 120)))
      .map(compactRecordingRecord)
      .filter(Boolean);
  }

  async function getSafeCaptureSources() {
    if (!desktopCapturer || typeof desktopCapturer.getSources !== 'function') throw new Error('Capture sources are unavailable.');
    const options = [
      { types: ['screen', 'window'], thumbnailSize: { width: 0, height: 0 }, fetchWindowIcons: false },
      { types: ['screen'], thumbnailSize: { width: 0, height: 0 }, fetchWindowIcons: false }
    ];
    let lastError = null;
    for (const option of options) {
      try {
        return await desktopCapturer.getSources(option);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error('Could not list capture sources');
  }

  function getSelectedCaptureSourceId() {
    return selectedCaptureSourceId;
  }

  function getSelectedCaptureAudio() {
    return selectedCaptureAudio;
  }

  function selectCaptureSource(payload) {
    selectedCaptureSourceId = payload && payload.sourceId ? String(payload.sourceId) : null;
    selectedCaptureAudio = Boolean(payload && payload.includeAudio);
    return { ok: Boolean(selectedCaptureSourceId), sourceId: selectedCaptureSourceId, includeAudio: selectedCaptureAudio };
  }

  function saveRecorderSettings(settings) {
    const state = readState();
    state.recorderSettings = {
      includeAudio: Object.prototype.hasOwnProperty.call(settings || {}, 'includeAudio') ? Boolean(settings.includeAudio) : true,
      performanceMode: ['low', 'balanced', 'quality'].includes(String(settings && settings.performanceMode || '')) ? String(settings.performanceMode) : 'balanced',
      approvedWowSourceNames: Array.isArray(settings && settings.approvedWowSourceNames)
        ? Array.from(new Set(settings.approvedWowSourceNames.map((item) => String(item || '').trim()).filter(Boolean)))
        : Array.isArray(state.recorderSettings && state.recorderSettings.approvedWowSourceNames) ? state.recorderSettings.approvedWowSourceNames : []
    };
    writeState(state);
    return state.recorderSettings;
  }

  function createRecording(payload = {}) {
    const state = readState();
    const recordingRoot = recordingsRootDir(state);
    if (!recordingRoot) return { ok: false, reason: 'Choose a recordings folder before starting a recording.' };
    const dateFolder = path.join(recordingRoot, todayStamp());
    ensureDir(dateFolder);
    const id = `rec_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
    const now = new Date();
    const sourceName = payload && payload.sourceName ? String(payload.sourceName) : 'Recording';
    const label = `Recording · ${sourceName}`;
    const fileLabel = sanitizeFilePart(sourceName);
    const filePath = path.join(dateFolder, `${localFileDateTimeStamp(now)}__Recording__${fileLabel}.webm`);
    fs.writeFileSync(filePath, Buffer.alloc(0));
    const record = {
      id,
      filePath,
      label,
      sourceName,
      matchId: payload && payload.matchId ? String(payload.matchId) : '',
      includeAudio: Object.prototype.hasOwnProperty.call(payload || {}, 'includeAudio') ? Boolean(payload.includeAudio) : true,
      startedAt: now.toISOString(),
      status: 'recording',
      bytes: 0,
      chunks: 0
    };
    activeRecordings.set(id, record);
    state.recordings = state.recordings || [];
    state.recordings.unshift(record);
    writeState(state);
    return { ok: true, recordingId: id, filePath };
  }

  function appendRecordingChunk(payload = {}) {
    const recordingId = payload && payload.recordingId;
    const chunk = payload && payload.chunk;
    const record = activeRecordings.get(recordingId);
    if (!record) return { ok: false, reason: 'Recording is not active' };
    const buffer = Buffer.from(chunk);
    fs.appendFileSync(record.filePath, buffer);
    record.bytes += buffer.length;
    record.chunks += 1;
    return { ok: true, bytes: record.bytes, chunks: record.chunks };
  }

  function finishRecording(payload = {}) {
    const recordingId = payload && payload.recordingId;
    const record = activeRecordings.get(recordingId);
    const state = readState();
    state.recordings = state.recordings || [];
    const now = new Date().toISOString();
    const reason = payload && payload.reason ? String(payload.reason) : 'Manual stop';

    let finalRecord = record || state.recordings.find((item) => item.id === recordingId);
    if (!finalRecord) return { ok: false, reason: 'Recording not found' };

    if (fs.existsSync(finalRecord.filePath)) {
      const stat = fs.statSync(finalRecord.filePath);
      finalRecord.bytes = stat.size;
    }
    finalRecord.status = 'saved';
    finalRecord.endedAt = now;
    finalRecord.stopReason = reason;
    if (payload && payload.audioTrackCount !== undefined) {
      finalRecord.audioTrackCount = Math.max(0, Number(payload.audioTrackCount) || 0);
      finalRecord.audioCaptured = finalRecord.audioTrackCount > 0;
    }

    state.recordings = state.recordings.map((item) => item.id === recordingId ? { ...item, ...finalRecord } : item);
    autoLinkRecordings(state, state.matches || []);
    writeState(state);
    finalRecord = state.recordings.find((item) => item.id === recordingId) || finalRecord;
    activeRecordings.delete(recordingId);
    return {
      ok: true,
      recording: compactRecordingRecord(finalRecord),
      ...compactMutationCollections(state, {
        changedRecordings: [finalRecord],
        changedMatches: compactRecentMatchesForResponse(state, 80),
        changedVods: compactVodsForResponse(state, 40)
      })
    };
  }

  function scanRecordingsFolder() {
    return runQueuedImportJob('video-scan', 'Indexing Videos', async (progress) => {
      progress({ detail: 'Scanning recordings folder', percent: 5 });
      const state = readState();
      const root = recordingsRootDir(state);
      if (!root) return { ok: false, reason: 'Choose a recordings folder first.', recordings: state.recordings || [], matches: state.matches || [] };
      const files = scanVideoFiles(root);
      progress({ detail: `Found ${files.length} video file${files.length === 1 ? '' : 's'}`, percent: 30 });
      const existingByPath = new Map((state.recordings || []).filter(Boolean).map((rec) => [path.normalize(String(rec.filePath || '')).toLowerCase(), rec]));
      let added = 0;
      const addedRecords = [];
      const merged = [...(state.recordings || [])];
      const usedIds = new Set(merged.map((rec) => rec && rec.id).filter(Boolean));
      for (let fileIndex = 0; fileIndex < files.length; fileIndex += 1) {
        const filePath = files[fileIndex];
        if (fileIndex % 10 === 0) progress({ detail: `Indexing video ${fileIndex + 1}/${files.length}`, percent: Math.min(88, 35 + Math.round((fileIndex / Math.max(1, files.length)) * 50)) });
        const norm = path.normalize(filePath).toLowerCase();
        if (existingByPath.has(norm)) continue;
        let record = recordingRecordFromFile(filePath);
        if (usedIds.has(record.id)) record = { ...record, id: `vid_${Date.now()}_${crypto.randomBytes(3).toString('hex')}` };
        usedIds.add(record.id);
        merged.unshift(record);
        addedRecords.push(record);
        existingByPath.set(norm, record);
        added += 1;
      }
      state.recordings = merged;
      resolveStateMatchLibrary(state, 'recording-scan', { autoLink: true });
      progress({ detail: 'Saving indexed videos', percent: 94 });
      writeState(state);
      return {
        ok: true,
        root,
        found: files.length,
        added,
        ...compactMutationCollections(state, {
          changedRecordings: addedRecords.length ? addedRecords : compactRecordingsForResponse(state, 120),
          changedMatches: compactRecentMatchesForResponse(state, 80),
          changedVods: compactVodsForResponse(state, 40)
        })
      };
    }, { key: 'video-scan:index-recordings', exclusiveGroup: 'video-scan-heavy', groupBusyMessage: 'Video indexing is already running. Duplicate scan skipped safely.' });
  }

  async function chooseRecordingsFolder() {
    if (!dialog) return null;
    const result = await dialog.showOpenDialog(getMainWindow(), {
      title: 'Select recordings folder',
      properties: ['openDirectory']
    });
    if (result.canceled) return null;
    const state = readState();
    state.settings.recordingsDir = result.filePaths[0];
    state.settings.recordingsDirConfirmed = true;
    ensureDir(state.settings.recordingsDir);
    writeState(state);
    return { recordingsDir: state.settings.recordingsDir };
  }

  function linkVideoFileToMatch(payload = {}) {
    const matchId = payload && payload.matchId ? String(payload.matchId) : '';
    const filePath = payload && payload.filePath ? String(payload.filePath) : '';
    if (!matchId || !filePath || !fs.existsSync(filePath)) return { ok: false, reason: 'Video file not found' };
    const stat = fs.statSync(filePath);
    const state = readState();
    state.recordings = state.recordings || [];
    state.matches = state.matches || [];
    const norm = path.normalize(filePath).toLowerCase();
    const targetMatch = (state.matches || []).find((match) => match && match.id === matchId);
    const label = matchRecordingLabel(targetMatch) || path.basename(filePath);
    const nowIso = new Date().toISOString();

    state.recordings = state.recordings.map((rec) => {
      if (!rec) return rec;
      const recNorm = rec.filePath ? path.normalize(String(rec.filePath)).toLowerCase() : '';
      if (rec.matchId === matchId || recNorm === norm) return { ...rec, matchId: '', autoLinked: false };
      return rec;
    });
    state.matches = state.matches.map((match) => {
      if (!match) return match;
      const matchVideoNorm = match.videoPath ? path.normalize(String(match.videoPath)).toLowerCase() : '';
      if (match.id === matchId) {
        return { ...match, videoPath: filePath, videoLabel: label, videoLinkedAt: nowIso, videoLinkMode: 'manual' };
      }
      if (matchVideoNorm === norm) return clearVideoFields(match);
      return match;
    });
    let record = state.recordings.find((item) => item && item.filePath && path.normalize(String(item.filePath)).toLowerCase() === norm);
    if (record) {
      record = { ...record, matchId, manualLinked: true, autoLinked: false, linkedAt: nowIso, label: record.label || label, bytes: record.bytes || stat.size };
      state.recordings = state.recordings.map((item) => item && item.id === record.id ? record : item);
    } else {
      record = {
        id: `link_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
        filePath,
        label,
        sourceName: 'Linked video',
        matchId,
        startedAt: new Date(stat.mtimeMs).toISOString(),
        status: 'linked',
        bytes: stat.size,
        chunks: 0,
        externalLink: true,
        manualLinked: true,
        linkedAt: nowIso
      };
      state.recordings.unshift(record);
    }
    refreshVideoLinkIndexes(state);
    writeState(state);
    return { ok: true, recording: compactRecordingRecord(record), ...compactMutationCollections(state, { changedRecordings: [record], changedMatches: compactRecentMatchesForResponse(state, 80), changedVods: compactVodsForResponse(state, 40) }) };
  }

  function dedupeRecordings() {
    const state = readState();
    const seen = new Map();
    const cleaned = [];
    let removed = 0;
    for (const rec of state.recordings || []) {
      if (!rec) continue;
      const filePath = rec.filePath ? path.normalize(String(rec.filePath)).toLowerCase() : '';
      const key = filePath || `${rec.sourceName || ''}|${rec.startedAt || ''}|${rec.bytes || 0}`;
      const existingIndex = seen.get(key);
      if (existingIndex === undefined) {
        seen.set(key, cleaned.length);
        cleaned.push(rec);
        continue;
      }
      const existing = cleaned[existingIndex];
      const currentScore = (rec.matchId ? 4 : 0) + (rec.status === 'complete' ? 2 : 0) + (rec.bytes ? 1 : 0);
      const existingScore = (existing.matchId ? 4 : 0) + (existing.status === 'complete' ? 2 : 0) + (existing.bytes ? 1 : 0);
      if (currentScore > existingScore) cleaned[existingIndex] = rec;
      removed += 1;
    }
    state.recordings = cleaned;
    writeState(state);
    return { ok: true, changedRecordings: compactRecordingsForResponse(state, 160), removed, ...compactMutationCollections(state) };
  }

  function deleteRecording(payload = {}) {
    const state = readState();
    const recordingId = payload && payload.recordingId ? String(payload.recordingId) : '';
    const deleteFile = Boolean(payload && payload.deleteFile);
    if (!recordingId) return { ok: false, reason: 'Recording not found' };
    let deletedFile = '';
    state.recordings = (state.recordings || []).filter((rec) => {
      if (!rec || rec.id !== recordingId) return true;
      deletedFile = rec.filePath || '';
      return false;
    });
    if (deleteFile && deletedFile && fs.existsSync(deletedFile)) {
      try { fs.rmSync(deletedFile, { force: true }); } catch (_error) {}
    }
    if (deletedFile) {
      const normDeleted = path.normalize(deletedFile).toLowerCase();
      state.vods = (state.vods || []).filter((vod) => !(vod && (vod.recordingId === recordingId || (vod.filePath && path.normalize(String(vod.filePath)).toLowerCase() === normDeleted && vod.sourceType === 'recording-session'))));
      state.matches = (state.matches || []).map((match) => {
        if (!match || !match.videoPath || path.normalize(String(match.videoPath)).toLowerCase() !== normDeleted) return match;
        return clearVideoFields(match);
      });
    }
    refreshVideoLinkIndexes(state);
    writeState(state);
    return { ok: true, deletedFile, ...compactMutationCollections(state, { removedRecordingIds: [recordingId], changedMatches: compactRecentMatchesForResponse(state, 80), changedVods: compactVodsForResponse(state, 60) }) };
  }

  function unlinkRecording(payload = {}) {
    const state = readState();
    const recordingId = payload && payload.recordingId ? String(payload.recordingId) : '';
    if (!recordingId) return { ok: false, reason: 'Recording not found' };
    let removedPath = '';
    state.recordings = (state.recordings || []).map((rec) => {
      if (rec && rec.id === recordingId) {
        removedPath = rec.filePath || '';
        return { ...rec, matchId: '', linkedMatchIds: [], linkedCount: 0, autoLinked: false, manualLinked: false };
      }
      return rec;
    });
    if (removedPath) {
      const normRemoved = path.normalize(removedPath).toLowerCase();
      state.matches = (state.matches || []).map((match) => {
        if (!match || !match.videoPath || path.normalize(String(match.videoPath)).toLowerCase() !== normRemoved) return match;
        if (match.videoSessionId && match.videoSessionId !== recordingId) return match;
        return clearVideoFields(match);
      });
    }
    refreshVideoLinkIndexes(state);
    writeState(state);
    return { ok: true, ...compactMutationCollections(state, { changedRecordings: compactRecordingsForResponse(state, 80), changedMatches: compactRecentMatchesForResponse(state, 80), changedVods: compactVodsForResponse(state, 40) }) };
  }

  function unlinkVideoFromMatch(payload = {}) {
    const state = readState();
    const matchId = payload && payload.matchId ? String(payload.matchId) : '';
    const filePath = payload && payload.filePath ? String(payload.filePath) : '';
    if (!matchId) return { ok: false, reason: 'Match not found' };
    const norm = filePath ? path.normalize(filePath).toLowerCase() : '';
    state.recordings = (state.recordings || []).map((rec) => {
      if (!rec || rec.matchId !== matchId) return rec;
      if (norm && (!rec.filePath || path.normalize(String(rec.filePath)).toLowerCase() !== norm)) return rec;
      return { ...rec, matchId: '', autoLinked: false, manualLinked: false };
    });
    state.matches = (state.matches || []).map((match) => {
      if (!match || match.id !== matchId) return match;
      if (norm && match.videoPath && path.normalize(String(match.videoPath)).toLowerCase() !== norm) return match;
      return clearVideoFields(match);
    });
    refreshVideoLinkIndexes(state);
    writeState(state);
    return { ok: true, ...compactMutationCollections(state, { changedRecordings: compactRecordingsForResponse(state, 80), changedMatches: compactRecentMatchesForResponse(state, 80), changedVods: compactVodsForResponse(state, 40) }) };
  }

  function registerIpcHandlers() {
    if (!ipcMain || didRegisterIpcHandlers) return false;
    didRegisterIpcHandlers = true;

    ipcMain.handle('list-capture-sources', async () => {
      try {
        const sources = await getSafeCaptureSources();
        return sources.map((source) => ({
          id: source.id,
          name: source.name,
          displayId: source.display_id || '',
          kind: String(source.id || '').toLowerCase().startsWith('screen:') ? 'screen' : 'program',
          thumbnail: source.thumbnail && !source.thumbnail.isEmpty() ? source.thumbnail.toDataURL() : '',
          error: ''
        }));
      } catch (error) {
        return [{
          id: '',
          name: 'Capture sources unavailable',
          displayId: '',
          kind: 'error',
          thumbnail: '',
          error: error && error.message ? error.message : 'Unable to list capture sources'
        }];
      }
    });

    ipcMain.handle('set-capture-source', async (_event, payload) => selectCaptureSource(payload));
    ipcMain.handle('save-recorder-settings', async (_event, settings) => saveRecorderSettings(settings));
    ipcMain.handle('create-recording', async (_event, payload) => createRecording(payload));
    ipcMain.handle('append-recording-chunk', async (_event, payload) => appendRecordingChunk(payload));
    ipcMain.handle('finish-recording', async (_event, payload) => finishRecording(payload));
    ipcMain.handle('get-recordings', async () => (readState().recordings || []));
    ipcMain.handle('scan-recordings-folder', async () => scanRecordingsFolder());
    ipcMain.handle('select-recordings-folder', async () => chooseRecordingsFolder());
    ipcMain.handle('link-video-file-to-match', async (_event, payload) => linkVideoFileToMatch(payload));
    ipcMain.handle('dedupe-recordings', async () => dedupeRecordings());
    ipcMain.handle('delete-recording', async (_event, payload) => deleteRecording(payload));
    ipcMain.handle('unlink-recording', async (_event, payload) => unlinkRecording(payload));
    ipcMain.handle('unlink-video-from-match', async (_event, payload) => unlinkVideoFromMatch(payload));
    return true;
  }

  return {
    defaultRecordingsFolderPath,
    ensureDefaultRecordingsFolder,
    recordingsRootDir,
    isVideoFileName,
    scanVideoFiles,
    recordingRecordFromFile,
    bestRecordingPickerPath,
    intervalsOverlap,
    confidentRecordingMatchOverlap,
    autoLinkRecordings,
    localDateStamp,
    localFileDateTimeStamp,
    todayStamp,
    matchRecordingLabel,
    compactRecordingRecord,
    compactRecordingsForResponse,
    getSafeCaptureSources,
    getSelectedCaptureSourceId,
    getSelectedCaptureAudio,
    registerIpcHandlers
  };
}

module.exports = { createRecordingBackendTools };
