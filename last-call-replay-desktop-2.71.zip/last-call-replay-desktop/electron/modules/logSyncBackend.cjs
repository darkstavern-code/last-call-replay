'use strict';

function createLogSyncBackendTools(deps = {}) {
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const defaultSettings = typeof deps.defaultSettings === 'function' ? deps.defaultSettings : (() => ({}));
  const readState = typeof deps.readState === 'function' ? deps.readState : (() => ({}));
  const writeState = typeof deps.writeState === 'function' ? deps.writeState : (() => {});
  const matchTargetTimeMs = typeof deps.matchTargetTimeMs === 'function' ? deps.matchTargetTimeMs : (() => 0);
  const logFileApproxTimeMs = typeof deps.logFileApproxTimeMs === 'function' ? deps.logFileApproxTimeMs : (() => 0);
  const logFileEntryWeight = typeof deps.logFileEntryWeight === 'function' ? deps.logFileEntryWeight : (() => 0);
  const getCandidateLogFolders = typeof deps.getCandidateLogFolders === 'function' ? deps.getCandidateLogFolders : (() => []);
  const getLogFileSummaryInFolder = typeof deps.getLogFileSummaryInFolder === 'function' ? deps.getLogFileSummaryInFolder : (() => ({ files: [], totalFiles: 0, statLimited: false }));
  const startupLightLogStatus = typeof deps.startupLightLogStatus === 'function' ? deps.startupLightLogStatus : (() => ({ skipTail: false }));
  const buildLogFileRoster = typeof deps.buildLogFileRoster === 'function' ? deps.buildLogFileRoster : (() => ({ folders: [], filesWithFolder: [], infos: [] }));
  const rememberLogFileInfo = typeof deps.rememberLogFileInfo === 'function' ? deps.rememberLogFileInfo : (() => {});
  const buildLogFileInfo = typeof deps.buildLogFileInfo === 'function' ? deps.buildLogFileInfo : (() => null);
  const processActiveLogTail = typeof deps.processActiveLogTail === 'function' ? deps.processActiveLogTail : (() => ({ ok: true, parsed: 0, imported: 0, updated: 0, bytes: 0 }));
  const importLogFileChunkedIntoState = typeof deps.importLogFileChunkedIntoState === 'function' ? deps.importLogFileChunkedIntoState : (() => ({ ok: true, parsed: 0, imported: 0, updated: 0, bytes: 0 }));
  const importLogFileWindowedForMatchIntoState = typeof deps.importLogFileWindowedForMatchIntoState === 'function' ? deps.importLogFileWindowedForMatchIntoState : (() => ({ ok: true, parsed: 0, imported: 0, updated: 0, bytes: 0, windowed: true }));
  const normalizeMatchDataSources = typeof deps.normalizeMatchDataSources === 'function' ? deps.normalizeMatchDataSources : ((match) => match);
  const matchNeedsCombatLog = typeof deps.matchNeedsCombatLog === 'function' ? deps.matchNeedsCombatLog : (() => false);
  const addonMatchScore = typeof deps.addonMatchScore === 'function' ? deps.addonMatchScore : (() => 0);
  const mergeUserPreservedMatchFields = typeof deps.mergeUserPreservedMatchFields === 'function' ? deps.mergeUserPreservedMatchFields : ((incoming) => incoming);
  const dedupeStateMatches = typeof deps.dedupeStateMatches === 'function' ? deps.dedupeStateMatches : (() => {});
  const autoLinkRecordings = typeof deps.autoLinkRecordings === 'function' ? deps.autoLinkRecordings : (() => {});
  const logRegistryKey = typeof deps.logRegistryKey === 'function' ? deps.logRegistryKey : ((filePath) => String(filePath || ''));
  const sanitizeMatchForStorage = typeof deps.sanitizeMatchForStorage === 'function' ? deps.sanitizeMatchForStorage : ((match) => match);
  const compactRecentMatchesForResponse = typeof deps.compactRecentMatchesForResponse === 'function' ? deps.compactRecentMatchesForResponse : ((state) => (state.matches || []));
  const uniqueList = typeof deps.uniqueList === 'function' ? deps.uniqueList : ((values = []) => Array.from(new Set((values || []).filter(Boolean).map((value) => String(value)))));
  const compactImportedFilesForResponse = typeof deps.compactImportedFilesForResponse === 'function' ? deps.compactImportedFilesForResponse : ((state) => (state.importedFiles || []));
  const compactLogRegistryForResponse = typeof deps.compactLogRegistryForResponse === 'function' ? deps.compactLogRegistryForResponse : ((state) => (state.logFileRegistry || {}));

  const MATCH_LOG_TIME_PAD_MS = Number(deps.matchLogTimePadMs || (15 * 60 * 1000));
  const MAX_TARGETED_LOG_SYNC_BYTES = Number(deps.maxTargetedLogSyncBytes || (320 * 1024 * 1024));
  const MAX_MATCH_TARGETED_LOG_SYNC_BYTES = Number(deps.maxMatchTargetedLogSyncBytes || (1024 * 1024 * 1024));
  const STARTUP_CHANGED_LOG_SWEEP_LIMIT = Number(deps.startupChangedLogSweepLimit || 8);
  const STARTUP_REPAIR_MAX_MATCHES = Number(deps.startupRepairMaxMatches || 20);
  const STARTUP_REPAIR_MAX_FILES_PER_MATCH = Number(deps.startupRepairMaxFilesPerMatch || 2);
  const REFRESH_ACTIVE_MAX_PASSES = Number(deps.refreshActiveMaxPasses || 6);
  const REFRESH_CHANGED_LOG_SWEEP_LIMIT = Number(deps.refreshChangedLogSweepLimit || 2);
  const REFRESH_REPAIR_MAX_MATCHES = Number(deps.refreshRepairMaxMatches || 3);
  const REFRESH_REPAIR_MAX_FILES_PER_MATCH = Number(deps.refreshRepairMaxFilesPerMatch || 1);
  const STARTUP_ACTIVE_TAIL_READ_BYTES = Number(deps.startupActiveTailReadBytes || (512 * 1024));
  const MAX_ACTIVE_TAIL_READ_BYTES = Number(deps.maxActiveTailReadBytes || (8 * 1024 * 1024));
  const REFRESH_ACTIVE_TAIL_READ_BYTES = Number(deps.refreshActiveTailReadBytes || (4 * 1024 * 1024));
  const MAX_WINDOW_SCAN_BYTES = Number(deps.maxWindowScanBytes || (192 * 1024 * 1024));
  const REFRESH_WINDOW_SCAN_BYTES = Number(deps.refreshWindowScanBytes || (96 * 1024 * 1024));

  function logRegistryEntryLooksFullyScanned(entry = {}) {
    const status = String(entry && entry.status || '').toLowerCase();
    if (!status) return false;
    if (/partial|indexed|selected|window|repair/.test(status)) return false;
    return /active-tail-scanned|changed-log-sweep-scanned|active-resumed-from-cache|initial-backfill|full|imported|manual/.test(status);
  }


  function isSoloShuffleLikeMatch(match = {}) {
    const raw = `${match.matchType || ''} ${match.bracket || ''} ${match.matchLabel || ''}`;
    return Boolean(match && (match.isSoloShuffle || match.isSoloShuffleLobby || /shuffle/i.test(raw)));
  }

  function incompleteVisibleSoloShuffleMatch(match = {}) {
    if (!match || !isSoloShuffleLikeMatch(match)) return false;
    if (match.hideFromMatchLibrary || match.isSoloShuffleRoundChild) return false;
    const detected = Number(match.soloShuffleDetectedRoundCount || (Array.isArray(match.soloRounds) ? match.soloRounds.length : 0)) || 0;
    if (match.isSoloShuffleLobby) return detected > 0 && detected < 6;
    return true;
  }

  function repairIncompleteSoloShuffleSessionsFromLog(state = {}, info = {}, options = {}) {
    if (!state || !info || !info.filePath || !fs.existsSync(info.filePath)) return { filesScanned: 0, parsed: 0, imported: 0, updated: 0, repaired: 0, details: [] };
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : (() => {});
    const candidates = (state.matches || [])
      .filter(incompleteVisibleSoloShuffleMatch)
      .sort((a, b) => (Number(matchTargetTimeMs(b)) || 0) - (Number(matchTargetTimeMs(a)) || 0))
      .slice(0, Math.max(1, Number(options.maxMatches || 3)));
    if (!candidates.length) return { filesScanned: 0, parsed: 0, imported: 0, updated: 0, repaired: 0, details: [] };

    let parsed = 0;
    let imported = 0;
    let updated = 0;
    let repaired = 0;
    const details = [];
    for (const match of candidates) {
      onProgress({ detail: `Repairing Solo Shuffle grouping near ${match.map || 'arena'}`, percent: 66 });
      const beforeLobbyCount = (state.matches || []).filter((item) => item && item.isSoloShuffleLobby).length;
      const scan = importLogFileWindowedForMatchIntoState(state, info, match, 'solo-shuffle-session-repair', {
        maxBytes: options.maxBytes || MAX_MATCH_TARGETED_LOG_SYNC_BYTES,
        allowLogOnlyOpenSegments: true,
        allowBgAtFileEnd: true,
        onProgress
      }) || {};
      parsed += Number(scan.parsed || 0);
      imported += Number(scan.imported || 0);
      updated += Number(scan.updated || 0);
      const afterLobbyCount = (state.matches || []).filter((item) => item && item.isSoloShuffleLobby).length;
      if (Number(scan.parsed || 0) || afterLobbyCount > beforeLobbyCount) repaired += 1;
      details.push({ matchId: match.id || '', map: match.map || '', parsed: scan.parsed || 0, imported: scan.imported || 0, updated: scan.updated || 0, reason: scan.reason || '', windowed: Boolean(scan.windowed) });
    }
    if (parsed || imported || updated || repaired) {
      dedupeStateMatches(state);
      autoLinkRecordings(state);
    }
    return { filesScanned: candidates.length ? 1 : 0, parsed, imported, updated, repaired, details };
  }

  function seedWatchedRecordFromRegistry(state = {}, file = {}, record = {}) {
    if (!state || !file || !file.filePath) return { record, changed: false };
    const existingOffset = Number(record && record.offset || 0) || 0;
    if (existingOffset > 0) return { record, changed: false };
    const registry = state.logFileRegistry && typeof state.logFileRegistry === 'object' ? state.logFileRegistry : {};
    const reg = registry[logRegistryKey(file.filePath)] || null;
    if (!reg || !logRegistryEntryLooksFullyScanned(reg)) return { record, changed: false };
    const currentSize = Number(file.size || reg.size || 0) || 0;
    const processedSize = Math.min(currentSize, Number(reg.size || 0) || 0);
    if (!processedSize || processedSize > currentSize) return { record, changed: false };
    return {
      record: {
        ...(record || {}),
        offset: processedSize,
        fileSize: currentSize,
        lineTail: '',
        initialBackfilled: true,
        needsInitialBackfill: false,
        restoredFromRegistry: true,
        restoredFromRegistryAt: new Date().toISOString()
      },
      changed: true
    };
  }

  function effectiveLogEndMs(info = {}) {
    const start = Number(info.startMs || 0) || 0;
    const ownEnd = Number(info.endMs || 0) || 0;
    const nextStart = Number(info.nextStartMs || 0) || 0;
    const mtime = Number(info.mtimeMs || 0) || 0;
    const possibleEnds = [ownEnd, mtime, start].filter((value) => Number.isFinite(value) && value > 0);
    const naturalEnd = possibleEnds.length ? Math.max(...possibleEnds) : 0;
    if (nextStart && (!start || nextStart > start)) return Math.min(naturalEnd || (nextStart - 1), nextStart - 1);
    return naturalEnd || 0;
  }

  function chooseLogInfosForMatch(infos = [], match = {}, options = {}) {
    const target = matchTargetTimeMs(match);
    const maxFiles = Math.max(1, Number(options.maxFiles || 4));
    if (!target) {
      return [...(infos || [])].sort((a, b) => (Number(b.mtimeMs || 0) - Number(a.mtimeMs || 0))).slice(0, maxFiles);
    }
    const scored = (infos || []).map((info, index) => {
      const start = Number(info.startMs || 0) || 0;
      const end = effectiveLogEndMs(info) || start;
      const inWindow = start && end && target >= (start - MATCH_LOG_TIME_PAD_MS) && target <= (end + MATCH_LOG_TIME_PAD_MS);
      const startedBefore = start && start <= target + MATCH_LOG_TIME_PAD_MS;
      const distance = inWindow ? 0 : (startedBefore ? Math.abs(target - start) : Math.abs(start - target) + MATCH_LOG_TIME_PAD_MS);
      return { info, index, start, end, inWindow, startedBefore, distance };
    });
    const direct = scored.filter((item) => item.inWindow);
    const pool = direct.length ? direct : scored.filter((item) => item.startedBefore);
    const finalPool = pool.length ? pool : scored;
    return finalPool
      .sort((a, b) => (a.distance - b.distance) || (Number(b.start || 0) - Number(a.start || 0)) || (Number(b.info.mtimeMs || 0) - Number(a.info.mtimeMs || 0)))
      .slice(0, maxFiles)
      .map((item) => item.info);
  }

  function recordingStartTimeMs(item = {}) {
    for (const value of [item.startedAt, item.createdAt, item.importedAt]) {
      const parsed = value ? Date.parse(value) : 0;
      if (Number.isFinite(parsed) && parsed > 0) return parsed;
    }
    return 0;
  }

  function collectLogSearchTargetTimes(state = {}) {
    const times = [];
    const addTime = (value) => {
      const n = Number(value);
      if (Number.isFinite(n) && n > 1000000000000) times.push(n);
    };
    for (const match of state.matches || []) {
      if (!match || match.createdFromRealLog) continue;
      addTime(match.startMs);
      addTime(match.enteredAtMs);
      addTime(match.loadedInMs);
      addTime(match.gameStartMs);
      addTime(match.videoSegmentStartMs);
      addTime(match.startIso ? Date.parse(match.startIso) : 0);
      addTime(match.capturedAt ? Date.parse(match.capturedAt) : 0);
      addTime(match.date ? Date.parse(match.date) : 0);
    }
    for (const rec of state.recordings || []) addTime(recordingStartTimeMs(rec));
    for (const vod of state.vods || []) {
      addTime(vod.startedAt ? Date.parse(vod.startedAt) : 0);
      addTime(vod.createdAt ? Date.parse(vod.createdAt) : 0);
      addTime(vod.startIso ? Date.parse(vod.startIso) : 0);
    }
    return Array.from(new Set(times.filter(Boolean))).sort((a, b) => b - a).slice(0, 40);
  }

  function chooseTargetedLogFilesForMedia(files = [], state = {}, activeFile = '') {
    const targets = collectLogSearchTargetTimes(state);
    if (!targets.length) return [];
    const activeNorm = activeFile ? path.normalize(activeFile).toLowerCase() : '';
    const dayWindowMs = 36 * 60 * 60 * 1000;
    const maxFiles = 8;
    return (files || [])
      .filter((file) => file && file.filePath && path.normalize(file.filePath).toLowerCase() !== activeNorm)
      .map((file) => {
        const approx = logFileApproxTimeMs(file);
        const distance = approx ? Math.min(...targets.map((target) => Math.abs(target - approx))) : Infinity;
        return { ...file, approxTimeMs: approx, targetDistanceMs: distance };
      })
      .filter((file) => Number.isFinite(file.targetDistanceMs) && file.targetDistanceMs <= dayWindowMs)
      .sort((a, b) => (a.targetDistanceMs - b.targetDistanceMs) || (b.mtimeMs - a.mtimeMs) || (b.size - a.size))
      .slice(0, maxFiles);
  }

  function importFullLogForAutoSync(state, filePath, reason = 'targeted-log-sync') {
    if (!filePath || !fs.existsSync(filePath)) return { ok: false, reason: 'File missing', parsed: 0, imported: 0, updated: 0, bytes: 0 };
    return importLogFileChunkedIntoState(state, filePath, reason, { maxBytes: MAX_TARGETED_LOG_SYNC_BYTES });
  }

  function syncOneLogInfoIntoState(state, info, reason = 'match-targeted-log-sync', options = {}) {
    if (!info || !info.filePath) return { ok: false, reason: 'No log file selected', parsed: 0, imported: 0, updated: 0, bytes: 0 };
    const maxBytes = Number(options.maxBytes || MAX_MATCH_TARGETED_LOG_SYNC_BYTES) || MAX_MATCH_TARGETED_LOG_SYNC_BYTES;
    rememberLogFileInfo(state, info, { status: 'selected' });
    const scan = importLogFileChunkedIntoState(state, info.filePath, `${reason}:${path.basename(info.filePath)}`, { maxBytes, allowLogOnlyOpenSegments: Boolean(options.allowLogOnlyOpenSegments), allowBgAtFileEnd: Boolean(options.allowBgAtFileEnd) });
    rememberLogFileInfo(state, info, {
      status: scan.ok === false ? 'scan-failed' : 'scanned',
      processedAt: new Date().toISOString(),
      parsedCount: Number(scan.parsed || 0),
      importedCount: Number(scan.imported || 0),
      updatedCount: Number(scan.updated || 0),
      bytes: Number(scan.bytes || info.size || 0),
      lastReason: scan.reason || ''
    });
    return scan;
  }

  function mergeBestCombatLogIntoMatch(state, originalMatch = {}) {
    if (!state || !originalMatch || !originalMatch.id) return { merged: false, match: originalMatch, score: 0 };
    state.matches = (state.matches || []).map(normalizeMatchDataSources);
    let current = state.matches.find((match) => match && match.id === originalMatch.id) || originalMatch;
    current = normalizeMatchDataSources(current);
    if (!matchNeedsCombatLog(current)) return { merged: false, match: current, score: 0, alreadyLinked: true };

    let best = null;
    let bestScore = 0;
    for (const candidate of state.matches || []) {
      if (!candidate || candidate.id === current.id || !candidate.createdFromRealLog) continue;
      const score = Math.max(addonMatchScore(candidate, current), addonMatchScore(current, candidate));
      if (score > bestScore) {
        bestScore = score;
        best = candidate;
      }
    }

    if (!best || bestScore < 45) return { merged: false, match: current, score: bestScore };

    const merged = normalizeMatchDataSources(mergeUserPreservedMatchFields({ ...best, id: current.id, favorite: Boolean(current.favorite || best.favorite) }, current));
    let replacedCurrent = false;
    state.matches = (state.matches || [])
      .filter((match) => match && match.id !== best.id)
      .map((match) => {
        if (match && match.id === current.id) {
          replacedCurrent = true;
          return merged;
        }
        return match;
      });
    if (!replacedCurrent) state.matches.unshift(merged);
    dedupeStateMatches(state);
    autoLinkRecordings(state);
    return { merged: true, match: merged, score: bestScore, sourceMatchId: best.id };
  }

  function syncLogsForMatchIntoState(state, matchId, options = {}) {
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : (() => {});
    state.settings = { ...defaultSettings(), ...(state.settings || {}) };
    const original = (state.matches || []).find((match) => match && match.id === matchId);
    if (!original) return { ok: false, reason: 'Selected match was not found.', parsed: 0, imported: 0, updated: 0, filesScanned: 0 };
    const roster = buildLogFileRoster(state.settings || {}, state, { readBoundaries: false });
    for (const info of roster.infos) rememberLogFileInfo(state, info, { status: 'indexed' });
    const candidates = chooseLogInfosForMatch(roster.infos, original, { maxFiles: options.maxFiles || 4 });
    if (!candidates.length) return { ok: false, reason: 'No combat log files were found near this match time.', parsed: 0, imported: 0, updated: 0, filesScanned: 0, searchedFolders: roster.folders };

    let parsed = 0;
    let imported = 0;
    let updated = 0;
    let skippedLarge = 0;
    const details = [];
    for (const info of candidates) {
      onProgress({ detail: `Checking ${info.name || path.basename(info.filePath || 'combat log')}`, percent: Math.round((details.length / Math.max(1, candidates.length)) * 85) });
      const scan = importLogFileWindowedForMatchIntoState(state, info, original, 'selected-match-log-sync', { maxBytes: options.maxBytes || MAX_MATCH_TARGETED_LOG_SYNC_BYTES, onProgress });
      rememberLogFileInfo(state, info, { status: scan.ok === false ? 'window-scan-failed' : 'window-scanned', scannedAt: new Date().toISOString(), parsedCount: Number(scan.parsed || 0), importedCount: Number(scan.imported || 0), updatedCount: Number(scan.updated || 0), bytes: Number(scan.bytes || 0), lastReason: scan.reason || '' });
      parsed += Number(scan.parsed || 0);
      imported += Number(scan.imported || 0);
      updated += Number(scan.updated || 0);
      if (scan.skippedLarge) skippedLarge += 1;
      details.push({ filePath: info.filePath, name: info.name, startMs: info.startMs, endMs: info.endMs, size: info.size, parsed: scan.parsed || 0, imported: scan.imported || 0, updated: scan.updated || 0, skippedLarge: Boolean(scan.skippedLarge), reason: scan.reason || '' });
    }

    onProgress({ detail: 'Merging best combat-log match data', percent: 92 });
    const merge = mergeBestCombatLogIntoMatch(state, original);
    const selected = (state.matches || []).find((match) => match && match.id === (merge.match && merge.match.id ? merge.match.id : original.id)) || merge.match || original;
    const linked = !matchNeedsCombatLog(selected);
    const now = new Date().toISOString();
    state.settings = {
      ...defaultSettings(),
      ...(state.settings || {}),
      logLastSyncAt: now,
      logLastSyncMode: 'selected-match-log-sync',
      logLastSyncFilePath: details[0] ? details[0].filePath : (state.settings.logLastSyncFilePath || ''),
      logLastSyncBytes: details.reduce((sum, item) => sum + Number(item.size || 0), 0)
    };
    state.importedFiles = state.importedFiles || [];
    state.importedFiles.unshift({
      filePath: details[0] ? details[0].filePath : '',
      importedAt: now,
      state: linked ? 'Selected match log synced' : 'Selected match log scan finished, but no matching combat-log segment was found',
      parsedCount: parsed,
      importedCount: imported,
      updatedCount: updated,
      filesScanned: candidates.length,
      selectedMatchId: original.id,
      targetedDetails: details,
      skippedLarge
    });
    return { ok: true, parsed, imported, updated, filesScanned: candidates.length, skippedLarge, details, linked, merge, selectedMatch: selected, searchedFolders: roster.folders };
  }

  function repairMissingLogsIntoState(state, options = {}) {
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : (() => {});
    state.settings = { ...defaultSettings(), ...(state.settings || {}) };
    const roster = buildLogFileRoster(state.settings || {}, state, { readBoundaries: false });
    for (const info of roster.infos) rememberLogFileInfo(state, info, { status: 'indexed' });
    const missing = (state.matches || [])
      .filter(matchNeedsCombatLog)
      .filter((match) => match && match.id)
      .slice()
      .sort((a, b) => (matchTargetTimeMs(b) - matchTargetTimeMs(a)) || String(b.id || '').localeCompare(String(a.id || '')))
      .slice(0, Math.max(1, Number(options.maxMatches || STARTUP_REPAIR_MAX_MATCHES)));
    if (!missing.length) return { ok: true, repaired: 0, missing: 0, parsed: 0, imported: 0, updated: 0, filesScanned: 0, details: [], repairedMatches: [], reason: 'No missing combat-log links were found.' };

    let parsed = 0;
    let imported = 0;
    let updated = 0;
    let skippedLarge = 0;
    let filesScanned = 0;
    const details = [];
    const repairedMatches = [];
    const scannedMatchFiles = new Set();

    for (let missingIndex = 0; missingIndex < missing.length; missingIndex += 1) {
      const match = missing[missingIndex];
      onProgress({ detail: `Repairing ${missingIndex + 1}/${missing.length} missing log links`, percent: Math.round((missingIndex / Math.max(1, missing.length)) * 90) });
      const candidates = chooseLogInfosForMatch(roster.infos, match, { maxFiles: Math.max(1, Number(options.maxFilesPerMatch || 2)) });
      if (!candidates.length) {
        details.push({ matchId: match.id, name: '', parsed: 0, imported: 0, updated: 0, reason: 'No likely log file found for this match time.' });
        continue;
      }

      for (const info of candidates) {
        const scanKey = `${match.id}:${logRegistryKey(info.filePath)}`;
        if (scannedMatchFiles.has(scanKey)) continue;
        scannedMatchFiles.add(scanKey);
        const scan = importLogFileWindowedForMatchIntoState(state, info, match, 'repair-missing-log-sync', { maxBytes: options.maxBytes || MAX_MATCH_TARGETED_LOG_SYNC_BYTES, onProgress });
        rememberLogFileInfo(state, info, { status: scan.ok === false ? 'repair-window-failed' : 'repair-window-scanned', scannedAt: new Date().toISOString(), parsedCount: Number(scan.parsed || 0), importedCount: Number(scan.imported || 0), updatedCount: Number(scan.updated || 0), bytes: Number(scan.bytes || 0), lastReason: scan.reason || '' });
        parsed += Number(scan.parsed || 0);
        imported += Number(scan.imported || 0);
        updated += Number(scan.updated || 0);
        filesScanned += 1;
        if (scan.skippedLarge) skippedLarge += 1;
        details.push({ matchId: match.id, filePath: info.filePath, name: info.name, startMs: info.startMs, endMs: info.endMs, size: info.size, parsed: scan.parsed || 0, imported: scan.imported || 0, updated: scan.updated || 0, skippedLarge: Boolean(scan.skippedLarge), windowed: Boolean(scan.windowed), windowLines: scan.windowLines || 0, bytes: scan.bytes || 0, reason: scan.reason || '' });

        const before = (state.matches || []).find((item) => item && item.id === match.id) || match;
        const result = mergeBestCombatLogIntoMatch(state, before);
        const after = (state.matches || []).find((item) => item && item.id === match.id) || result.match;
        if (after && !matchNeedsCombatLog(after)) {
          repairedMatches.push(sanitizeMatchForStorage(after));
          break;
        }
      }
    }

    onProgress({ detail: 'Linking repaired logs to recordings', percent: 94 });
    autoLinkRecordings(state);
    const now = new Date().toISOString();
    state.settings = {
      ...defaultSettings(),
      ...(state.settings || {}),
      logLastRepairAt: now,
      logLastRepairSummary: `Repaired ${repairedMatches.length} of ${missing.length} missing combat-log links`,
      logLastSyncAt: now,
      logLastSyncMode: 'repair-missing-log-sync'
    };
    state.importedFiles = state.importedFiles || [];
    state.importedFiles.unshift({
      filePath: details[0] ? details[0].filePath : '',
      importedAt: now,
      state: state.settings.logLastRepairSummary,
      parsedCount: parsed,
      importedCount: imported,
      updatedCount: updated,
      filesScanned,
      targetedDetails: details.slice(0, 30),
      skippedLarge
    });
    return { ok: true, repaired: repairedMatches.length, missing: missing.length, parsed, imported, updated, filesScanned, details: details.slice(0, 30), repairedMatches, skippedLarge, searchedFolders: roster.folders };
  }

  function sweepChangedOlderLogsIntoState(files = [], activeFile = '', options = {}) {
    const summary = { ok: true, filesScanned: 0, parsed: 0, imported: 0, updated: 0, bytes: 0, details: [], skipped: 0, fileCap: 0 };
    if (!Array.isArray(files) || !files.length) return summary;

    const cap = Math.max(0, Number(options.maxFiles || STARTUP_CHANGED_LOG_SWEEP_LIMIT));
    summary.fileCap = cap;
    if (!cap) return summary;

    const snapshot = readState();
    const registry = snapshot.logFileRegistry || {};
    const watched = snapshot.watchedFiles || {};
    const activeNorm = activeFile ? path.normalize(activeFile).toLowerCase() : '';

    const candidates = [];
    for (const file of files) {
      if (!file || !file.filePath) continue;
      if (activeNorm && path.normalize(file.filePath).toLowerCase() === activeNorm) continue;
      const key = logRegistryKey(file.filePath);
      const reg = registry[key] || null;
      const w = watched[file.filePath] || null;
      const currentSize = Number(file.size || 0);
      const currentMtime = Number(file.mtimeMs || 0);
      const regSize = Number((reg && reg.size) || 0);
      const regMtime = Number((reg && reg.mtimeMs) || 0);
      const offset = Number((w && w.offset) || 0);

      const isNew = !reg;
      const grew = currentSize > regSize || currentSize > offset;
      const newerMtime = currentMtime > regMtime + 1;
      if (isNew || grew || newerMtime) candidates.push(file);
    }

    if (!candidates.length) return summary;

    const sortedCandidates = candidates
      .slice()
      .sort((a, b) => (Number(b.mtimeMs || 0) - Number(a.mtimeMs || 0)) || (logFileApproxTimeMs(b) - logFileApproxTimeMs(a)) || (Number(b.size || 0) - Number(a.size || 0)) || (logFileEntryWeight(b.name || path.basename(b.filePath || '')) - logFileEntryWeight(a.name || path.basename(a.filePath || ''))));
    const limited = sortedCandidates.slice(0, cap);
    summary.skipped = Math.max(0, sortedCandidates.length - limited.length);

    const perFileMaxPasses = Math.max(1, Math.min(12, Number(options.maxPasses || 12)));
    const perFileMaxTailBytes = Number(options.maxTailBytes || 0) || undefined;
    const onProgress = typeof options.onProgress === 'function' ? options.onProgress : (() => {});

    for (let sweepIndex = 0; sweepIndex < limited.length; sweepIndex += 1) {
      const file = limited[sweepIndex];
      onProgress({ detail: `Checking rotated log ${sweepIndex + 1}/${limited.length}`, percent: Math.min(68, 55 + Math.round((sweepIndex / Math.max(1, limited.length)) * 12)) });
      try {
        const seedState = readState();
        seedState.watchedFiles = seedState.watchedFiles || {};
        const currentRecord = seedState.watchedFiles[file.filePath] || { offset: 0, fileSize: 0, lineTail: '', startedAt: new Date().toISOString() };
        const seeded = seedWatchedRecordFromRegistry(seedState, file, currentRecord);
        if (seeded.changed) {
          seedState.watchedFiles[file.filePath] = seeded.record;
          writeState(seedState);
        }
        const result = processActiveLogTail(file.filePath, { maxPasses: perFileMaxPasses, reason: 'startup-changed-log-sweep', allowLogOnlyOpenSegments: true, allowBgAtFileEnd: true, maxTailBytes: perFileMaxTailBytes }) || {};
        const afterState = readState();
        const info = buildLogFileInfo(file, afterState, { readBoundaries: false });
        if (info) {
          rememberLogFileInfo(afterState, info, {
            status: result.hasMoreTail ? 'changed-log-sweep-partial' : 'changed-log-sweep-scanned',
            scannedAt: new Date().toISOString(),
            parsedCount: Number(result.parsed || 0),
            importedCount: Number(result.imported || 0),
            bytes: Number(result.bytes || 0),
            lastReason: result.reason || ''
          });
          writeState(afterState);
        }
        summary.filesScanned += 1;
        summary.parsed += Number(result.parsed || 0);
        summary.imported += Number(result.imported || 0);
        summary.updated += Number(result.updated || 0);
        summary.bytes += Number(result.bytes || 0);
        summary.details.push({
          filePath: file.filePath,
          name: path.basename(file.filePath),
          parsed: Number(result.parsed || 0),
          imported: Number(result.imported || 0),
          updated: Number(result.updated || 0),
          bytes: Number(result.bytes || 0),
          hasMoreTail: Boolean(result.hasMoreTail),
          reason: result.reason || ''
        });
      } catch (error) {
        summary.details.push({
          filePath: file.filePath,
          name: path.basename(file.filePath),
          error: error && error.message ? error.message : String(error)
        });
      }
    }

    return summary;
  }


  function scanLogsFolderIntoState(payload = {}) {
    try {
      const syncOptions = payload && typeof payload === 'object' ? payload : {};
      const onProgress = typeof syncOptions.onProgress === 'function' ? syncOptions.onProgress : (() => {});
      const startupLight = Boolean(syncOptions.startupLight || syncOptions.mode === 'startup-light');
      const refreshLight = Boolean(syncOptions.refreshLight || syncOptions.mode === 'refresh-light');
      const state = readState();
      state.settings = { ...defaultSettings(), ...(state.settings || {}) };
      const savedStartupFile = startupLight && state.settings.logFilePath && fs.existsSync(state.settings.logFilePath) ? state.settings.logFilePath : '';
      const folders = savedStartupFile ? [path.dirname(savedStartupFile)] : getCandidateLogFolders(state.settings || {});
      let filesWithFolder = [];
      if (savedStartupFile) {
        const stat = fs.statSync(savedStartupFile);
        filesWithFolder = [{ filePath: savedStartupFile, folderPath: path.dirname(savedStartupFile), name: path.basename(savedStartupFile), mtimeMs: stat.mtimeMs || 0, size: stat.size || 0, statLimited: false, totalFiles: 1 }];
      } else {
        const summaries = folders.map((folderPath) => ({ folderPath, summary: getLogFileSummaryInFolder(folderPath) }));
        filesWithFolder = summaries.flatMap((item) => (item.summary.files || []).map((file) => ({ ...file, folderPath: item.folderPath, statLimited: Boolean(item.summary.statLimited), totalFiles: item.summary.totalFiles || 0 })));
      }
      onProgress({ detail: 'Finding combat log files', percent: 8 });
      const files = filesWithFolder
        .filter((item) => item && item.filePath)
        .sort((a, b) => (Number(b.mtimeMs || 0) - Number(a.mtimeMs || 0)) || (Number(b.size || 0) - Number(a.size || 0)) || (logFileEntryWeight(b.name || path.basename(b.filePath || '')) - logFileEntryWeight(a.name || path.basename(a.filePath || ''))));

      const fallbackFolder = state.settings.logFolderPath
        || (state.settings.logFilePath ? path.dirname(state.settings.logFilePath) : '')
        || folders[0]
        || '';

      if (!files.length) {
        return {
          ok: false,
          reason: fallbackFolder ? 'No WoWCombatLog*.txt files found in the detected Logs folders.' : 'Choose your WoW Logs folder first.',
          folder: fallbackFolder,
          searchedFolders: folders,
          matches: state.matches || [],
          imported: 0,
          parsed: 0,
          files: 0
        };
      }

      // Performance rule: sync only the newest active log across detected WoW Logs folders.
      // Old logs are handled by changed-log sweep, missing-log repair, or explicit import.
      const active = files[0];
      const activeFile = active.filePath;
      const folder = active.folderPath || path.dirname(activeFile);
      const activeInfo = buildLogFileInfo(active, state, { readBoundaries: false });
      const skippedHistoricalFiles = Math.max(0, filesWithFolder.length - 1);
      const previousLogFolder = state.settings.logFolderPath || (state.settings.logFilePath ? path.dirname(state.settings.logFilePath) : '');
      const stat = fs.statSync(activeFile);
      state.watchedFiles = state.watchedFiles || {};
      let record = state.watchedFiles[activeFile] || { offset: 0, fileSize: 0, lineTail: '', startedAt: new Date().toISOString(), needsInitialBackfill: true };
      const seededActive = seedWatchedRecordFromRegistry(state, { ...active, size: stat.size, mtimeMs: stat.mtimeMs || active.mtimeMs || 0 }, record);
      record = seededActive.record;

      if (!startupLight && (record.autoLocated || record.needsInitialBackfill) && !record.initialBackfilled && stat.size > 0 && Number(record.offset || 0) >= stat.size) {
        record.offset = 0;
        record.fileSize = 0;
        record.lineTail = '';
        record.needsInitialBackfill = true;
      }

      if (!record.offset && !record.fileSize) {
        record.offset = 0;
        record.fileSize = 0;
        record.lineTail = '';
        record.startedAt = record.startedAt || new Date().toISOString();
        record.needsInitialBackfill = record.needsInitialBackfill !== false;
      }
      state.watchedFiles[activeFile] = record;
      if (activeInfo) rememberLogFileInfo(state, activeInfo, { status: seededActive.changed ? 'active-resumed-from-cache' : 'active-selected' });
      state.settings = { ...defaultSettings(), ...(state.settings || {}), logFolderPath: folder, logFilePath: activeFile };
      writeState(state);

      const activeMaxPasses = startupLight ? 1 : (refreshLight ? REFRESH_ACTIVE_MAX_PASSES : 24);
      const changedSweepLimit = startupLight ? 0 : (refreshLight ? REFRESH_CHANGED_LOG_SWEEP_LIMIT : STARTUP_CHANGED_LOG_SWEEP_LIMIT);
      const repairMaxMatches = startupLight ? 0 : (refreshLight ? REFRESH_REPAIR_MAX_MATCHES : STARTUP_REPAIR_MAX_MATCHES);
      const repairMaxFilesPerMatch = startupLight ? 0 : (refreshLight ? REFRESH_REPAIR_MAX_FILES_PER_MATCH : STARTUP_REPAIR_MAX_FILES_PER_MATCH);
      const activeTailBytes = startupLight ? STARTUP_ACTIVE_TAIL_READ_BYTES : (refreshLight ? REFRESH_ACTIVE_TAIL_READ_BYTES : MAX_ACTIVE_TAIL_READ_BYTES);
      const repairWindowBytes = refreshLight ? REFRESH_WINDOW_SCAN_BYTES : MAX_WINDOW_SCAN_BYTES;

      const startupTailStatus = startupLight ? startupLightLogStatus(state, activeFile, stat) : { skipTail: false };
      onProgress({ detail: 'Reading new active-log bytes', percent: 28 });
      const result = startupTailStatus.skipTail
        ? { ok: true, bytes: 0, parsed: 0, imported: 0, updated: 0, matches: [], hasMoreTail: false, skippedTail: true, reason: startupTailStatus.reason || 'Startup light tail already caught up.' }
        : (processActiveLogTail(activeFile, {
          maxPasses: activeMaxPasses,
          reason: startupLight ? 'startup-light-active-sync' : 'manual-active-sync',
          skipInitialBackfill: startupLight,
          maxTailBytes: activeTailBytes
        }) || {});
      let imported = Number(result.imported || 0);
      let activeUpdated = Number(result.updated || 0);
      let soloRepair = { filesScanned: 0, parsed: 0, imported: 0, updated: 0, repaired: 0, details: [] };

      // Sweep older files that changed since the last scan. This catches matches
      // written to rotated logs while the app was closed without deep-reading every file.
      onProgress({ detail: 'Checking changed rotated logs', percent: 55 });
      const sweepResult = changedSweepLimit
        ? (sweepChangedOlderLogsIntoState(filesWithFolder, activeFile, { maxFiles: changedSweepLimit, maxPasses: refreshLight ? 3 : 12, maxTailBytes: refreshLight ? REFRESH_ACTIVE_TAIL_READ_BYTES : MAX_ACTIVE_TAIL_READ_BYTES, onProgress }) || {})
        : { ok: true, filesScanned: 0, parsed: 0, imported: 0, updated: 0, bytes: 0, details: [], skipped: 0, fileCap: 0 };
      const sweepFilesScanned = Number(sweepResult.filesScanned || 0);
      const sweepParsed = Number(sweepResult.parsed || 0);
      const sweepImported = Number(sweepResult.imported || 0);
      const sweepUpdated = Number(sweepResult.updated || 0);
      const sweepBytes = Number(sweepResult.bytes || 0);
      const sweepSkipped = Number(sweepResult.skipped || 0);
      const sweepDetails = Array.isArray(sweepResult.details) ? sweepResult.details.slice(0, 12) : [];
      if (sweepImported) imported += sweepImported;

      const updated = readState();
      const updatedActiveInfo = buildLogFileInfo(active, updated, { readBoundaries: false });
      if (updatedActiveInfo) {
        soloRepair = repairIncompleteSoloShuffleSessionsFromLog(updated, updatedActiveInfo, { maxMatches: startupLight ? 1 : 3, maxBytes: refreshLight ? REFRESH_WINDOW_SCAN_BYTES : MAX_WINDOW_SCAN_BYTES, onProgress }) || soloRepair;
        if (soloRepair.imported) imported += Number(soloRepair.imported || 0);
        if (soloRepair.updated) activeUpdated += Number(soloRepair.updated || 0);
        if (soloRepair.repaired) rememberLogFileInfo(updated, updatedActiveInfo, { status: 'solo-shuffle-repair-scanned', soloShuffleRepaired: soloRepair.repaired, soloShuffleRepairAt: new Date().toISOString() });
        rememberLogFileInfo(updated, updatedActiveInfo, { status: result.hasMoreTail ? 'active-tail-partial' : 'active-tail-scanned', scannedAt: new Date().toISOString(), parsedCount: (Number(result.parsed || 0) + Number(soloRepair.parsed || 0)), importedCount: (Number(result.imported || 0) + Number(soloRepair.imported || 0)), updatedCount: activeUpdated, bytes: Number(result.bytes || 0), lastReason: result.reason || '' });
      }

      onProgress({ detail: 'Checking nearby logs for unlinked matches', percent: 72 });
      const targetedRepair = repairMaxMatches
        ? (repairMissingLogsIntoState(updated, { maxMatches: repairMaxMatches, maxFilesPerMatch: repairMaxFilesPerMatch, maxBytes: repairWindowBytes, onProgress }) || {})
        : { ok: true, filesScanned: 0, parsed: 0, imported: 0, updated: 0, skippedLarge: 0, details: [] };
      const targetedFilesScanned = Number(targetedRepair.filesScanned || 0);
      const targetedParsed = Number(targetedRepair.parsed || 0);
      const targetedImported = Number(targetedRepair.imported || 0);
      const targetedUpdated = Number(targetedRepair.updated || 0);
      const targetedSkippedLarge = Number(targetedRepair.skippedLarge || 0);
      const targetedDetails = Array.isArray(targetedRepair.details) ? targetedRepair.details.slice(0, 12) : [];
      if (targetedFilesScanned || sweepImported || sweepUpdated) autoLinkRecordings(updated);
      if (targetedFilesScanned) imported += targetedImported;

      const switchedFolder = Boolean(previousLogFolder && path.normalize(previousLogFolder).toLowerCase() !== path.normalize(folder).toLowerCase());
      const targetedNote = targetedFilesScanned
        ? ` Also checked ${targetedFilesScanned} nearby log file${targetedFilesScanned === 1 ? '' : 's'} for unlogged videos/matches${targetedParsed ? ` (${targetedParsed} parsed, ${targetedUpdated} updated)` : ''}.`
        : '';
      const soloRepairNote = soloRepair && soloRepair.repaired
        ? ` Repaired ${soloRepair.repaired} Solo Shuffle grouping issue${soloRepair.repaired === 1 ? '' : 's'} from the active log.`
        : '';
      const sweepNote = sweepFilesScanned
        ? ` Re-scanned ${sweepFilesScanned} older log file${sweepFilesScanned === 1 ? '' : 's'} that changed since last sync${sweepImported ? ` (+${sweepImported} match${sweepImported === 1 ? '' : 'es'})` : (sweepUpdated ? ` (${sweepUpdated} updated)` : '')}.`
        : '';
      const sweepSkippedNote = sweepSkipped ? ` ${sweepSkipped} more changed log${sweepSkipped === 1 ? '' : 's'} queued for the next sync.` : '';
      const skippedLargeNote = targetedSkippedLarge ? ` ${targetedSkippedLarge} large historical log${targetedSkippedLarge === 1 ? '' : 's'} skipped.` : '';
      const totalUpdated = activeUpdated + targetedUpdated + sweepUpdated;
      let syncState = '';
      if (startupLight) {
        if (imported) {
          syncState = `Startup catch-up found ${imported} finalized PvP match${imported === 1 ? '' : 'es'}. Deep catch-up is available from Sync Active Log.`;
        } else if (result.hasMoreTail) {
          syncState = 'Startup catch-up read a small log slice. Use Sync Active Log for deeper catch-up.';
        } else if (result.bytes || targetedFilesScanned || sweepFilesScanned) {
          syncState = 'Startup catch-up checked the latest log slice. Use Sync Active Log for deeper catch-up.';
        } else {
          syncState = 'Watching logs. Deep catch-up is parked until you ask for it.';
        }
      } else if (imported) {
        syncState = `Synced logs: ${imported} finalized PvP match${imported === 1 ? '' : 'es'}${sweepNote}${targetedNote}${soloRepairNote}${skippedLargeNote}${sweepSkippedNote}`;
      } else if (totalUpdated) {
        syncState = `Synced logs: ${totalUpdated} existing PvP match${totalUpdated === 1 ? '' : 'es'} updated.${sweepNote}${targetedNote}${soloRepairNote}${skippedLargeNote}${sweepSkippedNote}`;
      } else if (result.hasMoreTail) {
        syncState = `Synced part of active log tail. More backlog will be read on the next sync.${sweepNote}${targetedNote}${soloRepairNote}${skippedLargeNote}${sweepSkippedNote}`;
      } else if (result.bytes || targetedFilesScanned || sweepFilesScanned) {
        syncState = `No new matches found. Log data is already up to date.${sweepNote}${targetedNote}${soloRepairNote}${skippedLargeNote}${sweepSkippedNote}`;
      } else {
        syncState = 'Already up to date. No new matches found.';
      }
      const syncMode = startupLight
        ? (result.hasMoreTail ? 'startup-light-active-log-tail-partial' : 'startup-light-active-log-tail')
        : (sweepFilesScanned
          ? 'active-plus-changed-log-sweep'
          : (targetedFilesScanned ? 'active-plus-targeted-log-sync' : (result.hasMoreTail ? 'active-log-tail-catchup-partial' : 'active-log-tail')));
      updated.settings = { ...defaultSettings(), ...(updated.settings || {}), logFolderPath: folder, logFilePath: activeFile, logLastSyncAt: new Date().toISOString(), logLastSyncFilePath: activeFile, logLastSyncBytes: (result.bytes || 0), logLastSyncMode: syncMode, logDetectedFolderCount: folders.length, logTargetedFilesScanned: targetedFilesScanned, logChangedFilesSwept: sweepFilesScanned, logChangedFilesQueued: sweepSkipped };
      updated.importedFiles = updated.importedFiles || [];
      updated.importedFiles.unshift({
        filePath: activeFile,
        importedAt: updated.settings.logLastSyncAt,
        state: switchedFolder ? `${syncState} Newer Logs folder detected.` : syncState,
        parsedCount: (Number(result.parsed || 0)) + targetedParsed + sweepParsed + Number(soloRepair.parsed || 0),
        importedCount: imported,
        updatedCount: totalUpdated,
        filesScanned: 1 + targetedFilesScanned + sweepFilesScanned + (soloRepair && soloRepair.filesScanned ? soloRepair.filesScanned : 0),
        changedLogFilesScanned: sweepFilesScanned,
        changedLogFilesQueued: sweepSkipped,
        foldersScanned: folders.length,
        targetedDetails,
        changedLogDetails: sweepDetails,
        statLimited: Boolean(active.statLimited),
        skippedHistoricalFiles
      });
      onProgress({ detail: 'Saving compact sync results', percent: 94 });
      writeState(updated);

      return {
        ok: true,
        folder,
        activeFile,
        files: 1 + targetedFilesScanned + sweepFilesScanned + (soloRepair && soloRepair.filesScanned ? soloRepair.filesScanned : 0),
        targetedFilesScanned,
        targetedDetails,
        changedLogFilesScanned: sweepFilesScanned,
        changedLogFilesQueued: sweepSkipped,
        changedLogDetails: sweepDetails,
        foldersScanned: folders.length,
        searchedFolders: folders,
        skippedHistoricalFiles,
        parsed: (Number(result.parsed || 0)) + targetedParsed + sweepParsed + Number(soloRepair.parsed || 0),
        imported,
        updated: totalUpdated,
        bytes: (Number(result.bytes || 0)) + sweepBytes,
        changedMatches: compactRecentMatchesForResponse(updated, 80),
        removedMatchIds: uniqueList(updated._removedDuplicateMatchIds || []),
        importedFiles: compactImportedFilesForResponse(updated),
        logFileRegistry: compactLogRegistryForResponse(updated),
        settings: updated.settings,
        watchFile: activeFile,
        startupLight,
        refreshLight,
        hasMoreTail: Boolean(result.hasMoreTail),
        startupTailSkipped: Boolean(result.skippedTail),
        state: switchedFolder ? `${syncState} Newer Logs folder detected.` : syncState
      };
    } catch (error) {
      const state = readState();
      const message = error && error.message ? error.message : String(error || 'Unknown log sync error');
      return {
        ok: false,
        reason: `Log sync failed safely: ${message}`,
        changedMatches: compactRecentMatchesForResponse(state, 40),
        importedFiles: compactImportedFilesForResponse(state),
        logFileRegistry: compactLogRegistryForResponse(state),
        settings: state.settings || {},
        imported: 0,
        parsed: 0,
        updated: 0,
        files: 0
      };
    }
  }

  return {
    effectiveLogEndMs,
    chooseLogInfosForMatch,
    recordingStartTimeMs,
    collectLogSearchTargetTimes,
    chooseTargetedLogFilesForMedia,
    importFullLogForAutoSync,
    syncOneLogInfoIntoState,
    mergeBestCombatLogIntoMatch,
    syncLogsForMatchIntoState,
    repairMissingLogsIntoState,
    sweepChangedOlderLogsIntoState,
    scanLogsFolderIntoState
  };
}

module.exports = { createLogSyncBackendTools };
