'use strict';

function createImportJobQueueTools(deps = {}) {
  const onStatus = typeof deps.onStatus === 'function' ? deps.onStatus : (() => {});
  const queue = {
    active: null,
    recent: [],
    promise: Promise.resolve(),
    nextId: 1,
    queued: 0,
    inflightByKey: new Map(),
    inflightByGroup: new Map()
  };

  function emitStatus(reason = 'update') {
    try { onStatus({ ok: true, reason, importJobStatus: importJobStatusSnapshot() }); } catch (_error) {}
  }

  function canceledJobError(job) {
    const error = new Error((job && job.cancelReason) || 'Canceled by user.');
    error.code = 'LCR_IMPORT_JOB_CANCELED';
    error.canceled = true;
    return error;
  }

  function resultLooksCanceled(result = {}) {
    if (!result || typeof result !== 'object') return false;
    if (result.canceled || result.cancelled) return true;
    const reason = String(result.reason || result.state || '').toLowerCase();
    return reason.includes('canceled by user') || reason.includes('cancelled by user') || reason.includes('cancel requested');
  }

  function errorLooksCanceled(error) {
    if (!error) return false;
    return Boolean(error.canceled || error.cancelled || error.code === 'LCR_IMPORT_JOB_CANCELED' || /cancell?ed by user|cancel requested/i.test(error.message || String(error)));
  }

  function compactImportJob(job = {}) {
    if (!job || typeof job !== 'object') return null;
    return {
      id: job.id || '',
      type: job.type || '',
      label: job.label || '',
      status: job.status || '',
      startedAt: job.startedAt || '',
      queuedAt: job.queuedAt || '',
      finishedAt: job.finishedAt || '',
      durationMs: Number(job.durationMs || 0),
      ok: job.ok !== false,
      reason: job.reason ? String(job.reason).slice(0, 220) : '',
      progress: job.progress && typeof job.progress === 'object' ? job.progress : null,
      cancelRequested: Boolean(job.cancelRequested),
      cancelRequestedAt: job.cancelRequestedAt || '',
      canCancel: Boolean(job.startedAt && !job.finishedAt)
    };
  }

  function importJobStatusSnapshot() {
    return {
      active: compactImportJob(queue.active),
      queued: Math.max(0, Number(queue.queued || 0)),
      recent: queue.recent.slice(0, 8).map(compactImportJob).filter(Boolean)
    };
  }

  function finishImportJob(job, result = {}, error = null) {
    const finishedAt = new Date().toISOString();
    const started = Date.parse(job.startedAt || '') || Date.now();
    const failedByResult = result && result.ok === false;
    const canceled = errorLooksCanceled(error) || resultLooksCanceled(result) || Boolean(job.cancelRequested && failedByResult);
    const reason = canceled
      ? ((error && (error.message || String(error))) || (result && (result.reason || result.state)) || job.cancelReason || 'Canceled by user.')
      : (error ? (error.message || String(error)) : (failedByResult ? (result.reason || 'Job returned no successful result.') : ''));
    const finished = {
      ...job,
      status: canceled ? 'canceled' : (error || failedByResult ? 'failed' : 'complete'),
      ok: !(error || failedByResult || canceled),
      canceled,
      reason,
      finishedAt,
      durationMs: Math.max(0, Date.now() - started),
      progress: {
        ...(job.progress || {}),
        percent: canceled ? Number((job.progress && job.progress.percent) || 0) : (error || failedByResult ? Number((job.progress && job.progress.percent) || 100) : 100),
        detail: canceled ? 'Canceled by user.' : (error || failedByResult ? (reason || 'Job failed') : ((job.progress && job.progress.detail) || 'Completed')),
        updatedAt: finishedAt
      }
    };
    queue.recent.unshift(finished);
    queue.recent = queue.recent.slice(0, 12);
    queue.active = null;
    return finished;
  }

  function cancelImportJob(jobId = '', reason = 'Canceled by user.') {
    const active = queue.active;
    const requestedId = String(jobId || '').trim();
    if (!active || (requestedId && active.id !== requestedId)) {
      return { ok: false, reason: 'No matching running job was found.', importJobStatus: importJobStatusSnapshot() };
    }
    active.cancelRequested = true;
    active.cancelRequestedAt = new Date().toISOString();
    active.cancelReason = String(reason || 'Canceled by user.').slice(0, 220);
    active.status = 'canceling';
    active.progress = {
      ...(active.progress || {}),
      detail: 'Cancel requested. Waiting for a safe stop point.',
      updatedAt: active.cancelRequestedAt
    };
    emitStatus('cancel-requested');
    return { ok: true, cancelRequested: true, jobId: active.id, importJobStatus: importJobStatusSnapshot() };
  }

  function runQueuedImportJob(type, label, worker, options = {}) {
    const duplicateKey = options && options.key ? String(options.key) : '';
    const exclusiveGroup = options && options.exclusiveGroup ? String(options.exclusiveGroup) : '';
    if (exclusiveGroup && queue.inflightByGroup.has(exclusiveGroup)) {
      const message = options.groupBusyMessage || 'Another heavy job is already running. Duplicate request skipped.';
      return Promise.resolve({
        ok: true,
        busy: true,
        skippedDuplicate: true,
        state: message,
        importJobStatus: importJobStatusSnapshot()
      });
    }
    if (duplicateKey && queue.inflightByKey.has(duplicateKey)) {
      const existing = queue.inflightByKey.get(duplicateKey);
      return existing.then((result = {}) => ({
        ...(result || {}),
        coalesced: true,
        state: result && result.state ? `${result.state} Duplicate request was skipped while the first one finished.` : 'Already running. Duplicate request skipped.',
        importJobStatus: importJobStatusSnapshot()
      }));
    }

    const job = {
      id: `job_${Date.now()}_${queue.nextId++}`,
      type: String(type || 'job'),
      label: String(label || 'Working'),
      status: 'queued',
      startedAt: '',
      queuedAt: new Date().toISOString(),
      cancelRequested: false,
      cancelRequestedAt: '',
      cancelReason: ''
    };
    queue.queued += 1;
    if (exclusiveGroup) queue.inflightByGroup.set(exclusiveGroup, job);
    emitStatus('queued');

    const run = async () => {
      queue.queued = Math.max(0, Number(queue.queued || 0) - 1);
      job.status = 'running';
      job.startedAt = new Date().toISOString();
      queue.active = job;
      emitStatus('started');
      const progress = (update = {}) => {
        if (job.cancelRequested) throw canceledJobError(job);
        job.progress = { ...(job.progress || {}), ...(update || {}), updatedAt: new Date().toISOString() };
        emitStatus('progress');
        if (job.cancelRequested) throw canceledJobError(job);
      };
      try {
        if (job.cancelRequested) throw canceledJobError(job);
        const result = await worker(progress);
        if (job.cancelRequested && (!result || result.ok !== false)) throw canceledJobError(job);
        finishImportJob(job, result || {}, null);
        emitStatus(resultLooksCanceled(result) ? 'canceled' : 'finished');
        return { ...(result || {}), importJobStatus: importJobStatusSnapshot() };
      } catch (error) {
        const finished = finishImportJob(job, {}, error);
        emitStatus(finished.canceled ? 'canceled' : 'failed');
        return { ok: false, canceled: Boolean(finished.canceled), reason: finished.reason || (finished.canceled ? 'Canceled by user.' : 'Job failed.'), importJobStatus: importJobStatusSnapshot() };
      }
    };

    const queued = queue.promise.then(run, run);
    const cleanup = () => {
      if (duplicateKey) queue.inflightByKey.delete(duplicateKey);
      if (exclusiveGroup) queue.inflightByGroup.delete(exclusiveGroup);
      emitStatus('cleared');
    };
    const tracked = (duplicateKey || exclusiveGroup) ? queued.finally(cleanup) : queued;
    if (duplicateKey) queue.inflightByKey.set(duplicateKey, tracked);
    queue.promise = queued.catch(() => null);
    return tracked;
  }

  return {
    compactImportJob,
    importJobStatusSnapshot,
    finishImportJob,
    cancelImportJob,
    runQueuedImportJob
  };
}

module.exports = { createImportJobQueueTools };
