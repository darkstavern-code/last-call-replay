'use strict';

function createPvPHelperStatusTools(deps = {}) {
  const extractPvPHelperVersion = typeof deps.extractPvPHelperVersion === 'function' ? deps.extractPvPHelperVersion : () => '';
  const buildPvPHelperVersionStatus = typeof deps.buildPvPHelperVersionStatus === 'function' ? deps.buildPvPHelperVersionStatus : () => ({});
  const objectArrayLikeToArray = typeof deps.objectArrayLikeToArray === 'function' ? deps.objectArrayLikeToArray : () => [];
  const parseBooleanish = typeof deps.parseBooleanish === 'function' ? deps.parseBooleanish : () => null;
  const firstBooleanStatus = typeof deps.firstBooleanStatus === 'function' ? deps.firstBooleanStatus : () => ({ known: false, value: null, source: '' });
  const clonePlainValue = typeof deps.clonePlainValue === 'function' ? deps.clonePlainValue : (value) => value;

function extractPvPHelperBridgeSchema(db, matches = []) {
  const meta = db && typeof db === 'object' && db.matchHistoryMeta && typeof db.matchHistoryMeta === 'object' ? db.matchHistoryMeta : {};
  const candidates = [
    meta.schemaVersion,
    meta.matchHistorySchemaVersion,
    db && db.matchHistorySchemaVersion,
    db && db.scoreboardSchemaVersion,
    ...(Array.isArray(matches) ? matches.map((item) => item && item.addonScoreboard && item.addonScoreboard.schemaVersion) : [])
  ];
  for (const value of candidates) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 0) return n;
  }
  return 0;
}

function extractPvPHelperAddonStatus(db, matches = [], snapshots = []) {
  const addonVersion = extractPvPHelperVersion(db);
  const versionStatus = buildPvPHelperVersionStatus(addonVersion);
  const bridgeSchemaVersion = extractPvPHelperBridgeSchema(db, matches);
  const matchHistoryMeta = db && typeof db === 'object' && db.matchHistoryMeta && typeof db.matchHistoryMeta === 'object' ? db.matchHistoryMeta : {};
  const profile = db && typeof db === 'object' ? (db.profile || {}) : {};
  const combatLog = profile && typeof profile === 'object' ? (profile.combatLog || {}) : {};
  const diagnostics = db && typeof db === 'object' && db.diagnostics && typeof db.diagnostics === 'object' ? db.diagnostics : {};
  const loggingStatus = db && typeof db === 'object' && db.logging && typeof db.logging === 'object' ? db.logging : {};
  const appStatus = db && typeof db === 'object' && db.appStatus && typeof db.appStatus === 'object' ? db.appStatus : {};
  const appLogRequests = appStatus && typeof appStatus.logRequests === 'object' && appStatus.logRequests ? appStatus.logRequests : {};
  const appLoggingStatus = appStatus && typeof appStatus.loggingStatus === 'object' && appStatus.loggingStatus ? appStatus.loggingStatus : {};
  const appCurrentContext = appStatus && typeof appStatus.currentContext === 'object' && appStatus.currentContext ? appStatus.currentContext : {};
  const appStatusFound = Boolean(appStatus && Object.keys(appStatus).length);
  const logRequestSource = Object.keys(appLogRequests).length ? appLogRequests : combatLog;
  const combatLogConfigFound = Boolean((logRequestSource && typeof logRequestSource === 'object' && Object.keys(logRequestSource).length) || Object.prototype.hasOwnProperty.call(appStatus, 'hasLogRequests'));
  const matchHistoryObject = db && typeof db === 'object' ? (db.matchHistory || db.matches || []) : [];
  const matchHistory = objectArrayLikeToArray(matchHistoryObject);
  const latestMatchLogging = [...matchHistory].reverse().map((item) => item && typeof item === 'object' ? item.logging : null).find((item) => item && typeof item === 'object') || {};
  const modeLabels = [
    ['arena', 'Arena'],
    ['soloShuffle', 'Solo Shuffle'],
    ['skirmish', 'Skirmish'],
    ['ratedBattleground', 'Rated BG'],
    ['normalBattleground', 'Normal BG'],
    ['dungeon', 'Dungeon'],
    ['raid', 'Raid']
  ];
  const enabledModes = modeLabels.filter(([key]) => parseBooleanish(logRequestSource && logRequestSource[key]) === true).map(([, label]) => label);
  const disabledModes = modeLabels.filter(([key]) => parseBooleanish(logRequestSource && logRequestSource[key]) === false).map(([, label]) => label);
  const scoreboardCaptureStatus = firstBooleanStatus([
    { value: appStatus.captureScoreboard, source: 'PvPHelper appStatus.captureScoreboard' },
    { value: combatLog.captureScoreboard, source: 'PvPHelper profile.combatLog.captureScoreboard' },
    { value: matchHistoryMeta.captureScoreboard, source: 'PvPHelper matchHistoryMeta.captureScoreboard' },
    { value: loggingStatus.captureScoreboard, source: 'PvPHelper logging.captureScoreboard' },
    { value: diagnostics.captureScoreboard, source: 'PvPHelper diagnostics.captureScoreboard' }
  ]);
  const scoreboardCaptureEnabled = scoreboardCaptureStatus.known ? scoreboardCaptureStatus.value === true : false;
  const advancedCombatLoggingStatus = firstBooleanStatus([
    { value: appStatus.advancedCombatLogging, source: 'PvPHelper appStatus.advancedCombatLogging' },
    { value: appStatus.advancedCombatLoggingEnabled, source: 'PvPHelper appStatus.advancedCombatLoggingEnabled' },
    { value: appStatus.advancedCombatLoggingRaw, source: 'PvPHelper appStatus.advancedCombatLoggingRaw' },
    { value: combatLog.advancedCombatLogging, source: 'PvPHelper profile.combatLog.advancedCombatLogging' },
    { value: combatLog.advancedCombatLoggingEnabled, source: 'PvPHelper profile.combatLog.advancedCombatLoggingEnabled' },
    { value: combatLog.advancedLogging, source: 'PvPHelper profile.combatLog.advancedLogging' },
    { value: matchHistoryMeta.advancedCombatLogging, source: 'PvPHelper matchHistoryMeta.advancedCombatLogging' },
    { value: matchHistoryMeta.advancedCombatLoggingEnabled, source: 'PvPHelper matchHistoryMeta.advancedCombatLoggingEnabled' },
    { value: loggingStatus.advancedCombatLogging, source: 'PvPHelper logging.advancedCombatLogging' },
    { value: loggingStatus.advancedCombatLoggingEnabled, source: 'PvPHelper logging.advancedCombatLoggingEnabled' },
    { value: diagnostics.advancedCombatLogging, source: 'PvPHelper diagnostics.advancedCombatLogging' },
    { value: diagnostics.advancedCombatLoggingEnabled, source: 'PvPHelper diagnostics.advancedCombatLoggingEnabled' },
    { value: latestMatchLogging.advancedCombatLogging, source: 'latest PvPHelper scoreboard snapshot' },
    { value: latestMatchLogging.advancedCombatLoggingEnabled, source: 'latest PvPHelper scoreboard snapshot' }
  ]);
  const liveCombatLoggingStatus = firstBooleanStatus([
    { value: appStatus.combatLoggingActive, source: 'PvPHelper appStatus.combatLoggingActive' },
    { value: loggingStatus.combatLoggingActive, source: 'PvPHelper logging.combatLoggingActive' },
    { value: loggingStatus.active, source: 'PvPHelper logging.active' }
  ]);
  const recordingReminderStatus = firstBooleanStatus([
    { value: appStatus.recordingReminderEnabled, source: 'PvPHelper appStatus.recordingReminderEnabled' },
    { value: combatLog.recordingReminderEnabled, source: 'PvPHelper profile.combatLog.recordingReminderEnabled' }
  ]);
  const addonAutoStartedStatus = firstBooleanStatus([
    { value: appStatus.addonAutoStartedLogging, source: 'PvPHelper appStatus.addonAutoStartedLogging' },
    { value: combatLog.autoStarted, source: 'PvPHelper profile.combatLog.autoStarted' }
  ]);
  const characterObject = db && typeof db === 'object' && db.characters && typeof db.characters === 'object' ? db.characters : {};
  const characterCount = Object.keys(characterObject || {}).length;
  const matchHistoryCount = Array.isArray(matchHistoryObject) ? matchHistoryObject.length : Object.keys(matchHistoryObject || {}).length;
  const readinessIssues = [];
  const readinessWarnings = [];
  if (combatLogConfigFound && enabledModes.length === 0) readinessIssues.push('No PvPHelper match logging modes are enabled. Combat logs may not be started automatically.');
  if (scoreboardCaptureStatus.known && !scoreboardCaptureEnabled) readinessIssues.push('Save scoreboard snapshots is off. Final scoreboards will not be saved to PvPHelper.lua.');
  if (!scoreboardCaptureStatus.known) readinessWarnings.push('Could not confirm whether Save scoreboard snapshots is enabled. Sync after opening PvPHelper options in game.');
  if (advancedCombatLoggingStatus.known && advancedCombatLoggingStatus.value === false) readinessIssues.push('Advanced Combat Logging is off. Health/resource timelines may be missing or thinner.');
  if (!advancedCombatLoggingStatus.known) readinessWarnings.push('Advanced Combat Logging could not be verified from SavedVariables yet. A newer addon bridge can write this directly; current snapshots may only reveal it after a scoreboard capture.');
  if (!appStatusFound) readinessWarnings.push('PvPHelperDB.appStatus was not found yet. Update/sync PvPHelper 0.12.8+ after /reload for cleaner addon status checks.');
  return {
    ...versionStatus,
    addonFound: Boolean(db && typeof db === 'object' && Object.keys(db).length),
    matchHistorySchemaVersion: bridgeSchemaVersion,
    matchHistoryMeta: clonePlainValue(matchHistoryMeta),
    matchHistoryMetaFound: Boolean(matchHistoryMeta && Object.keys(matchHistoryMeta).length),
    appStatus: clonePlainValue(appStatus),
    appStatusFound,
    appStatusSchemaVersion: Number(appStatus.schemaVersion || 0) || 0,
    appStatusUpdatedAt: Number(appStatus.updatedAt || 0) || 0,
    appStatusUpdatedAtUTC: String(appStatus.updatedAtUTC || ''),
    appStatusUpdatedAtLocal: String(appStatus.updatedAtLocal || ''),
    appStatusReason: String(appStatus.reason || ''),
    appStatusSourceAddon: String(appStatus.sourceAddon || ''),
    combatLogConfigFound,
    combatLoggingEnabled: enabledModes.length > 0,
    combatLogSource: Object.keys(appLogRequests).length ? 'PvPHelper appStatus.logRequests' : 'PvPHelper profile.combatLog',
    enabledModes,
    disabledModes,
    scoreboardCaptureKnown: scoreboardCaptureStatus.known,
    scoreboardCaptureSource: scoreboardCaptureStatus.source,
    scoreboardCaptureEnabled,
    advancedCombatLoggingKnown: advancedCombatLoggingStatus.known,
    advancedCombatLoggingEnabled: advancedCombatLoggingStatus.value,
    advancedCombatLoggingSource: advancedCombatLoggingStatus.source,
    liveCombatLoggingKnown: liveCombatLoggingStatus.known,
    combatLoggingActive: liveCombatLoggingStatus.value,
    combatLoggingActiveSource: liveCombatLoggingStatus.source,
    loggingStatusText: String(appLoggingStatus.text || ''),
    loggingStatusColor: String(appLoggingStatus.color || ''),
    currentContext: clonePlainValue(appCurrentContext),
    dataReadinessOK: readinessIssues.length === 0,
    dataReadinessIssues: readinessIssues,
    dataReadinessWarnings: readinessWarnings,
    recordingReminderEnabled: recordingReminderStatus.value === true,
    recordingReminderSource: recordingReminderStatus.source,
    manualMode: appStatus.manualMode ? String(appStatus.manualMode) : (combatLog && combatLog.manualMode ? String(combatLog.manualMode) : ''),
    addonAutoStartedLogging: addonAutoStartedStatus.value === true,
    addonAutoStartedSource: addonAutoStartedStatus.source,
    addonAutoStartedAt: Number(appStatus.addonAutoStartedAt || 0) || 0,
    showStatus: combatLog && combatLog.showStatus === true,
    matchHistoryCount,
    scoreboardSnapshotCount: Array.isArray(matches) ? matches.length : 0,
    characterCount,
    characterSnapshotCount: Array.isArray(snapshots) ? snapshots.length : 0,
    hasScoreboardData: (Array.isArray(matches) && matches.length > 0) || matchHistoryCount > 0,
    hasCharacterData: characterCount > 0 || (Array.isArray(snapshots) && snapshots.length > 0)
  };
}

  return {
    extractPvPHelperBridgeSchema,
    extractPvPHelperAddonStatus
  };
}

module.exports = { createPvPHelperStatusTools };
