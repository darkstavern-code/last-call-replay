function createStateStorageTools(deps = {}) {
  const app = deps.app;
  const fs = deps.fs;
  const path = deps.path;
  const hashText = typeof deps.hashText === 'function' ? deps.hashText : (value) => String(value || '');
  const appStorageDir = typeof deps.appStorageDir === 'function' ? deps.appStorageDir : () => process.cwd();
  const ensureDir = typeof deps.ensureDir === 'function' ? deps.ensureDir : (dir) => { if (dir) fs.mkdirSync(dir, { recursive: true }); };
  const sanitizeVodRecord = typeof deps.sanitizeVodRecord === 'function' ? deps.sanitizeVodRecord : (record) => record;
  const cleanBracketName = typeof deps.cleanBracketName === 'function' ? deps.cleanBracketName : (value) => String(value || 'Unknown');
  const normalizeMatchDataSources = typeof deps.normalizeMatchDataSources === 'function' ? deps.normalizeMatchDataSources : (match) => match;
  const resolveStateMatchLibrary = typeof deps.resolveStateMatchLibrary === 'function' ? deps.resolveStateMatchLibrary : () => null;
  const constants = deps.constants || {};
  const EVENT_FEED_PREVIEW_ROWS = Number(constants.EVENT_FEED_PREVIEW_ROWS || 800);
  const EVENT_FEED_LEGACY_MAX_ROWS = Number(constants.EVENT_FEED_LEGACY_MAX_ROWS || 1600);
  const EVENT_FEED_CACHE_MAX_ROWS = Number(constants.EVENT_FEED_CACHE_MAX_ROWS || 12000);
  const EVENT_FEED_CACHE_TRIGGER_ROWS = Number(constants.EVENT_FEED_CACHE_TRIGGER_ROWS || 900);
  const STORAGE_HEALTH_PLAYER_LIMIT = Number(constants.STORAGE_HEALTH_PLAYER_LIMIT || 80);
  const STORAGE_HEALTH_POINT_LIMIT = Number(constants.STORAGE_HEALTH_POINT_LIMIT || 420);
  const STORAGE_METRIC_ROW_LIMIT = Number(constants.STORAGE_METRIC_ROW_LIMIT || 80);
  const STORAGE_ABILITY_LIMIT = Number(constants.STORAGE_ABILITY_LIMIT || 45);
  const STORAGE_ABILITY_EVENT_LIMIT = Number(constants.STORAGE_ABILITY_EVENT_LIMIT || 70);
  const STORAGE_TARGET_LIMIT = Number(constants.STORAGE_TARGET_LIMIT || 24);
  const EMERGENCY_EVENT_FEED_PREVIEW_ROWS = Number(constants.EMERGENCY_EVENT_FEED_PREVIEW_ROWS || 120);
  const EMERGENCY_HEALTH_POINT_LIMIT = Number(constants.EMERGENCY_HEALTH_POINT_LIMIT || 90);
  const EMERGENCY_ABILITY_EVENT_LIMIT = Number(constants.EMERGENCY_ABILITY_EVENT_LIMIT || 20);
  const DEFAULT_UPDATE_MANIFEST_URL = String(constants.DEFAULT_UPDATE_MANIFEST_URL || 'https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json');
  const DEFAULT_UPDATE_RELEASE_URL = String(constants.DEFAULT_UPDATE_RELEASE_URL || 'https://github.com/darkstavern-code/last-call-replay/releases');
  let stateBackupMadeThisRun = false;
  let lastStatePayloadHash = '';

function statePath() {
  return path.join(appStorageDir(), 'state.json');
}


function stateBackupsDir() {
  const dir = path.join(appStorageDir(), 'backups');
  ensureDir(dir);
  return dir;
}


function stateBackupStamp() {
  return new Date().toISOString().replace(/[:.]/g, '-');
}


function pruneStateBackups(keep = 30) {
  try {
    const dir = stateBackupsDir();
    const files = fs.readdirSync(dir)
      .filter((name) => /^state-.*\.json$/i.test(name))
      .map((name) => {
        const filePath = path.join(dir, name);
        let mtimeMs = 0;
        try { mtimeMs = fs.statSync(filePath).mtimeMs; } catch (_error) {}
        return { name, filePath, mtimeMs };
      })
      .sort((a, b) => b.mtimeMs - a.mtimeMs);
    for (const file of files.slice(Math.max(0, Number(keep) || 30))) {
      try { fs.unlinkSync(file.filePath); } catch (_error) {}
    }
  } catch (_error) {}
}


function createStateBackup(reason = 'manual') {
  const source = statePath();
  try {
    if (!fs.existsSync(source)) return { ok: false, reason: 'No existing state file to back up yet.', source, backupPath: '' };
    const stat = fs.statSync(source);
    if (!stat || stat.size < 2) return { ok: false, reason: 'State file is empty, backup skipped.', source, backupPath: '' };
    const cleanReason = String(reason || 'manual').replace(/[^a-z0-9_-]+/gi, '-').slice(0, 40) || 'manual';
    const backupPath = path.join(stateBackupsDir(), `state-${cleanReason}-v${app.getVersion()}-${stateBackupStamp()}.json`);
    fs.copyFileSync(source, backupPath);
    pruneStateBackups(30);
    return { ok: true, source, backupPath, bytes: stat.size, createdAt: new Date().toISOString() };
  } catch (error) {
    return { ok: false, reason: error && error.message ? error.message : String(error), source, backupPath: '' };
  }
}


function createStateBackupBeforeWrite(reason = 'before-write') {
  if (stateBackupMadeThisRun) return null;
  stateBackupMadeThisRun = true;
  return createStateBackup(reason);
}



function eventFeedCacheDir() {
  const dir = path.join(appStorageDir(), 'event-feeds');
  ensureDir(dir);
  return dir;
}


function safeEventFeedCacheKey(match = {}) {
  const source = [
    match.id || '',
    match.rawFingerprint || '',
    match.matchFingerprint || '',
    match.startIso || '',
    match.startMs || '',
    match.endIso || '',
    match.map || '',
    match.matchType || match.bracket || ''
  ].join('|');
  return hashText(source || JSON.stringify(match || {})).slice(0, 28);
}


function eventFeedCachePath(cacheRef) {
  const clean = String(cacheRef || '').replace(/[^a-f0-9]/gi, '').slice(0, 64);
  if (!clean) return '';
  return path.join(eventFeedCacheDir(), `${clean}.json`);
}


function storedEventFeedCount(match = {}) {
  return Math.max(
    Array.isArray(match && match.eventFeed) ? match.eventFeed.length : 0,
    Array.isArray(match && match.rawEvents) ? match.rawEvents.length : 0,
    Number(match && match.eventFeedRows || 0),
    Number(match && match.eventFeedCachedRows || 0)
  );
}


function eventFeedCacheStats() {
  const stats = { files: 0, bytes: 0 };
  try {
    const dir = eventFeedCacheDir();
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      if (!entry.isFile() || !/\.json$/i.test(entry.name)) continue;
      const stat = fs.statSync(path.join(dir, entry.name));
      stats.files += 1;
      stats.bytes += stat.size || 0;
    }
  } catch (_error) {}
  return stats;
}


function readMatchEventFeedCache(match = {}) {
  const ref = match && match.eventFeedCacheRef ? String(match.eventFeedCacheRef) : '';
  const filePath = eventFeedCachePath(ref);
  if (!filePath || !fs.existsSync(filePath)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    return Array.isArray(parsed && parsed.rows) ? parsed.rows : [];
  } catch (_error) {
    return [];
  }
}


function writeMatchEventFeedCache(match = {}, rows = []) {
  if (!Array.isArray(rows) || !rows.length) return { ok: false, reason: 'No event rows to cache.' };
  const cacheRef = safeEventFeedCacheKey(match);
  const filePath = eventFeedCachePath(cacheRef);
  if (!filePath) return { ok: false, reason: 'Could not build event cache path.' };
  const compactRows = compactEventFeedRows(rows, EVENT_FEED_CACHE_MAX_ROWS);
  const payload = {
    schemaVersion: 1,
    matchId: match.id || '',
    rawFingerprint: match.rawFingerprint || '',
    rows: compactRows,
    rowCount: compactRows.length,
    sourceRowCount: rows.length,
    cachedAt: new Date().toISOString()
  };
  try {
    fs.writeFileSync(filePath, JSON.stringify(payload), 'utf8');
    return { ok: true, cacheRef, filePath, rows: compactRows.length, cachedAt: payload.cachedAt };
  } catch (error) {
    return { ok: false, reason: error && error.message ? error.message : String(error) };
  }
}


function pruneEventFeedCache(state = {}) {
  const refs = new Set();
  for (const match of Array.isArray(state.matches) ? state.matches : []) {
    if (match && match.eventFeedCacheRef) refs.add(String(match.eventFeedCacheRef));
    if (Array.isArray(match && match.soloRounds)) {
      for (const round of match.soloRounds) {
        if (round && round.eventFeedCacheRef) refs.add(String(round.eventFeedCacheRef));
      }
    }
  }
  let removed = 0;
  let removedBytes = 0;
  try {
    const dir = eventFeedCacheDir();
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (!entry.isFile() || !/\.json$/i.test(entry.name)) continue;
      const ref = entry.name.replace(/\.json$/i, '');
      if (refs.has(ref)) continue;
      const filePath = path.join(dir, entry.name);
      let bytes = 0;
      try { bytes = fs.statSync(filePath).size || 0; } catch (_error) {}
      try {
        fs.unlinkSync(filePath);
        removed += 1;
        removedBytes += bytes;
      } catch (_error) {}
    }
  } catch (_error) {}
  return { removed, removedBytes };
}


function defaultSettings() {
  const base = appStorageDir();
  return {
    logFilePath: '',
    logFolderPath: '',
    recordingsDir: '',
    recordingsDirConfirmed: false,
    archiveDir: path.join(base, 'archives'),
    autoLinkWindowMinutes: 0,
    clipExportDir: '',
    pvpHelperSavedVariablesPath: '',
    updateReleaseUrl: DEFAULT_UPDATE_RELEASE_URL,
    updateManifestUrl: DEFAULT_UPDATE_MANIFEST_URL,
    updateLastCheckedAt: '',
    updateLatestVersion: '',
    updateReleasedAt: '',
    updateInstallerUrl: '',
    updateZipUrl: '',
    updateReleaseNotes: [],
    pvpHelperAddonInstallStatus: {},
    pvpHelperSavedVariablesDiscovery: {},
    pvpHelperAddonLastInstallAt: '',
    pvpHelperAutoSync: true,
    pvpHelperLastSyncMtimeMs: 0,
    pvpHelperLastSyncAt: '',
    pvpHelperFileExists: null,
    pvpHelperStatus: {},
    pvpHelperLastScoreboardCount: 0,
    pvpHelperLastPendingCount: 0,
    pvpHelperLastMergedCount: 0,
    pvpHelperLastRatingSnapshotCount: 0,
    logIngestMode: 'activeOnly',
    logLastSyncAt: '',
    logLastSyncFilePath: '',
    logLastSyncBytes: 0,
    logLastSyncMode: '',
    logLastRepairAt: '',
    logLastRepairSummary: ''
  };
}



function characterSnapshotDedupeKey(item = {}) {
  const name = String(item.character || item.name || 'Unknown').split('-')[0].toLowerCase().trim();
  const bracket = cleanBracketName(item.bracket || item.matchType || 'Unknown').toLowerCase();
  const capturedAt = String(item.capturedAt || item.date || '').trim();
  const rating = item.rating == null ? '' : String(item.rating);
  const played = item.seasonPlayed == null ? '' : String(item.seasonPlayed);
  const spec = String(item.specId || item.specName || item.spec || '').toLowerCase().trim();
  const source = String(item.sourceType || item.sourceFile || '').toLowerCase().trim();
  return `${name}|${bracket}|${spec}|${capturedAt}|${rating}|${played}|${source}`;
}


function dedupeCharacterSnapshots(list = []) {
  const seen = new Set();
  const out = [];
  for (const item of list || []) {
    if (!item) continue;
    const key = characterSnapshotDedupeKey(item);
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}



function isUsableStateMatch(match) {
  if (!match || typeof match !== 'object') return false;
  if (match.sample || match.demo || match.placeholder || match.isSample || match.isDemo || match.isPlaceholder) return false;
  const id = String(match.id || '').toLowerCase();
  if (/^(sample|demo|placeholder)/.test(id)) return false;
  return Boolean(
    match.id ||
    match.rawFingerprint ||
    match.createdFromRealLog ||
    match.createdFromAddon ||
    match.addonScoreboard ||
    match.startIso ||
    match.startMs ||
    match.map ||
    (Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length)
  );
}


function sanitizeState(state) {
  const safe = state && typeof state === 'object' ? state : {};
  const defaults = defaultSettings();
  const incomingSettings = safe.settings || {};
  safe.settings = { ...defaults, ...incomingSettings };
  if (typeof safe.settings.recordingsDirConfirmed !== 'boolean') {
    safe.settings.recordingsDirConfirmed = Boolean(incomingSettings.recordingsDir && incomingSettings.recordingsDir !== defaults.recordingsDir);
  }
  safe.settings.pvpHelperSavedVariablesPath = String(safe.settings.pvpHelperSavedVariablesPath || '');
  safe.settings.updateReleaseUrl = String(safe.settings.updateReleaseUrl || DEFAULT_UPDATE_RELEASE_URL);
  safe.settings.updateManifestUrl = String(safe.settings.updateManifestUrl || DEFAULT_UPDATE_MANIFEST_URL);
  safe.settings.updateLastCheckedAt = String(safe.settings.updateLastCheckedAt || '');
  safe.settings.updateLatestVersion = String(safe.settings.updateLatestVersion || '');
  safe.settings.updateReleasedAt = String(safe.settings.updateReleasedAt || '');
  safe.settings.updateInstallerUrl = String(safe.settings.updateInstallerUrl || '');
  safe.settings.updateZipUrl = String(safe.settings.updateZipUrl || '');
  safe.settings.updateReleaseNotes = Array.isArray(safe.settings.updateReleaseNotes) ? safe.settings.updateReleaseNotes.map((note) => String(note || '').trim()).filter(Boolean).slice(0, 12) : [];
  safe.settings.pvpHelperAddonInstallStatus = safe.settings.pvpHelperAddonInstallStatus && typeof safe.settings.pvpHelperAddonInstallStatus === 'object' ? safe.settings.pvpHelperAddonInstallStatus : {};
  safe.settings.pvpHelperAddonLastInstallAt = String(safe.settings.pvpHelperAddonLastInstallAt || '');
  safe.settings.pvpHelperAutoSync = safe.settings.pvpHelperAutoSync !== false;
  safe.settings.pvpHelperLastSyncMtimeMs = Number(safe.settings.pvpHelperLastSyncMtimeMs) || 0;
  safe.settings.pvpHelperLastSyncAt = String(safe.settings.pvpHelperLastSyncAt || '');
  safe.watchedFiles = safe.watchedFiles || {};
  safe.logFileRegistry = safe.logFileRegistry && typeof safe.logFileRegistry === 'object' ? safe.logFileRegistry : {};
  safe.importedFiles = Array.isArray(safe.importedFiles) ? safe.importedFiles : [];
  safe.addonImports = Array.isArray(safe.addonImports) ? safe.addonImports : [];
  safe.favoriteFolders = Array.isArray(safe.favoriteFolders) ? safe.favoriteFolders.filter((folder) => folder && folder.id && folder.name).map((folder) => ({ id: String(folder.id), name: String(folder.name).slice(0, 48), createdAt: folder.createdAt || new Date().toISOString() })) : [];
  safe.recordings = Array.isArray(safe.recordings) ? safe.recordings : [];
  safe.vods = Array.isArray(safe.vods) ? safe.vods.filter(Boolean).map(sanitizeVodRecord).filter(Boolean) : [];
  safe.characterSnapshots = Array.isArray(safe.characterSnapshots) ? dedupeCharacterSnapshots(safe.characterSnapshots.filter(Boolean)) : [];
  safe.hiddenPlayers = Array.isArray(safe.hiddenPlayers) ? safe.hiddenPlayers.filter(Boolean) : [];
  safe.deletedMatchIds = Array.isArray(safe.deletedMatchIds) ? safe.deletedMatchIds.filter(Boolean) : [];
  safe.recorderSettings = safe.recorderSettings && typeof safe.recorderSettings === 'object' ? safe.recorderSettings : {};
  delete safe.recorderSettings.stopOnLogUpdate;
  delete safe.recorderSettings.explicitMatchEndAutoStop;
  delete safe.recorderSettings.minSecondsBeforeLogStop;
  safe.recorderSettings.includeAudio = Object.prototype.hasOwnProperty.call(safe.recorderSettings, 'includeAudio') ? Boolean(safe.recorderSettings.includeAudio) : true;
  if (!['low', 'balanced', 'quality'].includes(String(safe.recorderSettings.performanceMode || ''))) safe.recorderSettings.performanceMode = 'balanced';
  if (!Array.isArray(safe.recorderSettings.approvedWowSourceNames)) safe.recorderSettings.approvedWowSourceNames = [];
  safe.matches = Array.isArray(safe.matches)
    ? safe.matches.filter(isUsableStateMatch).map((match) => normalizeMatchDataSources({ ...match, isBracketMatch: match.isBracketMatch !== false }))
    : [];
  resolveStateMatchLibrary(safe, 'sanitize-state', { autoLink: false });
  if (safe.settings.recordingsDir && safe.settings.recordingsDirConfirmed) ensureDir(safe.settings.recordingsDir);
  ensureDir(safe.settings.archiveDir || defaults.archiveDir);
  safe.schemaVersion = Number(safe.schemaVersion) || 0;
  pruneStateBeforeWrite(safe);
  return safe;
}


function readState() {
  try {
    const raw = fs.readFileSync(statePath(), 'utf8');
    lastStatePayloadHash = hashText(raw);
    return sanitizeState(JSON.parse(raw));
  } catch (_error) {
    return sanitizeState({});
  }
}


function writeState(state) {
  pruneStateBeforeWrite(state);
  let payload = '';
  try {
    const compactJson = stateNeedsPressureShrink(state);
    payload = JSON.stringify(state, null, compactJson ? 0 : 2);
  } catch (error) {
    console.error('[Last Call Replay] State was too large to save. Compacting heavy match data and retrying.', error);
    pruneStateBeforeWrite(state, { aggressive: true });
    payload = JSON.stringify(state, null, 0);
  }

  const payloadHash = hashText(payload);
  if (payloadHash && payloadHash === lastStatePayloadHash && fs.existsSync(statePath())) {
    return { ok: true, skipped: true, reason: 'State unchanged.' };
  }

  createStateBackupBeforeWrite('before-write');
  const targetPath = statePath();
  const tmpPath = `${targetPath}.${process.pid || 'pid'}.${Date.now()}.tmp`;
  try {
    fs.writeFileSync(tmpPath, payload, 'utf8');
    fs.renameSync(tmpPath, targetPath);
    lastStatePayloadHash = payloadHash;
    return { ok: true, bytes: Buffer.byteLength(payload, 'utf8'), compact: stateNeedsPressureShrink(state) };
  } catch (error) {
    try { if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath); } catch (_cleanupError) {}
    throw error;
  }
}


function compactEventFeedRows(rows = [], limit = EVENT_FEED_LEGACY_MAX_ROWS) {
  if (!Array.isArray(rows)) return [];
  const cap = Math.max(1, Number(limit || EVENT_FEED_LEGACY_MAX_ROWS));
  return rows.slice(0, cap).map((item) => {
    if (!item || typeof item !== 'object') return item;
    const { raw: _raw, rawText: _rawText, line: _line, ...rest } = item;
    for (const key of Object.keys(rest)) {
      if (typeof rest[key] === 'string' && rest[key].length > 220) rest[key] = rest[key].slice(0, 220);
    }
    return rest;
  });
}


function compactAbilityForStorage(ability = {}, options = {}) {
  if (!ability || typeof ability !== 'object') return ability;
  const eventLimit = Math.max(0, Number(options.eventLimit || STORAGE_ABILITY_EVENT_LIMIT));
  const targetLimit = Math.max(0, Number(options.targetLimit || STORAGE_TARGET_LIMIT));
  const compact = { ...ability };
  if (Array.isArray(compact.events)) compact.events = compact.events.slice(0, eventLimit).map((event) => {
    if (!event || typeof event !== 'object') return event;
    const { raw: _raw, rawText: _rawText, line: _line, fields: _fields, ...rest } = event;
    return rest;
  });
  if (Array.isArray(compact.targets)) compact.targets = compact.targets.slice(0, targetLimit);
  return compact;
}


function compactMetricRowsForStorage(rows = [], options = {}) {
  if (!Array.isArray(rows)) return [];
  const rowLimit = Math.max(0, Number(options.rowLimit || STORAGE_METRIC_ROW_LIMIT));
  const abilityLimit = Math.max(0, Number(options.abilityLimit || STORAGE_ABILITY_LIMIT));
  return rows.slice(0, rowLimit).map((row) => {
    if (!row || typeof row !== 'object') return row;
    const compact = { ...row };
    if (Array.isArray(compact.abilities)) compact.abilities = compact.abilities.slice(0, abilityLimit).map((ability) => compactAbilityForStorage(ability, options));
    if (Array.isArray(compact.petBreakdown)) compact.petBreakdown = compact.petBreakdown.slice(0, STORAGE_TARGET_LIMIT);
    return compact;
  });
}


function compactMetricsObjectForStorage(metrics = {}, options = {}) {
  if (!metrics || typeof metrics !== 'object' || Array.isArray(metrics)) return metrics;
  const compact = {};
  for (const [key, value] of Object.entries(metrics)) {
    compact[key] = Array.isArray(value) ? compactMetricRowsForStorage(value, options) : value;
  }
  return compact;
}


function compactHealthTimelineForStorage(timeline = {}, options = {}) {
  if (!timeline || typeof timeline !== 'object') return timeline;
  const playerLimit = Math.max(0, Number(options.playerLimit || STORAGE_HEALTH_PLAYER_LIMIT));
  const pointLimit = Math.max(0, Number(options.pointLimit || STORAGE_HEALTH_POINT_LIMIT));
  const compact = { ...timeline };
  if (Array.isArray(compact.players)) {
    compact.players = compact.players.slice(0, playerLimit).map((player) => {
      if (!player || typeof player !== 'object') return player;
      const { rawPoints: _rawPoints, ...rest } = player;
      if (Array.isArray(rest.points) && rest.points.length > pointLimit) {
        const first = rest.points[0];
        const last = rest.points[rest.points.length - 1];
        const stride = Math.max(1, Math.ceil(rest.points.length / pointLimit));
        const sampled = rest.points.filter((_point, index) => index % stride === 0).slice(0, pointLimit);
        if (first && sampled[0] !== first) sampled.unshift(first);
        if (last && sampled[sampled.length - 1] !== last) sampled.push(last);
        rest.points = sampled.slice(0, pointLimit);
      }
      return rest;
    });
  }
  if (Array.isArray(compact.deaths)) compact.deaths = compact.deaths.slice(0, 80);
  return compact;
}



function estimateStatePressure(state = {}) {
  const pressure = { matches: 0, eventRows: 0, healthPoints: 0, metricEvents: 0 };
  const matches = Array.isArray(state.matches) ? state.matches : [];
  pressure.matches = matches.length;
  for (const match of matches) {
    if (!match || typeof match !== 'object') continue;
    pressure.eventRows += Array.isArray(match.eventFeed) ? match.eventFeed.length : 0;
    pressure.eventRows += Array.isArray(match.rawEvents) ? match.rawEvents.length : 0;
    if (match.healthTimeline && Array.isArray(match.healthTimeline.players)) {
      for (const player of match.healthTimeline.players) pressure.healthPoints += Array.isArray(player && player.points) ? player.points.length : 0;
    }
    const metricGroups = [];
    if (match.metrics && typeof match.metrics === 'object') metricGroups.push(...Object.values(match.metrics));
    for (const key of ['damage', 'healing', 'taken']) if (Array.isArray(match[key])) metricGroups.push(match[key]);
    for (const rows of metricGroups) {
      if (!Array.isArray(rows)) continue;
      for (const row of rows) {
        const abilities = Array.isArray(row && row.abilities) ? row.abilities : [];
        for (const ability of abilities) pressure.metricEvents += Array.isArray(ability && ability.events) ? ability.events.length : 0;
      }
    }
    if (pressure.eventRows > 180000 || pressure.healthPoints > 140000 || pressure.metricEvents > 220000) break;
  }
  return pressure;
}

function stateNeedsPressureShrink(state = {}) {
  const pressure = estimateStatePressure(state);
  return pressure.matches > 450
    || pressure.eventRows > 180000
    || pressure.healthPoints > 140000
    || pressure.metricEvents > 220000;
}

function emergencyShrinkStateForWrite(state = {}) {
  if (!state || typeof state !== 'object') return state;
  if (Array.isArray(state.matches)) {
    state.matches = state.matches.map((match) => {
      if (!match || typeof match !== 'object') return match;
      const compact = sanitizeMatchForStorage(match);
      if (Array.isArray(compact.eventFeed)) compact.eventFeed = compactEventFeedRows(compact.eventFeed, EMERGENCY_EVENT_FEED_PREVIEW_ROWS);
      if (compact.healthTimeline) compact.healthTimeline = compactHealthTimelineForStorage(compact.healthTimeline, { pointLimit: EMERGENCY_HEALTH_POINT_LIMIT });
      if (compact.metrics) compact.metrics = compactMetricsObjectForStorage(compact.metrics, { eventLimit: EMERGENCY_ABILITY_EVENT_LIMIT, abilityLimit: 22, rowLimit: 50, targetLimit: 12 });
      for (const key of ['damage', 'healing', 'taken']) {
        if (Array.isArray(compact[key])) compact[key] = compactMetricRowsForStorage(compact[key], { eventLimit: EMERGENCY_ABILITY_EVENT_LIMIT, abilityLimit: 22, rowLimit: 50, targetLimit: 12 });
      }
      if (Array.isArray(compact.cooldowns)) compact.cooldowns = compact.cooldowns.slice(0, 40);
      if (Array.isArray(compact.ccChains)) compact.ccChains = compact.ccChains.slice(0, 40);
      if (Array.isArray(compact.interrupts)) compact.interrupts = compact.interrupts.slice(0, 40);
      return compact;
    });
  }
  if (Array.isArray(state.importedFiles)) state.importedFiles = state.importedFiles.slice(0, 80);
  if (state.settings) {
    state.settings.stateEmergencyCompactedAt = new Date().toISOString();
    state.settings.stateEmergencyCompactedReason = 'state-json-too-large';
  }
  return state;
}


function sanitizeMatchForStorage(match) {
  if (!match || typeof match !== 'object') return match;
  const eventFeed = Array.isArray(match.eventFeed) ? match.eventFeed : [];
  const rawEvents = Array.isArray(match.rawEvents) ? match.rawEvents : [];
  const sourceRows = eventFeed.length ? eventFeed : rawEvents;
  const existingStoredRows = Number(match.eventFeedRows || match.eventFeedCachedRows || 0) || 0;
  const hasExternalCache = Boolean(match.eventFeedCacheRef && existingStoredRows > sourceRows.length);

  if (sourceRows.length) {
    if (!hasExternalCache && sourceRows.length >= EVENT_FEED_CACHE_TRIGGER_ROWS) {
      const cache = writeMatchEventFeedCache(match, sourceRows);
      if (cache.ok) {
        match.eventFeedCacheRef = cache.cacheRef;
        match.eventFeedRows = cache.rows;
        match.eventFeedCachedRows = cache.rows;
        match.eventFeedCachedAt = cache.cachedAt;
        match.eventFeed = compactEventFeedRows(sourceRows, EVENT_FEED_PREVIEW_ROWS);
      } else {
        match.eventFeed = compactEventFeedRows(sourceRows, EVENT_FEED_LEGACY_MAX_ROWS);
        match.eventFeedCacheError = String(cache.reason || 'Event cache write failed.').slice(0, 180);
        match.eventFeedRows = Math.max(existingStoredRows, sourceRows.length);
      }
    } else {
      match.eventFeed = compactEventFeedRows(sourceRows, hasExternalCache ? EVENT_FEED_PREVIEW_ROWS : EVENT_FEED_LEGACY_MAX_ROWS);
      if (hasExternalCache) {
        match.eventFeedRows = existingStoredRows;
        match.eventFeedCachedRows = existingStoredRows;
      } else {
        match.eventFeedRows = Math.max(existingStoredRows, sourceRows.length);
      }
    }
  } else if (existingStoredRows) {
    match.eventFeedRows = existingStoredRows;
    match.eventFeedCachedRows = existingStoredRows;
    match.eventFeed = [];
  }

  // eventFeed and rawEvents usually point at the same replay feed. Keep one tiny
  // preview on the match summary and move the heavy copy to per-match cache files.
  delete match.rawEvents;
  delete match.eventFeedHydrated;

  if (Array.isArray(match.soloRounds)) {
    match.soloRounds = match.soloRounds.slice(0, 6).map((round) => {
      if (!round || typeof round !== 'object') return round;
      const nextRound = { ...round };
      const roundEventFeed = Array.isArray(nextRound.eventFeed) ? nextRound.eventFeed : [];
      const roundRawEvents = Array.isArray(nextRound.rawEvents) ? nextRound.rawEvents : [];
      const roundSourceRows = roundEventFeed.length ? roundEventFeed : roundRawEvents;
      const roundExistingRows = Number(nextRound.eventFeedRows || nextRound.eventFeedCachedRows || 0) || 0;
      const roundHasExternalCache = Boolean(nextRound.eventFeedCacheRef && roundExistingRows > roundSourceRows.length);
      if (roundSourceRows.length) {
        if (!roundHasExternalCache && roundSourceRows.length >= EVENT_FEED_CACHE_TRIGGER_ROWS) {
          const roundCache = writeMatchEventFeedCache({
            ...match,
            ...nextRound,
            id: `${match.id || 'solo_lobby'}:round:${nextRound.roundNumber || ''}`,
            rawFingerprint: `${match.rawFingerprint || match.matchFingerprint || match.id || 'solo_lobby'}:round:${nextRound.roundNumber || nextRound.startMs || ''}`,
            matchFingerprint: `${match.matchFingerprint || match.rawFingerprint || match.id || 'solo_lobby'}:round:${nextRound.roundNumber || nextRound.startMs || ''}`
          }, roundSourceRows);
          if (roundCache.ok) {
            nextRound.eventFeedCacheRef = roundCache.cacheRef;
            nextRound.eventFeedRows = roundCache.rows;
            nextRound.eventFeedCachedRows = roundCache.rows;
            nextRound.eventFeedCachedAt = roundCache.cachedAt;
            nextRound.eventFeed = compactEventFeedRows(roundSourceRows, Math.min(EVENT_FEED_PREVIEW_ROWS, 260));
          } else {
            nextRound.eventFeed = compactEventFeedRows(roundSourceRows, Math.min(EVENT_FEED_LEGACY_MAX_ROWS, 420));
            nextRound.eventFeedCacheError = String(roundCache.reason || 'Round event cache write failed.').slice(0, 180);
            nextRound.eventFeedRows = Math.max(roundExistingRows, roundSourceRows.length);
          }
        } else {
          nextRound.eventFeed = compactEventFeedRows(roundSourceRows, roundHasExternalCache ? Math.min(EVENT_FEED_PREVIEW_ROWS, 260) : Math.min(EVENT_FEED_LEGACY_MAX_ROWS, 420));
          if (roundHasExternalCache) {
            nextRound.eventFeedRows = roundExistingRows;
            nextRound.eventFeedCachedRows = roundExistingRows;
          } else {
            nextRound.eventFeedRows = Math.max(roundExistingRows, roundSourceRows.length);
          }
        }
      } else if (roundExistingRows) {
        nextRound.eventFeedRows = roundExistingRows;
        nextRound.eventFeedCachedRows = roundExistingRows;
        nextRound.eventFeed = [];
      }
      delete nextRound.rawEvents;
      delete nextRound.eventFeedHydrated;
      if (nextRound.healthTimeline) nextRound.healthTimeline = compactHealthTimelineForStorage(nextRound.healthTimeline, { playerLimit: 12, pointLimit: 120 });
      if (nextRound.metrics) nextRound.metrics = compactMetricsObjectForStorage(nextRound.metrics, { eventLimit: 80, abilityLimit: 24, rowLimit: 60, targetLimit: 15 });
      for (const key of ['damage', 'healing', 'taken']) {
        if (Array.isArray(nextRound[key])) nextRound[key] = compactMetricRowsForStorage(nextRound[key], { eventLimit: 80, abilityLimit: 24, rowLimit: 60, targetLimit: 15 });
      }
      if (Array.isArray(nextRound.cooldowns)) nextRound.cooldowns = nextRound.cooldowns.slice(0, 60);
      if (Array.isArray(nextRound.ccChains)) nextRound.ccChains = nextRound.ccChains.slice(0, 60);
      if (Array.isArray(nextRound.interrupts)) nextRound.interrupts = nextRound.interrupts.slice(0, 60);
      if (Array.isArray(nextRound.chart)) nextRound.chart = nextRound.chart.slice(0, 120);
      return nextRound;
    });
  }
  if (match.healthTimeline) match.healthTimeline = compactHealthTimelineForStorage(match.healthTimeline);
  if (match.metrics) match.metrics = compactMetricsObjectForStorage(match.metrics);
  for (const key of ['damage', 'healing', 'taken']) {
    if (Array.isArray(match[key])) match[key] = compactMetricRowsForStorage(match[key]);
  }
  if (Array.isArray(match.chart)) match.chart = match.chart.slice(0, 160);
  if (Array.isArray(match.cooldowns)) match.cooldowns = match.cooldowns.slice(0, 100);
  if (Array.isArray(match.ccChains)) match.ccChains = match.ccChains.slice(0, 100);
  if (Array.isArray(match.interrupts)) match.interrupts = match.interrupts.slice(0, 100);
  return match;
}


function pruneStateBeforeWrite(state, options = {}) {
  if (!state || typeof state !== 'object') return state;
  if (Array.isArray(state.matches)) state.matches = state.matches.map(sanitizeMatchForStorage);
  if ((options && options.aggressive) || stateNeedsPressureShrink(state)) emergencyShrinkStateForWrite(state);
  if (Array.isArray(state.importedFiles)) {
    state.importedFiles = state.importedFiles.slice(0, 250).map((item) => {
      if (!item || typeof item !== 'object') return item;
      const { matches: _matches, repairedMatches: _repairedMatches, selectedMatch: _selectedMatch, raw: _raw, rawText: _rawText, ...rest } = item;
      if (Array.isArray(rest.targetedDetails)) rest.targetedDetails = rest.targetedDetails.slice(0, 30);
      return rest;
    });
  }
  return state;
}



  return {
    statePath,
    stateBackupsDir,
    stateBackupStamp,
    pruneStateBackups,
    createStateBackup,
    createStateBackupBeforeWrite,
    eventFeedCacheDir,
    safeEventFeedCacheKey,
    eventFeedCachePath,
    storedEventFeedCount,
    eventFeedCacheStats,
    readMatchEventFeedCache,
    writeMatchEventFeedCache,
    pruneEventFeedCache,
    defaultSettings,
    characterSnapshotDedupeKey,
    dedupeCharacterSnapshots,
    isUsableStateMatch,
    sanitizeState,
    readState,
    writeState,
    compactEventFeedRows,
    compactAbilityForStorage,
    compactMetricRowsForStorage,
    compactMetricsObjectForStorage,
    compactHealthTimelineForStorage,
    emergencyShrinkStateForWrite,
    estimateStatePressure,
    stateNeedsPressureShrink,
    sanitizeMatchForStorage,
    pruneStateBeforeWrite,
  };
}

module.exports = { createStateStorageTools };
