'use strict';

function createSoloShuffleTools(deps = {}) {
  const normalizeMatchType = typeof deps.normalizeMatchType === 'function' ? deps.normalizeMatchType : ((value) => String(value || ''));
  const matchTimeRangeMs = typeof deps.matchTimeRangeMs === 'function' ? deps.matchTimeRangeMs : (() => ({ start: 0, gameStart: 0, end: 0 }));
  const normalizedMapKey = typeof deps.normalizedMapKey === 'function' ? deps.normalizedMapKey : ((value) => String(value || '').toLowerCase().trim());
  const uniqueList = typeof deps.uniqueList === 'function' ? deps.uniqueList : ((values = []) => Array.from(new Set((values || []).filter(Boolean))));
  const hashText = typeof deps.hashText === 'function' ? deps.hashText : ((value) => String(value || '').replace(/[^a-z0-9]+/gi, '').slice(0, 24));
  const formatDuration = typeof deps.formatDuration === 'function' ? deps.formatDuration : ((seconds) => `${Math.floor((Number(seconds) || 0) / 60)}:${String(Math.max(0, Math.round(Number(seconds) || 0) % 60)).padStart(2, '0')}`);
  const mergeUserPreservedMatchFields = typeof deps.mergeUserPreservedMatchFields === 'function' ? deps.mergeUserPreservedMatchFields : ((incoming) => incoming);
  const shortNameKey = typeof deps.shortNameKey === 'function' ? deps.shortNameKey : ((value) => String(value || '').toLowerCase().replace(/-.+$/, '').trim());
  const isUsefulUnitName = typeof deps.isUsefulUnitName === 'function' ? deps.isUsefulUnitName : ((name) => Boolean(String(name || '').trim()));
  const getParserVersion = typeof deps.getParserVersion === 'function' ? deps.getParserVersion : (() => deps.parserVersion || 0);

  function inferSoloShuffleRoundWinnerFromDeath(deaths = [], teams = {}) {
    const realDeath = (deaths || []).find((death) => death && !death.isFeignDeath && isUsefulUnitName(death.victim));
    if (!realDeath) return { winnerTeam: null, victim: '', victimTeam: '', source: '' };
    let victimTeam = String(realDeath.victimTeam || '').trim();
    if (victimTeam !== '0' && victimTeam !== '1') {
      const victimKeys = new Set([realDeath.victim, shortNameKey(realDeath.victim)].filter(Boolean).map((name) => String(name).toLowerCase()));
      for (const teamKey of ['0', '1']) {
        const names = Array.isArray(teams && teams[teamKey]) ? teams[teamKey] : [];
        if (names.some((name) => victimKeys.has(String(name || '').toLowerCase()) || victimKeys.has(shortNameKey(name)))) {
          victimTeam = teamKey;
          break;
        }
      }
    }
    if (victimTeam !== '0' && victimTeam !== '1') return { winnerTeam: null, victim: realDeath.victim || '', victimTeam: '', source: 'death-unknown-team' };
    return {
      winnerTeam: victimTeam === '0' ? '1' : '0',
      victim: realDeath.victim || '',
      victimTeam,
      source: 'first-player-death'
    };
  }


  function isSoloShuffleMatch(match = {}) {
    return normalizeMatchType(match.matchType || match.bracket || '') === 'Solo Shuffle' || Boolean(match.isSoloShuffle);
  }

  function nameFromScoreboardPlayer(player = {}) {
    return player && (player.name || player.fullName || player.playerName || player.playerFullName || player.character || player.unitName || player.rawName) || '';
  }

  function matchPlayerIdentitySet(match = {}) {
    const soloRoundNames = Array.isArray(match.soloRounds) ? match.soloRounds.flatMap((round) => [
      ...(Array.isArray(round && round.participants) ? round.participants : []),
      ...(Array.isArray(round && round.myComp) ? round.myComp : []),
      ...(Array.isArray(round && round.enemyComp) ? round.enemyComp : []),
      ...(Array.isArray(round && round.ownNames) ? round.ownNames : []),
      ...(Array.isArray(round && round.enemies) ? round.enemies : [])
    ]) : [];
    const scoreboardNames = Array.isArray(match.scoreboardPlayers) ? match.scoreboardPlayers.map(nameFromScoreboardPlayer) : [];
    const names = [
      ...(Array.isArray(match.participants) ? match.participants : []),
      ...(Array.isArray(match.myComp) ? match.myComp : []),
      ...(Array.isArray(match.enemyComp) ? match.enemyComp : []),
      ...(Array.isArray(match.ownNames) ? match.ownNames : []),
      ...(Array.isArray(match.enemies) ? match.enemies : []),
      ...soloRoundNames,
      ...scoreboardNames
    ];
    return new Set(names.map((name) => String(name || '').toLowerCase().replace(/-.+$/, '').trim()).filter(Boolean));
  }

  function asPlayerIdentitySet(value) {
    if (value instanceof Set) return value;
    if (Array.isArray(value)) return new Set(value.map((name) => String(name || '').toLowerCase().replace(/-.+$/, '').trim()).filter(Boolean));
    return new Set();
  }

  function playerSetOverlapCount(a, b) {
    const setA = asPlayerIdentitySet(a);
    const setB = asPlayerIdentitySet(b);
    if (!setA.size || !setB.size) return 0;
    let count = 0;
    for (const name of setA) if (setB.has(name)) count += 1;
    return count;
  }


  function normalizedSoloMap(value = '') {
    return normalizedMapKey(value).replace(/[’']/g, "'").replace(/\s+/g, ' ').trim();
  }

  function parseLocalDateTimeAsUtcMs(value = '') {
    const raw = String(value || '').trim();
    if (!raw) return 0;
    const normalized = raw.includes('T') ? raw : raw.replace(' ', 'T');
    const withSeconds = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(normalized) ? `${normalized}:00` : normalized;
    const ms = Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/i.test(withSeconds) ? withSeconds : `${withSeconds}Z`);
    return Number.isFinite(ms) ? ms : 0;
  }

  function addonLocalTimeCandidatesMs(match = {}) {
    const scoreboard = match && match.addonScoreboard && typeof match.addonScoreboard === 'object' ? match.addonScoreboard : {};
    const rawFields = scoreboard.rawFields && scoreboard.rawFields.scalarFields && typeof scoreboard.rawFields.scalarFields === 'object' ? scoreboard.rawFields.scalarFields : {};
    const values = [
      scoreboard.capturedAtLocal,
      scoreboard.capturedAtLocalText,
      rawFields.capturedAtLocal,
      rawFields.capturedAtLocalText,
      rawFields.matchEndTimeLocal,
      rawFields.matchStartTimeLocal
    ];
    return uniqueList(values).map(parseLocalDateTimeAsUtcMs).filter(Boolean);
  }

  function soloTimingCandidatesMs(match = {}) {
    const values = [
      Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0),
      Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0),
      match.capturedAt ? Date.parse(match.capturedAt) : 0,
      ...(addonLocalTimeCandidatesMs(match) || [])
    ];
    return values.map((value) => Number(value) || 0).filter((value) => Number.isFinite(value) && value > 1000000000000);
  }

  function soloLobbyTimeDistanceMs(lobby = {}, snapshot = {}) {
    const lobbyTimes = [
      Number(lobby.soloShuffleSessionStartMs) || Number(lobby.startMs) || (lobby.startIso ? Date.parse(lobby.startIso) : 0),
      Number(lobby.soloShuffleSessionEndMs) || Number(lobby.endMs) || (lobby.endIso ? Date.parse(lobby.endIso) : 0)
    ].filter(Boolean);
    const snapshotTimes = soloTimingCandidatesMs(snapshot);
    const distances = [];
    for (const a of lobbyTimes) for (const b of snapshotTimes) distances.push(Math.abs(a - b));
    return distances.length ? Math.min(...distances) : Infinity;
  }


  function soloStartMs(match = {}) {
    return Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0) || Number(match.gameStartMs) || (match.gameStartIso ? Date.parse(match.gameStartIso) : 0) || 0;
  }

  function soloEndMs(match = {}) {
    return Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0) || (soloStartMs(match) ? soloStartMs(match) + Math.max(1, Number(match.durationSec || 0)) * 1000 : 0);
  }

  function soloTimeOverlapsLobby(match = {}, lobby = {}, padMs = 3 * 60 * 1000) {
    const start = soloStartMs(match);
    const end = soloEndMs(match) || start;
    const lobbyStart = Number(lobby.soloShuffleSessionStartMs) || soloStartMs(lobby);
    const lobbyEnd = Number(lobby.soloShuffleSessionEndMs) || soloEndMs(lobby) || lobbyStart;
    if (!start || !lobbyStart || !lobbyEnd) return false;
    return start <= lobbyEnd + padMs && end >= lobbyStart - padMs;
  }

  function soloMapMatches(left = {}, right = {}) {
    const leftMap = normalizedSoloMap(left.map || left.zone || left.subzone || '');
    const rightMap = normalizedSoloMap(right.map || right.zone || right.subzone || '');
    return !leftMap || !rightMap || leftMap === rightMap;
  }

  function soloPlayerOverlapOrUnknown(left = {}, right = {}, minimum = 3) {
    const leftPlayers = matchPlayerIdentitySet(left);
    const rightPlayers = matchPlayerIdentitySet(right);
    if (!leftPlayers.size || !rightPlayers.size) return true;
    return playerSetOverlapCount(leftPlayers, rightPlayers) >= minimum;
  }

  function soloMatchLooksLikeOneRoundShell(match = {}) {
    if (!match || !isSoloShuffleMatch(match)) return false;
    if (isSoloShuffleRoundChildMatch(match)) return true;
    const rounds = Array.isArray(match.soloRounds) ? match.soloRounds.filter(Boolean) : [];
    const detected = Number(match.soloShuffleDetectedRoundCount || 0) || rounds.length || Number(match.soloShuffleRoundCount || 0) || 0;
    const duration = Number(match.durationSec || 0) || Math.round(Math.max(0, soloEndMs(match) - soloStartMs(match)) / 1000);
    const teamRoundLabel = /round/i.test(String(match.summary || match.danger || match.dataQualityNote || match.matchLabel || match.label || '').toLowerCase());
    return detected <= 1 || rounds.length <= 1 || duration <= 5 * 60 || teamRoundLabel;
  }

  function soloMatchDuplicatesLobby(match = {}, lobby = {}) {
    if (!match || !lobby || !isSoloShuffleMatch(match) || !isSoloShuffleLobbyMatch(lobby)) return false;
    if (String(match.id || '') && String(match.id || '') === String(lobby.id || '')) return false;
    if (!soloMapMatches(match, lobby)) return false;
    if (!soloTimeOverlapsLobby(match, lobby, 6 * 60 * 1000)) return false;
    if (!soloPlayerOverlapOrUnknown(match, lobby, 3)) return false;
    return soloMatchLooksLikeOneRoundShell(match);
  }

  function groupRangeForSoloItems(group = []) {
    const starts = (group || []).map((item) => Number(item.start || 0)).filter(Boolean);
    const ends = (group || []).map((item) => Number(item.end || 0)).filter(Boolean);
    const start = starts.length ? Math.min(...starts) : 0;
    const end = ends.length ? Math.max(...ends) : start;
    const map = group && group[0] ? group[0].map || '' : '';
    const players = new Set();
    for (const item of group || []) for (const name of asPlayerIdentitySet(item && item.players)) players.add(name);
    return { start, end, map, players };
  }

  function existingLobbyScoreForGroup(existing = {}, group = [], key = '') {
    if (!existing || !isSoloShuffleLobbyMatch(existing)) return 0;
    if (key && String(existing.id || '') === String(key)) return 10000;
    const range = groupRangeForSoloItems(group);
    if (!range.start) return 0;
    const lobbyStart = Number(existing.soloShuffleSessionStartMs) || soloStartMs(existing);
    const lobbyEnd = Number(existing.soloShuffleSessionEndMs) || soloEndMs(existing) || lobbyStart;
    if (!lobbyStart) return 0;
    const groupShell = { map: range.map, startMs: range.start, endMs: range.end, participants: Array.from(range.players) };
    if (!soloMapMatches(groupShell, existing)) return 0;
    const distance = Math.min(Math.abs(lobbyStart - range.start), lobbyEnd ? Math.abs(lobbyEnd - (range.end || range.start)) : Infinity);
    if (!Number.isFinite(distance) || distance > 25 * 60 * 1000) return 0;
    let score = 120 - Math.min(90, Math.round(distance / 10000));
    const overlap = playerSetOverlapCount(range.players, matchPlayerIdentitySet(existing));
    if (overlap >= 3) score += overlap * 20;
    else if (!range.players.size || !matchPlayerIdentitySet(existing).size) score += 15;
    if (Array.isArray(existing.soloRounds) && existing.soloRounds.length <= 1) score += 20;
    if (existing.videoPath || existing.vodId) score += 35;
    return score;
  }

  function bestExistingLobbyForGroup(existingLobbies = [], group = [], key = '') {
    let best = null;
    let bestScore = 0;
    for (const existing of existingLobbies || []) {
      const score = existingLobbyScoreForGroup(existing, group, key);
      if (score > bestScore) {
        bestScore = score;
        best = existing;
      }
    }
    return bestScore > 0 ? best : null;
  }

  function isAddonSoloScoreboardSnapshot(match = {}) {
    if (!match || !isSoloShuffleMatch(match)) return false;
    const hasScoreboard = Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length >= 4;
    return Boolean(hasScoreboard && (match.createdFromAddon || match.addonScoreboard || (match.dataSources || []).some((source) => /addon|scoreboard/i.test(String(source || '')))));
  }

  function soloSnapshotMatchesLobby(snapshot = {}, lobby = {}) {
    if (!isAddonSoloScoreboardSnapshot(snapshot) || !isSoloShuffleLobbyMatch(lobby)) return false;
    const snapshotMap = normalizedSoloMap(snapshot.map || snapshot.zone || snapshot.subzone || '');
    const lobbyMap = normalizedSoloMap(lobby.map || lobby.zone || lobby.subzone || '');
    if (snapshotMap && lobbyMap && snapshotMap !== lobbyMap) return false;
    const overlap = playerSetOverlapCount(matchPlayerIdentitySet(snapshot), matchPlayerIdentitySet(lobby));
    if (overlap < 4) return false;
    const distance = soloLobbyTimeDistanceMs(lobby, snapshot);
    return Number.isFinite(distance) ? distance <= 20 * 60 * 1000 : overlap >= 5;
  }

  function mergeSoloShuffleScoreboardIntoLobby(lobby = {}, snapshot = {}) {
    if (!lobby || !snapshot) return lobby;
    const addonKey = snapshot.addonDedupeKey || snapshot.rawFingerprint || snapshot.id || '';
    lobby.scoreboardPlayers = Array.isArray(snapshot.scoreboardPlayers) && snapshot.scoreboardPlayers.length ? snapshot.scoreboardPlayers : (lobby.scoreboardPlayers || []);
    lobby.addonScoreboard = snapshot.addonScoreboard || lobby.addonScoreboard || null;
    lobby.addonImportedAt = snapshot.addonImportedAt || lobby.addonImportedAt || new Date().toISOString();
    lobby.addonImportConfidence = 'solo-shuffle-lobby';
    lobby.scoreboardSourceMatchId = snapshot.id || lobby.scoreboardSourceMatchId || '';
    lobby.scoreboardLinkedAt = new Date().toISOString();
    lobby.scoreboardTeamCounts = snapshot.scoreboardTeamCounts || lobby.scoreboardTeamCounts || {};
    lobby.expectedTeamSize = snapshot.expectedTeamSize || lobby.expectedTeamSize || 0;
    lobby.actualTeamSize = snapshot.actualTeamSize || lobby.actualTeamSize || 0;
    lobby.participants = uniqueList([...(lobby.participants || []), ...(snapshot.participants || [])]);
    lobby.myComp = Array.isArray(lobby.myComp) && lobby.myComp.length ? lobby.myComp : (snapshot.myComp || []);
    lobby.enemyComp = Array.isArray(lobby.enemyComp) && lobby.enemyComp.length ? lobby.enemyComp : (snapshot.enemyComp || []);
    lobby.enemies = uniqueList([...(lobby.enemies || []), ...(snapshot.enemies || snapshot.enemyComp || [])]);
    lobby.classByName = { ...(snapshot.classByName || {}), ...(lobby.classByName || {}) };
    lobby.specByName = { ...(snapshot.specByName || {}), ...(lobby.specByName || {}) };
    if (snapshot.result && snapshot.result !== 'Parsed' && snapshot.result !== 'Unscored') lobby.result = snapshot.result;
    if (addonKey) lobby.linkedAddonFingerprints = uniqueList([...(lobby.linkedAddonFingerprints || []), addonKey]);
    lobby.dataSources = uniqueList([...(lobby.dataSources || []), ...(snapshot.dataSources || []), 'addonScoreboard']);
    lobby.tags = uniqueList([...(lobby.tags || []), 'PvPHelper scoreboard merged']);
    return lobby;
  }

  function soloShuffleGroups(matches = []) {
    const solo = (matches || [])
      .filter((match) => match && isSoloShuffleMatch(match))
      .map((match) => {
        const range = matchTimeRangeMs(match);
        const timeCandidates = soloTimingCandidatesMs(match);
        const fallbackTime = timeCandidates.length ? Math.min(...timeCandidates) : 0;
        const start = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0) || range.gameStart || range.start || fallbackTime || 0;
        const end = Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0) || range.end || (start && Number(match.durationSec || 0) ? start + Number(match.durationSec || 0) * 1000 : start);
        return { match, start, end, players: matchPlayerIdentitySet(match), map: normalizedMapKey(match.map || ''), seed: String(match.soloShuffleLobbySeedKey || match.soloShuffleSessionKey || '') };
      })
      .filter((item) => item.start > 0)
      .sort((a, b) => a.start - b.start);
    const groups = [];
    for (const item of solo) {
      const lastGroup = groups[groups.length - 1];
      const previous = lastGroup && lastGroup[lastGroup.length - 1];
      const previousPlayers = previous ? asPlayerIdentitySet(previous.players) : new Set();
      const itemPlayers = asPlayerIdentitySet(item && item.players);
      const gapMs = previous ? item.start - Math.max(previous.end || previous.start, previous.start) : Infinity;
      const sameMap = previous && (!previous.map || !item.map || previous.map === item.map);
      const sameSeed = previous && previous.seed && item.seed && previous.seed === item.seed;
      const overlap = previous ? playerSetOverlapCount(previousPlayers, itemPlayers) : 0;
      const enoughSharedPlayers = previous ? (overlap >= 4 || !previousPlayers.size || !itemPlayers.size) : false;
      const canJoin = previous && lastGroup.length < 6 && ((sameSeed && gapMs >= 0 && gapMs <= 20 * 60 * 1000) || (gapMs >= 0 && gapMs <= 8 * 60 * 1000 && sameMap && enoughSharedPlayers));
      if (canJoin) lastGroup.push(item);
      else groups.push([item]);
    }
    return groups;
  }


  function isSoloShuffleLobbyMatch(match = {}) {
    return Boolean(match && (match.isSoloShuffleLobby || match.soloShuffleLobbyMatch));
  }

  function isSoloShuffleRoundChildMatch(match = {}) {
    return Boolean(match && match.isSoloShuffleRoundChild);
  }

  function soloRoundResult(match = {}) {
    const raw = String(match.result || match.winner || '').trim();
    if (/^win$/i.test(raw)) return 'Win';
    if (/^loss$/i.test(raw)) return 'Loss';
    return 'Unknown';
  }

  function addMetricAbility(targetAbilities, ability = {}) {
    const name = String(ability && ability.name || '').trim();
    if (!name) return;
    const row = targetAbilities.get(name) || { name, amount: 0, count: 0, actions: 0, hits: 0, casts: 0, min: 0, max: 0, events: [], targets: new Map() };
    const amount = Number(ability.amount || ability.total || 0) || 0;
    row.amount += amount;
    row.count += Number(ability.count || 0) || 0;
    row.actions += Number(ability.actions || 0) || 0;
    row.hits += Number(ability.hits || 0) || 0;
    row.casts += Number(ability.casts || 0) || 0;
    const min = Number(ability.min || 0) || 0;
    const max = Number(ability.max || 0) || 0;
    if (min && (!row.min || min < row.min)) row.min = min;
    if (max && max > row.max) row.max = max;
    if (Array.isArray(ability.events)) row.events.push(...ability.events.slice(0, 60));
    for (const target of Array.isArray(ability.targets) ? ability.targets : []) {
      const targetName = String(target && target.name || '').trim();
      if (!targetName) continue;
      const targetRow = row.targets.get(targetName) || { name: targetName, amount: 0, hits: 0, count: 0, isPlayer: target.isPlayer !== false };
      targetRow.amount += Number(target.amount || 0) || 0;
      targetRow.hits += Number(target.hits || 0) || 0;
      targetRow.count += Number(target.count || 0) || 0;
      if (target.isPlayer === false) targetRow.isPlayer = false;
      row.targets.set(targetName, targetRow);
    }
    targetAbilities.set(name, row);
  }

  function mergeMetricRows(rows = []) {
    const byName = new Map();
    for (const source of rows || []) {
      if (!source) continue;
      const name = String(source.name || source.actor || 'Unknown').trim() || 'Unknown';
      const row = byName.get(name) || { name, amount: 0, count: 0, actions: 0, hits: 0, casts: 0, abilities: new Map(), targets: new Map() };
      row.amount += Number(source.amount || source.total || 0) || 0;
      row.count += Number(source.count || 0) || 0;
      row.actions += Number(source.actions || 0) || 0;
      row.hits += Number(source.hits || 0) || 0;
      row.casts += Number(source.casts || 0) || 0;
      for (const ability of Array.isArray(source.abilities) ? source.abilities : []) addMetricAbility(row.abilities, ability);
      for (const target of Array.isArray(source.targets) ? source.targets : []) {
        const targetName = String(target && target.name || '').trim();
        if (!targetName) continue;
        const targetRow = row.targets.get(targetName) || { name: targetName, amount: 0, hits: 0, count: 0, isPlayer: target.isPlayer !== false };
        targetRow.amount += Number(target.amount || 0) || 0;
        targetRow.hits += Number(target.hits || 0) || 0;
        targetRow.count += Number(target.count || 0) || 0;
        if (target.isPlayer === false) targetRow.isPlayer = false;
        row.targets.set(targetName, targetRow);
      }
      byName.set(name, row);
    }
    const out = Array.from(byName.values()).map((row) => {
      const abilities = Array.from(row.abilities.values()).map((ability) => {
        const events = Array.isArray(ability.events) ? ability.events.slice(0, 80).sort((a, b) => (Number(a.relativeSec) || 0) - (Number(b.relativeSec) || 0)) : [];
        const targets = Array.from(ability.targets.values()).sort((a, b) => (Number(b.amount || b.hits || b.count) || 0) - (Number(a.amount || a.hits || a.count) || 0)).slice(0, 30);
        const hits = Number(ability.hits || ability.count || ability.actions || 0) || 0;
        const avg = ability.amount && hits ? Math.round(ability.amount / Math.max(1, hits)) : 0;
        return { ...ability, avg, events, targets };
      }).sort((a, b) => (Number(b.amount || b.count || b.hits) || 0) - (Number(a.amount || a.count || a.hits) || 0)).slice(0, 40);
      const targets = Array.from(row.targets.values()).sort((a, b) => (Number(b.amount || b.hits || b.count) || 0) - (Number(a.amount || a.hits || a.count) || 0)).slice(0, 30);
      const top = abilities.slice(0, 3).map((item) => item.name).filter(Boolean).join(', ');
      const { abilities: _abilities, targets: _targets, ...rest } = row;
      return { ...rest, abilities, targets, top };
    }).sort((a, b) => (Number(b.amount || b.count || b.actions || b.hits) || 0) - (Number(a.amount || a.count || a.actions || a.hits) || 0));
    const max = out.reduce((best, row) => Math.max(best, Number(row.amount || row.count || row.actions || row.hits) || 0), 1);
    const total = out.reduce((sum, row) => sum + (Number(row.amount || row.count || row.actions || row.hits) || 0), 0) || 1;
    return out.map((row) => {
      const value = Number(row.amount || row.count || row.actions || row.hits) || 0;
      return { ...row, percent: Math.max(1, Math.round((value / total) * 100)), barPercent: Math.max(2, Math.round((value / max) * 100)) };
    });
  }

  function aggregateSoloShuffleMetrics(roundMatches = []) {
    const metrics = {};
    const metricKeys = ['Damage', 'Healing', 'Taken', 'CC', 'Interrupts', 'Purges', 'Dispels', 'CC Dispels', 'Deaths', 'DamagePlayers', 'HealingPlayers', 'TakenPlayers'];
    for (const key of metricKeys) {
      const rows = [];
      for (const match of roundMatches) {
        const source = (match.metrics && Array.isArray(match.metrics[key]) ? match.metrics[key] : null)
          || (key === 'Damage' && Array.isArray(match.damage) ? match.damage : null)
          || (key === 'Healing' && Array.isArray(match.healing) ? match.healing : null)
          || (key === 'Taken' && Array.isArray(match.taken) ? match.taken : null);
        if (Array.isArray(source)) rows.push(...source);
      }
      metrics[key] = mergeMetricRows(rows);
    }
    return metrics;
  }

  function soloShuffleRoundPayload(match = {}, roundNumber = 1, sessionStartMs = 0) {
    const start = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0) || 0;
    const end = Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0) || (start ? start + Math.max(1, Number(match.durationSec || 0)) * 1000 : 0);
    const result = soloRoundResult(match);
    const victim = match.soloRoundEndVictim || (match.death && match.death.victim && match.death.victim !== 'No death detected' ? match.death.victim : '');
    const durationSec = Number(match.durationSec) || (start && end && end > start ? Math.round((end - start) / 1000) : 0);
    return {
      id: match.id || `round_${roundNumber}`,
      roundMatchId: match.id || '',
      roundNumber,
      result,
      winnerTeam: match.winnerTeam || 'Unknown',
      winnerTeamSource: match.winnerTeamSource || '',
      startMs: start,
      endMs: end,
      startIso: match.startIso || (start ? new Date(start).toISOString() : ''),
      endIso: match.endIso || (end ? new Date(end).toISOString() : ''),
      startOffsetSec: sessionStartMs && start ? Math.max(0, Math.round(((start - sessionStartMs) / 1000) * 10) / 10) : 0,
      endOffsetSec: sessionStartMs && end ? Math.max(0, Math.round(((end - sessionStartMs) / 1000) * 10) / 10) : Math.max(1, durationSec),
      durationSec,
      duration: match.duration || formatDuration(durationSec),
      myComp: Array.isArray(match.myComp) ? match.myComp : [],
      enemyComp: Array.isArray(match.enemyComp) ? match.enemyComp : [],
      teams: match.teams || {},
      ownTeam: match.ownTeam || '',
      firstDeath: victim,
      endVictim: victim,
      endVictimTeam: match.soloRoundEndVictimTeam || '',
      death: match.death || null,
      metrics: match.metrics || {},
      damage: match.damage || [],
      healing: match.healing || [],
      taken: match.taken || [],
      cooldowns: match.cooldowns || [],
      ccChains: match.ccChains || [],
      interrupts: match.interrupts || [],
      scoreboardPlayers: Array.isArray(match.scoreboardPlayers) ? match.scoreboardPlayers : [],
      addonScoreboard: match.addonScoreboard || null,
      healthTimeline: match.healthTimeline || null,
      eventFeed: match.eventFeed || [],
      rawEvents: match.rawEvents || [],
      eventFeedRows: Number(match.eventFeedRows || match.eventFeedCachedRows || 0) || (Array.isArray(match.eventFeed) ? match.eventFeed.length : 0),
      eventFeedCachedRows: Number(match.eventFeedCachedRows || match.eventFeedRows || 0) || (Array.isArray(match.eventFeed) ? match.eventFeed.length : 0),
      chart: match.chart || [],
      summary: match.summary || '',
      danger: match.danger || '',
      dataQualityNote: match.dataQualityNote || ''
    };
  }

  function buildSoloShuffleLobbyMatch(group = [], key = '', existingLobby = null) {
    const roundMatches = group.map((item) => item.match).filter(Boolean);
    if (!roundMatches.length) return null;
    const starts = group.map((item) => Number(item.start || 0)).filter(Boolean);
    const ends = group.map((item) => Number(item.end || 0)).filter(Boolean);
    const existingStart = Number(existingLobby && existingLobby.soloShuffleSessionStartMs) || Number(existingLobby && existingLobby.startMs) || (existingLobby && existingLobby.startIso ? Date.parse(existingLobby.startIso) : 0) || 0;
    const existingEnd = Number(existingLobby && existingLobby.soloShuffleSessionEndMs) || Number(existingLobby && existingLobby.endMs) || (existingLobby && existingLobby.endIso ? Date.parse(existingLobby.endIso) : 0) || 0;
    const sessionStart = starts.length ? Math.min(...starts, ...(existingStart ? [existingStart] : [])) : existingStart;
    const sessionEnd = ends.length ? Math.max(...ends, ...(existingEnd ? [existingEnd] : [])) : (existingEnd || (sessionStart ? sessionStart + Math.max(1, Number(roundMatches[0].durationSec || 120)) * 1000 : 0));
    const rebuiltRounds = group.slice().sort((a, b) => a.start - b.start).map((item, index) => soloShuffleRoundPayload(item.match, index + 1, sessionStart));
    const existingRounds = Array.isArray(existingLobby && existingLobby.soloRounds) ? existingLobby.soloRounds.filter(Boolean) : [];
    const sortedRounds = existingRounds.length > rebuiltRounds.length && existingRounds.length >= 2 ? existingRounds : rebuiltRounds;
    const wins = sortedRounds.filter((round) => round.result === 'Win').length;
    const losses = sortedRounds.filter((round) => round.result === 'Loss').length;
    const unknown = sortedRounds.filter((round) => round.result !== 'Win' && round.result !== 'Loss').length;
    const detectedRoundCount = sortedRounds.length;
    const incomplete = detectedRoundCount < 6;
    const participants = uniqueList(roundMatches.flatMap((match) => [
      ...(match.participants || []), ...(match.ownNames || []), ...(match.myComp || []), ...(match.enemyComp || []), ...(match.enemies || [])
    ].filter(Boolean)));
    const classByName = Object.assign({}, ...roundMatches.map((match) => match.classByName || {}));
    const specByName = Object.assign({}, ...roundMatches.map((match) => match.specByName || {}));
    const first = roundMatches[0] || {};
    const videoSeed = existingLobby || roundMatches.find((match) => match.videoPath) || {};
    const metrics = aggregateSoloShuffleMetrics(roundMatches);
    const result = wins > losses ? 'Win' : losses > wins ? 'Loss' : (wins || losses ? 'Parsed' : 'Parsed');
    const lobby = {
      ...(existingLobby || {}),
      id: key || `shuffle_lobby_${hashText(`${sessionStart}|${participants.join('|')}`).slice(0, 12)}`,
      isSoloShuffle: true,
      isSoloShuffleLobby: true,
      matchType: 'Solo Shuffle',
      bracket: 'Solo Shuffle',
      result,
      soloShuffleWins: wins,
      soloShuffleLosses: losses,
      soloShuffleUnknownRounds: unknown,
      soloShuffleDetectedRoundCount: detectedRoundCount,
      soloShuffleExpectedRoundCount: 6,
      soloShuffleIncomplete: incomplete,
      soloShuffleSessionKey: key,
      soloShuffleSessionStartMs: sessionStart,
      soloShuffleSessionEndMs: sessionEnd,
      soloRounds: sortedRounds,
      map: first.map || 'Unknown arena',
      date: sessionStart ? new Date(sessionStart).toLocaleDateString() : (first.date || ''),
      time: sessionStart ? `${new Date(sessionStart).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}${sessionEnd ? ` to ${new Date(sessionEnd).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}` : ''}` : (first.time || 'Imported'),
      startIso: sessionStart ? new Date(sessionStart).toISOString() : (first.startIso || ''),
      endIso: sessionEnd ? new Date(sessionEnd).toISOString() : (first.endIso || ''),
      startMs: sessionStart,
      endMs: sessionEnd,
      gameStartMs: sessionStart,
      gameStartIso: sessionStart ? new Date(sessionStart).toISOString() : '',
      durationSec: sessionStart && sessionEnd && sessionEnd > sessionStart ? Math.round((sessionEnd - sessionStart) / 1000) : roundMatches.reduce((sum, match) => sum + (Number(match.durationSec) || 0), 0),
      duration: sessionStart && sessionEnd && sessionEnd > sessionStart ? formatDuration(Math.round((sessionEnd - sessionStart) / 1000)) : formatDuration(roundMatches.reduce((sum, match) => sum + (Number(match.durationSec) || 0), 0)),
      alt: first.alt || first.playerName || first.character || 'Unknown Player',
      playerGuid: first.playerGuid || '',
      ownNames: uniqueList(roundMatches.flatMap((match) => match.ownNames || []).filter(Boolean)),
      myComp: sortedRounds[0] ? sortedRounds[0].myComp : (first.myComp || []),
      enemyComp: sortedRounds[0] ? sortedRounds[0].enemyComp : (first.enemyComp || []),
      enemies: uniqueList(roundMatches.flatMap((match) => match.enemies || match.enemyComp || []).filter(Boolean)),
      participants,
      classByName,
      specByName,
      spec: first.spec || 'Spec unknown',
      metrics,
      damage: metrics.Damage || [],
      healing: metrics.Healing || [],
      taken: metrics.Taken || [],
      cooldowns: roundMatches.flatMap((match) => match.cooldowns || []).slice(0, 120),
      ccChains: roundMatches.flatMap((match) => match.ccChains || []).slice(0, 120),
      interrupts: roundMatches.flatMap((match) => match.interrupts || []).slice(0, 120),
      death: sortedRounds.find((round) => round.death && round.death.victim && round.death.victim !== 'No death detected')?.death || first.death || null,
      chart: first.chart || [],
      healthTimeline: first.healthTimeline || null,
      eventFeed: roundMatches.flatMap((match) => match.eventFeed || []).slice(0, 250),
      rawFingerprint: key,
      sourceLabel: uniqueList(roundMatches.map((match) => match.sourceLabel).filter(Boolean)).join(', '),
      createdFromRealLog: roundMatches.some((match) => match.createdFromRealLog),
      isBracketMatch: true,
      parserVersion: getParserVersion(),
      summary: `Solo Shuffle lobby: ${wins}W - ${losses}L, ${detectedRoundCount} round${detectedRoundCount === 1 ? '' : 's'} detected${incomplete ? ', incomplete/unclear.' : '.'}`,
      danger: incomplete ? 'Solo Shuffle lobby is incomplete or has unclear rounds.' : 'Solo Shuffle lobby grouped successfully.',
      dataQualityNote: incomplete ? 'Solo Shuffle detected fewer than 6 clear rounds. This can happen when someone leaves early or a log ends before the lobby is complete.' : (unknown ? 'Solo Shuffle has all six rounds, but one or more round results could not be inferred from the combat log.' : ''),
      tags: uniqueList(['Solo Shuffle lobby', `${wins}W - ${losses}L`, `${detectedRoundCount} rounds detected`, ...(incomplete ? ['Incomplete'] : [])]),
      dataSources: uniqueList(roundMatches.flatMap((match) => match.dataSources || []).concat('combatLog'))
    };
    for (const keyName of ['videoPath', 'videoLabel', 'videoLinkedAt', 'videoLinkMode', 'vodId', 'vodLinkedAt', 'videoSessionId', 'videoClipStartSec', 'videoClipEndSec', 'videoMatchStartSec', 'videoMatchEndSec', 'videoShuffleStartSec', 'videoShuffleEndSec', 'videoClipPreRollSec', 'videoClipPostRollSec', 'videoSyncAdjustmentSec', 'manualVideoSection', 'videoSectionUpdatedAt']) {
      if (videoSeed[keyName] !== undefined && videoSeed[keyName] !== null && videoSeed[keyName] !== '') lobby[keyName] = videoSeed[keyName];
    }
    for (const sourceMatch of roundMatches) {
      if (isAddonSoloScoreboardSnapshot(sourceMatch)) mergeSoloShuffleScoreboardIntoLobby(lobby, sourceMatch);
    }
    return mergeUserPreservedMatchFields(lobby, existingLobby || {});
  }


  function soloCanonicalSourceRows(matches = []) {
    return (Array.isArray(matches) ? matches : []).filter((match) => match && isSoloShuffleMatch(match) && !isSoloShuffleLobbyMatch(match));
  }

  function soloLooksLikeEmptyGenericArenaSnapshot(match = {}, lobbies = []) {
    if (!match || isSoloShuffleMatch(match) || isSoloShuffleLobbyMatch(match)) return false;
    const typeText = `${match.matchType || ''} ${match.bracket || ''} ${match.matchLabel || ''} ${match.label || ''}`.toLowerCase();
    if (!/arena/.test(typeText)) return false;
    if ((Array.isArray(match.scoreboardPlayers) ? match.scoreboardPlayers.length : 0) > 0) return false;
    const hasCombat = Boolean(match.createdFromRealLog) || (match.dataSources || []).some((source) => /combat|log/i.test(String(source || '')));
    if (hasCombat) return false;
    const weakReason = `${match.captureReason || ''} ${match.reason || ''} ${match.sourceLabel || ''} ${match.dataQualityNote || ''}`.toLowerCase();
    const looksWeak = /player_leaving_world|leaving|empty|generic|addon|scoreboard/.test(weakReason) || Boolean(match.createdFromAddon || match.addonScoreboard);
    if (!looksWeak) return false;
    return (lobbies || []).some((lobby) => soloMapMatches(match, lobby) && soloTimeOverlapsLobby(match, lobby, 8 * 60 * 1000));
  }

  function soloGroupCanonicalKey(group = [], existingLobbies = []) {
    const sessionStart = Math.min(...group.map((item) => Number(item.start || 0)).filter(Boolean));
    const participants = uniqueList(group.flatMap((item) => Array.from(item.players || []))).sort().join('|');
    const map = group[0] ? group[0].map || '' : '';
    const seed = group.find((item) => item && item.seed)?.seed || '';
    const existing = bestExistingLobbyForGroup(existingLobbies, group, seed ? `shuffle_lobby_${hashText(seed).slice(0, 12)}` : '');
    if (existing && existing.id && isSoloShuffleLobbyMatch(existing)) return String(existing.id);
    return seed ? `shuffle_lobby_${hashText(seed).slice(0, 12)}` : `shuffle_lobby_${hashText(`${sessionStart}|${map}|${participants}`).slice(0, 12)}`;
  }

  function hasSoloCombatDetails(match = {}) {
    if (!match || typeof match !== 'object') return false;
    const sources = Array.isArray(match.dataSources) ? match.dataSources : [];
    return Boolean(match.createdFromRealLog || sources.some((source) => /combat|log|tail/i.test(String(source || ''))) || (Array.isArray(match.eventFeed) && match.eventFeed.length) || (match.healthTimeline && ((Array.isArray(match.healthTimeline.players) && match.healthTimeline.players.length) || Array.isArray(match.healthTimeline))));
  }

  function mergeSoloCombatDetailsIntoLobby(lobby = {}, source = {}) {
    if (!lobby || !source || !hasSoloCombatDetails(source)) return lobby;
    lobby.createdFromRealLog = Boolean(lobby.createdFromRealLog || source.createdFromRealLog);
    lobby.parserVersion = Math.max(Number(lobby.parserVersion || 0) || 0, Number(source.parserVersion || 0) || 0) || lobby.parserVersion || source.parserVersion;
    for (const keyName of ['sourceLabel', 'sourceFile', 'rawFingerprint', 'matchFingerprint', 'playerGuid', 'spec', 'logOnlyReason', 'logOnlyMatch', 'endInferred', 'inferredEndTime', 'inferredEndMs', 'captureReason']) {
      if ((lobby[keyName] === undefined || lobby[keyName] === null || lobby[keyName] === '') && source[keyName] !== undefined && source[keyName] !== null && source[keyName] !== '') lobby[keyName] = source[keyName];
    }
    for (const keyName of ['eventFeed', 'rawEvents', 'eventFeedRows', 'eventFeedCachedRows', 'cooldowns', 'ccChains', 'interrupts', 'chart']) {
      const left = Array.isArray(lobby[keyName]) ? lobby[keyName] : [];
      const right = Array.isArray(source[keyName]) ? source[keyName] : [];
      if (right.length) lobby[keyName] = [...left, ...right].slice(0, keyName === 'eventFeed' || keyName === 'rawEvents' ? 500 : 160);
    }
    if ((!lobby.healthTimeline || (Array.isArray(lobby.healthTimeline) && !lobby.healthTimeline.length)) && source.healthTimeline) lobby.healthTimeline = source.healthTimeline;
    if ((!lobby.death || lobby.death.victim === 'No death detected') && source.death) lobby.death = source.death;
    if (source.metrics && typeof source.metrics === 'object') {
      lobby.metrics = lobby.metrics && Object.keys(lobby.metrics || {}).length ? lobby.metrics : source.metrics;
      lobby.damage = Array.isArray(lobby.damage) && lobby.damage.length ? lobby.damage : (source.damage || (source.metrics && source.metrics.Damage) || []);
      lobby.healing = Array.isArray(lobby.healing) && lobby.healing.length ? lobby.healing : (source.healing || (source.metrics && source.metrics.Healing) || []);
      lobby.taken = Array.isArray(lobby.taken) && lobby.taken.length ? lobby.taken : (source.taken || (source.metrics && source.metrics.Taken) || []);
    }
    lobby.dataSources = uniqueList([...(lobby.dataSources || []), ...(source.dataSources || []), 'combatLog']);
    return lobby;
  }

  function mergeSoloShellFieldsIntoLobby(lobby = {}, shell = {}) {
    if (!lobby || !shell) return lobby;
    const preservedKeys = ['videoPath', 'videoLabel', 'videoLinkedAt', 'videoLinkMode', 'vodId', 'vodLinkedAt', 'videoSessionId', 'videoClipStartSec', 'videoClipEndSec', 'videoMatchStartSec', 'videoMatchEndSec', 'videoShuffleStartSec', 'videoShuffleEndSec', 'videoClipPreRollSec', 'videoClipPostRollSec', 'videoSyncAdjustmentSec', 'manualVideoSection', 'videoSectionUpdatedAt', 'favorite', 'favoriteNote', 'favoriteFolderId'];
    for (const keyName of preservedKeys) {
      if ((lobby[keyName] === undefined || lobby[keyName] === null || lobby[keyName] === '') && shell[keyName] !== undefined && shell[keyName] !== null && shell[keyName] !== '') lobby[keyName] = shell[keyName];
    }
    mergeSoloCombatDetailsIntoLobby(lobby, shell);
    lobby.dataSources = uniqueList([...(lobby.dataSources || []), ...(shell.dataSources || [])]);
    return lobby;
  }

  function soloRoundMergeKey(round = {}) {
    const id = String(round.roundMatchId || round.id || '').trim();
    if (id) return `id:${id}`;
    const start = Number(round.startMs || 0) || (round.startIso ? Date.parse(round.startIso) : 0) || 0;
    if (start) return `start:${Math.round(start / 1000)}`;
    return `round:${Number(round.roundNumber || 0) || 0}:${String(round.result || '')}:${String(round.firstDeath || round.endVictim || '')}`;
  }

  function mergeSoloRoundLists(...roundLists) {
    const byKey = new Map();
    const loose = [];
    for (const round of roundLists.flat().filter(Boolean)) {
      const key = soloRoundMergeKey(round);
      if (!key || /^round:0::?$/.test(key)) {
        loose.push({ ...round });
        continue;
      }
      const existing = byKey.get(key);
      if (!existing) byKey.set(key, { ...round });
      else byKey.set(key, { ...round, ...existing, ...Object.fromEntries(Object.entries(round).filter(([, value]) => value !== undefined && value !== null && value !== '' && (!Array.isArray(value) || value.length))) });
    }
    const rounds = [...Array.from(byKey.values()), ...loose].sort((a, b) => {
      const aStart = Number(a.startMs || 0) || (a.startIso ? Date.parse(a.startIso) : 0) || 0;
      const bStart = Number(b.startMs || 0) || (b.startIso ? Date.parse(b.startIso) : 0) || 0;
      if (aStart || bStart) return aStart - bStart;
      return (Number(a.roundNumber || 0) || 0) - (Number(b.roundNumber || 0) || 0);
    });
    return rounds.slice(0, 6).map((round, index) => ({ ...round, roundNumber: index + 1 }));
  }

  function soloLobbyRange(match = {}) {
    const starts = [
      Number(match.soloShuffleSessionStartMs) || 0,
      Number(match.startMs) || 0,
      match.startIso ? Date.parse(match.startIso) : 0,
      ...(Array.isArray(match.soloRounds) ? match.soloRounds.map((round) => Number(round && round.startMs || 0) || (round && round.startIso ? Date.parse(round.startIso) : 0) || 0) : [])
    ].filter(Boolean);
    const ends = [
      Number(match.soloShuffleSessionEndMs) || 0,
      Number(match.endMs) || 0,
      match.endIso ? Date.parse(match.endIso) : 0,
      ...(Array.isArray(match.soloRounds) ? match.soloRounds.map((round) => Number(round && round.endMs || 0) || (round && round.endIso ? Date.parse(round.endIso) : 0) || 0) : [])
    ].filter(Boolean);
    const start = starts.length ? Math.min(...starts) : soloStartMs(match);
    const end = ends.length ? Math.max(...ends) : (soloEndMs(match) || start);
    return { start, end: end || start };
  }

  function soloLobbyTimesOverlapOrNearby(left = {}, right = {}, padMs = 12 * 60 * 1000) {
    const a = soloLobbyRange(left);
    const b = soloLobbyRange(right);
    if (!a.start || !b.start) return false;
    const aEnd = a.end || a.start;
    const bEnd = b.end || b.start;
    return a.start <= bEnd + padMs && b.start <= aEnd + padMs;
  }

  function soloLobbyStablePlayersMatch(left = {}, right = {}) {
    const leftPlayers = matchPlayerIdentitySet(left);
    const rightPlayers = matchPlayerIdentitySet(right);
    if (!leftPlayers.size || !rightPlayers.size) return true;
    const overlap = playerSetOverlapCount(leftPlayers, rightPlayers);
    const smaller = Math.min(leftPlayers.size, rightPlayers.size);
    if (leftPlayers.size >= 6 && rightPlayers.size >= 6) return overlap >= 5;
    return overlap >= Math.min(4, smaller);
  }

  function soloParentLobbiesShouldMerge(left = {}, right = {}) {
    if (!isSoloShuffleLobbyMatch(left) || !isSoloShuffleLobbyMatch(right)) return false;
    if (String(left.id || '') && String(left.id || '') === String(right.id || '')) return true;
    if (!soloMapMatches(left, right)) return false;
    if (!soloLobbyStablePlayersMatch(left, right)) return false;
    return soloLobbyTimesOverlapOrNearby(left, right, 12 * 60 * 1000);
  }

  function soloLobbyStrength(match = {}) {
    const rounds = Array.isArray(match.soloRounds) ? match.soloRounds.filter(Boolean).length : 0;
    const range = soloLobbyRange(match);
    const duration = range.start && range.end ? Math.max(0, range.end - range.start) : 0;
    let score = rounds * 1000 + Math.min(900, Math.round(duration / 1000));
    if (match.createdFromRealLog) score += 500;
    if (Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length >= 4) score += 350;
    if (match.videoPath || match.vodId) score += 250;
    if (match.favorite) score += 100;
    return score;
  }

  function recomputeSoloLobbySummary(lobby = {}) {
    const rounds = Array.isArray(lobby.soloRounds) ? lobby.soloRounds.filter(Boolean) : [];
    const range = soloLobbyRange(lobby);
    const wins = rounds.filter((round) => round.result === 'Win').length;
    const losses = rounds.filter((round) => round.result === 'Loss').length;
    const unknown = rounds.filter((round) => round.result !== 'Win' && round.result !== 'Loss').length;
    const detectedRoundCount = rounds.length;
    const incomplete = detectedRoundCount < 6;
    const metrics = aggregateSoloShuffleMetrics(rounds);
    lobby.soloRounds = rounds.map((round, index) => ({ ...round, roundNumber: index + 1 }));
    lobby.soloShuffleWins = wins;
    lobby.soloShuffleLosses = losses;
    lobby.soloShuffleUnknownRounds = unknown;
    lobby.soloShuffleDetectedRoundCount = detectedRoundCount;
    lobby.soloShuffleExpectedRoundCount = 6;
    lobby.soloShuffleIncomplete = incomplete;
    lobby.soloShuffleSessionStartMs = range.start || Number(lobby.soloShuffleSessionStartMs || 0) || Number(lobby.startMs || 0) || 0;
    lobby.soloShuffleSessionEndMs = range.end || Number(lobby.soloShuffleSessionEndMs || 0) || Number(lobby.endMs || 0) || 0;
    lobby.startMs = lobby.soloShuffleSessionStartMs;
    lobby.endMs = lobby.soloShuffleSessionEndMs;
    lobby.startIso = lobby.startMs ? new Date(lobby.startMs).toISOString() : lobby.startIso || '';
    lobby.endIso = lobby.endMs ? new Date(lobby.endMs).toISOString() : lobby.endIso || '';
    lobby.gameStartMs = lobby.startMs;
    lobby.gameStartIso = lobby.startIso;
    lobby.durationSec = lobby.startMs && lobby.endMs && lobby.endMs > lobby.startMs ? Math.round((lobby.endMs - lobby.startMs) / 1000) : Number(lobby.durationSec || 0) || 0;
    lobby.duration = formatDuration(lobby.durationSec || 0);
    lobby.result = wins > losses ? 'Win' : losses > wins ? 'Loss' : 'Parsed';
    lobby.metrics = metrics;
    lobby.damage = metrics.Damage || lobby.damage || [];
    lobby.healing = metrics.Healing || lobby.healing || [];
    lobby.taken = metrics.Taken || lobby.taken || [];
    lobby.myComp = rounds[0] && Array.isArray(rounds[0].myComp) && rounds[0].myComp.length ? rounds[0].myComp : lobby.myComp || [];
    lobby.enemyComp = rounds[0] && Array.isArray(rounds[0].enemyComp) && rounds[0].enemyComp.length ? rounds[0].enemyComp : lobby.enemyComp || [];
    lobby.summary = `Solo Shuffle lobby: ${wins}W - ${losses}L, ${detectedRoundCount} round${detectedRoundCount === 1 ? '' : 's'} detected${incomplete ? ', incomplete/unclear.' : '.'}`;
    lobby.danger = incomplete ? 'Solo Shuffle lobby is incomplete or has unclear rounds.' : 'Solo Shuffle lobby grouped successfully.';
    lobby.dataQualityNote = incomplete ? 'Solo Shuffle detected fewer than 6 clear rounds. This can happen when someone leaves early or a log ends before the lobby is complete.' : (unknown ? 'Solo Shuffle has all six rounds, but one or more round results could not be inferred from the combat log.' : '');
    const roundFeeds = rounds.flatMap((round) => Array.isArray(round.eventFeed) ? round.eventFeed : []);
    if (roundFeeds.length) lobby.eventFeed = [...(Array.isArray(lobby.eventFeed) ? lobby.eventFeed : []), ...roundFeeds].slice(0, 500);
    const roundWithHealth = rounds.find((round) => round && round.healthTimeline && ((Array.isArray(round.healthTimeline.players) && round.healthTimeline.players.length) || Array.isArray(round.healthTimeline)));
    if ((!lobby.healthTimeline || (Array.isArray(lobby.healthTimeline) && !lobby.healthTimeline.length)) && roundWithHealth) lobby.healthTimeline = roundWithHealth.healthTimeline;
    const hasRoundCombat = rounds.some((round) => round && (round.metrics && Object.keys(round.metrics || {}).length || Array.isArray(round.eventFeed) && round.eventFeed.length || round.healthTimeline));
    if (hasRoundCombat || lobby.createdFromRealLog) lobby.createdFromRealLog = true;
    lobby.dataSources = uniqueList([...(lobby.dataSources || []), ...(hasRoundCombat || lobby.createdFromRealLog ? ['combatLog'] : [])]);
    lobby.tags = uniqueList([...(lobby.tags || []), 'Solo Shuffle lobby', `${wins}W - ${losses}L`, `${detectedRoundCount} rounds detected`, ...(incomplete ? ['Incomplete'] : [])]);
    lobby.matchType = 'Solo Shuffle';
    lobby.bracket = 'Solo Shuffle';
    lobby.isSoloShuffle = true;
    lobby.isSoloShuffleLobby = true;
    lobby.hideFromMatchLibrary = false;
    delete lobby.isSoloShuffleRoundChild;
    delete lobby.parentLobbyMatchId;
    return lobby;
  }

  function mergeSoloParentLobby(stronger = {}, weaker = {}) {
    if (!stronger || !weaker) return stronger || weaker;
    mergeSoloShellFieldsIntoLobby(stronger, weaker);
    if (isAddonSoloScoreboardSnapshot(weaker) || (Array.isArray(weaker.scoreboardPlayers) && weaker.scoreboardPlayers.length > (Array.isArray(stronger.scoreboardPlayers) ? stronger.scoreboardPlayers.length : 0))) mergeSoloShuffleScoreboardIntoLobby(stronger, weaker);
    stronger.soloRounds = mergeSoloRoundLists(stronger.soloRounds || [], weaker.soloRounds || []);
    stronger.participants = uniqueList([...(stronger.participants || []), ...(weaker.participants || []), ...Array.from(matchPlayerIdentitySet(stronger)), ...Array.from(matchPlayerIdentitySet(weaker))]);
    stronger.ownNames = uniqueList([...(stronger.ownNames || []), ...(weaker.ownNames || [])]);
    stronger.enemies = uniqueList([...(stronger.enemies || []), ...(weaker.enemies || [])]);
    stronger.classByName = { ...(weaker.classByName || {}), ...(stronger.classByName || {}) };
    stronger.specByName = { ...(weaker.specByName || {}), ...(stronger.specByName || {}) };
    stronger.cooldowns = uniqueList([...(stronger.cooldowns || []), ...(weaker.cooldowns || [])]).slice(0, 120);
    stronger.ccChains = uniqueList([...(stronger.ccChains || []), ...(weaker.ccChains || [])]).slice(0, 120);
    stronger.interrupts = uniqueList([...(stronger.interrupts || []), ...(weaker.interrupts || [])]).slice(0, 120);
    stronger.eventFeed = [...(stronger.eventFeed || []), ...(weaker.eventFeed || [])].slice(0, 250);
    mergeSoloCombatDetailsIntoLobby(stronger, weaker);
    stronger.createdFromRealLog = Boolean(stronger.createdFromRealLog || weaker.createdFromRealLog || (stronger.soloRounds || []).some((round) => round && (round.metrics || (Array.isArray(round.eventFeed) && round.eventFeed.length))));
    stronger.dataSources = uniqueList([...(stronger.dataSources || []), ...(weaker.dataSources || []), ...(stronger.createdFromRealLog ? ['combatLog'] : [])]);
    stronger.tags = uniqueList([...(stronger.tags || []), ...(weaker.tags || [])]);
    const rangeA = soloLobbyRange(stronger);
    const rangeB = soloLobbyRange(weaker);
    const start = Math.min(...[rangeA.start, rangeB.start].filter(Boolean));
    const end = Math.max(...[rangeA.end, rangeB.end].filter(Boolean));
    if (start) stronger.soloShuffleSessionStartMs = start;
    if (end) stronger.soloShuffleSessionEndMs = end;
    return recomputeSoloLobbySummary(stronger);
  }

  function mergeDuplicateSoloLobbies(lobbies = [], removedIds = [], idRemap = {}) {
    const canonical = [];
    for (const lobby of (lobbies || []).filter(Boolean)) {
      const existingIndex = canonical.findIndex((candidate) => soloParentLobbiesShouldMerge(candidate, lobby));
      if (existingIndex < 0) {
        canonical.push(recomputeSoloLobbySummary(lobby));
        continue;
      }
      const existing = canonical[existingIndex];
      const stronger = soloLobbyStrength(lobby) > soloLobbyStrength(existing) ? lobby : existing;
      const weaker = stronger === lobby ? existing : lobby;
      const strongerId = String(stronger.id || '');
      const weakerId = String(weaker.id || '');
      const merged = mergeSoloParentLobby(stronger, weaker);
      canonical[existingIndex] = merged;
      if (weakerId && weakerId !== strongerId) {
        removedIds.push(weakerId);
        if (strongerId) idRemap[weakerId] = strongerId;
      }
    }
    return canonical;
  }

  function annotateSoloShuffleSessions(state) {
    if (!state || !Array.isArray(state.matches)) return state;

    const originalMatches = (state.matches || []).filter(Boolean);
    const existingLobbies = originalMatches.filter(isSoloShuffleLobbyMatch);
    const existingLobbyById = new Map(existingLobbies.map((match) => [String(match.id || ''), match]));
    const removedIds = Array.isArray(state._removedDuplicateMatchIds) ? state._removedDuplicateMatchIds.slice() : [];
    const idRemap = state._duplicateMatchIdRemap && typeof state._duplicateMatchIdRemap === 'object' ? { ...state._duplicateMatchIdRemap } : {};
    const sourceRows = soloCanonicalSourceRows(originalMatches);

    // If the state already contains only canonical lobby rows, keep it that way and
    // remove any leftover hidden child rows from older versions. Do not rebuild the
    // lobby from nothing, because its soloRounds are already the source of truth.
    if (!sourceRows.length) {
      const nonSoloRows = [];
      const lobbyRows = [];
      for (const match of originalMatches) {
        if (!match) continue;
        if (isSoloShuffleRoundChildMatch(match) || match.hideFromMatchLibrary) {
          if (match.id) removedIds.push(String(match.id));
          continue;
        }
        if (isSoloShuffleLobbyMatch(match)) lobbyRows.push(match);
        else nonSoloRows.push(match);
      }
      state.matches = [...nonSoloRows, ...mergeDuplicateSoloLobbies(lobbyRows, removedIds, idRemap)];
      if (removedIds.length) state._removedDuplicateMatchIds = uniqueList(removedIds);
      if (Object.keys(idRemap).length) state._duplicateMatchIdRemap = idRemap;
      applySoloShuffleVideoBounds(state);
      return state;
    }

    // Work on source rows only. Children/shells are consumed into parent soloRounds
    // and removed from state.matches, so the stored match library has one visible
    // canonical Solo Shuffle object instead of several fragile rows.
    for (const match of sourceRows) {
      delete match.soloShuffleSessionKey;
      delete match.soloShuffleRound;
      delete match.soloShuffleRoundCount;
      delete match.soloShuffleSessionStartMs;
      delete match.soloShuffleSessionEndMs;
      delete match.isSoloShuffleRoundChild;
      delete match.hideFromMatchLibrary;
      delete match.parentLobbyMatchId;
    }

    const groups = soloShuffleGroups(sourceRows);
    const lobbyMatches = [];
    const consumedIds = new Set();
    const usedExistingLobbyIds = new Set();

    for (const group of groups) {
      if (!group.length) continue;
      const key = soloGroupCanonicalKey(group, existingLobbies);
      const existingLobby = existingLobbyById.get(key) || bestExistingLobbyForGroup(existingLobbies, group, key) || null;
      if (existingLobby && existingLobby.id) usedExistingLobbyIds.add(String(existingLobby.id));
      const lobby = buildSoloShuffleLobbyMatch(group, key, existingLobby);
      if (!lobby) continue;

      lobby.isSoloShuffle = true;
      lobby.isSoloShuffleLobby = true;
      lobby.hideFromMatchLibrary = false;
      delete lobby.isSoloShuffleRoundChild;
      delete lobby.parentLobbyMatchId;

      if (existingLobby && existingLobby.id && String(existingLobby.id) !== String(lobby.id)) {
        removedIds.push(String(existingLobby.id));
        idRemap[String(existingLobby.id)] = String(lobby.id || key);
      }

      group.forEach((item, index) => {
        if (!item || !item.match) return;
        const sourceId = String(item.match.id || '');
        if (sourceId) {
          consumedIds.add(sourceId);
          removedIds.push(sourceId);
          idRemap[sourceId] = String(lobby.id || key);
        }
        // Keep internal markers only on the copied round payload in soloRounds.
        // The source row itself is not kept in state.matches below.
        item.match.soloShuffleSessionKey = key;
        item.match.soloShuffleRound = index + 1;
        item.match.soloShuffleRoundCount = group.length;
        item.match.isSoloShuffleRoundChild = true;
        item.match.hideFromMatchLibrary = true;
        item.match.parentLobbyMatchId = lobby.id;
      });

      lobbyMatches.push(lobby);
    }

    // Merge addon Solo Shuffle scoreboard snapshots and one-round shells into the
    // canonical lobby, then consume their source row so they cannot leak to UI pages.
    for (const match of sourceRows) {
      if (!match || !match.id || consumedIds.has(String(match.id))) continue;
      const lobby = lobbyMatches.find((candidate) => soloSnapshotMatchesLobby(match, candidate))
        || lobbyMatches.find((candidate) => soloMatchDuplicatesLobby(match, candidate));
      if (!lobby) continue;
      if (isAddonSoloScoreboardSnapshot(match)) mergeSoloShuffleScoreboardIntoLobby(lobby, match);
      else mergeSoloShellFieldsIntoLobby(lobby, match);
      consumedIds.add(String(match.id));
      removedIds.push(String(match.id));
      idRemap[String(match.id)] = String(lobby.id || '');
    }

    // Remove old lobby parents that were replaced by a better canonical parent.
    for (const oldLobby of existingLobbies) {
      const oldId = String(oldLobby && oldLobby.id || '');
      if (!oldId) continue;
      if (lobbyMatches.some((lobby) => String(lobby.id || '') === oldId)) continue;
      if (usedExistingLobbyIds.has(oldId)) continue;
      const replacement = lobbyMatches.find((lobby) => soloMatchDuplicatesLobby(oldLobby, lobby));
      if (replacement) {
        mergeSoloShellFieldsIntoLobby(replacement, oldLobby);
        idRemap[oldId] = String(replacement.id || '');
        removedIds.push(oldId);
      }
    }

    const lobbyById = new Map();
    for (const lobby of lobbyMatches) {
      if (!lobby || !lobby.id) continue;
      const existing = lobbyById.get(String(lobby.id));
      if (!existing) lobbyById.set(String(lobby.id), lobby);
      else {
        const stronger = (Array.isArray(lobby.soloRounds) ? lobby.soloRounds.length : 0) >= (Array.isArray(existing.soloRounds) ? existing.soloRounds.length : 0) ? lobby : existing;
        const weaker = stronger === lobby ? existing : lobby;
        lobbyById.set(String(stronger.id), mergeSoloShellFieldsIntoLobby(stronger, weaker));
      }
    }
    const canonicalLobbies = mergeDuplicateSoloLobbies(Array.from(lobbyById.values()), removedIds, idRemap);

    const removeMatchIds = new Set(consumedIds);
    const finalRows = [];
    for (const match of originalMatches) {
      if (!match || !match.id) continue;
      const id = String(match.id || '');
      if (removeMatchIds.has(id)) continue;
      if (isSoloShuffleRoundChildMatch(match) || match.hideFromMatchLibrary) {
        removedIds.push(id);
        continue;
      }
      if (isSoloShuffleLobbyMatch(match)) {
        if (canonicalLobbies.some((lobby) => String(lobby.id || '') === id)) continue;
        const replacement = canonicalLobbies.find((lobby) => soloMatchDuplicatesLobby(match, lobby));
        if (replacement) {
          mergeSoloShellFieldsIntoLobby(replacement, match);
          idRemap[id] = String(replacement.id || '');
          removedIds.push(id);
          continue;
        }
      }
      const duplicateLobby = canonicalLobbies.find((lobby) => soloMatchDuplicatesLobby(match, lobby));
      if (duplicateLobby) {
        mergeSoloShellFieldsIntoLobby(duplicateLobby, match);
        idRemap[id] = String(duplicateLobby.id || '');
        removedIds.push(id);
        continue;
      }
      if (soloLooksLikeEmptyGenericArenaSnapshot(match, canonicalLobbies)) {
        const replacement = canonicalLobbies.find((lobby) => soloMapMatches(match, lobby) && soloTimeOverlapsLobby(match, lobby, 8 * 60 * 1000));
        if (replacement) idRemap[id] = String(replacement.id || '');
        removedIds.push(id);
        continue;
      }
      finalRows.push(match);
    }

    for (const lobby of canonicalLobbies) finalRows.push(lobby);
    state.matches = finalRows;
    if (removedIds.length) state._removedDuplicateMatchIds = uniqueList(removedIds);
    if (Object.keys(idRemap).length) state._duplicateMatchIdRemap = idRemap;
    applySoloShuffleVideoBounds(state);
    return state;
  }


  function soloShuffleSessionRangeMs(match = {}) {
    if (!isSoloShuffleMatch(match)) return null;
    const start = Number(match.soloShuffleSessionStartMs) || 0;
    const end = Number(match.soloShuffleSessionEndMs) || 0;
    if (!start || !end || end <= start) return null;
    return { start, end };
  }

  function applySoloShuffleVideoBounds(state) {
    if (!state || !Array.isArray(state.matches)) return state;
    for (const match of state.matches) {
      if (!match || match.manualVideoSection || !match.videoPath || !isSoloShuffleMatch(match)) continue;
      const session = soloShuffleSessionRangeMs(match);
      if (!session) continue;
      const roundRange = matchTimeRangeMs(match);
      const roundStart = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0) || roundRange.gameStart || roundRange.start || 0;
      if (!roundStart) continue;
      const roundVideoStart = Number(match.videoMatchStartSec);
      if (!Number.isFinite(roundVideoStart)) continue;
      const groupStartSec = Math.max(0, roundVideoStart - Math.max(0, (roundStart - session.start) / 1000));
      const groupEndSec = Math.max(groupStartSec + 5, roundVideoStart + Math.max(5, (session.end - roundStart) / 1000));
      match.videoShuffleStartSec = Math.round(groupStartSec * 10) / 10;
      match.videoShuffleEndSec = Math.round(groupEndSec * 10) / 10;
      const currentStart = Number(match.videoClipStartSec);
      const currentEnd = Number(match.videoClipEndSec);
      if (!Number.isFinite(currentStart) || currentStart > groupStartSec + 1) match.videoClipStartSec = Math.round(groupStartSec * 10) / 10;
      if (!Number.isFinite(currentEnd) || currentEnd < groupEndSec - 1) match.videoClipEndSec = Math.round(groupEndSec * 10) / 10;
    }
    return state;
  }

  function videoGroupRangeForMatch(match = {}) {
    const session = soloShuffleSessionRangeMs(match);
    return session || null;
  }


  return {
    inferSoloShuffleRoundWinnerFromDeath,
    isSoloShuffleMatch,
    matchPlayerIdentitySet,
    asPlayerIdentitySet,
    playerSetOverlapCount,
    soloShuffleGroups,
    soloSnapshotMatchesLobby,
    mergeSoloShuffleScoreboardIntoLobby,
    isSoloShuffleLobbyMatch,
    isSoloShuffleRoundChildMatch,
    soloRoundResult,
    aggregateSoloShuffleMetrics,
    soloShuffleRoundPayload,
    buildSoloShuffleLobbyMatch,
    annotateSoloShuffleSessions,
    soloShuffleSessionRangeMs,
    applySoloShuffleVideoBounds,
    videoGroupRangeForMatch
  };
}

module.exports = { createSoloShuffleTools };
