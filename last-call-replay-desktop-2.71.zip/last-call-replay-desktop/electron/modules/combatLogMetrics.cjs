function createCombatLogMetricsTools(deps = {}) {
  const {
    core,
    hashText = (value) => String(value || ''),
    uniqueList = (items = []) => Array.from(new Set(items || [])),
    shortNameKey = (value) => String(value || '').split('-')[0].trim().toLowerCase(),
    metaForSpec = () => null,
    cleanMatchMapName = (value) => String(value || '').trim(),
    expectedTeamSizeForType = () => 0,
    teamCountsFromNames = () => ({}),
    maxTeamCount = () => 0,
    isBattlegroundType = () => false,
    isRatedBattlegroundType = () => false,
    inferSoloShuffleRoundWinnerFromDeath = () => ({ winnerTeam: null, victim: '', source: 'unknown' }),
    parserVersion = 0
  } = deps;
  if (!core) throw new Error('combatLogMetrics requires core tools');
  const {
    cleanSpellName,
    eventKind,
    isOffensivePurgeEvent,
    formatDuration,
    relativeLabel,
    isUsefulUnitName,
    isPlayerGuid,
    noteOwnCandidate
  } = core;
  const PARSER_VERSION = Number(parserVersion) || 0;
  const summaryCache = new Map();
  const SUMMARY_CACHE_LIMIT = 48;
  const MAX_CACHED_SUMMARY_JSON_CHARS = 8 * 1024 * 1024;

  function clonePlain(value) {
    if (!value) return value;
    try { return JSON.parse(JSON.stringify(value)); } catch (_error) { return null; }
  }

  function trimSummaryCache() {
    while (summaryCache.size > SUMMARY_CACHE_LIMIT) {
      const oldest = summaryCache.keys().next().value;
      summaryCache.delete(oldest);
    }
  }

  function getCachedSummary(key) {
    if (!key || !summaryCache.has(key)) return null;
    const json = summaryCache.get(key);
    summaryCache.delete(key);
    summaryCache.set(key, json);
    try { return JSON.parse(json); } catch (_error) { summaryCache.delete(key); return null; }
  }

  function setCachedSummary(key, summary) {
    if (!key || !summary) return;
    try {
      const json = JSON.stringify(summary);
      if (json.length > MAX_CACHED_SUMMARY_JSON_CHARS) return;
      summaryCache.set(key, json);
      trimSummaryCache();
    } catch (_error) {}
  }

  function metricSummaryCacheKey(events = [], sourceLabel = '', segmentIndex = '', context = {}) {
    if (!Array.isArray(events) || !events.length) return '';
    const first = events[0] || {};
    const last = events[events.length - 1] || {};
    const eventSeed = events.length > 240
      ? `${events.slice(0, 80).map((ev) => ev && ev.hash || '').join('')}|${events.slice(-80).map((ev) => ev && ev.hash || '').join('')}`
      : events.map((ev) => ev && ev.hash || '').join('');
    return hashText([
      'summary-v2',
      PARSER_VERSION,
      sourceLabel,
      segmentIndex,
      events.length,
      first.hash || first.stamp || '',
      last.hash || last.stamp || '',
      context.bracket || '',
      context.zoneName || '',
      context.ownGuid || '',
      context.ownName || '',
      eventSeed
    ].join('|'));
  }

const offensiveCooldowns = new Set([
  'Avenging Wrath', 'Crusade', 'Avatar', 'Trueshot', 'Combustion', 'Incarnation', 'Dark Soul', 'Dragonrage', 'Power Infusion',
  'Vendetta', 'Deathmark', 'Icy Veins', 'Summon Infernal', 'Colossus Smash', 'Coordinated Assault', 'Metamorphosis',
  'Ascendance', 'Stormkeeper', 'The Hunt', 'Pillar of Frost', 'Berserk'
]);

const defensiveCooldowns = new Set([
  'Barkskin', 'Pain Suppression', 'Ice Block', 'Life Cocoon', 'Trinket', 'Gladiator\'s Medallion', 'Will to Survive',
  'Die by the Sword', 'Cloak of Shadows', 'Evasion', 'Divine Shield', 'Blessing of Protection', 'Blessing of Spellwarding',
  'Blur', 'Dark Pact', 'Survival Instincts', 'Astral Shift', 'Shield Wall', 'Dispersion', 'Netherwalk',
  'Aspect of the Turtle', 'Fortifying Brew', 'Renewal', 'Sacrificial Pact'
]);

const ccSpells = new Set([
  'Fear', 'Psychic Scream', 'Polymorph', 'Kidney Shot', 'Storm Bolt', 'Hammer of Justice', 'Maim', 'Repentance', 'Cyclone',
  'Freezing Trap', 'Mortal Coil', 'Axe Toss', 'Sap', 'Blind', 'Intimidation', 'Cheap Shot', 'Hex', 'Imprison',
  'Scatter Shot', 'Disorienting Roar', 'Leg Sweep', 'Sleep Walk', 'Paralysis', 'Sigil of Misery', 'Chaos Nova'
]);


function addAmount(map, name, amount, spellName) {
  if (!isUsefulUnitName(name) || !amount) return;
  const entry = map.get(name) || { amount: 0, spells: new Map() };
  entry.amount += Number(amount) || 0;
  if (spellName) entry.spells.set(spellName, (entry.spells.get(spellName) || 0) + (Number(amount) || 0));
  map.set(name, entry);
}



function getMapEntry(map, key, factory) {
  const safeKey = key || 'Unknown';
  let entry = map.get(safeKey);
  if (!entry) {
    entry = factory ? factory(safeKey) : {};
    map.set(safeKey, entry);
  }
  return entry;
}

function incNestedCount(map, actor, ability) {
  if (!isUsefulUnitName(actor) || !ability) return;
  const byActor = getMapEntry(map, actor, () => new Map());
  byActor.set(ability, (byActor.get(ability) || 0) + 1);
}

function castCountFor(castMap, actor, ability) {
  const byActor = castMap.get(actor);
  return byActor ? (byActor.get(ability) || 0) : 0;
}

function buildPetOwnerMap(events) {
  const owners = new Map();
  for (const ev of events || []) {
    if (ev.event !== 'SPELL_SUMMON') continue;
    if (!isPlayerGuid(ev.sourceGuid) || isPlayerGuid(ev.destGuid)) continue;
    if (!ev.destGuid || !isUsefulUnitName(ev.sourceName)) continue;
    owners.set(ev.destGuid, {
      ownerGuid: ev.sourceGuid,
      ownerName: ev.sourceName,
      petGuid: ev.destGuid,
      petName: isUsefulUnitName(ev.destName) ? ev.destName : (ev.spellName || 'Pet')
    });
  }
  return owners;
}

function petOwnerForGuid(petOwnerMap, guid) {
  return petOwnerMap && guid ? petOwnerMap.get(guid) : null;
}

function metricActorInfo(ev, side, petOwnerMap) {
  const guid = side === 'dest' ? ev.destGuid : ev.sourceGuid;
  const name = side === 'dest' ? ev.destName : ev.sourceName;
  const owner = petOwnerForGuid(petOwnerMap, guid);
  if (owner && isUsefulUnitName(owner.ownerName)) {
    return {
      rowName: owner.ownerName,
      rowGuid: owner.ownerGuid,
      originalName: isUsefulUnitName(name) ? name : owner.petName,
      originalGuid: guid,
      isPet: true,
      petName: isUsefulUnitName(name) ? name : owner.petName,
      petGuid: guid,
      isPlayerActor: true
    };
  }
  return {
    rowName: name,
    rowGuid: guid,
    originalName: name,
    originalGuid: guid,
    isPet: false,
    petName: '',
    petGuid: '',
    isPlayerActor: isPlayerGuid(guid)
  };
}

function pushAmountMetric(map, actor, ability, amount, ev, targetMode = 'target', actorInfo = {}) {
  if (!isUsefulUnitName(actor) || !ability || !amount) return;
  const safeAmount = Number(amount) || 0;
  const row = getMapEntry(map, actor, (name) => ({
    name,
    guid: actorInfo.rowGuid || '',
    isPlayerActor: actorInfo.isPlayerActor !== false,
    totalAll: 0,
    totalPlayers: 0,
    directAll: 0,
    directPlayers: 0,
    petAll: 0,
    petPlayers: 0,
    pets: new Map(),
    abilities: new Map()
  }));
  if (actorInfo.rowGuid && !row.guid) row.guid = actorInfo.rowGuid;
  if (actorInfo.isPlayerActor === false) row.isPlayerActor = false;
  const abilityRow = getMapEntry(row.abilities, ability, (name) => ({ name, totalAll: 0, totalPlayers: 0, hitsAll: 0, hitsPlayers: 0, minAll: Infinity, maxAll: 0, minPlayers: Infinity, maxPlayers: 0, targets: new Map(), events: [] }));
  const targetGuid = targetMode === 'source' ? ev.sourceGuid : ev.destGuid;
  const targetName = targetMode === 'source' ? ev.sourceName : ev.destName;
  const targetIsPlayer = isPlayerGuid(targetGuid);
  row.totalAll += safeAmount;
  if (actorInfo.isPet) {
    row.petAll += safeAmount;
    const pet = getMapEntry(row.pets, actorInfo.petName || 'Pet', (name) => ({ name, guid: actorInfo.petGuid || '', amountAll: 0, amountPlayers: 0, hitsAll: 0, hitsPlayers: 0, abilities: new Map() }));
    pet.amountAll += safeAmount;
    pet.hitsAll += 1;
    pet.abilities.set(ability, (pet.abilities.get(ability) || 0) + safeAmount);
  } else {
    row.directAll += safeAmount;
  }
  abilityRow.totalAll += safeAmount;
  abilityRow.hitsAll += 1;
  abilityRow.minAll = Math.min(abilityRow.minAll, safeAmount);
  abilityRow.maxAll = Math.max(abilityRow.maxAll, safeAmount);
  if (targetIsPlayer) {
    row.totalPlayers += safeAmount;
    if (actorInfo.isPet) {
      row.petPlayers += safeAmount;
      const pet = getMapEntry(row.pets, actorInfo.petName || 'Pet', (name) => ({ name, guid: actorInfo.petGuid || '', amountAll: 0, amountPlayers: 0, hitsAll: 0, hitsPlayers: 0, abilities: new Map() }));
      pet.amountPlayers += safeAmount;
      pet.hitsPlayers += 1;
    } else {
      row.directPlayers += safeAmount;
    }
    abilityRow.totalPlayers += safeAmount;
    abilityRow.hitsPlayers += 1;
    abilityRow.minPlayers = Math.min(abilityRow.minPlayers, safeAmount);
    abilityRow.maxPlayers = Math.max(abilityRow.maxPlayers, safeAmount);
  }
  const target = getMapEntry(abilityRow.targets, targetName || 'Unknown', (name) => ({ name, amountAll: 0, amountPlayers: 0, hitsAll: 0, hitsPlayers: 0, crits: 0, isPlayer: targetIsPlayer }));
  target.amountAll += safeAmount;
  target.hitsAll += 1;
  if (targetIsPlayer) {
    target.amountPlayers += safeAmount;
    target.hitsPlayers += 1;
  }
  if (ev.isCritical) target.crits += 1;
  abilityRow.events.push({
    time: ev._relativeLabel || '',
    relativeSec: ev._relativeSec || 0,
    amount: Math.round(safeAmount),
    ability,
    target: targetName || 'Unknown',
    targetGuid,
    source: actorInfo.isPet ? (actorInfo.petName || ev.sourceName || 'Unknown') : (ev.sourceName || 'Unknown'),
    sourceGuid: ev.sourceGuid || '',
    ownerName: actorInfo.isPet ? (actorInfo.rowName || actor) : '',
    isPetSource: Boolean(actorInfo.isPet),
    event: ev.event,
    targetIsPlayer,
    targetHealthPct: ev.targetHealthPct == null ? null : Math.round(Number(ev.targetHealthPct)),
    sourceIsPlayer: isPlayerGuid(ev.sourceGuid),
    isCritical: Boolean(ev.isCritical)
  });
}

function pushCountMetric(map, actor, ability, ev, targetNameOverride = '') {
  if (!isUsefulUnitName(actor) || !ability) return;
  const row = getMapEntry(map, actor, (name) => ({ name, count: 0, abilities: new Map() }));
  row.count += 1;
  const abilityRow = getMapEntry(row.abilities, ability, (name) => ({ name, count: 0, targets: new Map(), events: [] }));
  abilityRow.count += 1;
  const targetName = targetNameOverride || ev.destName || 'Unknown';
  const target = getMapEntry(abilityRow.targets, targetName, (name) => ({ name, amount: 0, hits: 0, isPlayer: isPlayerGuid(ev.destGuid) }));
  target.hits += 1;
  abilityRow.events.push({
    time: ev._relativeLabel || '',
    relativeSec: ev._relativeSec || 0,
    ability,
    target: targetName,
    source: ev.sourceName || 'Unknown',
    event: ev.event,
    extraSpellName: ev.extraSpellName || '',
    interruptedSpellName: ev.interruptedSpellName || '',
    removedSpellName: ev.removedSpellName || ev.extraSpellName || '',
    dispelSpellName: ev.dispelSpellName || '',
    targetIsPlayer: isPlayerGuid(ev.destGuid)
  });
}

function pushDispelMetric(map, actor, dispelSpell, removedSpell, ev, targetNameOverride = '', groupByRemoved = false) {
  const cleanDispelSpell = cleanSpellName(dispelSpell || ev.spellName || 'Dispel');
  const cleanRemovedSpell = cleanSpellName(removedSpell || ev.extraSpellName || 'Removed effect');
  const abilityName = groupByRemoved ? cleanRemovedSpell : cleanDispelSpell;
  if (!isUsefulUnitName(actor) || !abilityName) return;
  const event = {
    ...ev,
    extraSpellName: cleanRemovedSpell,
    removedSpellName: cleanRemovedSpell,
    dispelSpellName: cleanDispelSpell,
    interruptedSpellName: ''
  };
  pushCountMetric(map, actor, abilityName, event, targetNameOverride || ev.destName || 'Unknown');
}

function rowsFromAmountMetric(map, castMap, playersOnly = false) {
  const rows = Array.from(map.values()).filter((row) => row.isPlayerActor !== false).map((row) => {
    const amount = playersOnly ? row.totalPlayers : row.totalAll;
    const directAmount = playersOnly ? (row.directPlayers || 0) : (row.directAll || 0);
    const petAmount = playersOnly ? (row.petPlayers || 0) : (row.petAll || 0);
    const petBreakdown = Array.from((row.pets || new Map()).values()).map((pet) => {
      const petValue = playersOnly ? (pet.amountPlayers || 0) : (pet.amountAll || 0);
      const petHits = playersOnly ? (pet.hitsPlayers || 0) : (pet.hitsAll || 0);
      const petAbilities = Array.from((pet.abilities || new Map()).entries()).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([name]) => name).join(', ');
      return { name: pet.name, guid: pet.guid || '', amount: Math.round(petValue), hits: petHits, top: petAbilities };
    }).filter((pet) => pet.amount > 0).sort((a, b) => b.amount - a.amount);
    const abilities = Array.from(row.abilities.values()).map((ability) => {
      const filteredEvents = playersOnly ? ability.events.filter((event) => event.targetIsPlayer) : ability.events;
      const abilityAmount = filteredEvents.reduce((sum, event) => sum + (Number(event.amount) || 0), 0);
      const hits = filteredEvents.length;
      const values = filteredEvents.map((event) => Number(event.amount) || 0).filter((n) => n > 0);
      const min = values.length ? Math.min(...values) : 0;
      const max = values.length ? Math.max(...values) : 0;
      const avg = hits ? abilityAmount / hits : 0;
      const targetMap = new Map();
      for (const event of filteredEvents) {
        const targetName = event.target || 'Unknown';
        const target = targetMap.get(targetName) || { name: targetName, amount: 0, hits: 0, crits: 0, isPlayer: Boolean(event.targetIsPlayer) };
        target.amount += Number(event.amount) || 0;
        target.hits += 1;
        if (event.isCritical) target.crits += 1;
        targetMap.set(targetName, target);
      }
      return {
        name: ability.name,
        amount: Math.round(abilityAmount),
        allAmount: Math.round(ability.totalAll),
        playerAmount: Math.round(ability.totalPlayers),
        hits,
        allHits: ability.hitsAll,
        playerHits: ability.hitsPlayers,
        casts: castCountFor(castMap, row.name, ability.name),
        min: Math.round(min || 0),
        max: Math.round(max || 0),
        avg: Math.round(avg || 0),
        crits: filteredEvents.filter((event) => event.isCritical).length,
        targets: Array.from(targetMap.values()).sort((a, b) => b.amount - a.amount).slice(0, 30).map((target) => ({ ...target, amount: Math.round(target.amount) })),
        events: filteredEvents.slice(0, 200)
      };
    }).filter((ability) => ability.amount > 0 || ability.hits > 0).sort((a, b) => b.amount - a.amount || b.hits - a.hits);
    return {
      name: row.name,
      amount: Math.round(amount || 0),
      allAmount: Math.round(row.totalAll || 0),
      playerAmount: Math.round(row.totalPlayers || 0),
      directAmount: Math.round(directAmount || 0),
      petAmount: Math.round(petAmount || 0),
      petBreakdown,
      hasPetDamage: petBreakdown.length > 0,
      abilities,
      top: abilities.slice(0, 3).map((item) => item.name).join(', ') || 'No abilities found'
    };
  }).filter((row) => row.amount > 0).sort((a, b) => b.amount - a.amount);
  const total = rows.reduce((sum, row) => sum + row.amount, 0) || 1;
  const max = rows.reduce((highest, row) => Math.max(highest, Number(row.amount) || 0), 1);
  return rows.map((row) => ({
    ...row,
    percent: Math.max(1, Math.round((row.amount / total) * 100)),
    barPercent: Math.max(2, Math.round(((Number(row.amount) || 0) / max) * 100))
  })).slice(0, 80);
}

function rowsFromCountMetric(map, castMap) {
  const rows = Array.from(map.values()).map((row) => {
    const abilities = Array.from(row.abilities.values()).map((ability) => {
      const best = new Map();
      for (const event of ability.events || []) {
        const bucket = Math.round((Number(event.relativeSec) || 0) * 2) / 2;
        const key = `${bucket}|${event.ability}|${event.target}|${event.extraSpellName || ''}|${event.removedSpellName || ''}|${event.dispelSpellName || ''}`;
        if (!best.has(key)) best.set(key, event);
      }
      const dedupedEvents = Array.from(best.values()).sort((a, b) => (Number(a.relativeSec) || 0) - (Number(b.relativeSec) || 0));
      const targetMap = new Map();
      for (const event of dedupedEvents) {
        const targetName = event.target || 'Unknown';
        const target = targetMap.get(targetName) || { name: targetName, amount: 0, hits: 0, isPlayer: Boolean(event.targetIsPlayer) };
        target.hits += 1;
        targetMap.set(targetName, target);
      }
      return {
        name: ability.name,
        amount: dedupedEvents.length,
        count: dedupedEvents.length,
        hits: dedupedEvents.length,
        casts: dedupedEvents.length,
        actions: dedupedEvents.length,
        targets: Array.from(targetMap.values()).sort((a, b) => b.hits - a.hits).slice(0, 30),
        events: dedupedEvents.slice(0, 200),
        min: 0,
        max: 0,
        avg: 0
      };
    }).filter((ability) => ability.count > 0).sort((a, b) => b.count - a.count);
    const count = abilities.reduce((sum, ability) => sum + ability.count, 0);
    return { name: row.name, amount: count, count, abilities, percent: 1, top: abilities.slice(0, 3).map((item) => item.name).join(', ') || 'No abilities found' };
  }).filter((row) => row.amount > 0).sort((a, b) => b.amount - a.amount);
  const total = rows.reduce((sum, row) => sum + row.amount, 0) || 1;
  return rows.map((row) => ({ ...row, percent: Math.max(1, Math.round((row.amount / total) * 100)) })).slice(0, 80);
}

function buildDeathMetricRows(deathEvents, damageEvents) {
  return deathEvents.map((death) => {
    const victim = death.victim || death.destName || 'Unknown';
    const hits = damageEvents
      .filter((hit) => hit.destName === victim && hit.relativeSec <= death.relativeSec && hit.relativeSec >= death.relativeSec - 20)
      .slice(-25)
      .map((hit) => ({
        time: relativeLabel(hit.relativeSec),
        relativeSec: hit.relativeSec,
        source: hit.sourceName,
        ability: hit.spellName || hit.event,
        amount: Math.round(hit.amount || 0),
        targetHealthPct: hit.targetHealthPct == null ? null : Math.round(Number(hit.targetHealthPct))
      }));
    const total = hits.reduce((sum, hit) => sum + hit.amount, 0);
    return {
      name: victim,
      amount: total,
      count: hits.length,
      percent: 1,
      top: `${hits.length} hits in last 20s`,
      at: relativeLabel(death.relativeSec),
      abilities: [{ name: 'Last 20 seconds', amount: total, hits: hits.length, casts: 0, min: hits.length ? Math.min(...hits.map((h) => h.amount)) : 0, max: hits.length ? Math.max(...hits.map((h) => h.amount)) : 0, avg: hits.length ? Math.round(total / hits.length) : 0, events: hits, targets: [] }],
      lastHits: hits
    };
  }).sort((a, b) => b.amount - a.amount);
}


function dedupeTimelineEvents(items, windowSec = 1.5) {
  const chosen = [];
  const sorted = [...(items || [])].sort((a, b) => (Number(a.relativeSec) || 0) - (Number(b.relativeSec) || 0));
  for (const item of sorted) {
    const relative = Number(item.relativeSec) || 0;
    const key = `${item.tone || item.category || ''}|${item.actor || ''}|${item.ability || ''}`;
    const duplicate = chosen.find((existing) => {
      const exRelative = Number(existing.relativeSec) || 0;
      const exKey = `${existing.tone || existing.category || ''}|${existing.actor || ''}|${existing.ability || ''}`;
      return exKey === key && Math.abs(exRelative - relative) <= windowSec;
    });
    if (!duplicate) chosen.push(item);
  }
  return chosen;
}

function dedupeFeedEvents(feed) {
  const best = new Map();
  for (const item of feed) {
    const sec = Number(item.relativeSec) || 0;
    const category = item.category || '';
    let key;
    if (['offense', 'defense'].includes(category)) {
      key = `${Math.round(sec)}|${category}|${item.actor}|${item.ability}`;
    } else if (['control', 'interrupt', 'purge', 'dispel', 'ccdispel', 'death', 'match'].includes(category)) {
      key = `${Math.round(sec * 2) / 2}|${category}|${item.actor}|${item.target}|${item.ability}`;
    } else {
      key = `${Math.round(sec * 2) / 2}|${category}|${item.actor}|${item.target}|${item.ability}|${item.amount || 0}`;
    }
    const existing = best.get(key);
    if (!existing || item.importance > existing.importance) best.set(key, item);
  }
  return Array.from(best.values()).sort((a, b) => a.relativeSec - b.relativeSec || b.importance - a.importance);
}

function buildEventFeed(events, matchStartMs, teamByGuid = new Map()) {
  const feed = [];
  const topDamageCutoff = [...events]
    .filter((ev) => eventKind(ev.event) === 'damage' && ev.amount > 0 && isPlayerGuid(ev.destGuid))
    .sort((a, b) => b.amount - a.amount)
    .slice(0, 40)
    .reduce((set, ev) => set.add(ev.hash), new Set());

  for (const ev of events) {
    const kind = eventKind(ev.event);
    const relativeSec = matchStartMs && ev.absoluteMs ? Math.max(0, (ev.absoluteMs - matchStartMs) / 1000) : 0;
    let importance = 1;
    let label = ev.spellName || ev.event;
    let category = kind;

    if (kind === 'match_start') { importance = 8; category = 'match'; label = 'Match Started'; }
    else if (kind === 'match_end') { importance = 8; category = 'match'; label = 'Match Ended'; }
    else if (kind === 'cast' && offensiveCooldowns.has(ev.spellName)) { importance = 7; category = 'offense'; }
    else if (kind === 'cast' && defensiveCooldowns.has(ev.spellName)) { importance = 7; category = 'defense'; }
    else if ((kind === 'cast' || kind === 'aura') && ccSpells.has(ev.spellName)) { importance = 6; category = 'control'; }
    else if (kind === 'interrupt') { importance = 6; category = 'interrupt'; label = ev.extraSpellName ? `${ev.spellName} → ${ev.extraSpellName}` : ev.spellName; }
    else if (kind === 'dispel') {
      const isPurge = isOffensivePurgeEvent(ev, teamByGuid);
      importance = ccSpells.has(ev.extraSpellName) || isPurge ? 6 : 5;
      category = isPurge ? 'purge' : (ccSpells.has(ev.extraSpellName) ? 'ccdispel' : 'dispel');
      label = ev.extraSpellName ? `${ev.spellName} ${isPurge ? 'purged' : 'removed'} ${ev.extraSpellName}` : ev.spellName;
    }
    else if (kind === 'death') { if (ev.isFeignDeath || !isPlayerGuid(ev.destGuid)) continue; importance = 8; category = 'death'; label = 'Died'; }
    else if (kind === 'damage' && ev.amount > 0) {
      importance = topDamageCutoff.has(ev.hash) || ev.amount >= 25000 ? 4 : 3;
      category = 'damage';
    }
    else if (kind === 'healing' && ev.amount > 0) {
      importance = ev.amount >= 25000 && isPlayerGuid(ev.destGuid) ? 4 : 3;
      category = 'healing';
    }
    else if (kind === 'cast' && ev.spellName && isPlayerGuid(ev.sourceGuid)) { importance = 3; category = 'cast'; }

    if (importance < 3) continue;

    feed.push({
      id: ev.hash,
      time: relativeLabel(relativeSec),
      relativeSec,
      stamp: ev.stamp,
      category,
      event: ev.event,
      actor: ev.sourceName,
      target: ev.destName,
      ability: label,
      amount: ev.amount || 0,
      isCritical: Boolean(ev.isCritical),
      targetHealthPct: ev.targetHealthPct == null ? null : Math.round(Number(ev.targetHealthPct)),
      raw: ev.raw,
      importance
    });
  }

  return dedupeFeedEvents(feed).slice(0, 1600);
}
function buildChart(events, matchStartMs = 0) {
  const buckets = new Map();
  for (const ev of events) {
    if (!matchStartMs || !ev.absoluteMs) continue;
    const bucket = Math.floor((ev.absoluteMs - matchStartMs) / 10000) * 10;
    const current = buckets.get(bucket) || { t: relativeLabel(bucket), you: 0, enemy: 0 };
    if (eventKind(ev.event) === 'damage') current.you += Number(ev.amount) || 0;
    if (eventKind(ev.event) === 'healing') current.enemy += Number(ev.amount) || 0;
    buckets.set(bucket, current);
  }
  const rows = Array.from(buckets.values()).slice(0, 24);
  if (!rows.length) return [{ t: '0:00', you: 0, enemy: 0 }];
  const max = Math.max(1, ...rows.flatMap((row) => [row.you, row.enemy]));
  return rows.map((row) => ({ t: row.t, you: Math.round((row.you / max) * 100), enemy: Math.round((row.enemy / max) * 100) }));
}

function buildNameMap(events) {
  const names = new Map();
  for (const ev of events) {
    if (isPlayerGuid(ev.sourceGuid) && isUsefulUnitName(ev.sourceName)) names.set(ev.sourceGuid, ev.sourceName);
    if (isPlayerGuid(ev.destGuid) && isUsefulUnitName(ev.destName)) names.set(ev.destGuid, ev.destName);
  }
  return names;
}


function normalizeMatchType(value) {
  const raw = String(value || '').trim();
  const lower = raw.toLowerCase();
  if (lower.includes('shuffle')) return 'Solo Shuffle';
  if (lower.includes('skirmish')) return 'Skirmish';
  if (lower.includes('blitz')) return 'Battleground Blitz';
  if (lower.includes('rated battleground') || lower === 'rbg') return 'Rated Battleground';
  if (lower.includes('battleground')) return lower.includes('rated') ? 'Rated Battleground' : 'Random Battleground';
  if (lower === '2v2' || lower === '2s' || /^2['’]?s$/.test(lower) || lower.includes('2v2')) return '2v2';
  if (lower === '3v3' || lower === '3s' || /^3['’]?s$/.test(lower) || lower.includes('3v3')) return '3v3';
  return raw || 'PvP Match';
}


function buildHealthTimeline(events, matchStartMs, metaByGuid = new Map(), teamByGuid = new Map(), deaths = []) {
  const byGuid = new Map();
  const byNameToGuid = new Map();

  function rememberHealthName(name, guid) {
    if (!guid || !isUsefulUnitName(name)) return;
    const raw = String(name || '').trim();
    const keys = [raw, raw.toLowerCase(), shortNameKey(raw)].filter(Boolean);
    for (const key of keys) {
      if (!byNameToGuid.has(key)) byNameToGuid.set(key, guid);
    }
  }

  function lookupHealthGuid(name) {
    const raw = String(name || '').trim();
    return byNameToGuid.get(raw) || byNameToGuid.get(raw.toLowerCase()) || byNameToGuid.get(shortNameKey(raw)) || '';
  }

  function ensurePlayer(guid, name) {
    if (!isPlayerGuid(guid) || !isUsefulUnitName(name)) return null;
    let item = byGuid.get(guid);
    if (!item) {
      const meta = metaByGuid.get(guid) || {};
      item = {
        guid,
        name,
        team: teamByGuid.get(guid) || meta.team || 'unknown',
        className: meta.className || '',
        specName: meta.specName || '',
        classColor: meta.classColor || '',
        rawPoints: []
      };
      byGuid.set(guid, item);
      rememberHealthName(name, guid);
    } else {
      rememberHealthName(name, guid);
    }
    return item;
  }

  for (const ev of events) {
    ensurePlayer(ev.sourceGuid, ev.sourceName);
    ensurePlayer(ev.destGuid, ev.destName);
  }

  const realDeaths = (deaths || []).filter((death) => death && !death.isFeignDeath && isUsefulUnitName(death.victim)).map((death) => {
    const name = death.victim;
    const guid = lookupHealthGuid(name);
    const meta = guid ? (metaByGuid.get(guid) || {}) : {};
    return {
      time: Number(death.relativeSec) || 0,
      label: relativeLabel(Number(death.relativeSec) || 0),
      victim: name,
      guid,
      className: meta.className || '',
      classColor: meta.classColor || ''
    };
  });
  const deathTimesByGuid = new Map();
  const deathTimesByName = new Map();
  for (const death of realDeaths) {
    if (death.guid) {
      const list = deathTimesByGuid.get(death.guid) || [];
      list.push(Number(death.time) || 0);
      deathTimesByGuid.set(death.guid, list);
    }
    if (death.victim) {
      const full = String(death.victim || '').trim();
      for (const key of [full, full.toLowerCase(), shortNameKey(full)].filter(Boolean)) {
        const list = deathTimesByName.get(key) || [];
        list.push(Number(death.time) || 0);
        deathTimesByName.set(key, list);
      }
    }
  }

  const durationSec = events.length && matchStartMs ? Math.max(1, ((events[events.length - 1].absoluteMs || matchStartMs) - matchStartMs) / 1000) : 1;

  function hasNearbyDeath(guid, name, time, windowSec = 2.25) {
    const lists = [];
    if (deathTimesByGuid.has(guid)) lists.push(deathTimesByGuid.get(guid));
    for (const key of [name, String(name || '').toLowerCase(), shortNameKey(name)].filter(Boolean)) {
      if (deathTimesByName.has(key)) lists.push(deathTimesByName.get(key));
    }
    return lists.some((list) => (list || []).some((deathTime) => Math.abs(Number(deathTime) - Number(time)) <= windowSec));
  }

  for (const ev of events) {
    const kind = eventKind(ev.event);
    if ((kind !== 'damage' && kind !== 'healing') || !isPlayerGuid(ev.destGuid) || !isUsefulUnitName(ev.destName) || ev.targetHealthPct == null) continue;

    const hp = Number(ev.targetCurrentHealth) || 0;
    const maxHp = Number(ev.targetMaxHealth) || 0;
    const pct = Math.max(0, Math.min(100, Number(ev.targetHealthPct)));
    const amount = Math.round(Number(ev.amount) || 0);
    const relativeSec = matchStartMs && ev.absoluteMs ? Math.max(0, (ev.absoluteMs - matchStartMs) / 1000) : 0;

    // Advanced combat logs can contain odd health snapshots for pets, stale units, or malformed payloads.
    // Keep the health graph restricted to plausible player health samples so it does not turn into barcode soup.
    if (!maxHp || maxHp < 50000) continue;
    if (hp < 0 || hp > maxHp * 1.05) continue;
    if (!Number.isFinite(pct)) continue;
    if (pct <= 0.5 && !hasNearbyDeath(ev.destGuid, ev.destName, relativeSec)) continue;

    const player = ensurePlayer(ev.destGuid, ev.destName);
    if (player) {
      player.rawPoints.push({
        time: relativeSec,
        label: relativeLabel(relativeSec),
        pct: Math.round(pct * 10) / 10,
        hp,
        maxHp,
        event: ev.event,
        kind,
        ability: ev.spellName || ev.event,
        source: ev.sourceName || 'Unknown',
        amount,
        isCritical: Boolean(ev.isCritical)
      });
    }
  }

  function compressHealthPoints(raw, player) {
    const sorted = (raw || []).filter((p) => p && Number.isFinite(Number(p.time)) && Number.isFinite(Number(p.pct))).sort((a, b) => Number(a.time) - Number(b.time));
    if (!sorted.length) return [];
    const bucketSize = durationSec > 900 ? 1.0 : durationSec > 240 ? 0.75 : 0.5;
    const bucketed = [];
    const buckets = new Map();
    for (const point of sorted) {
      const bucketKey = Math.round((Number(point.time) || 0) / bucketSize) * bucketSize;
      const existing = buckets.get(bucketKey);
      // Preserve the latest health sample in the bucket, but keep true low dips if they are meaningfully lower.
      if (!existing || Number(point.time) >= Number(existing.time) || Number(point.pct) <= Number(existing.pct) - 8) buckets.set(bucketKey, { ...point, time: bucketKey, label: relativeLabel(bucketKey) });
    }
    const compact = Array.from(buckets.values()).sort((a, b) => Number(a.time) - Number(b.time));
    if (!compact.length) return [];

    const deathList = deathTimesByGuid.get(player.guid) || deathTimesByName.get(player.name) || deathTimesByName.get(String(player.name || '').toLowerCase()) || deathTimesByName.get(shortNameKey(player.name)) || [];
    const cleaned = [];
    for (let i = 0; i < compact.length; i += 1) {
      const point = compact[i];
      const prev = cleaned[cleaned.length - 1];
      const next = compact[i + 1];
      const nearDeath = deathList.some((deathTime) => Math.abs(Number(deathTime) - Number(point.time)) <= 2.25);
      if (prev && next) {
        const diffPrev = Math.abs(Number(point.pct) - Number(prev.pct));
        const diffNext = Math.abs(Number(point.pct) - Number(next.pct));
        const prevNextDiff = Math.abs(Number(prev.pct) - Number(next.pct));
        const quickPoint = Math.abs(Number(next.time) - Number(prev.time)) <= 2.25;
        if (!nearDeath && quickPoint && diffPrev >= 55 && diffNext >= 55 && prevNextDiff <= 18) continue;
      }
      if (prev && Math.abs(Number(point.time) - Number(prev.time)) < 0.01) {
        if (Number(point.pct) <= Number(prev.pct)) cleaned[cleaned.length - 1] = point;
        continue;
      }
      cleaned.push(point);
    }

    const first = cleaned[0];
    const withAnchors = [];
    if (first && Number(first.time) > 0.75) {
      withAnchors.push({ ...first, time: 0, label: '0:00', pct: 100, amount: 0, ability: 'Match Start', synthetic: true });
    }
    withAnchors.push(...cleaned);
    for (const deathTime of deathList) {
      if (!withAnchors.some((point) => Math.abs(Number(point.time) - Number(deathTime)) <= 0.55 && Number(point.pct) <= 1)) {
        withAnchors.push({ time: Number(deathTime), label: relativeLabel(Number(deathTime)), pct: 0, amount: 0, ability: 'Death', source: '', syntheticDeath: true });
      }
    }
    return withAnchors.sort((a, b) => Number(a.time) - Number(b.time));
  }

  const players = Array.from(byGuid.values()).map((player) => {
    const points = compressHealthPoints(player.rawPoints, player);
    return {
      ...player,
      points,
      rawPointCount: (player.rawPoints || []).length,
      lowestPct: points.length ? Math.min(...points.map((p) => Number(p.pct) || 100)) : 100
    };
  }).filter((player) => player.points.length > 1);

  return { durationSec: Math.max(1, Math.round(durationSec)), players, deaths: realDeaths };
}


function summarizeBracketMatch(events, sourceLabel, segmentIndex, context = {}) {
  const summaryCacheKey = metricSummaryCacheKey(events, sourceLabel, segmentIndex, context);
  const cachedSummary = getCachedSummary(summaryCacheKey);
  if (cachedSummary) return cachedSummary;

  const damage = new Map();
  const healing = new Map();
  const taken = new Map();
  const damageDetail = new Map();
  const healingDetail = new Map();
  const takenDetail = new Map();
  const ccDetail = new Map();
  const interruptDetail = new Map();
  const purgeDetail = new Map();
  const dispelDetail = new Map();
  const ccDispelDetail = new Map();
  const castCounts = new Map();
  const damageHitsForDeaths = [];
  const deathEventsForMetrics = [];
  const cooldowns = [];
  const ccEvents = [];
  const deaths = [];
  const interrupts = [];
  const participantGuids = new Set();
  const teamByGuid = new Map();
  const metaByGuid = new Map();
  const nameMap = buildNameMap(events);
  let playerGuid = context.ownGuid || '';
  let playerName = context.ownName || '';
  const first = events[0];
  const last = events[events.length - 1];
  const startMarker = events.find((ev) => ev.event === 'ARENA_MATCH_START') || first;
  const endMarker = [...events].reverse().find((ev) => ev.event === 'ARENA_MATCH_END') || last;
  const hasArenaStart = Boolean(startMarker && startMarker.event === 'ARENA_MATCH_START');
  const hasArenaEnd = Boolean(endMarker && endMarker.event === 'ARENA_MATCH_END');
  const inferredEnd = Boolean(hasArenaStart && !hasArenaEnd && context.segmentSource && context.segmentSource !== 'arena-end');
  const matchStartMs = startMarker && startMarker.absoluteMs ? startMarker.absoluteMs : (first && first.absoluteMs ? first.absoluteMs : 0);
  const matchEndMs = endMarker && endMarker.absoluteMs ? endMarker.absoluteMs : (last && last.absoluteMs ? last.absoluteMs : matchStartMs);
  const petOwnerMap = buildPetOwnerMap(events);

  let bracket = context.bracket || 'PvP Match';
  let winnerTeam = null;
  if (startMarker && startMarker.event === 'ARENA_MATCH_START') {
    bracket = cleanSpellName(startMarker.fields[3] || 'Arena');
  }
  if (endMarker && endMarker.event === 'ARENA_MATCH_END') {
    winnerTeam = Number(endMarker.fields[1]);
  }

  for (const ev of events) {
    if (ev.event === 'COMBATANT_INFO') {
      const guid = ev.fields[1] || '';
      const team = ev.fields[2] || '';
      const specId = Number(ev.fields[25]) || 0;
      const meta = metaForSpec(specId);
      if (isPlayerGuid(guid)) {
        participantGuids.add(guid);
        teamByGuid.set(guid, team);
        if (meta) metaByGuid.set(guid, { ...meta, team });
      }
    }
    if (isPlayerGuid(ev.sourceGuid)) participantGuids.add(ev.sourceGuid);
    if (isPlayerGuid(ev.destGuid)) participantGuids.add(ev.destGuid);
    if (!playerGuid || !playerName) {
      const ownCandidate = noteOwnCandidate(ev, { guid: playerGuid, name: playerName });
      playerGuid = playerGuid || ownCandidate.guid;
      playerName = playerName || ownCandidate.name;
    }

    const kind = eventKind(ev.event);
    const relativeSec = matchStartMs && ev.absoluteMs ? Math.max(0, (ev.absoluteMs - matchStartMs) / 1000) : 0;
    ev._relativeSec = relativeSec;
    ev._relativeLabel = relativeLabel(relativeSec);

    const sourceActor = metricActorInfo(ev, 'source', petOwnerMap);
    const destActor = metricActorInfo(ev, 'dest', petOwnerMap);
    if (kind === 'cast' && ev.spellName) incNestedCount(castCounts, sourceActor.rowName || ev.sourceName, ev.spellName);

    if (kind === 'damage' && ev.amount > 0) {
      addAmount(damage, sourceActor.rowName || ev.sourceName, ev.amount, ev.spellName || ev.event);
      addAmount(taken, destActor.rowName || ev.destName, ev.amount, ev.spellName || ev.event);
      pushAmountMetric(damageDetail, sourceActor.rowName || ev.sourceName, ev.spellName || ev.event, ev.amount, ev, 'target', sourceActor);
      pushAmountMetric(takenDetail, destActor.rowName || ev.destName, ev.spellName || ev.event, ev.amount, ev, 'source', destActor);
      damageHitsForDeaths.push({ relativeSec, sourceName: ev.sourceName, destName: ev.destName, spellName: ev.spellName || ev.event, event: ev.event, amount: ev.amount, targetHealthPct: ev.targetHealthPct == null ? null : Math.round(Number(ev.targetHealthPct)) });
    }
    if (kind === 'healing' && ev.amount > 0) {
      addAmount(healing, sourceActor.rowName || ev.sourceName, ev.amount, ev.spellName || ev.event);
      pushAmountMetric(healingDetail, sourceActor.rowName || ev.sourceName, ev.spellName || ev.event, ev.amount, ev, 'target', sourceActor);
    }

    if ((kind === 'cast' || kind === 'aura') && ev.spellName) {
      if (kind === 'cast' && offensiveCooldowns.has(ev.spellName)) cooldowns.push({ time: relativeLabel(relativeSec), absolute: ev.stamp, actor: ev.sourceName, ability: ev.spellName, team: 'Observed', tone: 'offense', relativeSec });
      if (kind === 'cast' && defensiveCooldowns.has(ev.spellName)) cooldowns.push({ time: relativeLabel(relativeSec), absolute: ev.stamp, actor: ev.sourceName, ability: ev.spellName, team: 'Observed', tone: 'defense', relativeSec });
      if (ccSpells.has(ev.spellName)) {
        ccEvents.push({ time: relativeLabel(relativeSec), absolute: ev.stamp, actor: ev.sourceName, target: ev.destName, ability: ev.spellName, relativeSec });
        pushCountMetric(ccDetail, ev.sourceName, ev.spellName, ev);
      }
    }
    if (kind === 'interrupt') {
      interrupts.push({ time: relativeLabel(relativeSec), actor: ev.sourceName, target: ev.destName, ability: ev.spellName || 'Interrupt', interrupted: ev.extraSpellName || '', relativeSec });
      pushCountMetric(interruptDetail, ev.sourceName, ev.spellName || 'Interrupt', { ...ev, interruptedSpellName: ev.extraSpellName || '' }, ev.destName);
    }
    if (kind === 'dispel') {
      const removed = ev.extraSpellName || 'Dispelled effect';
      const dispelSpell = ev.spellName || 'Dispel';
      const isPurge = isOffensivePurgeEvent(ev, teamByGuid);
      if (isPurge) {
        // Purges are offensive removals: buffs stripped from an opposing target.
        pushDispelMetric(purgeDetail, ev.sourceName, dispelSpell, removed, ev, ev.destName, false);
      } else {
        // Dispels are friendly cleanses: debuffs/CC removed from an allied target.
        pushDispelMetric(dispelDetail, ev.sourceName, dispelSpell, removed, ev, ev.destName, false);
        if (ccSpells.has(removed)) pushDispelMetric(ccDispelDetail, ev.sourceName, dispelSpell, removed, ev, ev.destName, true);
      }
    }
    if (kind === 'death') {
      const deathRow = {
        time: relativeLabel(relativeSec),
        absolute: ev.stamp,
        victim: ev.destName,
        victimGuid: ev.destGuid || '',
        victimTeam: teamByGuid.get(ev.destGuid) || '',
        relativeSec,
        isFeignDeath: Boolean(ev.isFeignDeath)
      };
      if (!deathRow.isFeignDeath && isPlayerGuid(ev.destGuid)) {
        deaths.push(deathRow);
        deathEventsForMetrics.push({ victim: ev.destName, relativeSec, absolute: ev.stamp, isFeignDeath: false });
      }
    }
  }

  const teams = { '0': [], '1': [], unknown: [] };
  for (const guid of participantGuids) {
    const name = nameMap.get(guid) || guid;
    if (!isUsefulUnitName(name) && !isPlayerGuid(guid)) continue;
    const team = teamByGuid.get(guid);
    const bucket = team === '0' || team === '1' ? team : 'unknown';
    if (!teams[bucket].includes(name)) teams[bucket].push(name);
  }

  if (playerGuid && !playerName) playerName = nameMap.get(playerGuid) || '';
  let ownTeam = playerGuid ? teamByGuid.get(playerGuid) : '';
  if (!ownTeam && playerName) {
    if (teams['0'].includes(playerName)) ownTeam = '0';
    if (teams['1'].includes(playerName)) ownTeam = '1';
  }
  if (!playerName) {
    playerName = ownTeam && teams[ownTeam] && teams[ownTeam][0] ? teams[ownTeam][0] : (teams['1'][0] || teams['0'][0] || '');
  }
  if (!ownTeam && playerName) {
    if (teams['0'].includes(playerName)) ownTeam = '0';
    if (teams['1'].includes(playerName)) ownTeam = '1';
  }
  if (!ownTeam) ownTeam = '1';
  const ownNames = Array.from(new Set([playerName].filter(Boolean)));
  const participants = [...teams['1'], ...teams['0'], ...teams.unknown].filter(Boolean);
  const classByName = {};
  const specByName = {};
  for (const [guid, meta] of metaByGuid.entries()) {
    const name = nameMap.get(guid);
    if (!isUsefulUnitName(name)) continue;
    classByName[name] = { className: meta.className, classColor: meta.classColor, specName: meta.specName, specId: meta.specId, team: meta.team };
    specByName[name] = meta.specName;
  }
  const eventHashes = events.map((ev) => ev.hash).slice(0, 120).join('');
  const matchHash = hashText(`${sourceLabel}-${segmentIndex}-${events.length}-${eventHashes}-${startMarker ? startMarker.stamp : ''}-${endMarker ? endMarker.stamp : ''}-${winnerTeam ?? ''}`);
  const durationSec = endMarker && endMarker.event === 'ARENA_MATCH_END' && Number(endMarker.fields[2])
    ? Number(endMarker.fields[2])
    : Math.max(0, Math.round((matchEndMs - matchStartMs) / 1000));

  const damageRows = rowsFromAmountMetric(damageDetail, castCounts, false);
  const healingRows = rowsFromAmountMetric(healingDetail, castCounts, false);
  const takenRows = rowsFromAmountMetric(takenDetail, castCounts, false);
  const metrics = {
    Damage: damageRows,
    Healing: healingRows,
    Taken: takenRows,
    CC: rowsFromCountMetric(ccDetail, castCounts),
    Interrupts: rowsFromCountMetric(interruptDetail, castCounts),
    Purges: rowsFromCountMetric(purgeDetail, castCounts),
    Dispels: rowsFromCountMetric(dispelDetail, castCounts),
    'CC Dispels': rowsFromCountMetric(ccDispelDetail, castCounts),
    Deaths: buildDeathMetricRows(deathEventsForMetrics, damageHitsForDeaths)
  };
  metrics.DamagePlayers = rowsFromAmountMetric(damageDetail, castCounts, true);
  metrics.HealingPlayers = rowsFromAmountMetric(healingDetail, castCounts, true);
  metrics.TakenPlayers = rowsFromAmountMetric(takenDetail, castCounts, true);
  const topDamage = damageRows[0];
  const topHealing = healingRows[0];
  const eventFeed = buildEventFeed(events, matchStartMs, teamByGuid);
  const healthTimeline = buildHealthTimeline(events, matchStartMs, metaByGuid, teamByGuid, deaths);
  const death = deaths[deaths.length - 1];

  const friendlyTeam = (teams[ownTeam] || []).filter(Boolean);
  const enemyBuckets = ['0', '1'].filter((team) => team !== ownTeam).flatMap((team) => teams[team] || []);
  const enemyTeam = enemyBuckets.filter((name) => name && !ownNames.includes(name));
  const normalizedBracket = normalizeMatchType(bracket || 'Arena');
  const resolvedMapName = cleanMatchMapName(context.zoneName, startMarker);
  const isSoloShuffle = /shuffle/i.test(normalizedBracket);
  const inferredSoloRound = isSoloShuffle ? inferSoloShuffleRoundWinnerFromDeath(deaths, teams) : { winnerTeam: null, victim: '', victimTeam: '', source: '' };
  const roundWinnerTeam = isSoloShuffle && inferredSoloRound.winnerTeam !== null ? inferredSoloRound.winnerTeam : winnerTeam;
  const roundWinnerSource = isSoloShuffle && inferredSoloRound.winnerTeam !== null ? inferredSoloRound.source : (winnerTeam === null ? '' : 'arena-match-end');
  const result = roundWinnerTeam === null ? 'Parsed' : (String(roundWinnerTeam) === String(ownTeam) ? 'Win' : 'Loss');
  const confidentCombatLogResult = result === 'Win' || result === 'Loss';
  const resultSource = confidentCombatLogResult ? `combatLog:${roundWinnerSource || 'winner-team'}` : '';
  const scoreboardTeamCounts = teamCountsFromNames(teams);
  const expectedTeamSize = expectedTeamSizeForType(normalizedBracket, resolvedMapName || '');
  const actualTeamSize = maxTeamCount(scoreboardTeamCounts);
  const isRatedBattleground = isRatedBattlegroundType(normalizedBracket);
  const isBattleground = isBattlegroundType(normalizedBracket) || actualTeamSize >= 6 || participants.length >= 12;
  const bgCoverageNote = isBattleground
    ? 'BG combat logs are fight-event coverage only. They can miss distant fights, objectives, and final scoreboard totals. Link the PvPHelper final scoreboard for full end-of-game comparison.'
    : '';

  const summary = {
    id: `pvp_${matchHash.slice(0, 12)}`,
    result,
    resultSource,
    resultAuthority: confidentCombatLogResult ? 'combatLog' : '',
    combatLogResult: confidentCombatLogResult ? result : '',
    combatLogOwnTeam: String(ownTeam || ''),
    combatLogWinnerTeam: roundWinnerTeam === null ? '' : String(roundWinnerTeam),
    combatLogWinnerTeamSource: roundWinnerSource,
    bracket: normalizedBracket,
    winnerTeam: roundWinnerTeam === null ? 'Unknown' : String(roundWinnerTeam),
    winnerTeamSource: roundWinnerSource,
    soloRoundEndVictim: isSoloShuffle ? (inferredSoloRound.victim || '') : '',
    soloRoundEndVictimTeam: isSoloShuffle ? (inferredSoloRound.victimTeam || '') : '',
    ownTeam: String(ownTeam || ''),
    map: resolvedMapName || `Instance ${startMarker && startMarker.fields[1] ? startMarker.fields[1] : 'Unknown'}`,
    duration: formatDuration(durationSec),
    durationSec,
    date: startMarker && startMarker.iso ? new Date(startMarker.iso).toLocaleDateString() : new Date().toLocaleDateString(),
    time: startMarker && endMarker ? `${startMarker.timestampLabel} to ${endMarker.timestampLabel}` : 'Imported',
    startIso: startMarker && startMarker.iso ? startMarker.iso : '',
    endIso: endMarker && endMarker.iso ? endMarker.iso : '',
    startMs: matchStartMs,
    endMs: matchEndMs,
    endInferred: inferredEnd,
    inferredEndTime: inferredEnd && endMarker && endMarker.iso ? endMarker.iso : '',
    inferredEndMs: inferredEnd && endMarker && endMarker.absoluteMs ? endMarker.absoluteMs : 0,
    captureReason: inferredEnd ? String(context.segmentSource || 'arena-end-inferred') : String(context.segmentSource || ''),
    videoSegmentStartMs: first && first.absoluteMs ? first.absoluteMs : matchStartMs,
    videoSegmentStartIso: first && first.iso ? first.iso : (startMarker && startMarker.iso ? startMarker.iso : ''),
    gameStartMs: matchStartMs,
    gameStartIso: startMarker && startMarker.iso ? startMarker.iso : '',
    alt: playerName || friendlyTeam[0] || participants[0] || 'Unknown Player',
    playerGuid,
    ownNames,
    classByName,
    specByName,
    spec: (playerName && specByName[playerName]) ? specByName[playerName] : 'Spec unknown',
    myComp: friendlyTeam.length ? friendlyTeam : [],
    enemyComp: enemyTeam.length ? enemyTeam : [],
    enemies: enemyTeam,
    participants,
    teams,
    matchType: normalizedBracket,
    isSoloShuffle,
    isRatedBattleground,
    isBattleground,
    expectedTeamSize,
    actualTeamSize,
    scoreboardTeamCounts,
    parserVersion: PARSER_VERSION,
    summary: `Top damage: ${topDamage ? `${topDamage.name} ${Math.round(topDamage.amount).toLocaleString()}` : 'none detected'}. Top healing: ${topHealing ? `${topHealing.name} ${Math.round(topHealing.amount).toLocaleString()}` : 'none detected'}.`,
    danger: bgCoverageNote || (deaths.length > 0 ? 'Death events found.' : 'No deaths found.'),
    dataQualityNote: bgCoverageNote,
    tags: [normalizedBracket, `Winner team ${roundWinnerTeam ?? 'unknown'}`, `${events.length.toLocaleString()} Events`, ...(isSoloShuffle && inferredSoloRound.victim ? [`Round ended by ${inferredSoloRound.victim}`] : [])],
    damage: damageRows,
    healing: healingRows,
    taken: takenRows,
    metrics,
    cooldowns: dedupeTimelineEvents(cooldowns, 2.5).slice(0, 100),
    ccChains: dedupeTimelineEvents(ccEvents.map((cc) => ({ ...cc, tone: 'control' })), 1.0).slice(0, 100).map((cc) => ({ time: cc.time, target: cc.target, chain: cc.ability, duration: 0, result: `${cc.actor} controlled ${cc.target}`, relativeSec: cc.relativeSec })),
    interrupts: interrupts.slice(0, 80),
    death: {
      victim: death ? death.victim : 'No death detected',
      at: death ? death.time : 'n/a',
      recap: deathEventsForMetrics.length ? buildDeathMetricRows(deathEventsForMetrics, damageHitsForDeaths).slice(-1)[0].lastHits.slice(-10).map((hit) => `${hit.time} ${hit.source} ${hit.ability} ${Math.round(hit.amount).toLocaleString()}${hit.targetHealthPct != null ? ` (${hit.targetHealthPct}% HP)` : ''}`) : [],
      lastHits: deathEventsForMetrics.length ? buildDeathMetricRows(deathEventsForMetrics, damageHitsForDeaths).slice(-1)[0].lastHits.slice(-10) : [],
      note: deaths.length > 0 ? 'Last incoming hits are available in the Deaths meter.' : 'No death events were found in this match.'
    },
    chart: buildChart(events, matchStartMs),
    healthTimeline,
    eventFeed,
    rawEvents: eventFeed,
    rawFingerprint: matchHash,
    sourceLabel,
    createdFromRealLog: true,
    dataSources: ['combatLog'],
    isBracketMatch: true,
    soloRounds: isSoloShuffle ? [{ result, winnerTeam: roundWinnerTeam === null ? 'Unknown' : String(roundWinnerTeam), endVictim: inferredSoloRound.victim || '', source: roundWinnerSource || 'unknown' }] : []
  };
  setCachedSummary(summaryCacheKey, summary);
  return summary;
}




  return {
    addAmount,
    getMapEntry,
    incNestedCount,
    castCountFor,
    buildPetOwnerMap,
    petOwnerForGuid,
    metricActorInfo,
    pushAmountMetric,
    pushCountMetric,
    pushDispelMetric,
    rowsFromAmountMetric,
    rowsFromCountMetric,
    buildDeathMetricRows,
    dedupeTimelineEvents,
    dedupeFeedEvents,
    buildEventFeed,
    buildChart,
    buildNameMap,
    normalizeMatchType,
    buildHealthTimeline,
    summarizeBracketMatch
  };
}

module.exports = { createCombatLogMetricsTools };
