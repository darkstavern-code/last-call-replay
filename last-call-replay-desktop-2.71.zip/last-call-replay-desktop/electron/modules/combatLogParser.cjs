const { createCombatLogCoreTools } = require('./combatLogCore.cjs');
const { createCombatLogMetricsTools } = require('./combatLogMetrics.cjs');
const { createCombatLogSegmentTools } = require('./combatLogSegments.cjs');

function createCombatLogParserTools(deps = {}) {
  const {
    hashText = (value) => String(value || ''),
    uniqueList = (items = []) => Array.from(new Set(items || [])),
    shortNameKey = (value) => String(value || '').split('-')[0].trim().toLowerCase(),
    metaForSpec = () => null,
    mapNameFromArenaStart = () => '',
    cleanMatchMapName = (value) => String(value || '').trim(),
    isRawInstanceMapLabel = () => false,
    battlegroundInstanceMapName = () => '',
    battlegroundMapNameFromSubzone = () => '',
    isKnownBattlegroundZone = () => false,
    expectedTeamSizeForType = () => 0,
    teamCountsFromNames = () => ({}),
    maxTeamCount = () => 0,
    isBattlegroundType = () => false,
    isRatedBattlegroundType = () => false,
    inferSoloShuffleRoundWinnerFromDeath = () => ({ winnerTeam: null, victim: '', source: 'unknown' }),
    getParserVersion = () => 0
  } = deps;

  const parserVersion = Number(getParserVersion()) || 0;
  const core = createCombatLogCoreTools({ hashText });
  const metrics = createCombatLogMetricsTools({
    core,
    hashText,
    uniqueList,
    shortNameKey,
    metaForSpec,
    cleanMatchMapName,
    expectedTeamSizeForType,
    teamCountsFromNames,
    maxTeamCount,
    isBattlegroundType,
    isRatedBattlegroundType,
    inferSoloShuffleRoundWinnerFromDeath,
    parserVersion
  });
  const segments = createCombatLogSegmentTools({
    core,
    metrics,
    hashText,
    uniqueList,
    mapNameFromArenaStart,
    isRawInstanceMapLabel,
    battlegroundInstanceMapName,
    battlegroundMapNameFromSubzone,
    isKnownBattlegroundZone
  });

  function processRawText(rawText, sourceLabel, options = {}) {
    const lines = String(rawText || '').split(/\r?\n/).filter((line) => line.trim().length > 0);
    const events = [];
    const seen = new Set();
    for (const line of lines) {
      const parsed = core.parseCombatLine(line);
      if (!parsed) continue;
      if (seen.has(parsed.hash)) continue;
      seen.add(parsed.hash);
      events.push(parsed);
    }
    if (events.length === 0) return [];
    return segments.extractBracketMatches(events, sourceLabel, options);
  }

  return {
    ...core,
    ...metrics,
    ...segments,
    processRawText
  };
}

module.exports = { createCombatLogParserTools };
