'use strict';

const { createPvPHelperCoreTools } = require('./pvpHelperCore.cjs');
const { LuaSavedVariablesParser, parseLuaAssignment } = require('./pvpHelperLuaParser.cjs');
const { createPvPHelperInputTools } = require('./pvpHelperInput.cjs');
const { createPvPHelperCharacterTools } = require('./pvpHelperCharacters.cjs');
const { createPvPHelperSnapshotTools } = require('./pvpHelperSnapshots.cjs');
const { createPvPHelperStatusTools } = require('./pvpHelperStatus.cjs');
const { createPvPHelperMergeTools } = require('./pvpHelperMerge.cjs');

function createPvPHelperImportTools(deps = {}) {
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const zlib = deps.zlib || require('zlib');
  const WOW_CLASS_COLORS = deps.WOW_CLASS_COLORS || {};
  const hashText = typeof deps.hashText === 'function' ? deps.hashText : (value) => String(value || '');
  const metaForSpec = typeof deps.metaForSpec === 'function' ? deps.metaForSpec : () => null;
  const normalizeClassKey = typeof deps.normalizeClassKey === 'function' ? deps.normalizeClassKey : (value) => String(value || '');
  const cleanMatchMapName = typeof deps.cleanMatchMapName === 'function' ? deps.cleanMatchMapName : (value) => String(value || 'Unknown map');
  const teamCountsFromPlayers = typeof deps.teamCountsFromPlayers === 'function' ? deps.teamCountsFromPlayers : () => ({});
  const expectedTeamSizeForType = typeof deps.expectedTeamSizeForType === 'function' ? deps.expectedTeamSizeForType : () => 0;
  const maxTeamCount = typeof deps.maxTeamCount === 'function' ? deps.maxTeamCount : () => 0;
  const isRatedBattlegroundType = typeof deps.isRatedBattlegroundType === 'function' ? deps.isRatedBattlegroundType : () => false;
  const isBattlegroundType = typeof deps.isBattlegroundType === 'function' ? deps.isBattlegroundType : () => false;
  const durationSecondsFromValue = typeof deps.durationSecondsFromValue === 'function' ? deps.durationSecondsFromValue : () => 0;
  const formatDuration = typeof deps.formatDuration === 'function' ? deps.formatDuration : (seconds) => String(seconds || '');
  const normalizeMatchDataSources = typeof deps.normalizeMatchDataSources === 'function' ? deps.normalizeMatchDataSources : (match) => match;
  const uniqueList = typeof deps.uniqueList === 'function' ? deps.uniqueList : (items = []) => Array.from(new Set((items || []).filter(Boolean)));
  const extractPvPHelperVersion = typeof deps.extractPvPHelperVersion === 'function' ? deps.extractPvPHelperVersion : () => '';
  const buildPvPHelperVersionStatus = typeof deps.buildPvPHelperVersionStatus === 'function' ? deps.buildPvPHelperVersionStatus : () => ({});
  const matchDedupeKey = typeof deps.matchDedupeKey === 'function' ? deps.matchDedupeKey : (match) => match && (match.id || match.rawFingerprint || '');
  const matchExistsInState = typeof deps.matchExistsInState === 'function' ? deps.matchExistsInState : (state, match) => Boolean((state && state.matches || []).some((existing) => matchDedupeKey(existing) === matchDedupeKey(match)));
  const resolveStateMatchLibrary = typeof deps.resolveStateMatchLibrary === 'function' ? deps.resolveStateMatchLibrary : () => null;
  const dedupeCharacterSnapshots = typeof deps.dedupeCharacterSnapshots === 'function' ? deps.dedupeCharacterSnapshots : (items = []) => items;
  const characterSnapshotDedupeKey = typeof deps.characterSnapshotDedupeKey === 'function' ? deps.characterSnapshotDedupeKey : (item) => item && (item.id || JSON.stringify(item));
  const findPvPHelperSavedVariablesFromSelection = typeof deps.findPvPHelperSavedVariablesFromSelection === 'function' ? deps.findPvPHelperSavedVariablesFromSelection : () => ({ ok: false });
  const discoverPvPHelperSavedVariables = typeof deps.discoverPvPHelperSavedVariables === 'function' ? deps.discoverPvPHelperSavedVariables : () => ({});
  const defaultSettings = typeof deps.defaultSettings === 'function' ? deps.defaultSettings : () => ({});
  const writeState = typeof deps.writeState === 'function' ? deps.writeState : () => null;
  const autoLinkRecordings = typeof deps.autoLinkRecordings === 'function' ? deps.autoLinkRecordings : () => null;

  const coreTools = createPvPHelperCoreTools();
  const inputTools = createPvPHelperInputTools({ fs, path, zlib });
  const characterTools = createPvPHelperCharacterTools({
    WOW_CLASS_COLORS,
    hashText,
    metaForSpec,
    cleanBracketName: coreTools.cleanBracketName,
    firstDefinedNumber: coreTools.firstDefinedNumber
  });
  const snapshotTools = createPvPHelperSnapshotTools({
    WOW_CLASS_COLORS,
    hashText,
    normalizeClassKey,
    cleanMatchMapName,
    teamCountsFromPlayers,
    expectedTeamSizeForType,
    maxTeamCount,
    isRatedBattlegroundType,
    isBattlegroundType,
    durationSecondsFromValue,
    formatDuration,
    normalizeMatchDataSources,
    uniqueList,
    cleanBracketName: coreTools.cleanBracketName,
    firstDefinedNumber: coreTools.firstDefinedNumber,
    objectArrayLikeToArray: coreTools.objectArrayLikeToArray,
    firstTextValue: coreTools.firstTextValue,
    clonePlainValue: coreTools.clonePlainValue,
    normalizeTimestampToIso: coreTools.normalizeTimestampToIso,
    splitPlayerRealm: coreTools.splitPlayerRealm,
    parseCharacterSnapshotText: characterTools.parseCharacterSnapshotText
  });
  const statusTools = createPvPHelperStatusTools({
    extractPvPHelperVersion,
    buildPvPHelperVersionStatus,
    objectArrayLikeToArray: coreTools.objectArrayLikeToArray,
    parseBooleanish: coreTools.parseBooleanish,
    firstBooleanStatus: coreTools.firstBooleanStatus,
    clonePlainValue: coreTools.clonePlainValue
  });
  const mergeTools = createPvPHelperMergeTools({
    cleanBracketName: coreTools.cleanBracketName,
    strongerMatchType: coreTools.strongerMatchType,
    uniqueList,
    normalizeMatchDataSources,
    matchDedupeKey,
    matchExistsInState,
    resolveStateMatchLibrary,
    dedupeCharacterSnapshots,
    characterSnapshotDedupeKey
  });

  function parsePvPHelperSavedVariables(raw, sourceFile = '') {
    let db = null;
    try { db = JSON.parse(String(raw || '')); } catch (_error) {}
    if (!db) db = parseLuaAssignment(raw, 'PvPHelperDB') || parseLuaAssignment(raw, 'MrFixItDB') || {};
    db = db && typeof db === 'object' ? db : {};
    const primaryMatchHistory = db && db.matchHistory !== undefined ? db.matchHistory : null;
    const matchHistory = coreTools.objectArrayLikeToArray(primaryMatchHistory || db.matches || []).filter((item) => item && typeof item === 'object');
    const matches = [];
    let skippedMalformedSnapshots = 0;
    let skippedEmptySnapshots = 0;
    for (const item of matchHistory) {
      try {
        const normalized = snapshotTools.normalizeAddonMatchSnapshot(item, sourceFile);
        if (normalized) matches.push(normalized);
        else skippedEmptySnapshots += 1;
      } catch (error) {
        skippedMalformedSnapshots += 1;
        console.warn('[Last Call Replay] Skipped malformed PvPHelper matchHistory snapshot:', error && error.message ? error.message : error);
      }
    }
    const snapshots = [];
    if (db.characters) snapshots.push(...characterTools.collectCharacterSnapshotsFromObject({ characters: db.characters }, sourceFile));
    snapshots.push(...snapshotTools.characterSnapshotsFromMatchHistory(matchHistory, sourceFile));
    const addonStatus = statusTools.extractPvPHelperAddonStatus(db, matches, snapshots);
    addonStatus.skippedMalformedSnapshots = skippedMalformedSnapshots;
    addonStatus.skippedEmptySnapshots = skippedEmptySnapshots;
    return {
      db,
      matches,
      snapshots,
      matchHistoryCount: matchHistory.length,
      skippedMalformedSnapshots,
      skippedEmptySnapshots,
      matchHistoryMeta: coreTools.clonePlainValue(db.matchHistoryMeta || {}),
      primaryPathUsed: primaryMatchHistory !== null ? 'PvPHelperDB.matchHistory' : (db.matches !== undefined ? 'PvPHelperDB.matches' : ''),
      addonStatus
    };
  }

  function pvphFileMtimeMs(filePath) {
    try { return fs.statSync(filePath).mtimeMs || 0; } catch (_error) { return 0; }
  }

  function previewPvPHelperFilePath(state, filePath) {
    if (!filePath) return { ok: false, reason: 'Choose the SavedVariables folder or PvPHelper.lua file.', matches: state.matches || [], addonImports: state.addonImports || [] };
    const resolved = findPvPHelperSavedVariablesFromSelection(filePath, state.settings || {});
    if (!resolved.ok || !resolved.filePath) {
      return { ok: false, reason: resolved.reason || 'No PvPHelper.lua was found in that folder.', selectedPath: filePath, discovery: discoverPvPHelperSavedVariables(state.settings || {}), candidates: resolved.candidates || [], matches: state.matches || [], addonImports: state.addonImports || [] };
    }
    const resolvedPath = resolved.filePath;
    let input;
    try { input = inputTools.readPvPHelperInputFile(resolvedPath); } catch (error) {
      return { ok: false, reason: error.message || 'Could not read PvPHelper SavedVariables file.', selectedPath: filePath, filePath: resolvedPath, matches: state.matches || [] };
    }
    if (!input || !input.raw) {
      return { ok: false, reason: input && input.reason ? input.reason : 'No PvPHelperDB data was found. Choose the folder that contains the SavedVariables file named PvPHelper.lua.', selectedPath: filePath, filePath: resolvedPath, matches: state.matches || [], addonImports: state.addonImports || [] };
    }
    let parsed;
    try { parsed = parsePvPHelperSavedVariables(input.raw, input.sourceName || path.basename(resolvedPath)); } catch (error) {
      return { ok: false, reason: error.message || 'Could not parse PvPHelper SavedVariables.', selectedPath: filePath, filePath: resolvedPath, matches: state.matches || [] };
    }
    const preview = mergeTools.previewPvPHelperImportIntoState(state, parsed, resolvedPath);
    preview.addonStatus = parsed.addonStatus || {};
    if (input.archiveEntry) preview.archiveEntry = input.archiveEntry;
    preview.sourceName = input.sourceName || path.basename(resolvedPath);
    preview.filePath = resolvedPath;
    preview.mappedPath = resolvedPath;
    preview.selectedPath = filePath;
    preview.resolvedFromFolder = path.normalize(String(filePath || '')) !== path.normalize(String(resolvedPath || ''));
    preview.folderCandidateCount = resolved.candidates ? resolved.candidates.length : 0;
    preview.fileMtimeMs = pvphFileMtimeMs(resolvedPath);
    return preview;
  }

  function importPvPHelperFileIntoState(state, filePath, options = {}) {
    if (!filePath) return { ok: false, reason: 'Choose the SavedVariables folder or PvPHelper.lua file.', matches: state.matches || [], addonImports: state.addonImports || [] };
    const resolved = findPvPHelperSavedVariablesFromSelection(filePath, state.settings || {});
    if (!resolved.ok || !resolved.filePath) {
      return { ok: false, reason: resolved.reason || 'No PvPHelper.lua was found in that folder.', selectedPath: filePath, candidates: resolved.candidates || [], matches: state.matches || [], addonImports: state.addonImports || [] };
    }
    const resolvedPath = resolved.filePath;
    let input;
    try { input = inputTools.readPvPHelperInputFile(resolvedPath); } catch (error) {
      return { ok: false, reason: error.message || 'Could not read PvPHelper SavedVariables file.', selectedPath: filePath, filePath: resolvedPath, matches: state.matches || [] };
    }
    if (!input || !input.raw) {
      return { ok: false, reason: input && input.reason ? input.reason : 'No PvPHelperDB data was found. Choose the folder that contains the SavedVariables file named PvPHelper.lua.', selectedPath: filePath, filePath: resolvedPath, matches: state.matches || [], addonImports: state.addonImports || [] };
    }
    let parsed;
    try { parsed = parsePvPHelperSavedVariables(input.raw, input.sourceName || path.basename(resolvedPath)); } catch (error) {
      return { ok: false, reason: error.message || 'Could not parse PvPHelper SavedVariables.', selectedPath: filePath, filePath: resolvedPath, matches: state.matches || [] };
    }
    const beforeSnapshotIds = new Set((state.characterSnapshots || []).map((item) => item && item.id).filter(Boolean));
    const summary = mergeTools.importPvPHelperDataIntoState(state, parsed, resolvedPath);
    if (input.archiveEntry) summary.archiveEntry = input.archiveEntry;
    autoLinkRecordings(state, state.matches || []);
    const mtime = pvphFileMtimeMs(resolvedPath);
    state.settings = { ...defaultSettings(), ...(state.settings || {}) };
    state.settings.pvpHelperSavedVariablesPath = resolvedPath;
    state.settings.pvpHelperLastSyncMtimeMs = mtime;
    state.settings.pvpHelperLastSyncAt = new Date().toISOString();
    state.settings.pvpHelperFileExists = true;
    state.settings.pvpHelperStatus = parsed.addonStatus || {};
    state.settings.pvpHelperLastScoreboardCount = summary.parsed || 0;
    state.settings.pvpHelperLastPendingCount = summary.created || 0;
    state.settings.pvpHelperLastMergedCount = summary.merged || 0;
    state.settings.pvpHelperLastRatingSnapshotCount = (parsed.snapshots || []).length;
    state.settings.pvpHelperLastPrimaryPath = parsed.primaryPathUsed || '';
    state.settings.pvpHelperMatchHistorySchemaVersion = parsed.addonStatus && parsed.addonStatus.matchHistorySchemaVersion ? parsed.addonStatus.matchHistorySchemaVersion : 0;
    state.settings.pvpHelperMatchHistoryMetaFound = Boolean(parsed.addonStatus && parsed.addonStatus.matchHistoryMetaFound);
    state.settings.pvpHelperSavedVariablesDiscovery = discoverPvPHelperSavedVariables(state.settings || {});
    if (options.autoSync !== undefined) state.settings.pvpHelperAutoSync = Boolean(options.autoSync);
    const ratingImported = (state.characterSnapshots || []).filter((item) => item && item.id && !beforeSnapshotIds.has(item.id)).length;
    writeState(state);
    return {
      ok: true,
      filePath: resolvedPath,
      mappedPath: resolvedPath,
      ...summary,
      ratingImported,
      imported: summary.merged + summary.created + ratingImported,
      fileMtimeMs: mtime,
      addonStatus: parsed.addonStatus || {},
      matches: state.matches || [],
      characterSnapshots: state.characterSnapshots || [],
      addonImports: state.addonImports || [],
      importedFiles: state.importedFiles || [],
      settings: state.settings || {}
    };
  }

  return {
    ...coreTools,
    ...characterTools,
    LuaSavedVariablesParser,
    ...inputTools,
    parseLuaAssignment,
    ...snapshotTools,
    ...statusTools,
    parsePvPHelperSavedVariables,
    ...mergeTools,
    pvphFileMtimeMs,
    previewPvPHelperFilePath,
    importPvPHelperFileIntoState
  };
}

module.exports = { createPvPHelperImportTools };
