'use strict';

function createPvPHelperMergeTools(deps = {}) {
  const cleanBracketName = typeof deps.cleanBracketName === 'function' ? deps.cleanBracketName : (value) => String(value || 'Unknown Bracket');
  const strongerMatchType = typeof deps.strongerMatchType === 'function' ? deps.strongerMatchType : (base, addon) => base || addon || 'PvP Match';
  const uniqueList = typeof deps.uniqueList === 'function' ? deps.uniqueList : (items = []) => Array.from(new Set((items || []).filter(Boolean)));
  const normalizeMatchDataSources = typeof deps.normalizeMatchDataSources === 'function' ? deps.normalizeMatchDataSources : (match) => match;
  const matchDedupeKey = typeof deps.matchDedupeKey === 'function' ? deps.matchDedupeKey : (match) => match && (match.id || match.rawFingerprint || '');
  const matchExistsInState = typeof deps.matchExistsInState === 'function' ? deps.matchExistsInState : (state, match) => Boolean((state && state.matches || []).some((existing) => matchDedupeKey(existing) === matchDedupeKey(match)));
  const resolveStateMatchLibrary = typeof deps.resolveStateMatchLibrary === 'function' ? deps.resolveStateMatchLibrary : () => null;
  const dedupeCharacterSnapshots = typeof deps.dedupeCharacterSnapshots === 'function' ? deps.dedupeCharacterSnapshots : (items = []) => items;
  const characterSnapshotDedupeKey = typeof deps.characterSnapshotDedupeKey === 'function' ? deps.characterSnapshotDedupeKey : (item) => item && (item.id || JSON.stringify(item));

function namesOverlapScore(a = [], b = []) {
  const setA = new Set((a || []).map((name) => shortNameKey(name)).filter(Boolean));
  const setB = new Set((b || []).map((name) => shortNameKey(name)).filter(Boolean));
  let count = 0;
  for (const item of setA) if (setB.has(item)) count += 1;
  return count;
}

function shortNameKey(value) {
  return String(value || '').split('-')[0].toLowerCase().trim();
}

function isSoloShuffleLike(match = {}) {
  const values = [
    match.matchType,
    match.bracket,
    match.matchLabel,
    match.label,
    match.addonScoreboard && match.addonScoreboard.label
  ];
  return values.some((value) => /shuffle/i.test(String(value || '')));
}


function normalizedResultValue(value = '') {
  const raw = String(value || '').trim();
  if (!raw || /^parsed$/i.test(raw) || /^unscored$/i.test(raw)) return '';
  if (/^(win|won|winner|victory|victorious|success)$/i.test(raw) || /\b(win|won|victory)\b/i.test(raw)) return 'Win';
  if (/^(loss|lost|lose|loser|defeat|defeated|failure)$/i.test(raw) || /\b(loss|lost|defeat)\b/i.test(raw)) return 'Loss';
  return '';
}

function firstNonEmptyValue(...values) {
  for (const value of values) {
    if (value !== undefined && value !== null && String(value).trim() !== '' && String(value).trim() !== 'Unknown') return value;
  }
  return '';
}

function addonResultForMatch(match = {}) {
  const scoreboard = match && match.addonScoreboard && typeof match.addonScoreboard === 'object' ? match.addonScoreboard : {};
  const scalar = scoreboard.rawFields && scoreboard.rawFields.scalarFields && typeof scoreboard.rawFields.scalarFields === 'object' ? scoreboard.rawFields.scalarFields : {};
  const explicit = normalizedResultValue(firstNonEmptyValue(
    match.addonResult,
    match.addonScoreboardResult,
    scoreboard.result,
    scoreboard.winnerResult,
    scoreboard.outcome,
    scalar.result,
    scalar.winnerResult,
    scalar.outcome
  ));
  if (explicit) return explicit;
  const winner = firstNonEmptyValue(scoreboard.winnerTeam, scoreboard.winner, scoreboard.winnerRaw, scalar.winnerTeam, scalar.winningTeam, scalar.winner);
  const playerTeam = firstNonEmptyValue(scoreboard.playerTeam, scalar.playerTeam, match.ownTeam);
  if (winner !== '' && playerTeam !== '') return String(winner) === String(playerTeam) ? 'Win' : 'Loss';
  return normalizedResultValue(match && match.result);
}

function combatLogResultForMatch(match = {}) {
  if (!match || typeof match !== 'object') return null;
  const sources = Array.isArray(match.dataSources) ? match.dataSources.map((source) => String(source || '')) : [];
  const hasCombatLog = Boolean(match.createdFromRealLog || match.parserVersion || match.isBracketMatch || sources.some((source) => /combat|log|tail/i.test(source)));
  if (!hasCombatLog) return null;
  const ownTeam = firstNonEmptyValue(match.ownTeam, match.combatLogOwnTeam, match.playerTeam);
  const winnerTeam = firstNonEmptyValue(match.winnerTeam, match.combatLogWinnerTeam, match.winner);
  if (ownTeam === '' || winnerTeam === '') return null;
  const result = String(winnerTeam) === String(ownTeam) ? 'Win' : 'Loss';
  return {
    result,
    ownTeam: String(ownTeam),
    winnerTeam: String(winnerTeam),
    source: firstNonEmptyValue(match.winnerTeamSource, match.combatLogWinnerTeamSource, match.resultSource, 'combat-log') || 'combat-log'
  };
}

function markResultConflict(match = {}, combatLog, addonResult, addonMatch = {}) {
  if (!combatLog || !addonResult || combatLog.result === addonResult) {
    if (match.resultConflict && match.resultConflict.combatLogResult === match.resultConflict.addonResult) delete match.resultConflict;
    if (!match.resultConflict) delete match.resultConflictNeedsReview;
    return match;
  }
  match.resultConflictNeedsReview = true;
  match.resultConflict = {
    type: 'result-source-conflict',
    action: 'kept-combat-log-result',
    combatLogResult: combatLog.result,
    addonResult,
    combatLogOwnTeam: combatLog.ownTeam,
    combatLogWinnerTeam: combatLog.winnerTeam,
    combatLogWinnerTeamSource: combatLog.source,
    addonMatchId: addonMatch && addonMatch.id || '',
    addonCapturedAt: addonMatch && (addonMatch.capturedAt || addonMatch.endIso || '') || '',
    reviewed: false,
    detectedAt: new Date().toISOString()
  };
  match.warning = match.warning || 'Result sources disagree. Combat log result was kept.';
  return match;
}

function applyResultAuthorityAfterAddonMerge(merged = {}, addonMatch = {}) {
  const addonResult = addonResultForMatch(addonMatch) || addonResultForMatch(merged);
  if (addonResult) merged.addonResult = addonResult;
  const combatLog = combatLogResultForMatch(merged);
  if (combatLog) {
    merged.combatLogResult = combatLog.result;
    merged.combatLogOwnTeam = combatLog.ownTeam;
    merged.combatLogWinnerTeam = combatLog.winnerTeam;
    merged.combatLogWinnerTeamSource = combatLog.source;
    merged.result = combatLog.result;
    merged.resultSource = 'combatLog';
    merged.resultAuthority = 'combatLog';
    markResultConflict(merged, combatLog, addonResult, addonMatch);
    return merged;
  }
  if (addonResult) {
    merged.result = addonResult;
    merged.resultSource = merged.resultSource || 'addonScoreboard';
    merged.resultAuthority = merged.resultAuthority || 'addonScoreboard';
  }
  return merged;
}

function parseLocalDateTimeAsUtcMs(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return 0;
  const normalized = raw.includes('T') ? raw : raw.replace(' ', 'T');
  const withSeconds = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(normalized) ? `${normalized}:00` : normalized;
  const ms = Date.parse(/(?:Z|[+-]\d{2}:?\d{2})$/i.test(withSeconds) ? withSeconds : `${withSeconds}Z`);
  return Number.isFinite(ms) ? ms : 0;
}

function addonLocalTimeCandidatesMs(match = {}) {
  const scoreboard = match && match.addonScoreboard && typeof match.addonScoreboard === 'object' ? match.addonScoreboard : {};
  const rawFields = scoreboard.rawFields && scoreboard.rawFields.scalarFields && typeof scoreboard.rawFields.scalarFields === 'object' ? scoreboard.rawFields.scalarFields : {};
  return [
    scoreboard.capturedAtLocal,
    scoreboard.capturedAtLocalText,
    rawFields.capturedAtLocal,
    rawFields.capturedAtLocalText,
    rawFields.matchEndTimeLocal,
    rawFields.matchStartTimeLocal
  ].map(parseLocalDateTimeAsUtcMs).filter(Boolean);
}

function matchTimeCandidatesMs(match = {}) {
  return [
    Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0),
    Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0),
    match.capturedAt ? Date.parse(match.capturedAt) : 0,
    Number(match.soloShuffleSessionStartMs) || 0,
    Number(match.soloShuffleSessionEndMs) || 0,
    ...addonLocalTimeCandidatesMs(match)
  ].map((value) => Number(value) || 0).filter((value) => Number.isFinite(value) && value > 1000000000000);
}

function bestTimeDistanceMs(a = {}, b = {}) {
  const aTimes = matchTimeCandidatesMs(a);
  const bTimes = matchTimeCandidatesMs(b);
  const distances = [];
  for (const aTime of aTimes) for (const bTime of bTimes) distances.push(Math.abs(aTime - bTime));
  return distances.length ? Math.min(...distances) : Infinity;
}

function addonMatchScore(existing, addonMatch) {
  if (!existing || !addonMatch) return 0;
  let score = 0;
  const existingTime = existing.endIso ? Date.parse(existing.endIso) : (existing.startIso ? Date.parse(existing.startIso) : Number(existing.endMs || existing.startMs || 0));
  const addonTime = addonMatch.capturedAt ? Date.parse(addonMatch.capturedAt) : Number(addonMatch.startMs || 0);
  if (existingTime && addonTime) {
    const diff = Math.abs(existingTime - addonTime);
    if (diff <= 20 * 60 * 1000) score += 50;
    else if (diff <= 60 * 60 * 1000) score += 25;
    else if (new Date(existingTime).toDateString() === new Date(addonTime).toDateString()) score += 10;
  }
  const bestDistance = bestTimeDistanceMs(existing, addonMatch);
  if (Number.isFinite(bestDistance)) {
    if (bestDistance <= 20 * 60 * 1000) score += 45;
    else if (bestDistance <= 60 * 60 * 1000) score += 20;
  }
  const existingSolo = isSoloShuffleLike(existing);
  const addonSolo = isSoloShuffleLike(addonMatch);
  if (existingSolo !== addonSolo) return 0;
  const existingBracket = cleanBracketName(existing.matchType || existing.bracket || '');
  const addonBracket = cleanBracketName(addonMatch.matchType || addonMatch.bracket || '');
  if (existingBracket && addonBracket && existingBracket !== addonBracket) {
    const bothArenaSizes = ['2v2', '3v3'].includes(existingBracket) && ['2v2', '3v3'].includes(addonBracket);
    if (!bothArenaSizes) return 0;
  }
  if (existingSolo && addonSolo) {
    if (existing.isSoloShuffleLobby) score += 90;
    if (existing.isSoloShuffleRoundChild) score -= 35;
    if (existing.createdFromAddon && !existing.createdFromRealLog) score -= 20;
  }
  if (existing.map && addonMatch.map && String(existing.map).toLowerCase() === String(addonMatch.map).toLowerCase()) score += 20;
  if (cleanBracketName(existing.matchType || existing.bracket) === cleanBracketName(addonMatch.matchType || addonMatch.bracket)) score += 10;
  if (shortNameKey(existing.alt) && shortNameKey(existing.alt) === shortNameKey(addonMatch.alt)) score += 15;
  const overlap = namesOverlapScore(existing.participants || [...(existing.myComp || []), ...(existing.enemyComp || [])], addonMatch.participants || []);
  score += Math.min(35, overlap * 7);
  return score;
}


function isArenaBracket(value = '') {
  const bracket = cleanBracketName(value);
  return bracket === '2v2' || bracket === '3v3' || bracket === 'Skirmish' || bracket === 'Solo Shuffle';
}

function expectedArenaSize(value = '') {
  const bracket = cleanBracketName(value);
  if (bracket === '2v2') return 2;
  if (bracket === '3v3' || bracket === 'Skirmish' || bracket === 'Solo Shuffle') return 3;
  return 0;
}

function matchHasAddonSnapshot(existing, addonMatch, addonKey) {
  if (!existing || !addonMatch) return false;
  if (existing.id && addonMatch.id && existing.id === addonMatch.id) return true;
  if (addonKey && existing.addonDedupeKey && existing.addonDedupeKey === addonKey) return true;
  if (addonKey && existing.rawFingerprint && existing.rawFingerprint === addonKey) return true;
  if (addonKey && existing.addonScoreboard && existing.addonScoreboard.dedupeKey === addonKey) return true;
  if (addonKey && Array.isArray(existing.linkedAddonFingerprints) && existing.linkedAddonFingerprints.includes(addonKey)) return true;
  if (existing.rawFingerprint && addonMatch.rawFingerprint && existing.rawFingerprint === addonMatch.rawFingerprint) return true;
  return false;
}

function mergeAddonScoreboardIntoMatch(existing, addonMatch, confidence = 'medium') {
  const base = { ...(existing || {}) };
  const addonKey = addonMatch && (addonMatch.addonDedupeKey || addonMatch.rawFingerprint || addonMatch.id || matchDedupeKey(addonMatch));
  const mergedType = strongerMatchType(base.matchType || base.bracket, addonMatch.matchType || addonMatch.bracket);
  const mergedBracket = strongerMatchType(base.bracket || base.matchType, addonMatch.bracket || addonMatch.matchType);
  const arenaMatch = isArenaBracket(mergedType) || isArenaBracket(mergedBracket);
  const arenaExpected = expectedArenaSize(mergedType || mergedBracket);
  const merged = {
    ...base,
    map: base.map && base.map !== 'Unknown map' ? base.map : addonMatch.map,
    matchType: mergedType,
    bracket: mergedBracket,
    subzone: base.subzone || addonMatch.subzone || '',
    instanceType: base.instanceType || addonMatch.instanceType || '',
    alt: base.alt && base.alt !== 'Unknown Player' ? base.alt : addonMatch.alt,
    participants: uniqueList([...(base.participants || []), ...(addonMatch.participants || [])]),
    classByName: { ...(addonMatch.classByName || {}), ...(base.classByName || {}) },
    specByName: { ...(addonMatch.specByName || {}), ...(base.specByName || {}) },
    scoreboardPlayers: addonMatch.scoreboardPlayers || [],
    addonScoreboard: addonMatch.addonScoreboard || {},
    addonImportedAt: new Date().toISOString(),
    addonImportConfidence: confidence,
    linkedAddonFingerprints: uniqueList([...(base.linkedAddonFingerprints || []), addonKey]),
    scoreboardSourceMatchId: addonMatch.id || base.scoreboardSourceMatchId || '',
    scoreboardLinkedAt: new Date().toISOString(),
    scoreboardTeamCounts: addonMatch.scoreboardTeamCounts || base.scoreboardTeamCounts || {},
    expectedTeamSize: arenaExpected || addonMatch.expectedTeamSize || base.expectedTeamSize || 0,
    actualTeamSize: addonMatch.actualTeamSize || base.actualTeamSize || 0,
    isRatedBattleground: arenaMatch ? false : Boolean(base.isRatedBattleground || addonMatch.isRatedBattleground),
    isBattleground: arenaMatch ? false : Boolean(base.isBattleground || addonMatch.isBattleground),
    dataSources: uniqueList([...(base.dataSources || []), 'addonScoreboard'])
  };
  // Result authority: a confident combat-log own-team + winner-team result wins.
  // PvPHelper can fill missing results, but it should not silently flip a combat-log Loss/Win.
  applyResultAuthorityAfterAddonMerge(merged, addonMatch);
  if ((!base.myComp || !base.myComp.length) && addonMatch.myComp && addonMatch.myComp.length) merged.myComp = addonMatch.myComp;
  if ((!base.enemyComp || !base.enemyComp.length) && addonMatch.enemyComp && addonMatch.enemyComp.length) {
    merged.enemyComp = addonMatch.enemyComp;
    merged.enemies = addonMatch.enemyComp;
  }
  if ((!base.metrics || !Object.keys(base.metrics || {}).length) && addonMatch.metrics) merged.metrics = addonMatch.metrics;
  return normalizeMatchDataSources(merged);
}


function previewPvPHelperImportIntoState(state, parsed, filePath) {
  const matches = parsed.matches || [];
  let merged = 0;
  let created = 0;
  let skipped = 0;
  const previewRows = [];
  const workingMatches = (state.matches || []).map(normalizeMatchDataSources);
  const deleted = new Set(state.deletedMatchIds || []);
  const seenAddonKeys = new Set();

  for (const addonMatch of matches) {
    if (!addonMatch) continue;
    const addonKey = addonMatch.addonDedupeKey || addonMatch.rawFingerprint || addonMatch.id || matchDedupeKey(addonMatch);
    let action = 'create';
    let confidence = 'addon-only';
    let best = null;
    let bestScore = 0;

    if (deleted.has(addonMatch.id) || deleted.has(addonMatch.rawFingerprint) || (addonKey && deleted.has(addonKey)) || (addonKey && seenAddonKeys.has(addonKey))) {
      skipped += 1;
      action = 'skip';
      confidence = 'skipped';
    } else if (workingMatches.some((existing) => matchHasAddonSnapshot(existing, addonMatch, addonKey))) {
      skipped += 1;
      action = 'skip';
      confidence = 'duplicate';
    } else {
      for (const existing of workingMatches) {
        const existingLinkedAddon = existing && Array.isArray(existing.linkedAddonFingerprints) && addonKey && existing.linkedAddonFingerprints.includes(addonKey);
        const exactAddonSnapshot = existing && addonMatch && (existing.id === addonMatch.id || (existing.rawFingerprint && existing.rawFingerprint === addonMatch.rawFingerprint) || existingLinkedAddon);
        const existingIsAddonOnly = Boolean(existing && existing.createdFromAddon && !existing.createdFromRealLog);
        if (existingIsAddonOnly && !exactAddonSnapshot) continue;
        const score = exactAddonSnapshot ? 100 : addonMatchScore(existing, addonMatch);
        if (score > bestScore) { bestScore = score; best = existing; }
      }
      if (best && bestScore >= 45) {
        merged += 1;
        action = 'merge';
        confidence = bestScore >= 75 ? 'high' : 'medium';
      } else if (!workingMatches.some((existing) => matchDedupeKey(existing) === matchDedupeKey(addonMatch))) {
        created += 1;
        action = 'create';
        confidence = 'addon-only';
        workingMatches.unshift(normalizeMatchDataSources(addonMatch));
      } else {
        skipped += 1;
        action = 'skip';
        confidence = 'duplicate';
      }
    }

    if (addonKey) seenAddonKeys.add(addonKey);
    previewRows.push({
      map: addonMatch.map || 'Unknown map',
      bracket: addonMatch.bracket || addonMatch.matchType || 'PvP Match',
      capturedAt: addonMatch.capturedAt || addonMatch.startIso || '',
      playerCount: Array.isArray(addonMatch.scoreboardPlayers) ? addonMatch.scoreboardPlayers.length : 0,
      result: addonMatch.result || 'Parsed',
      action,
      confidence,
      matchedMap: best && best.map ? best.map : '',
      matchedAt: best && (best.endIso || best.startIso) ? (best.endIso || best.startIso) : '',
      score: bestScore
    });
  }

  return {
    ok: true,
    filePath,
    parsed: matches.length,
    matchHistoryCount: parsed.matchHistoryCount || matches.length,
    scoreboardSnapshots: matches.length,
    characterSnapshots: (parsed.snapshots || []).length,
    merged,
    created,
    skipped,
    previewRows: previewRows.slice(0, 40),
    extraRows: Math.max(0, previewRows.length - 40),
    primaryPathUsed: parsed.primaryPathUsed || '',
    matchHistorySchemaVersion: parsed.addonStatus && parsed.addonStatus.matchHistorySchemaVersion ? parsed.addonStatus.matchHistorySchemaVersion : 0,
    matchHistoryMetaFound: Boolean(parsed.addonStatus && parsed.addonStatus.matchHistoryMetaFound),
    skippedMalformedSnapshots: parsed.skippedMalformedSnapshots || 0,
    skippedEmptySnapshots: parsed.skippedEmptySnapshots || 0
  };
}

function importPvPHelperDataIntoState(state, parsed, filePath) {
  const matches = parsed.matches || [];
  let merged = 0;
  let created = 0;
  let skipped = 0;
  state.matches = (state.matches || []).map(normalizeMatchDataSources);
  for (const addonMatch of matches) {
    if (!addonMatch) continue;
    const addonKey = addonMatch.addonDedupeKey || addonMatch.rawFingerprint || addonMatch.id || matchDedupeKey(addonMatch);
    if ((state.deletedMatchIds || []).includes(addonMatch.id) || (state.deletedMatchIds || []).includes(addonMatch.rawFingerprint) || (addonKey && (state.deletedMatchIds || []).includes(addonKey))) {
      skipped += 1;
      continue;
    }
    if ((state.matches || []).some((existing) => matchHasAddonSnapshot(existing, addonMatch, addonKey))) {
      skipped += 1;
      continue;
    }
    let best = null;
    let bestScore = 0;
    for (const existing of state.matches || []) {
      const existingLinkedAddon = existing && Array.isArray(existing.linkedAddonFingerprints) && addonKey && existing.linkedAddonFingerprints.includes(addonKey);
      const exactAddonSnapshot = existing && addonMatch && (existing.id === addonMatch.id || (existing.rawFingerprint && existing.rawFingerprint === addonMatch.rawFingerprint) || existingLinkedAddon);
      const existingIsAddonOnly = Boolean(existing && existing.createdFromAddon && !existing.createdFromRealLog);
      if (existingIsAddonOnly && !exactAddonSnapshot) continue;
      const score = exactAddonSnapshot ? 100 : addonMatchScore(existing, addonMatch);
      if (score > bestScore) { bestScore = score; best = existing; }
    }
    if (best && bestScore >= 45) {
      const confidence = bestScore >= 75 ? 'high' : 'medium';
      state.matches = state.matches.map((match) => match && match.id === best.id ? mergeAddonScoreboardIntoMatch(match, addonMatch, confidence) : match);
      merged += 1;
    } else if (!matchExistsInState(state, addonMatch)) {
      state.matches.unshift(normalizeMatchDataSources(addonMatch));
      created += 1;
    } else {
      skipped += 1;
    }
  }
  if (parsed.snapshots && parsed.snapshots.length) {
    const existing = new Set((state.characterSnapshots || []).map((item) => characterSnapshotDedupeKey(item)));
    const unique = parsed.snapshots.filter((item) => item && !existing.has(characterSnapshotDedupeKey(item)));
    state.characterSnapshots = dedupeCharacterSnapshots([...unique, ...(state.characterSnapshots || [])]);
  } else {
    state.characterSnapshots = dedupeCharacterSnapshots(state.characterSnapshots || []);
  }
  resolveStateMatchLibrary(state, 'pvphelper-scoreboard-import', { autoLink: true });
  state.addonImports = state.addonImports || [];
  state.addonImports.unshift({
    filePath,
    importedAt: new Date().toISOString(),
    parsedCount: matches.length,
    matchHistoryCount: parsed.matchHistoryCount || matches.length,
    mergedCount: merged,
    createdCount: created,
    skippedCount: skipped,
    snapshotCount: (parsed.snapshots || []).length,
    primaryPathUsed: parsed.primaryPathUsed || '',
    matchHistorySchemaVersion: parsed.addonStatus && parsed.addonStatus.matchHistorySchemaVersion ? parsed.addonStatus.matchHistorySchemaVersion : 0,
    matchHistoryMetaFound: Boolean(parsed.addonStatus && parsed.addonStatus.matchHistoryMetaFound),
    skippedMalformedSnapshots: parsed.skippedMalformedSnapshots || 0,
    skippedEmptySnapshots: parsed.skippedEmptySnapshots || 0
  });
  state.importedFiles = state.importedFiles || [];
  state.importedFiles.unshift({
    filePath,
    importedAt: new Date().toISOString(),
    state: matches.length ? `Imported ${merged + created} addon scoreboard snapshot${merged + created === 1 ? '' : 's'}` : 'No PvPHelper matchHistory found',
    parsedCount: matches.length,
    importedCount: merged + created,
    type: 'PvPHelper SavedVariables',
    hiddenFromCombatLogHistory: true
  });
  return { merged, created, skipped, parsed: matches.length, snapshots: (parsed.snapshots || []).length, skippedMalformedSnapshots: parsed.skippedMalformedSnapshots || 0, skippedEmptySnapshots: parsed.skippedEmptySnapshots || 0 };
}

  return {
    namesOverlapScore,
    shortNameKey,
    addonMatchScore,
    matchHasAddonSnapshot,
    mergeAddonScoreboardIntoMatch,
    previewPvPHelperImportIntoState,
    importPvPHelperDataIntoState
  };
}

module.exports = { createPvPHelperMergeTools };
