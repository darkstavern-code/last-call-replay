function createPvPHelperIpcTools(deps = {}) {
  const {
    ipcMain,
    dialog,
    fs,
    path,
    getMainWindow,
    readState,
    writeState,
    defaultSettings,
    ensureDir,
    safeExists,
    copyDirRecursive,
    buildPvPHelperInstallStatus,
    discoverPvPHelperSavedVariables,
    previewPvPHelperFilePath,
    importPvPHelperFileIntoState,
    parseCharacterSnapshotText,
    characterSnapshotDedupeKey,
    dedupeCharacterSnapshots,
    pvphFileMtimeMs
  } = deps;

  function mainWindow() {
    return typeof getMainWindow === 'function' ? getMainWindow() : null;
  }

  function registerPvPHelperIpcHandlers() {
    if (!ipcMain || typeof ipcMain.handle !== 'function') throw new Error('ipcMain.handle is required for PvPHelper IPC handlers.');

    ipcMain.handle('import-character-snapshot', async () => {
      // Legacy escape hatch for older standalone snapshot exports. The normal UX now maps
      // PvPHelper.lua once and syncs both scoreboard + character/rating data from there.
      const state = readState();
      const result = await dialog.showOpenDialog(mainWindow(), {
        title: 'Import legacy rating snapshot',
        properties: ['openFile'],
        filters: [{ name: 'Legacy character snapshots or PvPHelper.lua', extensions: ['json', 'txt', 'lua'] }, { name: 'All files', extensions: ['*'] }]
      });
      if (result.canceled || !result.filePaths[0]) return { ok: false, snapshots: state.characterSnapshots || [], imported: 0 };
      const filePath = result.filePaths[0];
      const raw = fs.readFileSync(filePath, 'utf8');

      if (/\bPvPHelperDB\s*=/.test(raw) || /\bmatchHistory\b/.test(raw)) {
        const preview = previewPvPHelperFilePath(state, filePath);
        return {
          ...preview,
          ok: preview.ok !== false,
          importedAs: 'pvphelper-preview',
          matches: state.matches || [],
          snapshots: state.characterSnapshots || [],
          characterSnapshots: state.characterSnapshots || [],
          addonImports: state.addonImports || [],
          importedFiles: state.importedFiles || [],
          filePath,
          sourceName: path.basename(filePath)
        };
      }

      const parsed = parseCharacterSnapshotText(raw, path.basename(filePath));
      const existing = new Set((state.characterSnapshots || []).map((item) => characterSnapshotDedupeKey(item)));
      const unique = parsed.filter((item) => item && !existing.has(characterSnapshotDedupeKey(item)));
      state.characterSnapshots = dedupeCharacterSnapshots([...unique, ...(state.characterSnapshots || [])]);
      writeState(state);
      return { ok: true, snapshots: state.characterSnapshots, characterSnapshots: state.characterSnapshots, imported: unique.length, parsed: parsed.length, filePath };
    });

    ipcMain.handle('get-pvphelper-addon-status', async () => {
      const state = readState();
      const status = buildPvPHelperInstallStatus(state.settings || {});
      state.settings = { ...defaultSettings(), ...(state.settings || {}), pvpHelperAddonInstallStatus: status };
      writeState(state);
      return { ok: true, status, settings: state.settings || {} };
    });

    ipcMain.handle('install-pvphelper-addon', async () => {
      const state = readState();
      const status = buildPvPHelperInstallStatus(state.settings || {});
      if (!status.wowRoot || !status.addonsDir) {
        return { ok: false, reason: status.reason || 'Choose your WoW Logs folder first so the app can find _retail_.', status };
      }
      if (!status.packageAvailable || !status.packageDir) {
        return { ok: false, reason: 'No local PvPHelper package was found. Put the unzipped PvPHelper folder in addon-packages\\PvPHelper, then click Recheck.', status };
      }
      try {
        ensureDir(status.addonsDir);
        if (safeExists(status.installedDir)) fs.rmSync(status.installedDir, { recursive: true, force: true });
        copyDirRecursive(status.packageDir, status.installedDir);
        const nextStatus = buildPvPHelperInstallStatus(state.settings || {});
        nextStatus.installedByApp = true;
        state.settings = { ...defaultSettings(), ...(state.settings || {}), pvpHelperAddonLastInstallAt: new Date().toISOString(), pvpHelperAddonInstallStatus: nextStatus };
        writeState(state);
        return { ok: true, status: nextStatus, settings: state.settings || {} };
      } catch (error) {
        return { ok: false, reason: error && error.message ? error.message : 'Could not install PvPHelper.', status };
      }
    });

    ipcMain.handle('preview-pvph-savedvariables', async () => {
      const state = readState();
      const discovery = discoverPvPHelperSavedVariables(state.settings || {});
      const result = await dialog.showOpenDialog(mainWindow(), {
        title: 'Choose PvPHelper SavedVariables folder',
        defaultPath: state.settings && state.settings.pvpHelperSavedVariablesPath ? path.dirname(state.settings.pvpHelperSavedVariablesPath) : (discovery.defaultPath || undefined),
        properties: ['openDirectory', 'createDirectory'],
        buttonLabel: 'Use this folder'
      });
      if (result.canceled || !result.filePaths[0]) {
        return { ok: false, cancelled: true, discovery, matches: state.matches || [], characterSnapshots: state.characterSnapshots || [], imported: 0 };
      }
      const preview = previewPvPHelperFilePath(state, result.filePaths[0]);
      preview.discovery = discovery;
      return preview;
    });

    ipcMain.handle('get-pvph-savedvariables-discovery', async () => {
      const state = readState();
      const discovery = discoverPvPHelperSavedVariables(state.settings || {});
      state.settings = { ...defaultSettings(), ...(state.settings || {}), pvpHelperSavedVariablesDiscovery: discovery };
      writeState(state);
      return { ok: true, discovery, settings: state.settings || {} };
    });

    ipcMain.handle('auto-preview-pvph-savedvariables', async () => {
      const state = readState();
      const discovery = discoverPvPHelperSavedVariables(state.settings || {});
      if (!discovery.best || !discovery.best.filePath) {
        state.settings = { ...defaultSettings(), ...(state.settings || {}), pvpHelperSavedVariablesDiscovery: discovery };
        writeState(state);
        return { ok: false, reason: discovery.reason, discovery, matches: state.matches || [], characterSnapshots: state.characterSnapshots || [], imported: 0 };
      }
      const preview = previewPvPHelperFilePath(state, discovery.best.filePath);
      preview.discovery = discovery;
      preview.autoFound = true;
      return preview;
    });

    ipcMain.handle('apply-pvph-savedvariables-preview', async (_event, payload = {}) => {
      const state = readState();
      const filePath = payload && payload.filePath ? String(payload.filePath) : '';
      return importPvPHelperFileIntoState(state, filePath, { autoSync: payload.autoSync !== false });
    });

    ipcMain.handle('sync-mapped-pvph-savedvariables', async (_event, payload = {}) => {
      const state = readState();
      const filePath = state.settings && state.settings.pvpHelperSavedVariablesPath ? String(state.settings.pvpHelperSavedVariablesPath) : '';
      const force = Boolean(payload && payload.force);
      if (!filePath) return { ok: false, reason: 'Map PvPHelper.lua first.', matches: state.matches || [], characterSnapshots: state.characterSnapshots || [], addonImports: state.addonImports || [], settings: state.settings || {} };
      if (!fs.existsSync(filePath)) {
        state.settings = { ...defaultSettings(), ...(state.settings || {}), pvpHelperFileExists: false, pvpHelperStatus: { addonFound: false, missingFile: true, reason: 'Mapped PvPHelper.lua missing' } };
        writeState(state);
        return { ok: false, reason: 'Addon not found. The mapped PvPHelper.lua SavedVariables file was not found. Log into WoW with PvPHelper enabled, then map the file again if its path changed.', matches: state.matches || [], characterSnapshots: state.characterSnapshots || [], addonImports: state.addonImports || [], settings: state.settings || {} };
      }
      const mtime = pvphFileMtimeMs(filePath);
      if (!force && mtime && Number(state.settings.pvpHelperLastSyncMtimeMs || 0) >= mtime) {
        return {
          ok: true,
          upToDate: true,
          filePath,
          mappedPath: filePath,
          imported: 0,
          parsed: 0,
          merged: 0,
          created: 0,
          skipped: 0,
          ratingImported: 0,
          matches: state.matches || [],
          characterSnapshots: state.characterSnapshots || [],
          addonImports: state.addonImports || [],
          importedFiles: state.importedFiles || [],
          settings: state.settings || {}
        };
      }
      return importPvPHelperFileIntoState(state, filePath, { autoSync: state.settings.pvpHelperAutoSync !== false });
    });

    ipcMain.handle('clear-pvph-savedvariables-mapping', async () => {
      const state = readState();
      state.settings = { ...defaultSettings(), ...(state.settings || {}), pvpHelperSavedVariablesPath: '', pvpHelperLastSyncMtimeMs: 0, pvpHelperLastSyncAt: '', pvpHelperFileExists: null, pvpHelperStatus: {}, pvpHelperLastScoreboardCount: 0, pvpHelperLastPendingCount: 0, pvpHelperLastMergedCount: 0, pvpHelperLastRatingSnapshotCount: 0 };
      writeState(state);
      return { ok: true, settings: state.settings || {} };
    });

    ipcMain.handle('import-pvph-savedvariables', async () => {
      // Backward-compatible alias used by older renderer buttons.
      const state = readState();
      const discovery = discoverPvPHelperSavedVariables(state.settings || {});
      const result = await dialog.showOpenDialog(mainWindow(), {
        title: 'Choose PvPHelper SavedVariables folder',
        defaultPath: state.settings && state.settings.pvpHelperSavedVariablesPath ? path.dirname(state.settings.pvpHelperSavedVariablesPath) : (discovery.defaultPath || undefined),
        properties: ['openDirectory', 'createDirectory'],
        buttonLabel: 'Use this folder'
      });
      if (result.canceled || !result.filePaths[0]) {
        return { ok: false, matches: state.matches || [], characterSnapshots: state.characterSnapshots || [], imported: 0 };
      }
      return importPvPHelperFileIntoState(state, result.filePaths[0], { autoSync: true });
    });

    ipcMain.handle('delete-character-snapshot', async (_event, payload) => {
      const state = readState();
      const snapshotId = payload && payload.snapshotId ? String(payload.snapshotId) : '';
      if (!snapshotId) return { ok: false, snapshots: state.characterSnapshots || [] };
      state.characterSnapshots = dedupeCharacterSnapshots((state.characterSnapshots || []).filter((item) => item && item.id !== snapshotId));
      writeState(state);
      return { ok: true, snapshots: state.characterSnapshots };
    });
  }

  return { registerPvPHelperIpcHandlers };
}

module.exports = { createPvPHelperIpcTools };
