'use strict';

function createPvPHelperInputTools(deps = {}) {
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const zlib = deps.zlib || require('zlib');

function findZipEndOfCentralDirectory(buffer) {
  if (!Buffer.isBuffer(buffer) || buffer.length < 22) return -1;
  const min = Math.max(0, buffer.length - 0xffff - 22);
  for (let i = buffer.length - 22; i >= min; i -= 1) {
    if (buffer.readUInt32LE(i) === 0x06054b50) return i;
  }
  return -1;
}

function extractTextFilesFromZipBuffer(buffer) {
  const out = [];
  if (!Buffer.isBuffer(buffer) || buffer.length < 22) return out;
  const eocd = findZipEndOfCentralDirectory(buffer);
  if (eocd < 0 || eocd + 22 > buffer.length) return out;
  const entryCount = buffer.readUInt16LE(eocd + 10);
  const centralOffset = buffer.readUInt32LE(eocd + 16);
  let offset = centralOffset;
  for (let i = 0; i < entryCount && offset + 46 <= buffer.length; i += 1) {
    if (buffer.readUInt32LE(offset) !== 0x02014b50) break;
    const compression = buffer.readUInt16LE(offset + 10);
    const compressedSize = buffer.readUInt32LE(offset + 20);
    const fileNameLength = buffer.readUInt16LE(offset + 28);
    const extraLength = buffer.readUInt16LE(offset + 30);
    const commentLength = buffer.readUInt16LE(offset + 32);
    const localHeaderOffset = buffer.readUInt32LE(offset + 42);
    const nameStart = offset + 46;
    const nameEnd = nameStart + fileNameLength;
    const fileName = buffer.slice(nameStart, nameEnd).toString('utf8');
    offset = nameEnd + extraLength + commentLength;

    if (!fileName || fileName.endsWith('/')) continue;
    if (!/\.(lua|txt|json)$/i.test(fileName) && !/PvPHelper/i.test(fileName)) continue;
    if (localHeaderOffset + 30 > buffer.length || buffer.readUInt32LE(localHeaderOffset) !== 0x04034b50) continue;
    const localNameLength = buffer.readUInt16LE(localHeaderOffset + 26);
    const localExtraLength = buffer.readUInt16LE(localHeaderOffset + 28);
    const dataStart = localHeaderOffset + 30 + localNameLength + localExtraLength;
    const dataEnd = dataStart + compressedSize;
    if (dataStart < 0 || dataEnd > buffer.length || dataEnd < dataStart) continue;
    const compressed = buffer.slice(dataStart, dataEnd);
    let text = '';
    try {
      if (compression === 0) text = compressed.toString('utf8');
      else if (compression === 8) text = zlib.inflateRawSync(compressed).toString('utf8');
      else continue;
    } catch (_error) {
      continue;
    }
    if (text) out.push({ name: fileName, text });
  }
  return out;
}

function readPvPHelperInputFile(filePath) {
  const ext = path.extname(String(filePath || '')).toLowerCase();
  const buffer = fs.readFileSync(filePath);
  if (ext !== '.zip') return { raw: buffer.toString('utf8'), sourceName: path.basename(filePath), archiveEntry: '' };

  const candidates = extractTextFilesFromZipBuffer(buffer);
  const savedVariablesEntry = candidates.find((item) => /(^|[\/])PvPHelper\.lua$/i.test(item.name) && /PvPHelperDB\s*=/.test(item.text));
  const looksLikeAddonPackage = candidates.some((item) => /(^|[\/])PvPHelper\.toc$/i.test(item.name))
    || candidates.some((item) => /(^|[\/])PvPHelper[\/](Core|Logging)\.lua$/i.test(item.name));
  const preferred = savedVariablesEntry || (!looksLikeAddonPackage ? candidates.find((item) => /PvPHelperDB\s*=/.test(item.text)) : null);

  if (!preferred) {
    return {
      raw: '',
      sourceName: path.basename(filePath),
      archiveEntry: '',
      zipCandidateCount: candidates.length,
      looksLikeAddonPackage,
      reason: looksLikeAddonPackage
        ? 'That zip looks like the PvPHelper addon install package, not the SavedVariables file. Map WTF/Account/<AccountName>/SavedVariables/PvPHelper.lua instead.'
        : 'No PvPHelperDB data was found. Choose the SavedVariables file named PvPHelper.lua.'
    };
  }

  return {
    raw: preferred.text,
    sourceName: `${path.basename(filePath)} → ${preferred.name}`,
    archiveEntry: preferred.name,
    zipCandidateCount: candidates.length
  };
}

  return {
    findZipEndOfCentralDirectory,
    extractTextFilesFromZipBuffer,
    readPvPHelperInputFile
  };
}

module.exports = { createPvPHelperInputTools };
