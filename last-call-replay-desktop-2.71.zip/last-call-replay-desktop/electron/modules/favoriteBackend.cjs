'use strict';

function createFavoriteBackendTools(deps = {}) {
  const ipcMain = deps.ipcMain;
  const crypto = deps.crypto || require('crypto');
  const readState = deps.readState;
  const writeState = deps.writeState;
  const sanitizeMatchForStorage = deps.sanitizeMatchForStorage || ((match) => match);
  const compactRecentMatchesForResponse = deps.compactRecentMatchesForResponse || ((state) => state.matches || []);

  if (!ipcMain || typeof ipcMain.handle !== 'function') throw new Error('favoriteBackend requires ipcMain.');
  if (typeof readState !== 'function') throw new Error('favoriteBackend requires readState.');
  if (typeof writeState !== 'function') throw new Error('favoriteBackend requires writeState.');

  function safeFolders(state) {
    return Array.isArray(state.favoriteFolders) ? state.favoriteFolders.filter(Boolean) : [];
  }

  function folderNameExists(state, name) {
    const normalized = String(name || '').toLowerCase();
    return safeFolders(state).find((folder) => folder && String(folder.name || '').toLowerCase() === normalized) || null;
  }

  function registerIpcHandlers() {
    ipcMain.handle('set-match-favorite', async (_event, payload) => {
      const state = readState();
      const matchId = payload && payload.matchId ? String(payload.matchId) : '';
      const favorite = Boolean(payload && payload.favorite);
      if (!matchId) return { ok: false, reason: 'Match not found' };
      let found = false;
      state.matches = (state.matches || []).map((match) => {
        if (!match || match.id !== matchId) return match;
        found = true;
        return { ...match, favorite };
      });
      if (!found) return { ok: false, reason: 'Match not found' };
      writeState(state);
      const changedMatch = (state.matches || []).find((match) => match && match.id === matchId) || null;
      return { ok: true, changedMatches: changedMatch ? [sanitizeMatchForStorage({ ...changedMatch })] : [], favoriteFolders: state.favoriteFolders || [] };
    });

    ipcMain.handle('create-favorite-folder', async (_event, payload) => {
      const state = readState();
      const name = String((payload && payload.name) || '').trim().slice(0, 48);
      if (!name) return { ok: false, reason: 'Folder name required.', favoriteFolders: state.favoriteFolders || [] };
      const existing = folderNameExists(state, name);
      if (existing) return { ok: true, folder: existing, favoriteFolders: state.favoriteFolders || [] };
      const folder = { id: `fav_${Date.now()}_${crypto.randomBytes(3).toString('hex')}`, name, createdAt: new Date().toISOString() };
      state.favoriteFolders = [...safeFolders(state), folder];
      writeState(state);
      return { ok: true, folder, favoriteFolders: state.favoriteFolders };
    });

    ipcMain.handle('delete-favorite-folder', async (_event, payload) => {
      const state = readState();
      const folderId = payload && payload.folderId ? String(payload.folderId) : '';
      if (!folderId) return { ok: false, reason: 'Folder not found.', matches: state.matches || [], favoriteFolders: state.favoriteFolders || [] };
      const folders = safeFolders(state);
      const folder = folders.find((item) => item && item.id === folderId);
      if (!folder) return { ok: false, reason: 'Favorite folder not found.', matches: state.matches || [], favoriteFolders: folders };
      const usedCount = (state.matches || []).filter((match) => match && (match.favorite || match.favorited) && String(match.favoriteFolderId || '') === folderId).length;
      if (usedCount > 0) {
        return {
          ok: false,
          reason: `Move or remove ${usedCount} favorite${usedCount === 1 ? '' : 's'} from this folder before deleting it.`,
          matches: state.matches || [],
          favoriteFolders: folders
        };
      }
      state.favoriteFolders = folders.filter((item) => item && item.id !== folderId);
      writeState(state);
      return { ok: true, changedMatches: compactRecentMatchesForResponse(state, 80), favoriteFolders: state.favoriteFolders || [] };
    });

    ipcMain.handle('update-favorite-meta', async (_event, payload) => {
      const state = readState();
      const matchId = payload && payload.matchId ? String(payload.matchId) : '';
      if (!matchId) return { ok: false, reason: 'Match not found', matches: state.matches || [] };
      const hasFavorite = Object.prototype.hasOwnProperty.call(payload || {}, 'favorite');
      const hasFolder = Object.prototype.hasOwnProperty.call(payload || {}, 'folderId');
      const hasComment = Object.prototype.hasOwnProperty.call(payload || {}, 'comment');
      const folderId = hasFolder ? String(payload.folderId || '') : undefined;
      if (folderId && !safeFolders(state).some((folder) => folder && folder.id === folderId)) {
        return { ok: false, reason: 'Favorite folder not found.', matches: state.matches || [], favoriteFolders: state.favoriteFolders || [] };
      }
      let found = false;
      state.matches = (state.matches || []).map((match) => {
        if (!match || match.id !== matchId) return match;
        found = true;
        const next = { ...match };
        if (hasFavorite) next.favorite = Boolean(payload.favorite);
        if (hasFolder) next.favoriteFolderId = folderId;
        if (hasComment) {
          next.favoriteComment = String(payload.comment || '').slice(0, 180);
          next.favoriteCommentUpdatedAt = new Date().toISOString();
        }
        if (!next.favorite) {
          delete next.favoriteFolderId;
          delete next.favoriteComment;
          delete next.favoriteCommentUpdatedAt;
        }
        return next;
      });
      if (!found) return { ok: false, reason: 'Match not found.', matches: state.matches || [], favoriteFolders: state.favoriteFolders || [] };
      writeState(state);
      return { ok: true, changedMatches: compactRecentMatchesForResponse(state, 80), favoriteFolders: state.favoriteFolders || [] };
    });
  }

  return { registerIpcHandlers };
}

module.exports = { createFavoriteBackendTools };
