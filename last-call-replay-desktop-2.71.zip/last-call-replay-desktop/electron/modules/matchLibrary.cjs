'use strict';

function createMatchLibraryTools(deps = {}) {
  const sanitizeMatchForStorage = typeof deps.sanitizeMatchForStorage === 'function'
    ? deps.sanitizeMatchForStorage
    : ((match) => (match && typeof match === 'object' ? { ...match } : match));
  const isSoloShuffleRoundChildMatch = typeof deps.isSoloShuffleRoundChildMatch === 'function'
    ? deps.isSoloShuffleRoundChildMatch
    : ((match) => Boolean(match && match.isSoloShuffleRoundChild));
  const isSoloShuffleLobbyMatch = typeof deps.isSoloShuffleLobbyMatch === 'function'
    ? deps.isSoloShuffleLobbyMatch
    : ((match) => Boolean(match && match.isSoloShuffleLobby));
  const uniqueList = typeof deps.uniqueList === 'function'
    ? deps.uniqueList
    : ((values = []) => Array.from(new Set((values || []).filter(Boolean).map((value) => String(value)))));

  function matchResponseTime(match = {}) {
    if (!match || typeof match !== 'object') return 0;
    const numeric = Number(match.startMs || match.gameStartMs || match.endMs || 0) || 0;
    if (numeric > 0) return numeric;
    const parsed = Date.parse(match.startIso || match.gameStartIso || match.endIso || match.capturedAt || match.date || '');
    return Number.isFinite(parsed) ? parsed : 0;
  }

  function sortedMatches(matches = []) {
    return (Array.isArray(matches) ? matches : [])
      .filter(Boolean)
      .slice()
      .sort((a, b) => matchResponseTime(b) - matchResponseTime(a));
  }

  function byIdMap(state = {}) {
    return new Map((Array.isArray(state.matches) ? state.matches : [])
      .filter((match) => match && match.id)
      .map((match) => [String(match.id), match]));
  }

  function findSoloShuffleLobbyForRound(state = {}, round = {}) {
    if (!round || typeof round !== 'object') return null;
    const rows = Array.isArray(state.matches) ? state.matches : [];
    const parentId = String(round.parentLobbyMatchId || '');
    if (parentId) {
      const direct = rows.find((match) => match && String(match.id || '') === parentId && isSoloShuffleLobbyMatch(match));
      if (direct) return direct;
    }

    const roundId = String(round.id || round.roundMatchId || '');
    if (roundId) {
      const byRoundId = rows.find((match) => isSoloShuffleLobbyMatch(match) && Array.isArray(match.soloRounds)
        && match.soloRounds.some((item) => item && String(item.roundMatchId || item.id || '') === roundId));
      if (byRoundId) return byRoundId;
    }

    const sessionKey = String(round.soloShuffleSessionKey || '');
    if (sessionKey) {
      const bySession = rows.find((match) => isSoloShuffleLobbyMatch(match) && String(match.soloShuffleSessionKey || '') === sessionKey);
      if (bySession) return bySession;
    }

    return null;
  }

  function visibleMatchForResponse(state = {}, match = {}) {
    if (!match || typeof match !== 'object') return null;
    if (isSoloShuffleRoundChildMatch(match) || match.hideFromMatchLibrary) return findSoloShuffleLobbyForRound(state, match);
    return match;
  }

  function compactRecentMatchesForResponse(state = {}, limit = 80) {
    const rows = sortedMatches(Array.isArray(state.matches) ? state.matches : [])
      .filter((match) => !isSoloShuffleRoundChildMatch(match) && !match.hideFromMatchLibrary);
    return rows
      .slice(0, Math.max(1, Number(limit || 80)))
      .map((match) => sanitizeMatchForStorage({ ...(match || {}) }));
  }

  function compactVisibleChangedMatchesForResponse(state = {}, changedMatches = [], limit = 80) {
    const rows = Array.isArray(state.matches) ? state.matches : [];
    const idMap = byIdMap(state);
    const selected = [];
    const seen = new Set();

    const add = (match) => {
      const visible = visibleMatchForResponse(state, match);
      if (!visible || !visible.id) return;
      const id = String(visible.id || '');
      if (!id || seen.has(id)) return;
      seen.add(id);
      selected.push(visible);
    };

    for (const changed of Array.isArray(changedMatches) ? changedMatches : []) {
      if (!changed) continue;
      const current = changed.id ? (idMap.get(String(changed.id)) || changed) : changed;
      add(current);
    }

    // When the only changed rows are hidden Solo Shuffle children, always include the
    // fresh lobby parent. This prevents startup/watch deltas from making the rounds
    // exist in state while the visible lobby is missing from Matches/Dashboard.
    if (!selected.length && rows.length) {
      return compactRecentMatchesForResponse(state, limit);
    }

    return sortedMatches(selected)
      .slice(0, Math.max(1, Number(limit || 80)))
      .map((match) => sanitizeMatchForStorage({ ...(match || {}) }));
  }

  function responseMatchIdsForChanged(state = {}, changedMatches = []) {
    return uniqueList(compactVisibleChangedMatchesForResponse(state, changedMatches, 200).map((match) => match && match.id));
  }

  return {
    matchResponseTime,
    compactRecentMatchesForResponse,
    compactVisibleChangedMatchesForResponse,
    responseMatchIdsForChanged
  };
}

module.exports = { createMatchLibraryTools };
