'use strict';

class LuaSavedVariablesParser {
  constructor(text = '') {
    this.text = String(text || '');
    this.index = 0;
    this.current = null;
  }

  eof() { return this.index >= this.text.length; }
  peekChar(offset = 0) { return this.text[this.index + offset] || ''; }

  skipSpaceAndComments() {
    while (!this.eof()) {
      const ch = this.peekChar();
      if (/\s/.test(ch)) { this.index += 1; continue; }
      if (ch === '-' && this.peekChar(1) === '-') {
        if (this.peekChar(2) === '[' && this.peekChar(3) === '[') {
          this.index += 4;
          const end = this.text.indexOf(']]', this.index);
          this.index = end >= 0 ? end + 2 : this.text.length;
        } else {
          while (!this.eof() && this.peekChar() !== '\n') this.index += 1;
        }
        continue;
      }
      break;
    }
  }

  readString(quote) {
    this.index += 1;
    let out = '';
    while (!this.eof()) {
      const ch = this.peekChar();
      this.index += 1;
      if (ch === quote) break;
      if (ch === '\\' && !this.eof()) {
        const next = this.peekChar();
        this.index += 1;
        if (next === 'n') out += '\n';
        else if (next === 'r') out += '\r';
        else if (next === 't') out += '\t';
        else out += next;
      } else {
        out += ch;
      }
    }
    return out;
  }

  readNumber() {
    const start = this.index;
    if (this.peekChar() === '-') this.index += 1;
    while (!this.eof() && /[0-9.]/.test(this.peekChar())) this.index += 1;
    const raw = this.text.slice(start, this.index);
    const n = Number(raw);
    return Number.isFinite(n) ? n : raw;
  }

  readIdentifier() {
    const start = this.index;
    while (!this.eof() && /[A-Za-z0-9_]/.test(this.peekChar())) this.index += 1;
    return this.text.slice(start, this.index);
  }

  nextToken() {
    this.skipSpaceAndComments();
    if (this.eof()) return { type: 'eof', value: '' };
    const ch = this.peekChar();
    if ('{}[]=,;'.includes(ch)) { this.index += 1; return { type: ch, value: ch }; }
    if (ch === '"' || ch === "'") return { type: 'string', value: this.readString(ch) };
    if (ch === '-' || /[0-9]/.test(ch)) return { type: 'number', value: this.readNumber() };
    if (/[A-Za-z_]/.test(ch)) return { type: 'identifier', value: this.readIdentifier() };
    this.index += 1;
    return this.nextToken();
  }

  peek() {
    if (!this.current) this.current = this.nextToken();
    return this.current;
  }

  take() {
    const token = this.peek();
    this.current = null;
    return token;
  }

  expect(type) {
    const token = this.take();
    if (token.type !== type) throw new Error(`Expected ${type}, got ${token.type}`);
    return token;
  }

  parseValue() {
    const token = this.peek();
    if (token.type === '{') return this.parseTable();
    if (token.type === 'string' || token.type === 'number') return this.take().value;
    if (token.type === 'identifier') {
      const value = this.take().value;
      if (value === 'true') return true;
      if (value === 'false') return false;
      if (value === 'nil') return null;
      return value;
    }
    if (token.type === 'eof') return null;
    this.take();
    return null;
  }

  parseTable() {
    this.expect('{');
    const arr = [];
    const obj = {};
    let explicit = false;
    while (this.peek().type !== '}' && this.peek().type !== 'eof') {
      let key = null;
      let value;
      const token = this.peek();
      if (token.type === '[') {
        this.take();
        key = this.parseValue();
        this.expect(']');
        if (this.peek().type === '=') this.take();
        value = this.parseValue();
        explicit = true;
        obj[String(key)] = value;
      } else if (token.type === 'identifier') {
        const ident = this.take().value;
        if (this.peek().type === '=') {
          this.take();
          value = this.parseValue();
          explicit = true;
          obj[String(ident)] = value;
        } else {
          value = ident === 'true' ? true : ident === 'false' ? false : ident === 'nil' ? null : ident;
          arr.push(value);
        }
      } else {
        value = this.parseValue();
        arr.push(value);
      }
      if (this.peek().type === ',' || this.peek().type === ';') this.take();
    }
    if (this.peek().type === '}') this.take();
    if (!explicit) return arr;
    for (let i = 0; i < arr.length; i += 1) obj[String(i + 1)] = arr[i];
    return obj;
  }
}


function parseLuaAssignment(raw, variableName) {
  const text = String(raw || '');
  const match = new RegExp(`\\b${variableName}\\s*=`).exec(text);
  if (!match) return null;
  const parser = new LuaSavedVariablesParser(text.slice(match.index + match[0].length));
  return parser.parseValue();
}

module.exports = { LuaSavedVariablesParser, parseLuaAssignment };
