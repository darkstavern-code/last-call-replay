const { execFile } = require('child_process');

function createVodIpcTools(deps = {}) {
  const app = deps.app;
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const dialog = deps.dialog;
  const ipcMain = deps.ipcMain;
  const getMainWindow = typeof deps.getMainWindow === 'function' ? deps.getMainWindow : () => null;

  const readState = deps.readState;
  const writeState = deps.writeState;
  const ensureDir = deps.ensureDir || (() => {});
  const defaultSettings = deps.defaultSettings || (() => ({}));
  const appStorageDir = deps.appStorageDir || (() => process.cwd());
  const localFileDateTimeStamp = deps.localFileDateTimeStamp || (() => new Date().toISOString().replace(/[:.]/g, '-'));
  const bestRecordingPickerPath = deps.bestRecordingPickerPath || (() => undefined);
  const normalizeFilePathList = deps.normalizeFilePathList || ((value) => Array.isArray(value) ? value : (value ? [value] : []));
  const importVodPathsIntoState = deps.importVodPathsIntoState || (() => ({ imported: [], skipped: [] }));
  const sanitizeVodRecord = deps.sanitizeVodRecord || ((item) => item || null);
  const compactMutationCollections = deps.compactMutationCollections || (() => ({}));
  const refreshVideoLinkIndexes = deps.refreshVideoLinkIndexes || (() => {});
  const compactRecentMatchesForResponse = deps.compactRecentMatchesForResponse || (() => []);
  const compactRecordingsForResponse = deps.compactRecordingsForResponse || (() => []);
  const compactVodsForResponse = deps.compactVodsForResponse || (() => []);
  const vodClipCandidatesForState = deps.vodClipCandidatesForState || (() => []);
  const uniqueList = deps.uniqueList || ((items) => Array.from(new Set((items || []).filter(Boolean))));
  const buildClientStatePayload = deps.buildClientStatePayload || (() => ({}));

  function parseVodStartFromFilename(filePath = '') {
    const base = path.basename(String(filePath || '')).replace(/\.[^.]+$/, '');
    const match = base.match(/(20\d{2})[-_. ](\d{2})[-_. ](\d{2})[ T_-]+(\d{2})[-_.:](\d{2})(?:[-_.:](\d{2}))?/);
    if (!match) return null;
    const [, yyyy, mm, dd, hh, min, ss = '00'] = match;
    const d = new Date(Number(yyyy), Number(mm) - 1, Number(dd), Number(hh), Number(min), Number(ss));
    if (Number.isNaN(d.getTime())) return null;
    return { iso: d.toISOString(), label: `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}` };
  }

  function clipsDir(state) {
    const configured = state && state.settings && state.settings.clipExportDir ? String(state.settings.clipExportDir) : '';
    const base = configured || (state && state.settings && state.settings.recordingsDir && state.settings.recordingsDirConfirmed
      ? path.join(state.settings.recordingsDir, 'vod-exports')
      : path.join(appStorageDir(), 'vod-exports'));
    ensureDir(base);
    return base;
  }

  function safeClipBaseName(match = {}) {
    const stamp = match.startIso ? localFileDateTimeStamp(new Date(match.startIso)) : localFileDateTimeStamp(new Date());
    const parts = [stamp, match.matchType || match.bracket || 'match', match.map || 'map', match.alt || match.ownName || 'toon'];
    return parts.join('_').replace(/[^a-z0-9._-]+/gi, '_').replace(/_+/g, '_').slice(0, 120) || `vod_${Date.now()}`;
  }

  function execFilePromise(command, args, options = {}) {
    return new Promise((resolve, reject) => {
      execFile(command, args, options, (error, stdout, stderr) => {
        if (error) {
          error.stdout = stdout;
          error.stderr = stderr;
          reject(error);
          return;
        }
        resolve({ stdout, stderr });
      });
    });
  }

  function fileExistsSafe(filePath) {
    try { return Boolean(filePath && fs.existsSync(filePath)); } catch (_) { return false; }
  }

  function resolveFfmpegBinary() {
    const candidates = [];
    if (process.env.FFMPEG_PATH) candidates.push(process.env.FFMPEG_PATH);
    try {
      const staticPath = require('ffmpeg-static');
      if (staticPath) candidates.push(staticPath);
    } catch (_) {}
    try {
      const appPath = app && app.getAppPath ? app.getAppPath() : process.cwd();
      candidates.push(
        path.join(appPath, 'node_modules', 'ffmpeg-static', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'),
        path.join(appPath, 'node_modules', 'ffmpeg-static', 'ffmpeg')
      );
    } catch (_) {}
    try {
      if (process.resourcesPath) {
        candidates.push(
          path.join(process.resourcesPath, 'ffmpeg.exe'),
          path.join(process.resourcesPath, 'ffmpeg'),
          path.join(process.resourcesPath, 'app.asar.unpacked', 'node_modules', 'ffmpeg-static', process.platform === 'win32' ? 'ffmpeg.exe' : 'ffmpeg'),
          path.join(process.resourcesPath, 'app.asar.unpacked', 'node_modules', 'ffmpeg-static', 'ffmpeg')
        );
      }
    } catch (_) {}
    for (const candidate of candidates) {
      if (fileExistsSafe(candidate)) return candidate;
    }
    return 'ffmpeg';
  }

  function assertIpcDeps() {
    if (!ipcMain || typeof ipcMain.handle !== 'function') throw new Error('Missing ipcMain for VOD IPC handlers.');
    if (!dialog || typeof dialog.showOpenDialog !== 'function') throw new Error('Missing dialog for VOD IPC handlers.');
    if (typeof readState !== 'function' || typeof writeState !== 'function') throw new Error('Missing state helpers for VOD IPC handlers.');
  }

  function registerVodIpcHandlers() {
    assertIpcDeps();

    ipcMain.handle('select-video-file', async (_event, payload) => {
      const state = readState();
      const matchStartIso = payload && payload.matchStartIso ? String(payload.matchStartIso) : '';
      const matchDate = matchStartIso ? new Date(matchStartIso) : null;
      const result = await dialog.showOpenDialog(getMainWindow(), {
        title: 'Select match recording',
        defaultPath: bestRecordingPickerPath(state, matchDate),
        properties: ['openFile'],
        filters: [
          { name: 'Video Files', extensions: ['webm', 'mp4', 'mov', 'mkv', 'avi'] },
          { name: 'All Files', extensions: ['*'] }
        ]
      });
      if (result.canceled) return null;
      return result.filePaths[0];
    });

    ipcMain.handle('import-vod-file', async (_event, payload = {}) => {
      const state = readState();
      let filePaths = normalizeFilePathList(payload.filePaths || payload.filePath || []);
      if (!filePaths.length) {
        const result = await dialog.showOpenDialog(getMainWindow(), {
          title: 'Select Twitch VOD / long video file',
          defaultPath: bestRecordingPickerPath(state, null),
          properties: ['openFile', 'multiSelections'],
          filters: [
            { name: 'Video Files', extensions: ['mp4', 'mkv', 'mov', 'webm', 'avi'] },
            { name: 'All Files', extensions: ['*'] }
          ]
        });
        if (result.canceled || !result.filePaths || !result.filePaths[0]) return null;
        filePaths = result.filePaths;
      }
      const sourceName = payload && payload.source ? `Imported VOD (${String(payload.source).slice(0, 30)})` : 'Imported VOD';
      const { imported, skipped } = importVodPathsIntoState(state, filePaths, sourceName);
      if (!imported.length) {
        const reason = skipped.length ? `No supported VOD video files were imported. First issue: ${skipped[0].reason}.` : 'No VOD files were selected.';
        return { ok: false, reason, skipped, changedVods: [], ...compactMutationCollections(state) };
      }
      writeState(state);
      return { ok: true, vod: sanitizeVodRecord(imported[0]), imported: imported.map(sanitizeVodRecord).filter(Boolean), skipped, ...compactMutationCollections(state, { changedVods: imported }) };
    });

    ipcMain.handle('update-vod-meta', async (_event, payload = {}) => {
      const state = readState();
      const vodId = String(payload.vodId || '');
      if (!vodId) return { ok: false, reason: 'VOD not found.' };
      state.vods = Array.isArray(state.vods) ? state.vods : [];
      let found = false;
      state.vods = state.vods.map((item) => {
        if (!item || item.id !== vodId) return item;
        found = true;
        return sanitizeVodRecord({
          ...item,
          label: payload.label !== undefined ? String(payload.label || item.label || '') : item.label,
          startIso: payload.startIso !== undefined ? String(payload.startIso || '') : item.startIso,
          syncOffsetSec: payload.syncOffsetSec !== undefined ? Number(payload.syncOffsetSec) || 0 : item.syncOffsetSec,
          note: payload.note !== undefined ? String(payload.note || '') : item.note
        });
      }).filter(Boolean);
      if (!found) return { ok: false, reason: 'VOD not found.' };
      writeState(state);
      const updatedVod = state.vods.find((item) => item && item.id === vodId) || null;
      return { ok: true, vod: updatedVod ? sanitizeVodRecord(updatedVod) : null, ...compactMutationCollections(state, { changedVods: updatedVod ? [updatedVod] : [] }) };
    });

    ipcMain.handle('delete-vod', async (_event, payload = {}) => {
      const state = readState();
      const vodId = String(payload.vodId || '');
      if (!vodId) return { ok: false, reason: 'VOD not found.' };
      state.vods = Array.isArray(state.vods) ? state.vods : [];
      const vod = state.vods.find((item) => item && item.id === vodId);
      if (!vod) return { ok: false, reason: 'VOD not found.' };
      state.vods = state.vods.filter((item) => item && item.id !== vodId);
      let unlinked = 0;
      const preserve = (match) => {
        if (!match || match.vodId !== vodId) return match;
        unlinked += 1;
        const next = { ...match };
        delete next.videoPath;
        delete next.videoLabel;
        delete next.videoLinkedAt;
        delete next.videoLinkMode;
        delete next.videoSessionId;
        delete next.videoSyncAdjustmentSec;
        delete next.manualVideoSection;
        delete next.videoSectionUpdatedAt;
        delete next.vodId;
        delete next.vodLinkedAt;
        delete next.videoClipStartSec;
        delete next.videoClipEndSec;
        delete next.videoMatchStartSec;
        delete next.videoMatchEndSec;
        delete next.videoClipPreRollSec;
        delete next.videoClipPostRollSec;
        if (Array.isArray(next.dataSources)) next.dataSources = next.dataSources.filter((source) => source !== 'video' && source !== 'vod' && source !== 'recordingSession');
        return next;
      };
      state.matches = (state.matches || []).map(preserve);
      refreshVideoLinkIndexes(state);
      writeState(state);
      return { ok: true, vodId, deletedLabel: vod.label || path.basename(vod.filePath || 'VOD'), unlinked, ...compactMutationCollections(state, { removedVodIds: [vodId], changedMatches: compactRecentMatchesForResponse(state, 80), changedRecordings: compactRecordingsForResponse(state, 60) }) };
    });

    ipcMain.handle('link-vod-to-matches', async (_event, payload = {}) => {
      const state = readState();
      const vodId = String(payload.vodId || '');
      const vod = (state.vods || []).find((item) => item && item.id === vodId);
      if (!vod) return { ok: false, reason: 'VOD not found.' };
      if (!vod.startIso || Number.isNaN(Date.parse(vod.startIso))) return { ok: false, reason: 'Set the VOD start time first.' };
      let candidates = vodClipCandidatesForState(state, vod, payload);
      const requestedIds = Array.isArray(payload.matchIds) ? new Set(payload.matchIds.map((id) => String(id || '')).filter(Boolean)) : null;
      if (requestedIds && requestedIds.size) candidates = candidates.filter((item) => requestedIds.has(String(item.matchId || '')));
      if (!candidates.length) return { ok: false, reason: requestedIds && requestedIds.size ? 'That match does not line up with this VOD start time. Check the VOD time/offset.' : 'No combat-log matches line up with this VOD start time.', ...compactMutationCollections(state) };
      const byId = new Map(candidates.map((item) => [item.matchId, item]));
      const nowIso = new Date().toISOString();
      const isRecordingSession = vod.sourceType === 'recording-session' || Boolean(vod.recordingId);
      const linkMode = isRecordingSession ? 'recording-session' : 'vod';
      const sourceTag = isRecordingSession ? 'recordingSession' : 'vod';
      let linked = 0;
      state.matches = (state.matches || []).map((match) => {
        const candidate = byId.get(match && match.id);
        if (!candidate) return match;
        linked += 1;
        const sources = uniqueList([...(match.dataSources || []), 'video', sourceTag]);
        return {
          ...match,
          videoPath: vod.filePath,
          videoLabel: vod.label || path.basename(vod.filePath),
          videoLinkedAt: nowIso,
          videoLinkMode: linkMode,
          vodId: vod.id,
          vodLinkedAt: nowIso,
          videoSessionId: vod.recordingId || match.videoSessionId || '',
          videoClipStartSec: candidate.clipStartSec,
          videoClipEndSec: candidate.clipEndSec,
          videoMatchStartSec: Math.max(0, candidate.rawStartSec),
          videoMatchEndSec: Math.max(0, candidate.rawEndSec),
          videoShuffleStartSec: candidate.videoShuffleStartSec == null ? undefined : Math.max(0, candidate.videoShuffleStartSec),
          videoShuffleEndSec: candidate.videoShuffleEndSec == null ? undefined : Math.max(0, candidate.videoShuffleEndSec),
          videoClipPreRollSec: candidate.preRollSec,
          videoClipPostRollSec: candidate.postRollSec,
          manualVideoSection: false,
          dataSources: sources
        };
      });
      state.vods = (state.vods || []).map((item) => item && item.id === vod.id ? { ...item, lastLinkedAt: nowIso, lastLinkedCount: linked } : item);
      refreshVideoLinkIndexes(state);
      writeState(state);
      const linkedMatches = (state.matches || []).filter((match) => match && byId.has(match.id));
      const changedVod = (state.vods || []).find((item) => item && item.id === vod.id) || vod;
      return { ok: true, linked, candidates, ...compactMutationCollections(state, { changedMatches: linkedMatches, changedVods: [changedVod], changedRecordings: compactRecordingsForResponse(state, 40) }) };
    });

    ipcMain.handle('update-match-video-section', async (_event, payload = {}) => {
      const state = readState();
      const matchId = String(payload.matchId || '');
      if (!matchId) return { ok: false, reason: 'Match not found.' };
      const clipStart = Math.max(0, Number(payload.clipStartSec) || 0);
      const clipEnd = Math.max(clipStart + 1, Number(payload.clipEndSec) || clipStart + 1);
      const matchStart = Math.max(0, Number(payload.matchStartSec) || clipStart);
      const matchEnd = Math.max(matchStart + 1, Number(payload.matchEndSec) || clipEnd);
      const syncAdjustment = Math.max(-300, Math.min(300, Number(payload.syncAdjustmentSec) || 0));
      let found = false;
      state.matches = (state.matches || []).map((match) => {
        if (!match || match.id !== matchId) return match;
        found = true;
        return {
          ...match,
          videoClipStartSec: Math.round(clipStart * 10) / 10,
          videoClipEndSec: Math.round(clipEnd * 10) / 10,
          videoMatchStartSec: Math.round(matchStart * 10) / 10,
          videoMatchEndSec: Math.round(matchEnd * 10) / 10,
          videoSyncAdjustmentSec: Math.round(syncAdjustment * 10) / 10,
          manualVideoSection: true,
          videoSectionUpdatedAt: new Date().toISOString()
        };
      });
      if (!found) return { ok: false, reason: 'Match not found.' };
      refreshVideoLinkIndexes(state);
      writeState(state);
      const changedMatch = (state.matches || []).find((match) => match && match.id === matchId) || null;
      return { ok: true, ...compactMutationCollections(state, { changedMatches: changedMatch ? [changedMatch] : [], changedRecordings: compactRecordingsForResponse(state, 40), changedVods: compactVodsForResponse(state, 40) }) };
    });

    ipcMain.handle('export-vod-clip', async (_event, payload = {}) => {
      const state = readState();
      const matchId = String(payload.matchId || '');
      const match = (state.matches || []).find((item) => item && item.id === matchId);
      if (!match || !match.videoPath) return { ok: false, reason: 'No VOD/video is linked to this match.' };
      const requestedStart = Number(payload.startSec);
      const requestedEnd = Number(payload.endSec);
      const defaultStart = Math.max(0, Number(match.videoClipStartSec) || 0);
      const defaultEnd = Math.max(defaultStart + 1, Number(match.videoClipEndSec) || (defaultStart + Number(match.durationSec || 60)));
      const start = Math.max(0, Number.isFinite(requestedStart) ? requestedStart : defaultStart);
      const end = Math.max(start + 1, Number.isFinite(requestedEnd) ? requestedEnd : defaultEnd);
      const duration = Math.max(1, end - start);
      if (!fs.existsSync(match.videoPath)) return { ok: false, reason: 'Linked VOD file was not found.' };
      const includeAudio = payload.includeAudio !== false;
      const sourceExt = (path.extname(match.videoPath) || '.mp4').toLowerCase();
      const audioSuffix = includeAudio ? '' : '_no-sound';
      const requestedOutputDir = payload.outputDir ? String(payload.outputDir) : '';
      if (requestedOutputDir) {
        state.settings = { ...defaultSettings(), ...(state.settings || {}), clipExportDir: requestedOutputDir };
      }
      const outputDir = clipsDir(state);
      const outputPath = path.join(outputDir, `${safeClipBaseName(match)}${audioSuffix}${sourceExt}`);
      const args = ['-y', '-ss', String(start), '-i', match.videoPath, '-t', String(duration), '-c', 'copy'];
      if (!includeAudio) args.push('-an');
      args.push('-avoid_negative_ts', 'make_zero', outputPath);
      const ffmpegCommand = resolveFfmpegBinary();
      try {
        await execFilePromise(ffmpegCommand, args, { windowsHide: true, timeout: 10 * 60 * 1000 });
        state.settings.clipExportDir = outputDir;
        writeState(state);
        return { ok: true, outputPath, outputDir, startSec: start, endSec: end, durationSec: duration, includeAudio, ffmpegPath: ffmpegCommand, settings: state.settings || {} };
      } catch (error) {
        const stderr = String(error && error.stderr || error && error.message || '');
        const missing = /ENOENT|not found|spawn ffmpeg/i.test(stderr) || (error && error.code === 'ENOENT');
        const incompatible = /codec|muxer|container|tag|could not write header|invalid argument/i.test(stderr);
        return {
          ok: false,
          reason: missing
            ? 'FFmpeg was not found. Run npm install for the bundled exporter, install FFmpeg, or set FFMPEG_PATH to ffmpeg.exe, then try Download VOD again.'
            : incompatible
              ? 'VOD export failed while trimming the original file type with fast copy. This may need a future remux/transcode helper.'
              : `VOD export failed: ${stderr.slice(0, 600) || 'unknown ffmpeg error'}`,
          attemptedCommand: `${ffmpegCommand} ${args.map((arg) => /\s/.test(arg) ? `"${arg}"` : arg).join(' ')}`
        };
      }
    });

    ipcMain.handle('select-export-folder', async () => {
      const state = readState();
      const result = await dialog.showOpenDialog(getMainWindow(), {
        title: 'Choose VOD export folder',
        defaultPath: clipsDir(state),
        properties: ['openDirectory', 'createDirectory']
      });
      if (result.canceled || !result.filePaths || !result.filePaths[0]) return null;
      state.settings = { ...defaultSettings(), ...(state.settings || {}), clipExportDir: result.filePaths[0] };
      ensureDir(state.settings.clipExportDir);
      writeState(state);
      return { ok: true, clipExportDir: state.settings.clipExportDir, settings: state.settings || {}, appPaths: buildClientStatePayload(state).appPaths };
    });
  }

  return {
    parseVodStartFromFilename,
    clipsDir,
    safeClipBaseName,
    resolveFfmpegBinary,
    registerVodIpcHandlers
  };
}

module.exports = {
  createVodIpcTools
};
