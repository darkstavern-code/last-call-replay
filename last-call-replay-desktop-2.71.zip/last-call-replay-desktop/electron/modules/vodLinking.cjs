'use strict';

function createVodLinkingTools(deps = {}) {
  const path = deps.path || require('path');
  const fs = deps.fs || require('fs');
  const crypto = deps.crypto || require('crypto');
  const hashText = typeof deps.hashText === 'function' ? deps.hashText : (value) => String(value || '');
  const normalizeMatchType = typeof deps.normalizeMatchType === 'function' ? deps.normalizeMatchType : (value) => String(value || '');
  const isBattlegroundType = typeof deps.isBattlegroundType === 'function' ? deps.isBattlegroundType : () => false;
  const isSoloShuffleRoundChildMatch = typeof deps.isSoloShuffleRoundChildMatch === 'function' ? deps.isSoloShuffleRoundChildMatch : () => false;
  const annotateSoloShuffleSessions = typeof deps.annotateSoloShuffleSessions === 'function' ? deps.annotateSoloShuffleSessions : () => null;
  const videoGroupRangeForMatch = typeof deps.videoGroupRangeForMatch === 'function' ? deps.videoGroupRangeForMatch : () => null;
  const confidentRecordingMatchOverlap = typeof deps.confidentRecordingMatchOverlap === 'function' ? deps.confidentRecordingMatchOverlap : (sourceStart, sourceEnd, matchStart, matchEnd) => Boolean(sourceStart && sourceEnd && matchStart < sourceEnd && matchEnd > sourceStart);
  const uniqueList = typeof deps.uniqueList === 'function' ? deps.uniqueList : (items = []) => Array.from(new Set((items || []).filter(Boolean)));
  const parseVodStartFromFilename = typeof deps.parseVodStartFromFilename === 'function' ? deps.parseVodStartFromFilename : () => null;

  const VOD_VIDEO_EXTENSIONS = new Set(['.mp4', '.mkv', '.mov', '.webm', '.avi']);

  function looksLikeVodVideoFile(filePath = '') {
    return VOD_VIDEO_EXTENSIONS.has(path.extname(String(filePath || '')).toLowerCase());
  }

  function sanitizeVodRecord(item = {}) {
    if (!item || typeof item !== 'object') return null;
    const filePath = String(item.filePath || '');
    if (!filePath) return null;
    const id = String(item.id || `vod_${hashText(filePath).slice(0, 12)}`);
    return {
      id,
      filePath,
      label: String(item.label || path.basename(filePath) || 'Imported VOD').slice(0, 120),
      sourceName: String(item.sourceName || 'VOD file').slice(0, 80),
      sourceType: String(item.sourceType || ''),
      recordingId: String(item.recordingId || ''),
      startIso: String(item.startIso || ''),
      endIso: String(item.endIso || ''),
      suggestedStartIso: String(item.suggestedStartIso || ''),
      suggestedStartLabel: String(item.suggestedStartLabel || '').slice(0, 80),
      syncOffsetSec: Number(item.syncOffsetSec) || 0,
      importedAt: String(item.importedAt || new Date().toISOString()),
      bytes: Number(item.bytes) || 0,
      lastLinkedAt: String(item.lastLinkedAt || ''),
      lastLinkedCount: Number(item.lastLinkedCount) || 0,
      note: String(item.note || '').slice(0, 500)
    };
  }

  function defaultVideoPreRollSec(match = {}) {
    const type = normalizeMatchType(match.matchType || match.bracket || '');
    if (isBattlegroundType(type) || match.isBattleground || match.isRatedBattleground) return 90;
    return 45;
  }

  function matchReplayStartMs(match = {}, fallbackStart = 0) {
    const candidates = [
      Number(match.loadedInMs),
      Number(match.enteredAtMs),
      Number(match.videoSegmentStartMs),
      match.videoSegmentStartIso ? Date.parse(match.videoSegmentStartIso) : 0,
      Number(match.queueAcceptedMs),
      match.queueAcceptedIso ? Date.parse(match.queueAcceptedIso) : 0,
      fallbackStart
    ];
    const valid = candidates.filter((value) => Number.isFinite(value) && value > 0);
    if (!valid.length) return Number(fallbackStart || 0);
    const earliest = Math.min(...valid);
    const fallback = Number(fallbackStart || 0);
    if (fallback && earliest < fallback - 20 * 60 * 1000) return fallback;
    return earliest;
  }

  function isAddonOnlyTimingMatch(match = {}) {
    const sources = Array.isArray(match.dataSources) ? match.dataSources.map((source) => String(source || '').toLowerCase()) : [];
    const hasCombatLog = Boolean(match.createdFromRealLog) || sources.some((source) => /combat|log|tail/.test(source));
    const hasAddonScoreboard = Boolean(match.createdFromAddon || match.addonScoreboard || sources.includes('addonscoreboard'));
    return hasAddonScoreboard && !hasCombatLog;
  }

  function estimatedAddonOnlyDurationSec(match = {}) {
    const known = Number(match.durationSec || 0);
    if (Number.isFinite(known) && known > 5) return known;
    const type = normalizeMatchType(match.matchType || match.bracket || '');
    const expectedTeamSize = Number(match.expectedTeamSize || match.actualTeamSize || 0);
    if (isBattlegroundType(type) || expectedTeamSize >= 6 || match.isBattleground || match.isRatedBattleground) return 15 * 60;
    if (/shuffle/i.test(type) || match.isSoloShuffle) return 7 * 60;
    if (/arena|2v2|3v3|skirmish/i.test(type)) return 6 * 60;
    return 5 * 60;
  }

  function matchTimeRangeMs(match = {}) {
    const parsedStart = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0);
    const gameStart = Number(match.gameStartMs) || parsedStart;
    const enteredStart = Number(match.loadedInMs) || Number(match.enteredAtMs) || Number(match.gameStartMs) || parsedStart || Number(match.videoSegmentStartMs) || (match.videoSegmentStartIso ? Date.parse(match.videoSegmentStartIso) : 0);
    let start = enteredStart || gameStart;
    let end = Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0);
    const durationSec = Number(match.durationSec) || 0;
    let estimatedFromScoreboard = false;
    if (end && isAddonOnlyTimingMatch(match) && durationSec <= 5) {
      start = Math.max(0, end - estimatedAddonOnlyDurationSec(match) * 1000);
      estimatedFromScoreboard = true;
    }
    if ((!Number.isFinite(end) || end <= start) && gameStart && durationSec > 0) end = gameStart + durationSec * 1000;
    if ((!Number.isFinite(end) || end <= start) && start) end = start + 120000;
    return { start, gameStart, end, estimatedFromScoreboard };
  }

  function boundedMatchTimeRangeMs(state, match = {}, windowStart = 0, windowEnd = 0) {
    const range = matchTimeRangeMs(match);
    if (!range.estimatedFromScoreboard || !range.end || !Array.isArray(state && state.matches)) return range;
    const currentId = String(match.id || '');
    const previousEnd = (state.matches || []).reduce((best, other) => {
      if (!other || String(other.id || '') === currentId) return best;
      const otherRange = matchTimeRangeMs(other);
      const otherEnd = Number(otherRange.end || 0);
      if (!otherEnd || otherEnd >= range.end - 5000) return best;
      if (windowStart && otherEnd < windowStart - 600000) return best;
      if (windowEnd && otherEnd > windowEnd + 600000) return best;
      return Math.max(best, otherEnd);
    }, 0);
    const upperStart = Math.max(0, range.end - 5000);
    let safeStart = Math.max(
      Number(windowStart || 0),
      previousEnd ? previousEnd + 5000 : 0,
      range.start || 0
    );
    if (safeStart > upperStart) safeStart = Math.max(Number(windowStart || 0), range.start || 0);
    if (safeStart > upperStart) safeStart = upperStart;
    return { ...range, start: safeStart };
  }

  function vodClipCandidatesForState(state, vod, options = {}) {
    const vodStart = vod && vod.startIso ? Date.parse(vod.startIso) : 0;
    const vodEnd = vod && vod.endIso ? Date.parse(vod.endIso) : 0;
    const hasVodEnd = Number.isFinite(vodEnd) && vodEnd > vodStart;
    if (!vod || !vod.filePath || !Number.isFinite(vodStart) || vodStart <= 0) return [];
    const offset = Number(vod.syncOffsetSec) || 0;
    const requestedPre = Number(options.preRollSec);
    const requestedPost = Number(options.postRollSec);
    const preOverride = Number.isFinite(requestedPre) ? requestedPre : NaN;
    const post = Math.max(0, Math.min(240, Number.isFinite(requestedPost) ? requestedPost : 0));
    const maxStreamSeconds = Math.max(1800, Math.min(24 * 3600, Number(options.maxStreamSeconds) || 12 * 3600));
    const candidates = [];
    for (const match of state.matches || []) {
      if (!match || match.scoreboardPendingLink || match.pendingScoreboardLink || isSoloShuffleRoundChildMatch(match)) continue;
      const { start, end } = boundedMatchTimeRangeMs(state, match, vodStart, hasVodEnd ? vodEnd : 0);
      if (!start || !end || end <= start) continue;
      const groupRange = videoGroupRangeForMatch(match);
      const replayStart = matchReplayStartMs(match, start);
      const sectionStart = groupRange ? groupRange.start : replayStart;
      const sectionEnd = groupRange ? groupRange.end : end;
      const roundRawStart = (start - vodStart) / 1000 + offset;
      const roundRawEnd = (end - vodStart) / 1000 + offset;
      const rawStart = (sectionStart - vodStart) / 1000 + offset;
      const rawEnd = (sectionEnd - vodStart) / 1000 + offset;
      if (hasVodEnd && !confidentRecordingMatchOverlap(vodStart, vodEnd, sectionStart, sectionEnd, 90000)) continue;
      const pre = Math.max(0, Math.min(120, Number.isFinite(preOverride) ? preOverride : defaultVideoPreRollSec(match)));
      const clipStart = Math.max(0, rawStart - pre);
      const sessionEndSec = hasVodEnd ? Math.max(5, (vodEnd - vodStart) / 1000 + offset) : maxStreamSeconds;
      const clipEnd = Math.min(Math.max(clipStart + 5, rawEnd + post), Math.max(clipStart + 5, sessionEndSec));
      if (clipEnd <= 0 || rawStart > maxStreamSeconds || rawEnd < -300) continue;
      candidates.push({
        matchId: match.id,
        map: match.map || 'Unknown map',
        matchType: match.matchType || match.bracket || '',
        startIso: match.startIso || '',
        durationSec: Number(match.durationSec) || Math.max(1, Math.round((end - start) / 1000)),
        clipStartSec: Math.max(0, Math.round(clipStart * 10) / 10),
        clipEndSec: Math.max(0, Math.round(clipEnd * 10) / 10),
        rawStartSec: Math.round(roundRawStart * 10) / 10,
        rawEndSec: Math.round(roundRawEnd * 10) / 10,
        videoShuffleStartSec: groupRange ? Math.max(0, Math.round(rawStart * 10) / 10) : null,
        videoShuffleEndSec: groupRange ? Math.max(0, Math.round(rawEnd * 10) / 10) : null,
        preRollSec: pre,
        postRollSec: post
      });
    }
    candidates.sort((a, b) => (Date.parse(a.startIso || 0) || 0) - (Date.parse(b.startIso || 0) || 0));
    return candidates;
  }

  function recordingSessionVodId(record = {}) {
    return record && record.id ? `rec_session_${record.id}` : '';
  }

  function recordingTimeRangeMs(record = {}) {
    const start = record.startedAt ? Date.parse(record.startedAt) : 0;
    const end = record.endedAt ? Date.parse(record.endedAt) : 0;
    return { start, end };
  }

  function upsertRecordingSessionVod(state, record = {}) {
    if (!state || !record || !record.filePath || !record.startedAt) return null;
    state.vods = Array.isArray(state.vods) ? state.vods : [];
    const id = recordingSessionVodId(record);
    if (!id) return null;
    const existing = state.vods.find((item) => item && item.id === id);
    const base = sanitizeVodRecord({
      ...(existing || {}),
      id,
      filePath: record.filePath,
      label: existing && existing.label ? existing.label : `${path.basename(record.filePath)} · recorder session`,
      sourceName: 'Recorder session',
      sourceType: 'recording-session',
      recordingId: record.id,
      startIso: existing && existing.startIso ? existing.startIso : record.startedAt,
      endIso: record.endedAt || (existing && existing.endIso) || '',
      suggestedStartIso: record.startedAt,
      suggestedStartLabel: record.startedAt ? new Date(record.startedAt).toLocaleString() : '',
      importedAt: existing && existing.importedAt ? existing.importedAt : (record.startedAt || new Date().toISOString()),
      bytes: record.bytes || (existing && existing.bytes) || 0
    });
    state.vods = state.vods.filter((item) => item && item.id !== id);
    state.vods.unshift(base);
    return base;
  }

  function refreshVideoLinkIndexes(state) {
    if (!state || !Array.isArray(state.matches)) return state;
    try {
      annotateSoloShuffleSessions(state);
    } catch (error) {
      console.warn('[Last Call Replay] Solo Shuffle annotation skipped during VOD index refresh:', error && error.message ? error.message : error);
    }
    const matchesByPath = new Map();
    const matchesByVod = new Map();
    for (const match of state.matches || []) {
      if (!match || !match.videoPath) continue;
      const norm = path.normalize(String(match.videoPath)).toLowerCase();
      if (!matchesByPath.has(norm)) matchesByPath.set(norm, []);
      matchesByPath.get(norm).push(match.id);
      if (match.vodId) {
        if (!matchesByVod.has(match.vodId)) matchesByVod.set(match.vodId, []);
        matchesByVod.get(match.vodId).push(match.id);
      }
    }
    if (Array.isArray(state.recordings)) {
      state.recordings = state.recordings.map((rec) => {
        if (!rec || !rec.filePath) return rec;
        const norm = path.normalize(String(rec.filePath)).toLowerCase();
        const ids = uniqueList(matchesByPath.get(norm) || []);
        return {
          ...rec,
          linkedMatchIds: ids,
          linkedCount: ids.length,
          matchId: ids.length === 1 ? ids[0] : (ids.includes(rec.matchId) ? rec.matchId : '')
        };
      });
    }
    if (Array.isArray(state.vods)) {
      state.vods = state.vods.map((vod) => {
        if (!vod || !vod.id) return vod;
        const ids = uniqueList(matchesByVod.get(vod.id) || []);
        return { ...vod, lastLinkedCount: ids.length };
      });
    }
    return state;
  }

  function repairTinyVideoSectionClips(state) {
    if (!state || !Array.isArray(state.matches)) return state;
    const vodsById = new Map((state.vods || []).filter(Boolean).map((vod) => [String(vod.id || ''), vod]));
    const recById = new Map((state.recordings || []).filter(Boolean).map((rec) => [String(rec.id || ''), rec]));
    const recByPath = new Map((state.recordings || []).filter((rec) => rec && rec.filePath).map((rec) => [path.normalize(String(rec.filePath)).toLowerCase(), rec]));
    for (const match of state.matches) {
      if (!match || match.manualVideoSection || !match.videoPath || !isAddonOnlyTimingMatch(match)) continue;
      const mode = String(match.videoLinkMode || '');
      if (mode !== 'recording-session' && mode !== 'vod') continue;
      const clipStart = Number(match.videoClipStartSec);
      const clipEnd = Number(match.videoClipEndSec);
      const currentMatchStart = Number(match.videoMatchStartSec);
      const defaultPre = defaultVideoPreRollSec(match);
      const missingPreroll = Number.isFinite(clipStart) && Number.isFinite(currentMatchStart) && clipStart > Math.max(0, currentMatchStart - defaultPre) + 1;
      if (Number.isFinite(clipStart) && Number.isFinite(clipEnd) && clipEnd - clipStart > 12 && !missingPreroll) continue;
      const vod = match.vodId ? vodsById.get(String(match.vodId)) : null;
      const rec = (match.videoSessionId ? recById.get(String(match.videoSessionId)) : null) || recByPath.get(path.normalize(String(match.videoPath || '')).toLowerCase()) || null;
      const sourceStart = vod && vod.startIso ? Date.parse(vod.startIso) : (rec && rec.startedAt ? Date.parse(rec.startedAt) : 0);
      if (!sourceStart || !Number.isFinite(sourceStart)) continue;
      const sourceEnd = vod && vod.endIso ? Date.parse(vod.endIso) : (rec && rec.endedAt ? Date.parse(rec.endedAt) : 0);
      const range = boundedMatchTimeRangeMs(state, match, sourceStart, sourceEnd || 0);
      if (!range.start || !range.end || range.end <= range.start) continue;
      const pre = Math.max(0, Number(match.videoClipPreRollSec || 0) || defaultPre);
      const post = Math.max(0, Number(match.videoClipPostRollSec || 0) || 0);
      const sessionDuration = sourceEnd && sourceEnd > sourceStart ? (sourceEnd - sourceStart) / 1000 : 24 * 3600;
      const rawStart = Math.max(0, (range.start - sourceStart) / 1000);
      const rawEnd = Math.max(rawStart + 5, (range.end - sourceStart) / 1000);
      const nextStart = Math.max(0, rawStart - pre);
      const nextEnd = Math.min(Math.max(nextStart + 5, rawEnd + post), Math.max(nextStart + 5, sessionDuration));
      if (nextEnd - nextStart <= clipEnd - clipStart) continue;
      match.videoClipStartSec = Math.round(nextStart * 10) / 10;
      match.videoClipEndSec = Math.round(nextEnd * 10) / 10;
      match.videoMatchStartSec = Math.round(rawStart * 10) / 10;
      match.videoMatchEndSec = Math.round(rawEnd * 10) / 10;
      match.videoSectionRepairedAt = match.videoSectionRepairedAt || new Date().toISOString();
    }
    return state;
  }

  function linkRecordingSessionToMatches(state, record = {}, matches = []) {
    if (!state || !record || !record.filePath || !record.startedAt || !Array.isArray(state.matches)) return 0;
    const { start: recStart, end: recEnd } = recordingTimeRangeMs(record);
    if (!recStart) return 0;
    const configuredWindow = Number(state.settings && state.settings.autoLinkWindowMinutes);
    const windowMs = Math.max(0, Number.isFinite(configuredWindow) ? configuredWindow : 0) * 60 * 1000;
    const vod = upsertRecordingSessionVod(state, record);
    if (!vod) return 0;
    const candidateMatches = (matches && matches.length ? matches : state.matches).filter(Boolean);
    const byId = new Map(candidateMatches.map((match) => [match.id, match]));
    const nowIso = new Date().toISOString();
    let linked = 0;
    state.matches = state.matches.map((match) => {
      if (!match || !byId.has(match.id) || match.scoreboardPendingLink || match.pendingScoreboardLink) return match;
      const { start: matchStart, end: matchEnd } = boundedMatchTimeRangeMs(state, match, recStart, recEnd);
      if (!matchStart) return match;
      const hasDifferentVideo = match.videoPath && path.normalize(String(match.videoPath)).toLowerCase() !== path.normalize(String(record.filePath)).toLowerCase();
      if (hasDifferentVideo && match.videoLinkMode !== 'recording-session') return match;
      const matchStop = matchEnd && matchEnd > matchStart ? matchEnd : matchStart + Math.max(1, Number(match.durationSec || 120)) * 1000;
      const groupRange = videoGroupRangeForMatch(match);
      const replayStart = matchReplayStartMs(match, matchStart);
      const sectionStart = groupRange ? groupRange.start : replayStart;
      const sectionStop = groupRange ? groupRange.end : matchStop;
      const confident = recEnd ? confidentRecordingMatchOverlap(recStart, recEnd, sectionStart, sectionStop, Math.min(windowMs, 90000)) : false;
      if (!confident) return match;
      const sessionDuration = recEnd && recEnd > recStart ? (recEnd - recStart) / 1000 : 24 * 3600;
      const rawStart = Math.max(0, (matchStart - recStart) / 1000);
      const rawEnd = Math.max(rawStart + 5, (matchStop - recStart) / 1000);
      const rawSectionStart = Math.max(0, (sectionStart - recStart) / 1000);
      const rawSectionEnd = Math.max(rawSectionStart + 5, (sectionStop - recStart) / 1000);
      const preRollSec = Math.max(0, Number(match.videoClipPreRollSec || 0) || defaultVideoPreRollSec(match));
      const postRollSec = Math.max(0, Number(match.videoClipPostRollSec || 0));
      const clipStart = Math.max(0, rawSectionStart - preRollSec);
      const clipEnd = Math.min(Math.max(clipStart + 5, rawSectionEnd + postRollSec), Math.max(clipStart + 5, sessionDuration));
      linked += 1;
      const sources = uniqueList([...(match.dataSources || []), 'video', 'recordingSession']);
      return {
        ...match,
        videoPath: record.filePath,
        videoLabel: record.label || vod.label || path.basename(record.filePath),
        videoLinkedAt: match.videoLinkedAt || nowIso,
        videoLinkMode: 'recording-session',
        vodId: vod.id,
        vodLinkedAt: match.vodLinkedAt || nowIso,
        videoSessionId: record.id,
        videoClipStartSec: match.manualVideoSection && Number.isFinite(Number(match.videoClipStartSec)) ? match.videoClipStartSec : Math.round(clipStart * 10) / 10,
        videoClipEndSec: match.manualVideoSection && Number.isFinite(Number(match.videoClipEndSec)) ? match.videoClipEndSec : Math.round(clipEnd * 10) / 10,
        videoMatchStartSec: match.manualVideoSection && Number.isFinite(Number(match.videoMatchStartSec)) ? match.videoMatchStartSec : Math.round(rawStart * 10) / 10,
        videoMatchEndSec: match.manualVideoSection && Number.isFinite(Number(match.videoMatchEndSec)) ? match.videoMatchEndSec : Math.round(rawEnd * 10) / 10,
        videoShuffleStartSec: groupRange ? Math.round(rawSectionStart * 10) / 10 : undefined,
        videoShuffleEndSec: groupRange ? Math.round(rawSectionEnd * 10) / 10 : undefined,
        videoClipPreRollSec: preRollSec,
        videoClipPostRollSec: postRollSec,
        dataSources: sources
      };
    });
    state.vods = (state.vods || []).map((item) => item && item.id === vod.id ? { ...item, lastLinkedAt: nowIso } : item);
    refreshVideoLinkIndexes(state);
    return linked;
  }

  function normalizeFilePathList(value) {
    const raw = Array.isArray(value) ? value : (value ? [value] : []);
    const out = [];
    const seen = new Set();
    for (const item of raw) {
      const filePath = String(item || '').trim().replace(/^file:\/\//i, '').replace(/^['"]|['"]$/g, '');
      if (!filePath) continue;
      const norm = path.normalize(filePath).toLowerCase();
      if (seen.has(norm)) continue;
      seen.add(norm);
      out.push(filePath);
    }
    return out;
  }

  function importVodPathsIntoState(state, filePaths = [], sourceName = 'Imported VOD') {
    state.vods = Array.isArray(state.vods) ? state.vods : [];
    const imported = [];
    const skipped = [];
    for (const filePath of normalizeFilePathList(filePaths)) {
      try {
        if (!fs.existsSync(filePath)) {
          skipped.push({ filePath, reason: 'File not found' });
          continue;
        }
        const stat = fs.statSync(filePath);
        if (!stat.isFile()) {
          skipped.push({ filePath, reason: 'Not a file' });
          continue;
        }
        if (!looksLikeVodVideoFile(filePath)) {
          skipped.push({ filePath, reason: 'Unsupported video type' });
          continue;
        }
        const filenameStart = parseVodStartFromFilename(filePath);
        const norm = path.normalize(filePath).toLowerCase();
        let vod = state.vods.find((item) => item && item.filePath && path.normalize(String(item.filePath)).toLowerCase() === norm);
        if (!vod) {
          vod = sanitizeVodRecord({
            id: `vod_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`,
            filePath,
            label: path.basename(filePath),
            sourceName,
            importedAt: new Date().toISOString(),
            bytes: stat.size,
            startIso: filenameStart ? filenameStart.iso : '',
            suggestedStartIso: filenameStart ? filenameStart.iso : '',
            suggestedStartLabel: filenameStart ? filenameStart.label : ''
          });
          state.vods.unshift(vod);
        } else {
          vod = sanitizeVodRecord({
            ...vod,
            bytes: stat.size,
            label: vod.label || path.basename(filePath),
            startIso: vod.startIso || (filenameStart ? filenameStart.iso : ''),
            suggestedStartIso: vod.suggestedStartIso || (filenameStart ? filenameStart.iso : ''),
            suggestedStartLabel: vod.suggestedStartLabel || (filenameStart ? filenameStart.label : '')
          });
          state.vods = state.vods.filter((item) => !item || item.id !== vod.id);
          state.vods.unshift(vod);
        }
        imported.push(vod);
      } catch (error) {
        skipped.push({ filePath, reason: error && error.message ? error.message : 'Import failed' });
      }
    }
    return { imported, skipped };
  }

  return {
    looksLikeVodVideoFile,
    sanitizeVodRecord,
    defaultVideoPreRollSec,
    matchReplayStartMs,
    isAddonOnlyTimingMatch,
    estimatedAddonOnlyDurationSec,
    matchTimeRangeMs,
    boundedMatchTimeRangeMs,
    vodClipCandidatesForState,
    recordingSessionVodId,
    recordingTimeRangeMs,
    upsertRecordingSessionVod,
    refreshVideoLinkIndexes,
    repairTinyVideoSectionClips,
    linkRecordingSessionToMatches,
    normalizeFilePathList,
    importVodPathsIntoState
  };
}

module.exports = { createVodLinkingTools };
