'use strict';

function createPvPHelperCharacterTools(deps = {}) {
  const WOW_CLASS_COLORS = deps.WOW_CLASS_COLORS || {};
  const hashText = typeof deps.hashText === 'function' ? deps.hashText : (value) => String(value || '');
  const metaForSpec = typeof deps.metaForSpec === 'function' ? deps.metaForSpec : () => null;
  const cleanBracketName = typeof deps.cleanBracketName === 'function' ? deps.cleanBracketName : (value) => String(value || 'Unknown Bracket');
  const firstDefinedNumber = typeof deps.firstDefinedNumber === 'function' ? deps.firstDefinedNumber : () => null;

function normalizeCharacterSnapshot(raw, sourceFile = '') {
  const item = raw && typeof raw === 'object' ? raw : {};
  const character = String(item.character || item.characterName || item.name || item.player || item.toon || item.fullName || '').trim();
  if (!character) return [];
  const capturedAt = item.capturedAt || item.timestamp || item.date || item.updatedAt || new Date().toISOString();
  const specId = firstDefinedNumber(item.specId, item.specializationId, item.spec);
  const meta = specId ? metaForSpec(specId) : null;
  const specName = item.specName || item.specialization || (meta && meta.specName) || '';
  const className = item.className || item.class || (meta && meta.className) || '';
  const bracketSource = item.brackets || item.ratings || item.pvp || item.modes || {};
  const rows = [];
  const entries = Array.isArray(bracketSource)
    ? bracketSource.map((entry) => [entry && (entry.bracket || entry.mode || entry.name || entry.type), entry])
    : Object.entries(bracketSource || {});
  for (const [key, value] of entries) {
    const bracketData = value && typeof value === 'object' ? value : { rating: value };
    const bracket = cleanBracketName(bracketData.bracket || bracketData.mode || key);
    const rating = firstDefinedNumber(bracketData.rating, bracketData.currentRating, bracketData.cr, bracketData.personalRating, bracketData.value);
    const seasonWon = firstDefinedNumber(bracketData.seasonWon, bracketData.won, bracketData.wins, bracketData.weeklyWon, bracketData.blizzardWins);
    const seasonPlayed = firstDefinedNumber(bracketData.seasonPlayed, bracketData.played, bracketData.games, bracketData.weeklyPlayed, bracketData.blizzardPlayed);
    const seasonLost = firstDefinedNumber(bracketData.seasonLost, bracketData.lost, bracketData.losses, bracketData.blizzardLosses);
    const mmr = firstDefinedNumber(bracketData.mmr, bracketData.matchmakingRating);
    rows.push({
      id: hashText(`${character}|${specId || specName}|${bracket}|${capturedAt}|${rating}|${seasonWon}|${seasonPlayed}|${sourceFile}`),
      character,
      specId: specId || null,
      specName,
      className,
      classColor: className && WOW_CLASS_COLORS[className] ? WOW_CLASS_COLORS[className] : '',
      bracket,
      rating,
      mmr,
      seasonWon,
      seasonLost: seasonLost != null ? seasonLost : (seasonPlayed != null && seasonWon != null ? Math.max(0, seasonPlayed - seasonWon) : null),
      seasonPlayed: seasonPlayed != null ? seasonPlayed : (seasonWon != null && seasonLost != null ? seasonWon + seasonLost : null),
      capturedAt: new Date(capturedAt).toString() === 'Invalid Date' ? new Date().toISOString() : new Date(capturedAt).toISOString(),
      sourceFile
    });
  }
  return rows;
}

function collectCharacterSnapshotsFromObject(obj, sourceFile = '') {
  const out = [];
  if (!obj) return out;
  if (Array.isArray(obj)) {
    for (const item of obj) out.push(...collectCharacterSnapshotsFromObject(item, sourceFile));
    return out;
  }
  if (typeof obj !== 'object') return out;
  out.push(...normalizeCharacterSnapshot(obj, sourceFile));
  for (const key of ['characters', 'toons', 'players', 'snapshots']) {
    const value = obj[key];
    if (Array.isArray(value)) out.push(...collectCharacterSnapshotsFromObject(value, sourceFile));
    else if (value && typeof value === 'object') {
      for (const [name, child] of Object.entries(value)) {
        if (child && typeof child === 'object' && !child.character && !child.name) child.character = name;
        out.push(...collectCharacterSnapshotsFromObject(child, sourceFile));
      }
    }
  }
  return out;
}

function parseCharacterSnapshotText(raw, sourceFile = '') {
  const text = String(raw || '').trim();
  if (!text) return [];
  try { return collectCharacterSnapshotsFromObject(JSON.parse(text), sourceFile); } catch (_error) {}
  const rows = [];
  const characterMatch = text.match(/character\s*=\s*["']([^"']+)["']/i) || text.match(/characterName\s*=\s*["']([^"']+)["']/i);
  const character = characterMatch ? characterMatch[1] : '';
  if (!character) return rows;
  const capturedAtMatch = text.match(/capturedAt\s*=\s*["']([^"']+)["']/i) || text.match(/date\s*=\s*["']([^"']+)["']/i);
  const capturedAt = capturedAtMatch ? capturedAtMatch[1] : new Date().toISOString();
  const ratingPattern = /([A-Za-z0-9 _-]*(?:2v2|3v3|shuffle|blitz|battleground|skirmish)[A-Za-z0-9 _-]*)[^\n\r{]*(?:rating|cr)\s*=\s*(\d+)/gi;
  let match;
  while ((match = ratingPattern.exec(text))) {
    rows.push({
      id: hashText(`${character}|${match[1]}|${capturedAt}|${match[2]}|${sourceFile}`),
      character,
      specId: null,
      specName: '',
      className: '',
      classColor: '',
      bracket: cleanBracketName(match[1]),
      rating: Number(match[2]),
      mmr: null,
      seasonWon: null,
      seasonLost: null,
      seasonPlayed: null,
      capturedAt: new Date(capturedAt).toString() === 'Invalid Date' ? new Date().toISOString() : new Date(capturedAt).toISOString(),
      sourceFile
    });
  }
  return rows;
}


  return {
    normalizeCharacterSnapshot,
    collectCharacterSnapshotsFromObject,
    parseCharacterSnapshotText
  };
}

module.exports = { createPvPHelperCharacterTools };
