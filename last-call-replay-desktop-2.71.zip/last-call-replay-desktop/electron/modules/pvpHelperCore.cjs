'use strict';

function createPvPHelperCoreTools() {
  function cleanBracketName(value) {
    const raw = String(value || '').trim();
    const lower = raw.toLowerCase();
    if (lower.includes('2v2') || /^(2s|2['’]?s|two)/.test(lower) || lower === '2' || lower === 'arena 2') return '2v2';
    if (lower.includes('3v3') || /^(3s|3['’]?s|three)/.test(lower) || lower === '3' || lower === 'arena 3') return '3v3';
    if (/solo.*shuffle|shuffle/.test(lower)) return 'Solo Shuffle';
    if (/blitz/.test(lower)) return 'Battleground Blitz';
    if (/rated.*battle|\brbg\b/.test(lower)) return 'Rated Battleground';
    if (/random.*battle|\bbg\b/.test(lower)) return 'Random Battleground';
    if (lower === 'battleground' || lower === 'bg' || /battleground/.test(lower)) return 'Random Battleground';
    if (/skirm/.test(lower)) return 'Skirmish';
    return raw || 'Unknown Bracket';
  }

  function isArenaBracket(value = '') {
    const bracket = cleanBracketName(value);
    return bracket === '2v2' || bracket === '3v3' || bracket === 'Skirmish' || bracket === 'Solo Shuffle';
  }

  function strongerMatchType(baseType = '', addonType = '') {
    const base = cleanBracketName(baseType);
    const addon = cleanBracketName(addonType);
    if (isArenaBracket(base)) return base;
    if (isArenaBracket(addon)) return addon;
    if (base === 'Battleground Blitz' || addon === 'Battleground Blitz') return 'Battleground Blitz';
    if (base === 'Rated Battleground' || addon === 'Rated Battleground') return 'Rated Battleground';
    if (base === 'Random Battleground' || addon === 'Random Battleground') return 'Random Battleground';
    return base || addon || 'PvP Match';
  }

  function firstDefinedNumber(...values) {
    for (const value of values) {
      if (value === null || value === undefined || value === '') continue;
      const n = Number(value);
      if (Number.isFinite(n)) return n;
    }
    return null;
  }

  function objectArrayLikeToArray(value) {
    if (Array.isArray(value)) return value.filter(Boolean);
    if (!value || typeof value !== 'object') return [];
    const entries = Object.entries(value).filter(([key]) => /^\d+$/.test(String(key))).sort((a, b) => Number(a[0]) - Number(b[0])).map(([, item]) => item).filter(Boolean);
    return entries;
  }

  function firstTextValue(...values) {
    for (const value of values) {
      if (value === undefined || value === null) continue;
      const text = String(value).trim();
      if (text) return text;
    }
    return '';
  }

  function parseBooleanish(value) {
    if (value === undefined || value === null) return null;
    if (typeof value === 'boolean') return value;
    if (typeof value === 'number') {
      if (value === 1) return true;
      if (value === 0) return false;
      return null;
    }
    const text = String(value).trim().toLowerCase();
    if (!text) return null;
    if (['true', '1', 'on', 'yes', 'enabled'].includes(text)) return true;
    if (['false', '0', 'off', 'no', 'disabled'].includes(text)) return false;
    return null;
  }

  function firstBooleanStatus(candidates = []) {
    for (const candidate of candidates) {
      if (!candidate) continue;
      const value = Object.prototype.hasOwnProperty.call(candidate, 'value') ? candidate.value : candidate;
      const parsed = parseBooleanish(value);
      if (parsed === null) continue;
      return { known: true, value: parsed, source: candidate.source || '' };
    }
    return { known: false, value: null, source: '' };
  }

  function clonePlainValue(value) {
    if (value === undefined) return undefined;
    if (value === null) return null;
    try { return JSON.parse(JSON.stringify(value)); } catch (_error) { return value; }
  }

  function normalizeTimestampToIso(value) {
    if (value === undefined || value === null || value === '') return new Date().toISOString();
    if (typeof value === 'number' || /^\d+(\.\d+)?$/.test(String(value))) {
      const n = Number(value);
      const ms = n > 100000000000 ? n : n * 1000;
      const d = new Date(ms);
      return d.toString() === 'Invalid Date' ? new Date().toISOString() : d.toISOString();
    }
    const d = new Date(value);
    return d.toString() === 'Invalid Date' ? new Date().toISOString() : d.toISOString();
  }

  function splitPlayerRealm(value = '', fallbackRealm = '') {
    const raw = String(value || '').trim();
    const parts = raw.split('-');
    const name = parts[0] || raw || 'Unknown';
    const realm = parts.length > 1 ? parts.slice(1).join('-') : String(fallbackRealm || '').trim();
    return { name, realm, fullName: realm ? `${name}-${realm}` : name };
  }

  return {
    cleanBracketName,
    strongerMatchType,
    firstDefinedNumber,
    objectArrayLikeToArray,
    firstTextValue,
    parseBooleanish,
    firstBooleanStatus,
    clonePlainValue,
    normalizeTimestampToIso,
    splitPlayerRealm
  };
}

module.exports = { createPvPHelperCoreTools };
