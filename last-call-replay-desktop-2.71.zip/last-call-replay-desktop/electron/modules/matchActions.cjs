'use strict';

function createMatchActionTools(deps = {}) {
  const ipcMain = deps.ipcMain;
  const readState = deps.readState;
  const writeState = deps.writeState;
  const mergeAddonScoreboardIntoMatch = deps.mergeAddonScoreboardIntoMatch;
  const dedupeStateMatches = deps.dedupeStateMatches;
  const compactRecentMatchesForResponse = deps.compactRecentMatchesForResponse || ((state) => state.matches || []);
  const compactMutationCollections = deps.compactMutationCollections || ((state, extras = {}) => extras || {});
  const compactRecordingsForResponse = deps.compactRecordingsForResponse || ((state) => state.recordings || []);
  const uniqueList = deps.uniqueList || ((items = []) => Array.from(new Set((items || []).filter(Boolean))));
  const isSoloShuffleLobbyMatch = deps.isSoloShuffleLobbyMatch || (() => false);

  if (!ipcMain || typeof ipcMain.handle !== 'function') throw new Error('matchActions requires ipcMain.');
  if (typeof readState !== 'function') throw new Error('matchActions requires readState.');
  if (typeof writeState !== 'function') throw new Error('matchActions requires writeState.');
  if (typeof mergeAddonScoreboardIntoMatch !== 'function') throw new Error('matchActions requires mergeAddonScoreboardIntoMatch.');
  if (typeof dedupeStateMatches !== 'function') throw new Error('matchActions requires dedupeStateMatches.');

  function linkScoreboardToMatch(payload = {}) {
    const state = readState();
    const matchId = payload && payload.matchId ? String(payload.matchId) : '';
    const scoreboardMatchId = payload && payload.scoreboardMatchId ? String(payload.scoreboardMatchId) : '';
    if (!matchId || !scoreboardMatchId) return { ok: false, reason: 'Choose a match and a scoreboard snapshot.' };

    const target = (state.matches || []).find((match) => match && match.id === matchId);
    const scoreboard = (state.matches || []).find((match) => match && match.id === scoreboardMatchId);
    if (!target) return { ok: false, reason: 'Match not found.' };
    if (!scoreboard) return { ok: false, reason: 'Scoreboard snapshot not found.' };
    if (!Array.isArray(scoreboard.scoreboardPlayers) || !scoreboard.scoreboardPlayers.length) return { ok: false, reason: 'That match does not have scoreboard players.' };

    const mergedTarget = mergeAddonScoreboardIntoMatch(target, scoreboard, 'manual');
    state.matches = (state.matches || []).map((match) => {
      if (!match) return match;
      if (match.id === matchId) return mergedTarget;
      if (match.id === scoreboardMatchId) return { ...match, scoreboardLinkedToMatchId: matchId };
      return match;
    });

    const sourceIsDisposableShell = scoreboard.createdFromAddon && !scoreboard.createdFromRealLog && !scoreboard.favorite && scoreboard.id !== matchId;
    if (sourceIsDisposableShell) {
      state.matches = state.matches.filter((match) => match && match.id !== scoreboardMatchId);
    }

    dedupeStateMatches(state);
    writeState(state);
    return { ok: true, changedMatches: compactRecentMatchesForResponse(state, 80), removedMatchIds: uniqueList(state._removedDuplicateMatchIds || []) };
  }

  function deleteMatch(payload = {}) {
    const state = readState();
    const matchId = payload && payload.matchId ? String(payload.matchId) : '';
    if (!matchId) return { ok: false, reason: 'Match not found' };

    const targetMatch = (state.matches || []).find((match) => match && match.id === matchId);
    if (targetMatch && targetMatch.favorite) return { ok: false, reason: 'Favorite matches are protected. Unfavorite this match before deleting it.' };

    const removedIds = [matchId];
    if (targetMatch && isSoloShuffleLobbyMatch(targetMatch)) {
      for (const child of state.matches || []) {
        if (child && child.parentLobbyMatchId === matchId && child.id) removedIds.push(String(child.id));
      }
    }

    state.deletedMatchIds = Array.from(new Set([...(state.deletedMatchIds || []), ...removedIds]));
    const removed = new Set(removedIds);
    state.matches = (state.matches || []).filter((match) => match && !removed.has(String(match.id || '')));
    state.recordings = (state.recordings || []).map((rec) => rec && removed.has(String(rec.matchId || '')) ? { ...rec, matchId: '' } : rec);
    writeState(state);
    return { ok: true, removedMatchIds: removedIds, ...compactMutationCollections(state, { changedRecordings: compactRecordingsForResponse(state, 80) }) };
  }

  function hidePlayer(payload = {}) {
    const state = readState();
    const playerName = payload && payload.playerName ? String(payload.playerName) : '';
    if (!playerName) return { ok: false, reason: 'Player not found' };
    state.hiddenPlayers = Array.from(new Set([...(state.hiddenPlayers || []), playerName]));
    writeState(state);
    return { ok: true, hiddenPlayers: state.hiddenPlayers };
  }

  function registerIpcHandlers() {
    ipcMain.handle('link-scoreboard-to-match', async (_event, payload) => linkScoreboardToMatch(payload));
    ipcMain.handle('delete-match', async (_event, payload) => deleteMatch(payload));
    ipcMain.handle('hide-player', async (_event, payload) => hidePlayer(payload));
  }

  return {
    linkScoreboardToMatch,
    deleteMatch,
    hidePlayer,
    registerIpcHandlers
  };
}

module.exports = { createMatchActionTools };
