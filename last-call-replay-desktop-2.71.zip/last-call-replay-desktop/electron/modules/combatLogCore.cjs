function createCombatLogCoreTools(deps = {}) {
  const {
    hashText = (value) => String(value || '')
  } = deps;

function parseCsvLine(line) {
  const pieces = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
      continue;
    }
    if (char === ',' && !inQuotes) {
      pieces.push(current);
      current = '';
      continue;
    }
    current += char;
  }
  pieces.push(current);
  return pieces;
}


function parseHexFlag(value) {
  const raw = String(value || '').trim();
  if (!raw) return 0;
  const cleaned = raw.startsWith('0x') || raw.startsWith('0X') ? raw.slice(2) : raw;
  const parsed = parseInt(cleaned, 16);
  return Number.isFinite(parsed) ? parsed : 0;
}

function hasMineFlag(value) {
  return (parseHexFlag(value) & 0x00000001) !== 0;
}

function cleanUnitName(value) {
  const raw = String(value || '').replace(/^"|"$/g, '').trim();
  if (!raw || raw === 'nil' || raw === '0000000000000000') return 'Unknown';
  return raw;
}

function cleanSpellName(value) {
  return String(value || '').replace(/^"|"$/g, '').trim();
}

function normalizedMapKey(value) {
  return String(value || '').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim();
}

function numberField(fields, index) {
  if (!Array.isArray(fields) || index < 0 || index >= fields.length) return 0;
  const parsed = Number(fields[index]);
  return Number.isFinite(parsed) ? parsed : 0;
}

function isSupportCombatEvent(event) {
  return /_SUPPORT$/i.test(String(event || ''));
}

function eventAmountFromFields(event, fields) {
  const ev = String(event || '');
  if (ev === 'DAMAGE_SPLIT') return numberField(fields, 37);
  if (ev.startsWith('SWING')) return isSupportCombatEvent(ev) ? numberField(fields, 31) : numberField(fields, 28);
  if (ev.startsWith('ENVIRONMENTAL')) return numberField(fields, 29);
  if (ev.includes('DAMAGE') || ev.includes('HEAL')) return numberField(fields, 31) || numberField(fields, 32);
  return 0;
}

function advancedHealthFromFields(event, fields) {
  const ev = String(event || '');
  if (ev.startsWith('SWING') && !isSupportCombatEvent(ev)) {
    return { current: numberField(fields, 11), max: numberField(fields, 12) };
  }
  if (ev.startsWith('ENVIRONMENTAL')) {
    return { current: numberField(fields, 11), max: numberField(fields, 12) };
  }
  if (ev.includes('DAMAGE') || ev.includes('HEAL')) {
    return { current: numberField(fields, 14), max: numberField(fields, 15) };
  }
  return { current: 0, max: 0 };
}

function parseLogStamp(stamp) {
  const match = String(stamp || '').match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\s+(\d{1,2}):(\d{2}):(\d{2})\.(\d{1,3})/);
  if (!match) return { absoluteMs: 0, iso: '', label: stamp || '' };

  const now = new Date();
  const month = Number(match[1]) - 1;
  const day = Number(match[2]);
  let year = match[3] ? Number(match[3]) : now.getFullYear();
  if (year < 100) year += 2000;
  const hour = Number(match[4]);
  const minute = Number(match[5]);
  const second = Number(match[6]);
  const milli = Number(match[7].padEnd(3, '0'));
  const date = new Date(year, month, day, hour, minute, second, milli);
  return {
    absoluteMs: date.getTime(),
    iso: date.toISOString(),
    label: `${month + 1}/${day}/${year} ${hour}:${String(minute).padStart(2, '0')}:${String(second).padStart(2, '0')}`
  };
}

function parseCombatLine(line) {
  const trimmed = String(line || '').trim();
  if (!trimmed) return null;

  const match = trimmed.match(/^(\d{1,2}\/\d{1,2}(?:\/\d{2,4})?\s+\d{1,2}:\d{2}:\d{2}\.\d{1,3})(?:[-+]\d+)?\s+(.*)$/);
  if (!match) return null;

  const stamp = match[1];
  const rest = match[2];
  const fields = parseCsvLine(rest);
  const event = fields[0] || '';
  if (!event || event === 'COMBAT_LOG_VERSION') return null;

  const stampInfo = parseLogStamp(stamp);
  const isSwing = event.startsWith('SWING');
  const isEnvironmental = event.startsWith('ENVIRONMENTAL');
  const isCombatant = event === 'COMBATANT_INFO';
  const isArenaStart = event === 'ARENA_MATCH_START';
  const isArenaEnd = event === 'ARENA_MATCH_END';
  const isZoneChange = event === 'ZONE_CHANGE';

  let sourceGuid = '';
  let sourceName = 'Unknown';
  let sourceFlags = '';
  let destGuid = '';
  let destName = 'Unknown';
  let destFlags = '';
  let spellId = '';
  let spellName = '';
  let extraSpellId = '';
  let extraSpellName = '';
  let auraType = '';
  let amount = 0;
  let targetCurrentHealth = 0;
  let targetMaxHealth = 0;
  let isCritical = false;
  let isFeignDeath = false;

  if (isZoneChange) {
    spellId = fields[1] || '';
    spellName = cleanSpellName(fields[2] || 'Zone Change');
  } else if (isArenaStart) {
    spellId = fields[1] || '';
    spellName = cleanSpellName(fields[3] || 'Arena Match Start');
  } else if (isArenaEnd) {
    spellId = fields[1] || '';
    spellName = 'Arena Match End';
  } else if (isCombatant) {
    sourceGuid = fields[1] || '';
    sourceName = 'Unknown';
    sourceFlags = '';
    spellName = 'Combatant Info';
  } else if (isSwing) {
    sourceGuid = fields[1] || '';
    sourceName = cleanUnitName(fields[2]);
    sourceFlags = fields[3] || '';
    destGuid = fields[5] || '';
    destName = cleanUnitName(fields[6]);
    destFlags = fields[7] || '';
    spellId = isSupportCombatEvent(event) ? (fields[9] || '') : '';
    spellName = isSupportCombatEvent(event) ? cleanSpellName(fields[10] || 'Melee Support') : 'Melee';
    amount = eventAmountFromFields(event, fields);
    const hp = advancedHealthFromFields(event, fields);
    targetCurrentHealth = hp.current;
    targetMaxHealth = hp.max;
  } else if (isEnvironmental) {
    sourceGuid = fields[1] || '';
    sourceName = cleanUnitName(fields[2]);
    sourceFlags = fields[3] || '';
    destGuid = fields[5] || '';
    destName = cleanUnitName(fields[6]);
    destFlags = fields[7] || '';
    spellName = cleanSpellName(fields[28] || 'Environmental');
    amount = eventAmountFromFields(event, fields);
    const hp = advancedHealthFromFields(event, fields);
    targetCurrentHealth = hp.current;
    targetMaxHealth = hp.max;
  } else {
    sourceGuid = fields[1] || '';
    sourceName = cleanUnitName(fields[2]);
    sourceFlags = fields[3] || '';
    destGuid = fields[5] || '';
    destName = cleanUnitName(fields[6]);
    destFlags = fields[7] || '';
    spellId = fields[9] || '';
    spellName = cleanSpellName(fields[10]);
    auraType = cleanSpellName(fields[12] || '');
    if (event.includes('INTERRUPT') || event.includes('DISPEL') || event.includes('STOLEN')) {
      extraSpellId = fields[12] || '';
      extraSpellName = cleanSpellName(fields[13] || '');
      if (event.includes('DISPEL') || event.includes('STOLEN')) {
        auraType = cleanSpellName(fields[15] || '');
      }
    }
    if (event.includes('DAMAGE') || event.includes('HEAL')) {
      amount = eventAmountFromFields(event, fields);
      const hp = advancedHealthFromFields(event, fields);
      targetCurrentHealth = hp.current;
      targetMaxHealth = hp.max;
      // In advanced combat log payloads, critical is commonly a boolean flag shortly after amount/overkill/school.
      // Keep this heuristic defensive so unknown formats never break parsing.
      isCritical = ['1', 'true', 'TRUE'].includes(String(fields[38] || fields[35] || '').trim());
    }
  }

  if (event === 'UNIT_DIED') {
    // WoW can emit UNIT_DIED-like rows for feign/pretend deaths.
    // In the observed advanced log shape, the final field is 1 for these false deaths.
    isFeignDeath = String(fields[9] || '').trim() === '1' || /feign death/i.test(spellName);
  }

  return {
    stamp,
    timestampLabel: stampInfo.label,
    absoluteMs: stampInfo.absoluteMs,
    iso: stampInfo.iso,
    event,
    fields,
    sourceGuid,
    sourceName,
    sourceFlags,
    destGuid,
    destName,
    destFlags,
    spellId,
    spellName,
    extraSpellId,
    extraSpellName,
    auraType,
    amount,
    targetCurrentHealth,
    targetMaxHealth,
    targetHealthPct: targetMaxHealth ? Math.max(0, Math.min(100, (targetCurrentHealth / targetMaxHealth) * 100)) : null,
    isCritical,
    isFeignDeath,
    raw: trimmed,
    hash: hashText(trimmed)
  };
}

function eventKind(event) {
  if (!event) return 'other';
  if (event === 'ARENA_MATCH_START') return 'match_start';
  if (event === 'ARENA_MATCH_END') return 'match_end';
  if (event === 'COMBATANT_INFO') return 'combatant';
  if (event === 'ZONE_CHANGE') return 'zone';
  if (event === 'DAMAGE_SPLIT') return 'split';
  if (event.includes('DAMAGE')) return 'damage';
  if (event.includes('HEAL')) return 'healing';
  if (event.includes('AURA_APPLIED')) return 'aura';
  if (event.includes('AURA_REMOVED')) return 'aura_removed';
  if (event.includes('CAST_SUCCESS')) return 'cast';
  if (event.includes('INTERRUPT')) return 'interrupt';
  if (event.includes('DISPEL') || event.includes('STOLEN')) return 'dispel';
  if (event.includes('UNIT_DIED')) return 'death';
  return 'other';
}


function combatFlagMask(flags) {
  const raw = String(flags || '').trim();
  if (!raw) return 0;
  const parsed = raw.toLowerCase().startsWith('0x') ? parseInt(raw, 16) : Number(raw);
  return Number.isFinite(parsed) ? parsed : 0;
}

function combatReaction(flags) {
  const mask = combatFlagMask(flags);
  if (mask & 0x00000040) return 'hostile';
  if (mask & 0x00000010) return 'friendly';
  if (mask & 0x00000020) return 'neutral';
  return '';
}

function combatRelationForEvent(ev, teamByGuid = new Map()) {
  if (!ev) return '';
  const sourceTeam = ev.sourceGuid ? teamByGuid.get(ev.sourceGuid) : '';
  const destTeam = ev.destGuid ? teamByGuid.get(ev.destGuid) : '';
  if (sourceTeam !== undefined && sourceTeam !== null && sourceTeam !== '' && destTeam !== undefined && destTeam !== null && destTeam !== '') {
    return String(sourceTeam) === String(destTeam) ? 'same' : 'opponent';
  }
  const sourceReaction = combatReaction(ev.sourceFlags);
  const destReaction = combatReaction(ev.destFlags);
  if (sourceReaction && destReaction && sourceReaction !== 'neutral' && destReaction !== 'neutral') {
    return sourceReaction === destReaction ? 'same' : 'opponent';
  }
  return '';
}

function isOffensivePurgeEvent(ev, teamByGuid = new Map()) {
  if (!ev) return false;
  const eventName = String(ev.event || '');
  if (eventName.includes('STOLEN')) return true;
  const removedAuraType = String(ev.auraType || '').toUpperCase();
  if (removedAuraType === 'BUFF') return true;
  if (removedAuraType === 'DEBUFF') return false;
  if (isKnownOffensivePurgeSpell(ev.spellName || ev.dispelSpellName)) return true;
  return combatRelationForEvent(ev, teamByGuid) === 'opponent';
}


function isBattlegroundObjectiveEvent(ev) {
  if (!ev) return false;
  const text = `${ev.spellName || ''} ${ev.extraSpellName || ''} ${ev.raw || ''}`;
  return /flag|orb|cart|mine|assault|defend|captur|base|graveyard|victory|horde|alliance/i.test(text);
}

function isBattlegroundTailAnchorEvent(ev) {
  if (!ev) return false;
  const kind = eventKind(ev.event);
  if (['damage', 'healing', 'death', 'interrupt', 'dispel'].includes(kind)) return true;
  if ((kind === 'aura' || kind === 'aura_removed' || kind === 'cast') && isBattlegroundObjectiveEvent(ev)) return true;
  return false;
}

function trimBattlegroundSegmentNoise(segment = []) {
  const rows = Array.isArray(segment) ? segment.filter(Boolean) : [];
  if (rows.length < 2) return rows;
  let lastAnchor = -1;
  for (let i = rows.length - 1; i >= 0; i -= 1) {
    if (isBattlegroundTailAnchorEvent(rows[i])) {
      lastAnchor = i;
      break;
    }
  }
  if (lastAnchor < 0) return rows;
  // WoW can dump home-city/world auras immediately before the ZONE_CHANGE row that
  // leaves a BG. Those rows pollute rosters/metrics with players who were never in
  // the match. Keep a small tail buffer after the last real BG combat/objective row,
  // but trim long aura-only dumps.
  const anchorMs = Number(rows[lastAnchor].absoluteMs) || 0;
  let safeEnd = lastAnchor;
  for (let i = lastAnchor + 1; i < rows.length; i += 1) {
    const ev = rows[i];
    const ms = Number(ev.absoluteMs) || anchorMs;
    if (anchorMs && ms - anchorMs > 2500) break;
    if (ev.event === 'ZONE_CHANGE') break;
    safeEnd = i;
  }
  return rows.slice(0, Math.max(lastAnchor + 1, safeEnd + 1));
}


const knownOffensivePurgeSpells = new Set([
  'tranquilizing shot', 'purge', 'greater purge', 'spellsteal', 'consume magic', 'devour magic', 'dispel magic', 'arcane torrent'
]);

function isKnownOffensivePurgeSpell(name) {
  return knownOffensivePurgeSpells.has(String(name || '').replace(/^\"|\"$/g, '').trim().toLowerCase());
}

function formatDuration(seconds) {
  const safe = Math.max(0, Math.round(Number(seconds) || 0));
  const minutes = Math.floor(safe / 60);
  const secs = safe % 60;
  return `${minutes}:${String(secs).padStart(2, '0')}`;
}

function durationSecondsFromValue(value) {
  if (value === undefined || value === null || value === '') return 0;
  if (typeof value === 'number' && Number.isFinite(value)) {
    return Math.max(0, Math.round(value > 10000 ? value / 1000 : value));
  }
  const raw = String(value || '').trim();
  if (!raw) return 0;
  const numeric = Number(raw);
  if (Number.isFinite(numeric)) return Math.max(0, Math.round(numeric > 10000 ? numeric / 1000 : numeric));
  const clock = raw.match(/^(?:(\d+)\s*:)?(\d+)\s*:(\d+)$/);
  if (clock) {
    const hours = Number(clock[1] || 0);
    const minutes = Number(clock[2] || 0);
    const seconds = Number(clock[3] || 0);
    return Math.max(0, Math.round(hours * 3600 + minutes * 60 + seconds));
  }
  const shortClock = raw.match(/^(\d+)\s*:(\d+)$/);
  if (shortClock) return Math.max(0, Math.round(Number(shortClock[1]) * 60 + Number(shortClock[2])));
  const hours = Number((raw.match(/(\d+(?:\.\d+)?)\s*h/i) || [])[1] || 0);
  const minutes = Number((raw.match(/(\d+(?:\.\d+)?)\s*m/i) || [])[1] || 0);
  const seconds = Number((raw.match(/(\d+(?:\.\d+)?)\s*s/i) || [])[1] || 0);
  const total = hours * 3600 + minutes * 60 + seconds;
  return Number.isFinite(total) ? Math.max(0, Math.round(total)) : 0;
}

function relativeLabel(relativeSec) {
  return formatDuration(relativeSec);
}

function isUsefulUnitName(name) {
  const n = String(name || '').trim();
  return n && n !== 'Unknown' && n !== 'nil' && !n.startsWith('0x') && !/^Creature-/.test(n) && !/^GameObject-/.test(n);
}

function isPlayerGuid(guid) {
  return /^Player-/.test(String(guid || ''));
}

function noteOwnCandidate(ev, current = {}) {
  const candidate = { guid: current.guid || '', name: current.name || '' };
  if (isPlayerGuid(ev.sourceGuid) && hasMineFlag(ev.sourceFlags) && isUsefulUnitName(ev.sourceName)) {
    candidate.guid = ev.sourceGuid;
    candidate.name = ev.sourceName;
  }
  if (isPlayerGuid(ev.destGuid) && hasMineFlag(ev.destFlags) && isUsefulUnitName(ev.destName)) {
    candidate.guid = ev.destGuid;
    candidate.name = ev.destName;
  }
  return candidate;
}



  return {
    parseCsvLine,
    parseHexFlag,
    hasMineFlag,
    cleanUnitName,
    cleanSpellName,
    normalizedMapKey,
    numberField,
    isSupportCombatEvent,
    eventAmountFromFields,
    advancedHealthFromFields,
    parseLogStamp,
    parseCombatLine,
    eventKind,
    combatFlagMask,
    combatReaction,
    combatRelationForEvent,
    isOffensivePurgeEvent,
    isBattlegroundObjectiveEvent,
    isBattlegroundTailAnchorEvent,
    trimBattlegroundSegmentNoise,
    isKnownOffensivePurgeSpell,
    formatDuration,
    durationSecondsFromValue,
    relativeLabel,
    isUsefulUnitName,
    isPlayerGuid,
    noteOwnCandidate
  };
}

module.exports = { createCombatLogCoreTools };
