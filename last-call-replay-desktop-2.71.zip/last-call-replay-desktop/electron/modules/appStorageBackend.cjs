function createAppStorageTools(deps = {}) {
  const app = deps.app;
  const fs = deps.fs;
  const path = deps.path;
  const processObj = deps.processObj || process;
  const ensureDir = typeof deps.ensureDir === 'function'
    ? deps.ensureDir
    : ((dir) => fs.mkdirSync(dir, { recursive: true }));
  const readState = typeof deps.readState === 'function' ? deps.readState : (() => ({}));
  const writeState = typeof deps.writeState === 'function' ? deps.writeState : (() => {});
  const sanitizeState = typeof deps.sanitizeState === 'function' ? deps.sanitizeState : ((state) => state || {});
  const defaultSettings = typeof deps.defaultSettings === 'function' ? deps.defaultSettings : (() => ({}));
  const buildClientStatePayload = typeof deps.buildClientStatePayload === 'function' ? deps.buildClientStatePayload : (() => ({}));

  const STORAGE_POINTER_FILE = 'LastCallReplay.storage.json';
  const PORTABLE_STORAGE_POINTER_FILE = 'LastCallReplay.portable-storage.json';
  const PORTABLE_DATA_FOLDER_NAME = 'LastCallReplayData';

  function normalizePathText(value) {
    return path.normalize(String(value || '').trim());
  }

  function samePath(a, b) {
    if (!a || !b) return false;
    return normalizePathText(a).toLowerCase() === normalizePathText(b).toLowerCase();
  }

  function pathIsInside(child, parent) {
    if (!child || !parent) return false;
    const relative = path.relative(normalizePathText(parent), normalizePathText(child));
    return Boolean(relative && !relative.startsWith('..') && !path.isAbsolute(relative));
  }

  function defaultAppStorageDir() {
    return path.join(app.getPath('userData'), 'LastCallReplay');
  }

  function storagePointerPath() {
    return path.join(app.getPath('userData'), STORAGE_POINTER_FILE);
  }

  function portableRootDir() {
    try {
      return app.isPackaged ? path.dirname(processObj.execPath) : app.getAppPath();
    } catch (_error) {
      return app.getAppPath();
    }
  }

  function portableStoragePointerPath() {
    return path.join(portableRootDir(), PORTABLE_STORAGE_POINTER_FILE);
  }

  function defaultPortableStorageDir() {
    return path.join(portableRootDir(), PORTABLE_DATA_FOLDER_NAME);
  }

  function readPointerFile(filePath, baseDir, source) {
    try {
      const raw = fs.readFileSync(filePath, 'utf8');
      const parsed = JSON.parse(raw);
      const rawDir = String(parsed && parsed.storageDir ? parsed.storageDir : '').trim();
      if (!rawDir) return null;
      const isRelative = !path.isAbsolute(rawDir);
      const dir = normalizePathText(isRelative ? path.resolve(baseDir, rawDir) : rawDir);
      return { dir, source, path: filePath, rawDir, isRelative };
    } catch (_error) {
      return null;
    }
  }

  function readStoragePointer() {
    const portable = readPointerFile(portableStoragePointerPath(), portableRootDir(), 'portable');
    if (portable && portable.dir) return portable;
    const local = readPointerFile(storagePointerPath(), path.dirname(storagePointerPath()), 'windows');
    if (local && local.dir) return local;
    return { dir: '', source: 'default', path: storagePointerPath(), rawDir: '', isRelative: false };
  }

  function writeStoragePointer(storageDir) {
    ensureDir(app.getPath('userData'));
    fs.writeFileSync(storagePointerPath(), JSON.stringify({ storageDir: normalizePathText(storageDir), updatedAt: new Date().toISOString() }, null, 2), 'utf8');
  }

  function portablePointerPayload(storageDir) {
    const root = portableRootDir();
    const normalized = normalizePathText(storageDir);
    const relative = path.relative(root, normalized);
    const canUseRelative = Boolean(relative && relative !== '' && !relative.startsWith('..') && !path.isAbsolute(relative));
    return {
      storageDir: canUseRelative ? relative : normalized,
      portable: true,
      updatedAt: new Date().toISOString(),
      note: 'Keep this file beside the app if you want Last Call Replay to use the same data folder on another computer.'
    };
  }

  function writePortableStoragePointer(storageDir) {
    const pointer = portableStoragePointerPath();
    ensureDir(path.dirname(pointer));
    fs.writeFileSync(pointer, JSON.stringify(portablePointerPayload(storageDir), null, 2), 'utf8');
    return pointer;
  }

  function resolveAppStorageDir() {
    const fallback = defaultAppStorageDir();
    const pointer = readStoragePointer();
    const configured = pointer && pointer.dir ? pointer.dir : '';
    if (configured) {
      try {
        ensureDir(configured);
        return { dir: configured, fallback, configured, pointer, customActive: !samePath(configured, fallback), warning: '' };
      } catch (error) {
        ensureDir(fallback);
        return { dir: fallback, fallback, configured, pointer, customActive: false, warning: `Custom storage folder is not available: ${error && error.message ? error.message : error}` };
      }
    }
    ensureDir(fallback);
    return { dir: fallback, fallback, configured: '', pointer, customActive: false, warning: '' };
  }

  function appStorageInfo() {
    const info = resolveAppStorageDir();
    const pointer = info.pointer || { source: 'default', path: storagePointerPath() };
    return {
      storage: info.dir,
      defaultStorage: info.fallback,
      configuredStorage: info.configured || '',
      customStorageActive: Boolean(info.customActive),
      portableStorageActive: pointer.source === 'portable',
      storagePointerSource: pointer.source || 'default',
      storageWarning: info.warning || '',
      storagePointer: storagePointerPath(),
      activeStoragePointer: pointer.path || storagePointerPath(),
      portableStoragePointer: portableStoragePointerPath(),
      portableRoot: portableRootDir(),
      defaultPortableStorage: defaultPortableStorageDir()
    };
  }

  function appStorageDir() {
    const dir = resolveAppStorageDir().dir;
    ensureDir(dir);
    ensureDir(path.join(dir, 'archives'));
    ensureDir(path.join(dir, 'recordings'));
    ensureDir(path.join(dir, 'reports'));
    return dir;
  }

  function copyDirRecursive(source, destination) {
    ensureDir(destination);
    for (const entry of fs.readdirSync(source, { withFileTypes: true })) {
      const src = path.join(source, entry.name);
      const dest = path.join(destination, entry.name);
      if (entry.isDirectory()) copyDirRecursive(src, dest);
      else if (entry.isFile()) fs.copyFileSync(src, dest);
    }
  }

  function copyAppStorageData(source, destination) {
    if (!source || !destination || samePath(source, destination)) return;
    if (!fs.existsSync(source)) {
      ensureDir(destination);
      return;
    }
    if (pathIsInside(destination, source)) {
      throw new Error('Choose a folder outside the current app storage folder.');
    }
    copyDirRecursive(source, destination);
  }

  function tryWritePortableStoragePointer(storageDir) {
    try {
      return { ok: true, path: writePortableStoragePointer(storageDir), reason: '' };
    } catch (error) {
      return { ok: false, path: portableStoragePointerPath(), reason: error && error.message ? error.message : String(error) };
    }
  }

  function prepareMovedStateForStorage(currentState, oldStorageDir, newStorageDir) {
    const oldArchiveDir = path.join(oldStorageDir, 'archives');
    const oldRecordingsDir = path.join(oldStorageDir, 'recordings');
    const movedState = sanitizeState(currentState || {});
    movedState.settings = { ...defaultSettings(), ...(movedState.settings || {}) };
    if (!movedState.settings.archiveDir || samePath(movedState.settings.archiveDir, oldArchiveDir)) {
      movedState.settings.archiveDir = path.join(newStorageDir, 'archives');
    }
    if (!movedState.settings.recordingsDir || !movedState.settings.recordingsDirConfirmed || samePath(movedState.settings.recordingsDir, oldRecordingsDir)) {
      movedState.settings.recordingsDir = path.join(newStorageDir, 'recordings');
      movedState.settings.recordingsDirConfirmed = true;
    }
    ensureDir(movedState.settings.archiveDir);
    ensureDir(movedState.settings.recordingsDir);
    ensureDir(path.join(newStorageDir, 'reports'));
    return movedState;
  }

  function migrateAppStorageTo(selectedDir, options = {}) {
    const normalizedTarget = normalizePathText(selectedDir);
    if (!normalizedTarget) return { ok: false, reason: 'No storage folder was selected.' };
    const currentDir = appStorageDir();
    if (samePath(normalizedTarget, currentDir)) {
      const portableRequired = options.portable === true;
      const portableResult = portableRequired || options.writePortable !== false
        ? tryWritePortableStoragePointer(normalizedTarget)
        : { ok: false, path: portableStoragePointerPath(), reason: 'Portable pointer was not requested.' };
      if (portableRequired && !portableResult.ok) return { ok: false, reason: `Could not create portable pointer beside the app: ${portableResult.reason}` };
      if (portableResult.ok) writeStoragePointer(normalizedTarget);
      return { ok: true, movedFrom: currentDir, movedTo: normalizedTarget, alreadyActive: true, portablePointer: portableResult.path || appStorageInfo().portableStoragePointer, portablePointerWritten: portableResult.ok, portablePointerWarning: portableResult.ok ? '' : portableResult.reason, ...buildClientStatePayload(readState()) };
    }
    if (pathIsInside(normalizedTarget, currentDir)) return { ok: false, reason: 'Choose a folder outside the current app storage folder.' };

    const currentState = readState();
    ensureDir(normalizedTarget);
    if (options.copyCurrent !== false) copyAppStorageData(currentDir, normalizedTarget);

    const portableRequired = options.portable === true;
    const portableResult = portableRequired || options.writePortable !== false
      ? tryWritePortableStoragePointer(normalizedTarget)
      : { ok: false, path: portableStoragePointerPath(), reason: 'Portable pointer was not requested.' };
    if (portableRequired && !portableResult.ok) {
      return { ok: false, reason: `Could not create portable pointer beside the app: ${portableResult.reason}` };
    }

    writeStoragePointer(normalizedTarget);
    const movedState = prepareMovedStateForStorage(currentState, currentDir, normalizedTarget);
    writeState(movedState);
    return { ok: true, movedFrom: currentDir, movedTo: normalizedTarget, portablePointer: portableResult.path, portablePointerWritten: portableResult.ok, portablePointerWarning: portableResult.ok ? '' : portableResult.reason, ...buildClientStatePayload(readState()) };
  }

  function connectAppStorageTo(selectedDir, options = {}) {
    const normalizedTarget = normalizePathText(selectedDir);
    if (!normalizedTarget) return { ok: false, reason: 'No storage folder was selected.' };
    ensureDir(normalizedTarget);
    ensureDir(path.join(normalizedTarget, 'archives'));
    ensureDir(path.join(normalizedTarget, 'recordings'));
    ensureDir(path.join(normalizedTarget, 'reports'));
    const portableResult = options.writePortable !== false
      ? tryWritePortableStoragePointer(normalizedTarget)
      : { ok: false, path: portableStoragePointerPath(), reason: 'Portable pointer was not requested.' };
    writeStoragePointer(normalizedTarget);
    return { ok: true, movedTo: normalizedTarget, connectedOnly: true, portablePointer: portableResult.path, portablePointerWritten: portableResult.ok, portablePointerWarning: portableResult.ok ? '' : portableResult.reason, ...buildClientStatePayload(readState()) };
  }

  return {
    normalizePathText,
    samePath,
    pathIsInside,
    defaultAppStorageDir,
    storagePointerPath,
    portableRootDir,
    portableStoragePointerPath,
    defaultPortableStorageDir,
    readStoragePointer,
    writeStoragePointer,
    portablePointerPayload,
    writePortableStoragePointer,
    resolveAppStorageDir,
    appStorageInfo,
    appStorageDir,
    copyDirRecursive,
    copyAppStorageData,
    tryWritePortableStoragePointer,
    prepareMovedStateForStorage,
    migrateAppStorageTo,
    connectAppStorageTo
  };
}

module.exports = { createAppStorageTools };
