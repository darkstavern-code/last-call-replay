'use strict';

function createPvPHelperTools(deps = {}) {
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const app = deps.app || null;
  const processObj = deps.processObj || process;
  const dirname = deps.dirname || __dirname;
  const ensureDir = typeof deps.ensureDir === 'function' ? deps.ensureDir : (dirPath) => { if (dirPath) fs.mkdirSync(dirPath, { recursive: true }); };
  const appStorageDir = typeof deps.appStorageDir === 'function' ? deps.appStorageDir : (() => '');
  const getDefaultLogCandidates = typeof deps.getDefaultLogCandidates === 'function' ? deps.getDefaultLogCandidates : (() => []);
  const objectArrayLikeToArray = typeof deps.objectArrayLikeToArray === 'function'
    ? deps.objectArrayLikeToArray
    : (value) => Array.isArray(value) ? value : Object.values(value || {});
  const MIN_SUPPORTED_PVPHELPER_VERSION = String(deps.minimumSupportedVersion || '0.12.8');
  const ADDON_PACKAGE_NAME = 'PvPHelper';

  function versionParts(value) {
    return String(value || '')
      .trim()
      .replace(/^v/i, '')
      .split(/[^0-9]+/)
      .filter(Boolean)
      .map((part) => Number(part) || 0);
  }

  function compareVersions(a, b) {
    const left = versionParts(a);
    const right = versionParts(b);
    const max = Math.max(left.length, right.length, 3);
    for (let index = 0; index < max; index += 1) {
      const l = left[index] || 0;
      const r = right[index] || 0;
      if (l > r) return 1;
      if (l < r) return -1;
    }
    return 0;
  }

  function firstVersionValue(...values) {
    for (const value of values) {
      const text = String(value || '').trim();
      if (/\d+\.\d+/.test(text)) return text;
    }
    return '';
  }

  function extractPvPHelperVersion(db) {
    if (!db || typeof db !== 'object') return '';
    const profile = db.profile && typeof db.profile === 'object' ? db.profile : {};
    const meta = db.meta && typeof db.meta === 'object' ? db.meta : {};
    const appStatus = db.appStatus && typeof db.appStatus === 'object' ? db.appStatus : {};
    const matchHistory = objectArrayLikeToArray(db.matchHistory || db.matches || []);
    const firstMatch = matchHistory.find((item) => item && typeof item === 'object') || {};
    return firstVersionValue(
      appStatus.addonVersion,
      appStatus.version,
      db.version,
      db.addonVersion,
      db.PvPHelperVersion,
      profile.version,
      profile.addonVersion,
      meta.version,
      meta.addonVersion,
      firstMatch.addonVersion,
      firstMatch.version
    );
  }

  function buildPvPHelperVersionStatus(version) {
    const current = String(version || '').trim();
    const minimum = MIN_SUPPORTED_PVPHELPER_VERSION;
    if (!current) {
      return {
        addonVersion: '',
        minimumSupportedAddonVersion: minimum,
        addonVersionKnown: false,
        addonNeedsUpdate: true,
        addonVersionStatus: 'unknown',
        addonVersionMessage: `Could not read the PvPHelper addon version. Update PvPHelper if syncing or scoreboard capture acts weird.`
      };
    }
    const cmp = compareVersions(current, minimum);
    if (cmp < 0) {
      return {
        addonVersion: current,
        minimumSupportedAddonVersion: minimum,
        addonVersionKnown: true,
        addonNeedsUpdate: true,
        addonVersionStatus: 'old',
        addonVersionMessage: `PvPHelper ${current} is older than the supported ${minimum}+ bridge. Update the addon for the cleanest sync.`
      };
    }
    return {
      addonVersion: current,
      minimumSupportedAddonVersion: minimum,
      addonVersionKnown: true,
      addonNeedsUpdate: false,
      addonVersionStatus: 'ok',
      addonVersionMessage: `PvPHelper ${current} looks compatible with this app.`
    };
  }

  function safeExists(filePath) {
    try { return Boolean(filePath && fs.existsSync(filePath)); } catch (_error) { return false; }
  }

  function isPathWritable(dirPath) {
    try {
      if (!dirPath) return false;
      ensureDir(dirPath);
      fs.accessSync(dirPath, fs.constants.W_OK);
      return true;
    } catch (_error) {
      return false;
    }
  }

  function getAppPathSafe() {
    try { return app && typeof app.getAppPath === 'function' ? app.getAppPath() : ''; } catch (_error) { return ''; }
  }

  function localAddonPackageDropDir() {
    const candidates = [];
    try {
      const appPath = getAppPathSafe();
      if (appPath && !String(appPath).toLowerCase().includes('.asar')) candidates.push(path.join(appPath, 'addon-packages'));
    } catch (_error) {}
    try { candidates.push(path.join(dirname, '..', 'addon-packages')); } catch (_error) {}
    try { if (processObj.execPath) candidates.push(path.join(path.dirname(processObj.execPath), 'addon-packages')); } catch (_error) {}
    try { candidates.push(path.join(appStorageDir(), 'addon-packages')); } catch (_error) {}
    const unique = Array.from(new Set(candidates.filter(Boolean)));
    for (const dir of unique) {
      if (safeExists(dir) && isPathWritable(dir)) return dir;
    }
    for (const dir of unique) {
      if (isPathWritable(dir)) return dir;
    }
    return '';
  }

  function pvpHelperPackageBaseDirs() {
    const roots = [];
    try { roots.push(localAddonPackageDropDir()); } catch (_error) {}
    try { roots.push(path.join(getAppPathSafe(), 'addon-packages')); } catch (_error) {}
    try { roots.push(path.join(dirname, '..', 'addon-packages')); } catch (_error) {}
    try { if (processObj.resourcesPath) roots.push(path.join(processObj.resourcesPath, 'app.asar.unpacked', 'addon-packages')); } catch (_error) {}
    try { if (processObj.resourcesPath) roots.push(path.join(processObj.resourcesPath, 'addon-packages')); } catch (_error) {}
    try { if (processObj.execPath) roots.push(path.join(path.dirname(processObj.execPath), 'addon-packages')); } catch (_error) {}
    return Array.from(new Set(roots.filter(Boolean)));
  }

  function pvpHelperPackageCandidates() {
    return Array.from(new Set(pvpHelperPackageBaseDirs().map((baseDir) => path.join(baseDir, ADDON_PACKAGE_NAME)).filter(Boolean)));
  }

  function resolveAddonFolderPath(folderPath) {
    if (!folderPath) return '';
    if (safeExists(path.join(folderPath, `${ADDON_PACKAGE_NAME}.toc`))) return folderPath;
    const nested = path.join(folderPath, ADDON_PACKAGE_NAME);
    if (safeExists(path.join(nested, `${ADDON_PACKAGE_NAME}.toc`))) return nested;
    return '';
  }

  function addonFolderLooksValid(folderPath) {
    return Boolean(resolveAddonFolderPath(folderPath));
  }

  function readAddonTocVersion(folderPath) {
    try {
      const addonRoot = resolveAddonFolderPath(folderPath);
      if (!addonRoot) return '';
      const tocPath = path.join(addonRoot, `${ADDON_PACKAGE_NAME}.toc`);
      if (!safeExists(tocPath)) return '';
      const raw = fs.readFileSync(tocPath, 'utf8');
      const match = raw.match(/^##\s*Version\s*:\s*(.+)$/im);
      return match ? String(match[1] || '').trim() : '';
    } catch (_error) {
      return '';
    }
  }

  function bestPvPHelperPackage() {
    const valid = pvpHelperPackageCandidates()
      .map((folderPath) => resolveAddonFolderPath(folderPath))
      .filter(Boolean)
      .map((folderPath) => ({ folderPath, version: readAddonTocVersion(folderPath) }));
    valid.sort((left, right) => {
      const versionCompare = compareVersions(right.version || '0.0.0', left.version || '0.0.0');
      if (versionCompare !== 0) return versionCompare;
      return String(left.folderPath).localeCompare(String(right.folderPath));
    });
    return valid[0] || { folderPath: '', version: '' };
  }

  function bundledPvPHelperFolder() {
    return bestPvPHelperPackage().folderPath || '';
  }

  function rootThroughRetail(filePath = '') {
    const text = String(filePath || '');
    const match = text.match(/^(.*?[\\/]_retail_)(?:[\\/]|$)/i);
    return match ? match[1] : '';
  }

  function deriveWowRetailRoot(settings = {}) {
    const candidates = [];
    if (settings.logFolderPath) candidates.push(String(settings.logFolderPath));
    if (settings.logFilePath) candidates.push(path.dirname(String(settings.logFilePath)));
    if (settings.pvpHelperSavedVariablesPath) candidates.push(String(settings.pvpHelperSavedVariablesPath));
    for (const candidate of candidates.filter(Boolean)) {
      const retailRoot = rootThroughRetail(candidate);
      if (retailRoot) return retailRoot;
      if (/logs$/i.test(path.basename(candidate))) {
        const parent = path.dirname(candidate);
        if (/^_retail_$/i.test(path.basename(parent))) return parent;
      }
    }
    const detected = getDefaultLogCandidates()[0];
    if (detected) return deriveWowRetailRoot({ logFilePath: detected });
    return '';
  }

  function pvpHelperInstallPaths(settings = {}) {
    const wowRoot = deriveWowRetailRoot(settings);
    const addonsDir = wowRoot ? path.join(wowRoot, 'Interface', 'AddOns') : '';
    const installedDir = addonsDir ? path.join(addonsDir, ADDON_PACKAGE_NAME) : '';
    const packageInfo = bestPvPHelperPackage();
    const packageDir = packageInfo.folderPath || '';
    const packageDropDir = localAddonPackageDropDir();
    return { wowRoot, addonsDir, installedDir, packageDir, packageDropDir };
  }

  function pvpHelperWtfAccountRoot(settings = {}) {
    const wowRoot = deriveWowRetailRoot(settings);
    return wowRoot ? path.join(wowRoot, 'WTF', 'Account') : '';
  }

  function safeStat(filePath) {
    try { return filePath && fs.existsSync(filePath) ? fs.statSync(filePath) : null; } catch (_error) { return null; }
  }

  function looksLikePvPHelperSavedVariables(filePath) {
    try {
      if (!filePath || !fs.existsSync(filePath) || !/PvPHelper\.lua$/i.test(path.basename(filePath))) return false;
      const stat = fs.statSync(filePath);
      if (!stat.isFile()) return false;
      const fd = fs.openSync(filePath, 'r');
      const buffer = Buffer.alloc(Math.min(stat.size || 0, 512 * 1024));
      const bytes = fs.readSync(fd, buffer, 0, buffer.length, 0);
      fs.closeSync(fd);
      return /PvPHelperDB\s*=/.test(buffer.slice(0, bytes).toString('utf8'));
    } catch (_error) {
      return false;
    }
  }

  function pvpHelperCandidateAccountName(filePath = '') {
    const parts = String(filePath || '').split(/[\\/]+/);
    const idx = parts.findIndex((part) => /^Account$/i.test(part));
    if (idx >= 0 && parts[idx + 1]) return parts[idx + 1];
    return '';
  }

  function summarizePvPHelperSavedVariablesCandidate(filePath = '', source = 'found') {
    const stat = safeStat(filePath);
    if (!stat || !stat.isFile()) return null;
    const hasDb = looksLikePvPHelperSavedVariables(filePath);
    return {
      filePath,
      source,
      accountName: pvpHelperCandidateAccountName(filePath),
      hasDb,
      sizeBytes: stat.size || 0,
      mtimeMs: stat.mtimeMs || 0,
      modifiedAt: stat.mtime ? stat.mtime.toISOString() : '',
      displayPath: filePath
    };
  }

  function selectedPvPHelperSearchRoots(selectedPath = '', settings = {}) {
    const roots = [];
    const add = (value) => {
      if (!value) return;
      try {
        const normalized = path.normalize(value);
        if (!roots.some((item) => item.toLowerCase() === normalized.toLowerCase())) roots.push(normalized);
      } catch (_error) {}
    };

    const selected = String(selectedPath || '').trim();
    if (selected) {
      const stat = safeStat(selected);
      if (stat && stat.isFile()) add(path.dirname(selected));
      else if (stat && stat.isDirectory()) add(selected);

      const parts = path.normalize(selected).split(/[\/]+/);
      const retailIndex = parts.findIndex((part) => /^_retail_$/i.test(part));
      const accountIndex = parts.findIndex((part) => /^Account$/i.test(part));
      if (accountIndex >= 0) add(parts.slice(0, accountIndex + 1).join(path.sep));
      if (retailIndex >= 0) add(path.join(parts.slice(0, retailIndex + 1).join(path.sep), 'WTF', 'Account'));
    }

    add(pvpHelperWtfAccountRoot(settings));
    add(deriveWowRetailRoot(settings) ? path.join(deriveWowRetailRoot(settings), 'WTF', 'Account') : '');
    return roots;
  }

  function sortPvPHelperCandidates(candidates = []) {
    return Array.from(candidates || []).sort((a, b) => {
      if (a.hasDb !== b.hasDb) return a.hasDb ? -1 : 1;
      return Number(b.mtimeMs || 0) - Number(a.mtimeMs || 0);
    });
  }

  function findPvPHelperSavedVariablesFromSelection(selectedPath = '', settings = {}) {
    const input = String(selectedPath || '').trim();
    if (!input) return { ok: false, reason: 'Choose your WoW SavedVariables folder or PvPHelper.lua file.' };

    const stat = safeStat(input);
    if (!stat) return { ok: false, reason: 'That path could not be found. Choose the folder that contains PvPHelper.lua.' };
    if (stat.isFile()) {
      return { ok: true, filePath: input, selectedPath: input, candidates: [summarizePvPHelperSavedVariablesCandidate(input, 'selected file')].filter(Boolean), reason: 'Selected PvPHelper.lua directly.' };
    }
    if (!stat.isDirectory()) return { ok: false, reason: 'Choose a folder or the PvPHelper.lua file.' };

    const found = new Map();
    const addCandidate = (filePath, source = 'folder search') => {
      if (!filePath) return;
      const normalized = path.normalize(filePath);
      if (found.has(normalized.toLowerCase())) return;
      const item = summarizePvPHelperSavedVariablesCandidate(normalized, source);
      if (item) found.set(normalized.toLowerCase(), item);
    };

    const directPaths = [
      path.join(input, 'PvPHelper.lua'),
      path.join(input, 'SavedVariables', 'PvPHelper.lua'),
      path.join(input, 'WTF', 'Account'),
      path.join(input, '_retail_', 'WTF', 'Account')
    ];
    directPaths.forEach((candidate) => {
      const candidateStat = safeStat(candidate);
      if (candidateStat && candidateStat.isFile()) addCandidate(candidate, 'selected folder');
    });

    const roots = selectedPvPHelperSearchRoots(input, settings);
    const walkRoots = [input, ...roots];
    let visited = 0;
    const walk = (dir, depth) => {
      if (!dir || depth < 0 || visited > 6500) return;
      const dirStat = safeStat(dir);
      if (!dirStat || !dirStat.isDirectory()) return;
      visited += 1;
      let entries = [];
      try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (_error) { return; }
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isFile() && /^PvPHelper\.lua$/i.test(entry.name)) addCandidate(full, 'folder scan');
        else if (entry.isDirectory() && depth > 0) {
          const lower = entry.name.toLowerCase();
          if (['cache', 'logs', 'screenshots', 'interface', 'addons', 'errors'].includes(lower)) continue;
          walk(full, depth - 1);
        }
      }
    };

    for (const root of walkRoots) walk(root, 5);

    const candidates = sortPvPHelperCandidates(found.values());
    const best = candidates[0] || null;
    if (!best) {
      return {
        ok: false,
        selectedPath: input,
        candidates,
        reason: 'No PvPHelper.lua was found in that folder. Try selecting WTF\\Account, your account folder, or the SavedVariables folder after logging out or typing /reload in WoW.'
      };
    }
    return {
      ok: true,
      filePath: best.filePath,
      selectedPath: input,
      best,
      candidates,
      reason: candidates.length === 1 ? 'Found PvPHelper.lua in the selected folder.' : `Found ${candidates.length} PvPHelper.lua candidates. Using the newest valid one.`
    };
  }

  function discoverPvPHelperSavedVariables(settings = {}) {
    const wowRoot = deriveWowRetailRoot(settings);
    const accountRoot = pvpHelperWtfAccountRoot(settings);
    const found = new Map();
    const addCandidate = (filePath, source = 'found') => {
      if (!filePath) return;
      const normalized = path.normalize(filePath);
      if (found.has(normalized)) return;
      const item = summarizePvPHelperSavedVariablesCandidate(normalized, source);
      if (item) found.set(normalized, item);
    };

    const mappedPath = String(settings.pvpHelperSavedVariablesPath || '');
    if (mappedPath) addCandidate(mappedPath, 'current mapping');

    if (accountRoot && fs.existsSync(accountRoot)) {
      try {
        for (const accountEntry of fs.readdirSync(accountRoot, { withFileTypes: true })) {
          if (!accountEntry.isDirectory()) continue;
          const lower = accountEntry.name.toLowerCase();
          if (lower === 'savedvariables' || lower === 'sharedmedia') continue;
          addCandidate(path.join(accountRoot, accountEntry.name, 'SavedVariables', 'PvPHelper.lua'), 'account SavedVariables');
        }
      } catch (_error) {}

      let visited = 0;
      const walk = (dir, depth) => {
        if (!dir || depth < 0 || visited > 5000) return;
        visited += 1;
        let entries = [];
        try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch (_error) { return; }
        for (const entry of entries) {
          const full = path.join(dir, entry.name);
          if (entry.isFile() && /^PvPHelper\.lua$/i.test(entry.name)) addCandidate(full, 'scan');
          else if (entry.isDirectory() && depth > 0) {
            const lower = entry.name.toLowerCase();
            if (lower === 'cache' || lower === 'logs' || lower === 'screenshots') continue;
            walk(full, depth - 1);
          }
        }
      };
      walk(accountRoot, 5);
    }

    const candidates = sortPvPHelperCandidates(found.values());
    const best = candidates[0] || null;
    return {
      ok: Boolean(best),
      wowRoot,
      accountRoot,
      best,
      candidates,
      count: candidates.length,
      defaultPath: best ? best.filePath : (accountRoot || wowRoot || ''),
      reason: best
        ? `Found ${candidates.length} PvPHelper.lua SavedVariables candidate${candidates.length === 1 ? '' : 's'}.`
        : (accountRoot ? 'No PvPHelper.lua file was found under WTF\\Account yet. Log into WoW with PvPHelper enabled, then /reload or log out.' : 'Choose your WoW Logs folder first so the app can find World of Warcraft\\_retail_\\WTF\\Account.')
    };
  }

  function buildPvPHelperInstallStatus(settings = {}) {
    const paths = pvpHelperInstallPaths(settings);
    const addonInstalled = addonFolderLooksValid(paths.installedDir);
    const packageAvailable = addonFolderLooksValid(paths.packageDir);
    const installedVersion = addonInstalled ? readAddonTocVersion(paths.installedDir) : '';
    const packageVersion = packageAvailable ? readAddonTocVersion(paths.packageDir) : '';
    const installedIsNewer = Boolean(addonInstalled && packageAvailable && installedVersion && packageVersion && compareVersions(installedVersion, packageVersion) > 0);
    const needsUpdate = Boolean(addonInstalled && packageAvailable && packageVersion && (!installedVersion || compareVersions(installedVersion, packageVersion) < 0));
    const canInstall = Boolean(paths.addonsDir && packageAvailable);
    const mapped = Boolean(settings.pvpHelperSavedVariablesPath && settings.pvpHelperFileExists !== false);
    const status = {
      addonName: ADDON_PACKAGE_NAME,
      addonInstalled,
      installedVersion,
      packageAvailable,
      packageVersion,
      localPackageAvailable: packageAvailable,
      localPackageVersion: packageVersion,
      bundledAvailable: packageAvailable,
      bundledVersion: packageVersion,
      needsInstall: Boolean(!addonInstalled),
      needsUpdate,
      installedIsNewer,
      canInstall,
      wowRoot: paths.wowRoot,
      addonsDir: paths.addonsDir,
      installedDir: paths.installedDir,
      packageDir: paths.packageDir,
      packageDropDir: paths.packageDropDir,
      bundledDir: paths.packageDir,
      mapped,
      mappedPath: String(settings.pvpHelperSavedVariablesPath || ''),
      lastInstallAt: String(settings.pvpHelperAddonLastInstallAt || ''),
      reason: ''
    };
    if (!paths.wowRoot) status.reason = 'Choose your WoW Logs folder first so the app can find _retail_.';
    else if (!addonInstalled && !packageAvailable) status.reason = 'PvPHelper is not installed, and no local PvPHelper package was found. Put the unzipped PvPHelper folder in addon-packages\\PvPHelper.';
    else if (!addonInstalled) status.reason = packageVersion ? `PvPHelper is not installed. Local package ${packageVersion} is ready.` : 'PvPHelper is not installed. Local package is ready.';
    else if (!packageAvailable) status.reason = installedVersion ? `PvPHelper ${installedVersion} is installed. No local package is available to compare or update from.` : 'PvPHelper is installed. No local package is available to compare or update from.';
    else if (needsUpdate) status.reason = `Installed PvPHelper ${installedVersion || 'unknown'} is older than local app package ${packageVersion}.`;
    else if (installedIsNewer) status.reason = `WoW has PvPHelper ${installedVersion}, which is newer than the local app package ${packageVersion}. No update needed.`;
    else status.reason = installedVersion ? `PvPHelper ${installedVersion} is installed and matches the local package.` : 'PvPHelper is installed.';
    return status;
  }

  return {
    versionParts,
    compareVersions,
    firstVersionValue,
    extractPvPHelperVersion,
    buildPvPHelperVersionStatus,
    safeExists,
    isPathWritable,
    localAddonPackageDropDir,
    pvpHelperPackageBaseDirs,
    pvpHelperPackageCandidates,
    resolveAddonFolderPath,
    addonFolderLooksValid,
    readAddonTocVersion,
    bestPvPHelperPackage,
    bundledPvPHelperFolder,
    rootThroughRetail,
    deriveWowRetailRoot,
    pvpHelperInstallPaths,
    pvpHelperWtfAccountRoot,
    safeStat,
    looksLikePvPHelperSavedVariables,
    pvpHelperCandidateAccountName,
    summarizePvPHelperSavedVariablesCandidate,
    selectedPvPHelperSearchRoots,
    findPvPHelperSavedVariablesFromSelection,
    discoverPvPHelperSavedVariables,
    buildPvPHelperInstallStatus
  };
}

module.exports = { createPvPHelperTools };
