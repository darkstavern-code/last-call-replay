'use strict';

function createLiveLogSessionTools(deps = {}) {
  const path = deps.path || require('path');
  const parseCombatLine = typeof deps.parseCombatLine === 'function' ? deps.parseCombatLine : (() => null);
  const processRawText = typeof deps.processRawText === 'function' ? deps.processRawText : (() => []);
  const cleanSpellName = typeof deps.cleanSpellName === 'function' ? deps.cleanSpellName : ((value) => String(value || '').replace(/^"|"$/g, '').trim());
  const battlegroundInstanceMapName = typeof deps.battlegroundInstanceMapName === 'function' ? deps.battlegroundInstanceMapName : (() => '');
  const battlegroundMapNameFromSubzone = typeof deps.battlegroundMapNameFromSubzone === 'function' ? deps.battlegroundMapNameFromSubzone : (() => '');
  const isKnownBattlegroundZone = typeof deps.isKnownBattlegroundZone === 'function' ? deps.isKnownBattlegroundZone : (() => false);
  const normalizedMapKey = typeof deps.normalizedMapKey === 'function' ? deps.normalizedMapKey : ((value) => String(value || '').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim());

  const liveLogSessions = new Map();

  function getLiveSession(filePath) {
    const key = path.resolve(String(filePath || ''));
    if (!liveLogSessions.has(key)) {
      liveLogSessions.set(key, {
        activeKind: '',
        activeArenaIsSoloShuffle: false,
        bgZoneId: '',
        bgZoneName: '',
        lines: [],
        preArenaLines: [],
        startedAt: '',
        trimmed: false,
        charCount: 0
      });
    }
    return liveLogSessions.get(key);
  }

  function resetLiveSession(filePath) {
    const key = path.resolve(String(filePath || ''));
    liveLogSessions.delete(key);
  }


  function lineCharCount(line) {
    return String(line || '').length + 1;
  }

  function setSessionLines(session, lines = []) {
    if (!session) return;
    session.lines = Array.isArray(lines) ? lines : [];
    session.charCount = session.lines.reduce((sum, line) => sum + lineCharCount(line), 0);
  }

  function appendSessionLine(session, line) {
    if (!session) return;
    session.lines = Array.isArray(session.lines) ? session.lines : [];
    session.lines.push(line);
    session.charCount = (Number(session.charCount || 0) || 0) + lineCharCount(line);
  }

  function liveSessionLineText(lines) {
    return Array.isArray(lines) ? `${lines.join('\n')}\n` : '';
  }

  function liveSessionTooLarge(session) {
    const soloShuffleArena = Boolean(session.activeArenaIsSoloShuffle);
    const maxLines = soloShuffleArena ? 140000 : 30000;
    const maxChars = (soloShuffleArena ? 72 : 14) * 1024 * 1024;
    const trimTargetLines = soloShuffleArena ? 120000 : 22000;
    const trimTargetChars = (soloShuffleArena ? 64 : 10) * 1024 * 1024;
    const anchorLines = soloShuffleArena ? 8000 : 650;
    if (!session || !Array.isArray(session.lines)) return false;
    if (!Number(session.charCount || 0)) {
      session.charCount = session.lines.reduce((sum, line) => sum + lineCharCount(line), 0);
    }
    let tooLarge = session.lines.length > maxLines || (Number(session.charCount || 0) > maxChars);
    if (!tooLarge) return false;

    // Keep the session anchors plus the tail. The anchor lines include ZONE_CHANGE or
    // ARENA_MATCH_START, which the parser needs to create a match at all. Previous tail
    // only trimming could make long BGs invisible because the start marker was discarded.
    const anchors = session.lines.slice(0, Math.min(anchorLines, session.lines.length));
    const anchorChars = anchors.reduce((sum, line) => sum + lineCharCount(line), 0);
    const kept = [];
    let keptChars = 0;
    const tailLineBudget = Math.max(2000, trimTargetLines - anchors.length);
    const tailCharBudget = Math.max(4 * 1024 * 1024, trimTargetChars - anchorChars);

    for (let i = session.lines.length - 1; i >= anchors.length && kept.length < tailLineBudget; i -= 1) {
      const line = session.lines[i];
      const addChars = lineCharCount(line);
      if ((keptChars + addChars) > tailCharBudget && kept.length > 2000) break;
      keptChars += addChars;
      kept.push(line);
    }

    setSessionLines(session, [...anchors, ...kept.reverse()]);
    session.trimmed = true;
    session.trimmedPreservedAnchors = true;
    return true;
  }

  function finalizeLiveSegment(filePath, session, reason = 'segment-ended', options = {}) {
    if (!session || !Array.isArray(session.lines) || session.lines.length < 2) return [];
    const raw = liveSessionLineText(session.lines);
    const parsed = processRawText(raw, `watch:${path.basename(filePath)}:${reason}`, options || {});
    session.activeKind = '';
    session.activeArenaIsSoloShuffle = false;
    session.bgZoneId = '';
    session.bgZoneName = '';
    setSessionLines(session, []);
    session.preArenaLines = [];
    session.startedAt = '';
    session.trimmed = false;
    return parsed;
  }


  function fastLogEventName(line) {
    const raw = String(line || '');
    if (!raw) return '';
    const stampEnd = raw.indexOf('  ');
    const rest = stampEnd >= 0 ? raw.slice(stampEnd + 2) : raw;
    const comma = rest.indexOf(',');
    return (comma >= 0 ? rest.slice(0, comma) : rest).trim();
  }

  function finalizeLiveSessionAtFileEnd(filePath, reason = 'file-end', options = {}) {
    const session = getLiveSession(filePath);
    if (!session || !session.activeKind || !Array.isArray(session.lines) || session.lines.length < 2) return [];
    const kind = String(session.activeKind || '');
    if (kind === 'arena' && !options.allowLogOnlyOpenSegments) return [];
    if (kind === 'bg' && !options.allowBgAtFileEnd && !options.allowLogOnlyOpenSegments) return [];
    return finalizeLiveSegment(filePath, session, kind === 'arena' ? (reason || 'log-only-file-end') : 'file-end', options || {});
  }

  function processLiveLogLines(filePath, lines, options = {}) {
    const session = getLiveSession(filePath);
    const finalized = [];

    for (const line of lines || []) {
      const eventName = fastLogEventName(line);
      const isMarker = eventName === 'ARENA_MATCH_START' || eventName === 'ARENA_MATCH_END' || eventName === 'ZONE_CHANGE';
      const ev = isMarker ? parseCombatLine(line) : null;

      if (ev && ev.event === 'ARENA_MATCH_START') {
        const bracket = cleanSpellName(ev.fields && ev.fields[3] ? ev.fields[3] : '');
        const nextIsSoloShuffle = /shuffle/i.test(bracket);
        if (session.activeKind === 'arena' && session.activeArenaIsSoloShuffle && nextIsSoloShuffle) {
          // Solo Shuffle emits ARENA_MATCH_START for each round but only one final
          // ARENA_MATCH_END for the lobby. Keep the same live session open so the
          // final import has all round starts instead of producing one-row tails.
          appendSessionLine(session, line);
          liveSessionTooLarge(session);
          continue;
        }
        if (session.activeKind === 'arena') finalized.push(...finalizeLiveSegment(filePath, session, nextIsSoloShuffle ? 'solo-shuffle-next-round' : 'arena-next-start-without-end', { ...options, allowLogOnlyOpenSegments: true, logOnlyReason: nextIsSoloShuffle ? 'solo-shuffle-next-round' : 'arena-next-start-without-end' }));
        if (session.activeKind === 'bg') finalized.push(...finalizeLiveSegment(filePath, session, 'arena-start', options));
        session.activeKind = 'arena';
        session.activeArenaIsSoloShuffle = nextIsSoloShuffle;
        const warmup = Array.isArray(session.preArenaLines) ? session.preArenaLines.slice(-2000) : [];
        setSessionLines(session, [...warmup, line]);
        session.preArenaLines = [];
        session.startedAt = ev.iso || '';
        continue;
      }

      if (ev && ev.event === 'ARENA_MATCH_END' && session.activeKind === 'arena') {
        appendSessionLine(session, line);
        finalized.push(...finalizeLiveSegment(filePath, session, 'arena-end', options));
        continue;
      }

      if (ev && ev.event === 'ZONE_CHANGE') {
        const zoneId = String(ev.fields[1] || '');
        const zoneName = cleanSpellName(ev.fields[2] || '');
        const bgDisplayName = battlegroundInstanceMapName(zoneId) || battlegroundMapNameFromSubzone(zoneName) || zoneName;
        const isBg = Boolean(battlegroundInstanceMapName(zoneId)) || isKnownBattlegroundZone(zoneName) || isKnownBattlegroundZone(bgDisplayName);
        const sameBg = session.activeKind === 'bg' && (
          (zoneId && zoneId !== '0' && zoneId === session.bgZoneId)
          || (isBg && normalizedMapKey(bgDisplayName) && normalizedMapKey(bgDisplayName) === normalizedMapKey(session.bgZoneName))
          || (isBg && battlegroundMapNameFromSubzone(zoneName) && normalizedMapKey(battlegroundMapNameFromSubzone(zoneName)) === normalizedMapKey(session.bgZoneName))
        );

        if (session.activeKind === 'arena') {
          appendSessionLine(session, line);
          finalized.push(...finalizeLiveSegment(filePath, session, 'arena-zone-out-without-end', { ...options, allowLogOnlyOpenSegments: true, logOnlyReason: 'arena-zone-out-without-end' }));
        }

        if (session.activeKind === 'bg' && !sameBg) {
          finalized.push(...finalizeLiveSegment(filePath, session, isBg ? 'bg-switch' : 'bg-exit', options));
        }

        if (isBg) {
          if (session.activeKind !== 'bg') {
            session.activeKind = 'bg';
            session.activeArenaIsSoloShuffle = false;
            session.bgZoneId = zoneId;
            session.bgZoneName = bgDisplayName;
            setSessionLines(session, [line]);
            session.startedAt = ev.iso || '';
          } else {
            appendSessionLine(session, line);
          }
        } else if (!session.activeKind) {
          session.preArenaLines = [line];
        }
        continue;
      }

      if (session.activeKind) {
        appendSessionLine(session, line);
        liveSessionTooLarge(session);
      } else {
        session.preArenaLines = Array.isArray(session.preArenaLines) ? session.preArenaLines : [];
        if (session.preArenaLines.length) {
          session.preArenaLines.push(line);
          if (session.preArenaLines.length > 2000) session.preArenaLines = session.preArenaLines.slice(-2000);
        }
      }
    }

    return finalized;
  }

  return {
    resetLiveSession,
    processLiveLogLines,
    finalizeLiveSessionAtFileEnd,
    _test: {
      getLiveSession,
      liveSessionTooLarge,
      finalizeLiveSegment,
      fastLogEventName,
      setSessionLines,
      appendSessionLine
    }
  };
}

module.exports = { createLiveLogSessionTools };
