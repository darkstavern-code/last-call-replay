'use strict';

function createCombatLogDiscoveryTools(deps = {}) {
  const fs = deps.fs || require('fs');
  const path = deps.path || require('path');
  const app = deps.app || null;
  const processObj = deps.processObj || process;
  const readRange = typeof deps.readRange === 'function' ? deps.readRange : ((filePath, start, end) => {
    const fd = fs.openSync(filePath, 'r');
    try {
      const length = Math.max(0, Number(end || 0) - Number(start || 0));
      const buffer = Buffer.alloc(length);
      const bytesRead = fs.readSync(fd, buffer, 0, length, Math.max(0, Number(start || 0)));
      return buffer.subarray(0, bytesRead).toString('utf8');
    } finally {
      fs.closeSync(fd);
    }
  });
  const rootThroughRetail = typeof deps.rootThroughRetail === 'function' ? deps.rootThroughRetail : (() => '');
  const deriveWowRetailRoot = typeof deps.deriveWowRetailRoot === 'function' ? deps.deriveWowRetailRoot : (() => '');
  const defaultSettings = typeof deps.defaultSettings === 'function' ? deps.defaultSettings : (() => ({}));
  const LOG_BOUNDARY_READ_BYTES = Number(deps.logBoundaryReadBytes || (1024 * 1024));
  const LARGE_LOG_FOLDER_COUNT = Number(deps.largeLogFolderCount || 800);
  const LARGE_LOG_FOLDER_STAT_CANDIDATES = Number(deps.largeLogFolderStatCandidates || 250);

  function safeExists(filePath) {
    try { return Boolean(filePath && fs.existsSync(filePath)); } catch (_error) { return false; }
  }

  function normalizePathKey(filePath = '') {
    try { return path.normalize(String(filePath || '')).toLowerCase(); } catch (_error) { return String(filePath || '').toLowerCase(); }
  }

  function addUniquePath(list, filePath) {
    if (!filePath) return;
    const normalized = normalizePathKey(filePath);
    if (!list.some((item) => normalizePathKey(item) === normalized)) list.push(path.normalize(String(filePath)));
  }

  function getPreferredRetailLogFolder() {
    if (processObj.platform === 'win32') {
      return 'C:\\Program Files (x86)\\World of Warcraft\\_retail_\\Logs';
    }
    if (processObj.platform === 'darwin') {
      return '/Applications/World of Warcraft/_retail_/Logs';
    }
    return '';
  }

  function getPotentialLogFolders() {
    const folders = [];
    const preferred = getPreferredRetailLogFolder();
    if (preferred) folders.push(preferred);

    if (processObj.platform === 'win32') {
      const drives = ['C:', 'D:', 'E:', 'F:', 'G:'];
      for (const drive of drives) {
        folders.push(path.join(drive, 'Program Files (x86)', 'World of Warcraft', '_retail_', 'Logs'));
        folders.push(path.join(drive, 'Program Files', 'World of Warcraft', '_retail_', 'Logs'));
        folders.push(path.join(drive, 'World of Warcraft', '_retail_', 'Logs'));
        folders.push(path.join(drive, 'Games', 'World of Warcraft', '_retail_', 'Logs'));
      }
    }

    if (processObj.platform === 'darwin') {
      folders.push('/Applications/World of Warcraft/_retail_/Logs');
    }

    return Array.from(new Set(folders.filter(Boolean)));
  }

  function isCombatLogFileName(fileName) {
    return /^WoWCombatLog(?:[-_].*)?\.txt$/i.test(String(fileName || ''));
  }

  function logFileNameTimeScore(name = '') {
    const raw = String(name || '');
    const match = raw.match(/WoWCombatLog[-_](\d{2})(\d{2})(\d{2})[-_](\d{2})(\d{2})(\d{2})\.txt$/i);
    if (!match) return 0;
    const [, mm, dd, yy, hh, min, ss] = match;
    return Number(`20${yy}${mm}${dd}${hh}${min}${ss}`) || 0;
  }

  function logFileEntryWeight(name = '') {
    const raw = String(name || '');
    if (/^WoWCombatLog\.txt$/i.test(raw)) return Number.MAX_SAFE_INTEGER;
    return logFileNameTimeScore(raw);
  }

  function logFileNameTimeMs(name = '') {
    const raw = String(name || '');
    const match = raw.match(/WoWCombatLog[-_](\d{2})(\d{2})(\d{2})[-_](\d{2})(\d{2})(\d{2})\.txt$/i);
    if (!match) return 0;
    const [, mm, dd, yy, hh, min, ss] = match;
    const date = new Date(2000 + Number(yy), Math.max(0, Number(mm) - 1), Number(dd), Number(hh), Number(min), Number(ss));
    const time = date.getTime();
    return Number.isFinite(time) ? time : 0;
  }

  function logFileApproxTimeMs(file = {}) {
    const named = logFileNameTimeMs(file.name || path.basename(file.filePath || ''));
    if (named) return named;
    return Number(file.mtimeMs || 0) || 0;
  }

  function logFileNameYear(name = '') {
    const match = String(name || '').match(/WoWCombatLog[-_](\d{2})(\d{2})(\d{2})[-_]/i);
    return match ? 2000 + Number(match[3]) : 0;
  }

  function lineStampTimeMs(line = '', fallbackYear = 0) {
    const match = String(line || '').match(/^(\d{1,2})\/(\d{1,2})(?:\/(\d{2,4}))?\s+(\d{1,2}):(\d{2}):(\d{2})\.(\d{1,3})/);
    if (!match) return 0;
    const month = Number(match[1]) - 1;
    const day = Number(match[2]);
    let year = match[3] ? Number(match[3]) : (Number(fallbackYear || 0) || new Date().getFullYear());
    if (year < 100) year += 2000;
    const date = new Date(year, month, day, Number(match[4]), Number(match[5]), Number(match[6]), Number(String(match[7]).padEnd(3, '0')));
    const time = date.getTime();
    return Number.isFinite(time) ? time : 0;
  }

  function readFirstLogLineTimeMs(filePath, fallbackYear = 0) {
    try {
      const stat = fs.statSync(filePath);
      if (!stat.size) return 0;
      const raw = readRange(filePath, 0, Math.min(stat.size, LOG_BOUNDARY_READ_BYTES));
      for (const line of raw.split(/\r?\n/)) {
        const time = lineStampTimeMs(line, fallbackYear);
        if (time) return time;
      }
    } catch (_error) {}
    return 0;
  }

  function readLastLogLineTimeMs(filePath, fallbackYear = 0) {
    try {
      const stat = fs.statSync(filePath);
      if (!stat.size) return 0;
      const start = Math.max(0, stat.size - LOG_BOUNDARY_READ_BYTES);
      const raw = readRange(filePath, start, stat.size);
      const lines = raw.split(/\r?\n/).reverse();
      for (const line of lines) {
        const time = lineStampTimeMs(line, fallbackYear);
        if (time) return time;
      }
    } catch (_error) {}
    return 0;
  }

  function logRegistryKey(filePath = '') {
    try { return path.resolve(String(filePath || '')); } catch (_error) { return String(filePath || ''); }
  }

  function buildLogFileInfo(file = {}, state = null, options = {}) {
    const filePath = typeof file === 'string' ? file : (file.filePath || '');
    if (!filePath || !safeExists(filePath)) return null;
    const stat = fs.statSync(filePath);
    const name = path.basename(filePath);
    const registry = state && state.logFileRegistry && state.logFileRegistry[logRegistryKey(filePath)] ? state.logFileRegistry[logRegistryKey(filePath)] : null;
    const sameFile = registry && Number(registry.size || 0) === stat.size && Math.abs(Number(registry.mtimeMs || 0) - Number(stat.mtimeMs || 0)) < 2;
    let firstLineMs = sameFile ? Number(registry.firstLineMs || 0) : 0;
    let lastLineMs = sameFile ? Number(registry.lastLineMs || 0) : 0;
    if (options.readBoundaries !== false && (!firstLineMs || !lastLineMs)) {
      const fallbackYear = logFileNameYear(name);
      firstLineMs = firstLineMs || readFirstLogLineTimeMs(filePath, fallbackYear);
      lastLineMs = lastLineMs || readLastLogLineTimeMs(filePath, fallbackYear);
    }
    const nameStartMs = logFileNameTimeMs(name);
    const startMs = nameStartMs || firstLineMs || Number(file.mtimeMs || stat.mtimeMs || 0) || 0;
    const endMs = lastLineMs || Number(stat.mtimeMs || file.mtimeMs || 0) || startMs;
    return {
      filePath,
      name,
      size: stat.size || 0,
      mtimeMs: stat.mtimeMs || 0,
      nameStartMs,
      firstLineMs,
      lastLineMs,
      startMs,
      endMs,
      indexedAt: new Date().toISOString(),
      folderPath: path.dirname(filePath),
      totalFiles: file.totalFiles || 0,
      statLimited: Boolean(file.statLimited)
    };
  }

  function rememberLogFileInfo(state, info, extra = {}) {
    if (!state || !info || !info.filePath) return;
    state.logFileRegistry = state.logFileRegistry || {};
    const key = logRegistryKey(info.filePath);
    const old = state.logFileRegistry[key] || {};
    state.logFileRegistry[key] = {
      ...old,
      ...info,
      ...extra,
      filePath: info.filePath,
      name: info.name || path.basename(info.filePath),
      updatedAt: new Date().toISOString()
    };
  }

  function buildLogFileRoster(settings = {}, state = null, options = {}) {
    const folders = getCandidateLogFolders(settings || {});
    const summaries = folders.map((folderPath) => ({ folderPath, summary: getLogFileSummaryInFolder(folderPath) }));
    const filesWithFolder = summaries.flatMap((item) => (item.summary.files || []).map((file) => ({ ...file, folderPath: item.folderPath, statLimited: Boolean(item.summary.statLimited), totalFiles: item.summary.totalFiles || 0 })));
    const infos = filesWithFolder
      .map((file) => buildLogFileInfo(file, state, options))
      .filter(Boolean)
      .sort((a, b) => (a.startMs - b.startMs) || (a.mtimeMs - b.mtimeMs) || String(a.filePath).localeCompare(String(b.filePath)));
    for (let index = 0; index < infos.length; index += 1) {
      infos[index].nextStartMs = infos[index + 1] ? Number(infos[index + 1].startMs || 0) : 0;
    }
    return { folders, filesWithFolder, infos };
  }

  function logFileCandidatesForStats(names = []) {
    const list = (names || []).filter(isCombatLogFileName);
    if (list.length <= LARGE_LOG_FOLDER_COUNT) return list;
    const exact = list.filter((name) => /^WoWCombatLog\.txt$/i.test(name));
    const timestamped = list
      .filter((name) => !/^WoWCombatLog\.txt$/i.test(name))
      .sort((a, b) => logFileEntryWeight(b) - logFileEntryWeight(a) || String(b).localeCompare(String(a)))
      .slice(0, LARGE_LOG_FOLDER_STAT_CANDIDATES);
    return Array.from(new Set([...exact, ...timestamped]));
  }

  function getLogFileSummaryInFolder(folder) {
    if (!folder || !safeExists(folder)) return { files: [], totalFiles: 0, statLimited: false };
    try {
      const names = fs.readdirSync(folder).filter(isCombatLogFileName);
      const candidates = logFileCandidatesForStats(names);
      const files = candidates
        .map((name) => {
          const filePath = path.join(folder, name);
          try {
            const stat = fs.statSync(filePath);
            return { filePath, mtimeMs: stat.mtimeMs || 0, size: stat.size || 0, name };
          } catch (_error) {
            return null;
          }
        })
        .filter(Boolean)
        .sort((a, b) => (b.mtimeMs - a.mtimeMs) || (b.size - a.size) || (logFileEntryWeight(b.name) - logFileEntryWeight(a.name)));
      return { files, totalFiles: names.length, statLimited: candidates.length < names.length };
    } catch (_error) {
      return { files: [], totalFiles: 0, statLimited: false };
    }
  }

  function getLogFilesInFolder(folder) {
    return getLogFileSummaryInFolder(folder).files.map((item) => item.filePath);
  }

  function findBestLogFileInFolder(folder) {
    const summary = getLogFileSummaryInFolder(folder);
    if (summary.files[0]) return summary.files[0].filePath;
    return folder ? path.join(folder, 'WoWCombatLog.txt') : '';
  }

  function getNearbyLogFolders(settings = {}) {
    const folders = [];
    const addFolder = (folderPath) => addUniquePath(folders, folderPath);

    const savedFolder = settings.logFolderPath || (settings.logFilePath ? path.dirname(settings.logFilePath) : '');
    addFolder(savedFolder);

    const retailRoots = new Set();
    const maybeRetail = deriveWowRetailRoot(settings);
    if (maybeRetail) retailRoots.add(path.normalize(maybeRetail));
    if (savedFolder) {
      const root = rootThroughRetail(savedFolder);
      if (root) retailRoots.add(path.normalize(root));
      const parent = path.dirname(savedFolder);
      if (/^_retail_$/i.test(path.basename(parent))) retailRoots.add(path.normalize(parent));
    }
    if (settings.logFilePath) {
      const root = rootThroughRetail(settings.logFilePath);
      if (root) retailRoots.add(path.normalize(root));
    }

    for (const retailRoot of retailRoots) {
      addFolder(path.join(retailRoot, 'Logs'));
      const installRoot = path.dirname(retailRoot);
      try {
        for (const name of fs.readdirSync(installRoot)) {
          if (!/^_.*_$/.test(name)) continue;
          addFolder(path.join(installRoot, name, 'Logs'));
        }
      } catch (_error) {}

      try {
        for (const name of fs.readdirSync(retailRoot)) {
          const full = path.join(retailRoot, name);
          if (!safeExists(full) || !fs.statSync(full).isDirectory()) continue;
          if (/logs?/i.test(name)) addFolder(full);
        }
      } catch (_error) {}
    }

    if (savedFolder) {
      const parent = path.dirname(savedFolder);
      try {
        for (const name of fs.readdirSync(parent)) {
          const full = path.join(parent, name);
          if (!safeExists(full) || !fs.statSync(full).isDirectory()) continue;
          if (/logs?/i.test(name)) addFolder(full);
        }
      } catch (_error) {}
    }

    return folders.filter((folderPath) => folderPath && safeExists(folderPath));
  }

  function getCandidateLogFolders(settings = {}) {
    const folders = [];
    const addFolder = (folderPath) => addUniquePath(folders, folderPath);
    getNearbyLogFolders(settings).forEach(addFolder);
    getPotentialLogFolders().forEach(addFolder);
    return folders.filter((folderPath) => folderPath && safeExists(folderPath));
  }

  function getLogCandidatesFromFolders(folders = []) {
    const found = [];
    for (const folder of folders) {
      found.push(...getLogFilesInFolder(folder));
    }
    return Array.from(new Set(found))
      .map((filePath) => {
        try {
          const stat = fs.statSync(filePath);
          return { filePath, mtimeMs: stat.mtimeMs || 0, size: stat.size || 0 };
        } catch (_error) {
          return { filePath, mtimeMs: 0, size: 0 };
        }
      })
      .sort((a, b) => (b.mtimeMs - a.mtimeMs) || (b.size - a.size))
      .map((item) => item.filePath);
  }

  function getLogCandidates(settings = {}) {
    return getLogCandidatesFromFolders(getCandidateLogFolders(settings));
  }

  function getDefaultLogCandidates() {
    return getLogCandidatesFromFolders(getPotentialLogFolders());
  }

  function getLogPickerDefaultPath(preferFile = false) {
    const candidates = getDefaultLogCandidates();
    if (preferFile && candidates[0]) return candidates[0];
    if (candidates[0]) return path.dirname(candidates[0]);

    const folders = getPotentialLogFolders();
    const existing = folders.find((folder) => safeExists(folder));
    if (existing) return existing;

    const preferred = getPreferredRetailLogFolder();
    const preferredParent = preferred ? path.dirname(preferred) : '';
    if (preferredParent && safeExists(preferredParent)) return preferredParent;

    return app && typeof app.getPath === 'function' ? app.getPath('home') : processObj.cwd();
  }

  function getLogSuggestion(settings = {}) {
    const preferredFolder = getPreferredRetailLogFolder();
    const preferredFile = preferredFolder ? findBestLogFileInFolder(preferredFolder) : '';
    const candidates = getLogCandidates(settings);
    const first = candidates[0] || preferredFile || '';
    return {
      preferredFolder,
      preferredFile,
      preferredExists: Boolean(preferredFile && safeExists(preferredFile)),
      firstDetectedFile: first,
      firstDetectedFolder: first ? path.dirname(first) : '',
      detectedFiles: candidates
    };
  }

  function autoLocateCombatLog(state = {}) {
    state.settings = { ...defaultSettings(), ...(state.settings || {}) };
    const candidates = getLogCandidates(state.settings || {});
    const filePath = candidates[0] || '';
    const existingFolder = getPotentialLogFolders().find((folder) => folder && safeExists(folder)) || '';
    if (!filePath) {
      if (existingFolder) {
        state.settings = { ...defaultSettings(), ...(state.settings || {}), logFolderPath: existingFolder };
      }
      return {
        ok: false,
        filePath: '',
        folderPath: existingFolder,
        detectedFiles: candidates,
        searchedFolders: getCandidateLogFolders(state.settings || {}),
        reason: existingFolder ? 'Found a WoW Logs folder, but no WoWCombatLog*.txt file yet.' : 'No WoW Retail Logs folder was found automatically.'
      };
    }

    const folderPath = path.dirname(filePath);
    state.settings = { ...defaultSettings(), ...(state.settings || {}), logFilePath: filePath, logFolderPath: folderPath };
    state.watchedFiles = state.watchedFiles || {};
    if (!state.watchedFiles[filePath]) {
      state.watchedFiles[filePath] = {
        offset: 0,
        fileSize: 0,
        lineTail: '',
        startedAt: new Date().toISOString(),
        autoLocated: true,
        needsInitialBackfill: true
      };
    }

    return {
      ok: true,
      filePath,
      folderPath,
      detectedFiles: candidates,
      searchedFolders: getCandidateLogFolders(state.settings || {}),
      reason: `Connected ${path.basename(filePath)} from ${folderPath}.`
    };
  }

  function startupLightLogStatus(state = {}, activeFile = '', stat = null) {
    const record = state && state.watchedFiles && activeFile ? state.watchedFiles[activeFile] : null;
    const fileSize = stat ? Number(stat.size || 0) : 0;
    const offset = Number(record && record.offset || 0) || 0;
    const storedSize = Number(record && record.fileSize || 0) || 0;
    const lineTail = String(record && record.lineTail || '');
    const caughtUp = Boolean(record && fileSize > 0 && offset >= fileSize && storedSize === fileSize && !lineTail);
    return {
      caughtUp,
      skipTail: caughtUp,
      reason: caughtUp ? 'Startup light skipped tail parsing because the active log has not grown since the last sync.' : '',
      offset,
      fileSize,
      storedSize
    };
  }

  return {
    getPreferredRetailLogFolder,
    getPotentialLogFolders,
    isCombatLogFileName,
    logFileNameTimeScore,
    logFileEntryWeight,
    logFileNameTimeMs,
    logFileApproxTimeMs,
    logFileNameYear,
    lineStampTimeMs,
    readFirstLogLineTimeMs,
    readLastLogLineTimeMs,
    logRegistryKey,
    buildLogFileInfo,
    rememberLogFileInfo,
    buildLogFileRoster,
    logFileCandidatesForStats,
    getLogFileSummaryInFolder,
    getLogFilesInFolder,
    findBestLogFileInFolder,
    getNearbyLogFolders,
    getCandidateLogFolders,
    getLogCandidatesFromFolders,
    getLogCandidates,
    getDefaultLogCandidates,
    getLogPickerDefaultPath,
    getLogSuggestion,
    autoLocateCombatLog,
    startupLightLogStatus
  };
}

module.exports = { createCombatLogDiscoveryTools };
