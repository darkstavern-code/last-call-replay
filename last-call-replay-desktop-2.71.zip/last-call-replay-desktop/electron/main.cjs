const { app, BrowserWindow, dialog, ipcMain, desktopCapturer, session, shell, Menu, nativeImage } = require('electron');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');
const http = require('http');
const https = require('https');
const { createSoloShuffleTools } = require('./modules/soloShuffle.cjs');
const { createVodLinkingTools } = require('./modules/vodLinking.cjs');
const { createPvPHelperTools } = require('./modules/pvpHelper.cjs');
const { createMatchLibraryTools } = require('./modules/matchLibrary.cjs');
const { createStartupPayloadTools } = require('./modules/startupPayload.cjs');
const { createCombatLogDiscoveryTools } = require('./modules/combatLogDiscovery.cjs');
const { createStateStorageTools } = require('./modules/stateStorage.cjs');
const { createPvPHelperImportTools } = require('./modules/pvpHelperImport.cjs');
const { createRecordingBackendTools } = require('./modules/recordingBackend.cjs');
const { createFavoriteBackendTools } = require('./modules/favoriteBackend.cjs');
const { createMatchActionTools } = require('./modules/matchActions.cjs');
const { createCombatLogParserTools } = require('./modules/combatLogParser.cjs');
const { createImportJobQueueTools } = require('./modules/importJobQueue.cjs');
const { createLogSyncBackendTools } = require('./modules/logSyncBackend.cjs');
const { createAppStorageTools } = require('./modules/appStorageBackend.cjs');
const { createLiveLogSessionTools } = require('./modules/liveLogSessions.cjs');
const { createVodIpcTools } = require('./modules/vodIpcHandlers.cjs');
const { createPvPHelperIpcTools } = require('./modules/pvpHelperIpcHandlers.cjs');

// Prefer boring stability over clever window capture. Some Windows/WoW/window-source
// combinations can crash Electron's WGC path. These switches reduce GPU/capture
// weirdness and the renderer will use the OS display picker for program windows.
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');

app.setName('Last Call Replay');
if (process.platform === 'win32') {
  app.setAppUserModelId('com.darkstavern.lastcallreplay');
}

let mainWindow;
let recordingOverlayIcon = null;
const DEFAULT_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json';
const DEFAULT_UPDATE_RELEASE_URL = 'https://github.com/darkstavern-code/last-call-replay/releases';

function getRecordingOverlayIcon() {
  if (!recordingOverlayIcon) {
    const pngBase64 = 'iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAgklEQVR4nLWTwQ3AIAhFwQXKUk7NUjqBvRSDCGrS9t8Q/gsQBHgpjBKttTIVI9IW4BlXoAGgzSXnyxqJuVpIOjXbd6lPq6IdBOAZQWg2SczaCCZX3Q48sxeLQsCp/gPYmW0s6ncQLdKTLBARaepAH8vKLOoAfZ4RxLvEb//CDuT9xhvrrEkFNBw4zwAAAABJRU5ErkJggg==';
    recordingOverlayIcon = nativeImage.createFromBuffer(Buffer.from(pngBase64, 'base64'));
  }
  return recordingOverlayIcon;
}

function setRecordingTaskbarIndicator(active) {
  const win = mainWindow;
  if (!win || win.isDestroyed()) return { ok: false, reason: 'Main window unavailable.' };
  try {
    if (process.platform === 'win32' && typeof win.setOverlayIcon === 'function') {
      win.setOverlayIcon(active ? getRecordingOverlayIcon() : null, active ? 'Recording active' : '');
    }
    if (typeof win.setProgressBar === 'function') {
      active ? win.setProgressBar(2, { mode: 'indeterminate' }) : win.setProgressBar(-1);
    }
    return { ok: true, active: Boolean(active) };
  } catch (error) {
    console.error('[Last Call Replay] Taskbar recording indicator failed:', error);
    try { if (typeof win.setProgressBar === 'function') { active ? win.setProgressBar(2, { mode: 'indeterminate' }) : win.setProgressBar(-1); } } catch (_) {}
    return { ok: false, active: Boolean(active), reason: error && error.message ? error.message : 'Taskbar indicator failed.' };
  }
}


function normalizeVersionParts(value = '') {
  return String(value || '')
    .trim()
    .replace(/^v/i, '')
    .split(/[.\-+]/)
    .slice(0, 4)
    .map((part) => Number.parseInt(part, 10))
    .map((part) => Number.isFinite(part) ? part : 0);
}

function compareAppVersions(a = '', b = '') {
  const left = normalizeVersionParts(a);
  const right = normalizeVersionParts(b);
  const length = Math.max(left.length, right.length, 3);
  for (let i = 0; i < length; i += 1) {
    const diff = (left[i] || 0) - (right[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

function safeUpdateUrl(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return '';
  try {
    const parsed = new URL(raw);
    return parsed.protocol === 'https:' || parsed.protocol === 'http:' ? parsed.toString() : '';
  } catch (_error) {
    return '';
  }
}

function normalizeReleaseNotes(value) {
  const source = Array.isArray(value) ? value : (typeof value === 'string' ? value.split(/\r?\n/) : []);
  return source
    .map((item) => String(item || '').replace(/\s+/g, ' ').trim())
    .filter(Boolean)
    .slice(0, 12)
    .map((item) => item.slice(0, 220));
}

function normalizeUpdateManifest(manifest = {}, fallbackReleaseUrl = '') {
  const safeManifest = manifest && typeof manifest === 'object' ? manifest : {};
  const latestVersion = String(safeManifest.version || safeManifest.latestVersion || safeManifest.appVersion || '').replace(/^v/i, '').trim();
  const releaseUrl = safeUpdateUrl(safeManifest.releaseUrl || safeManifest.htmlUrl || safeManifest.releasePageUrl || fallbackReleaseUrl || '');
  const installerUrl = safeUpdateUrl(safeManifest.installerUrl || safeManifest.exeUrl || safeManifest.windowsInstallerUrl || '');
  const zipUrl = safeUpdateUrl(safeManifest.zipUrl || safeManifest.portableZipUrl || safeManifest.archiveUrl || '');
  const downloadUrl = safeUpdateUrl(safeManifest.downloadUrl || installerUrl || zipUrl || releaseUrl || '');
  return {
    latestVersion,
    releasedAt: String(safeManifest.releasedAt || safeManifest.publishedAt || safeManifest.date || '').trim().slice(0, 40),
    releaseUrl,
    installerUrl,
    zipUrl,
    downloadUrl,
    releaseNotes: normalizeReleaseNotes(safeManifest.releaseNotes || safeManifest.notes || safeManifest.changelog)
  };
}

function fetchJsonUrl(url, redirects = 0) {
  const target = safeUpdateUrl(url);
  if (!target) return Promise.reject(new Error('Update manifest URL must start with http:// or https://.'));
  if (redirects > 3) return Promise.reject(new Error('Too many redirects while checking updates.'));
  return new Promise((resolve, reject) => {
    let parsed;
    try { parsed = new URL(target); } catch (error) { reject(error); return; }
    const client = parsed.protocol === 'http:' ? http : https;
    const req = client.get(parsed, { timeout: 10000, headers: { 'Accept': 'application/json', 'User-Agent': `LastCallReplay/${app.getVersion ? app.getVersion() : '0.0.0'}` } }, (res) => {
      const status = Number(res.statusCode || 0);
      const location = res.headers && res.headers.location ? String(res.headers.location) : '';
      if (status >= 300 && status < 400 && location) {
        res.resume();
        const nextUrl = new URL(location, target).toString();
        fetchJsonUrl(nextUrl, redirects + 1).then(resolve, reject);
        return;
      }
      if (status < 200 || status >= 300) {
        res.resume();
        reject(new Error(`Update manifest returned HTTP ${status || 'error'}.`));
        return;
      }
      let body = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        body += chunk;
        if (body.length > 512 * 1024) {
          req.destroy(new Error('Update manifest is too large.'));
        }
      });
      res.on('end', () => {
        try { resolve(JSON.parse(body)); }
        catch (_error) { reject(new Error('Update manifest is not valid JSON.')); }
      });
    });
    req.on('timeout', () => req.destroy(new Error('Update check timed out.')));
    req.on('error', reject);
  });
}

async function checkForUpdates(payload = {}) {
  const state = readState();
  state.settings = { ...defaultSettings(), ...(state.settings || {}) };
  const currentVersion = typeof app.getVersion === 'function' ? app.getVersion() : '';
  const manifestUrl = safeUpdateUrl(payload.manifestUrl || state.settings.updateManifestUrl || DEFAULT_UPDATE_MANIFEST_URL);
  const fallbackReleaseUrl = safeUpdateUrl(payload.releaseUrl || state.settings.updateReleaseUrl || DEFAULT_UPDATE_RELEASE_URL);
  const checkedAt = new Date().toISOString();

  state.settings.updateManifestUrl = manifestUrl;
  state.settings.updateReleaseUrl = fallbackReleaseUrl;
  state.settings.updateLastCheckedAt = checkedAt;

  if (!manifestUrl) {
    const result = {
      ok: true,
      configured: false,
      currentVersion,
      latestVersion: state.settings.updateLatestVersion || '',
      releasedAt: state.settings.updateReleasedAt || '',
      updateAvailable: false,
      releaseUrl: fallbackReleaseUrl,
      installerUrl: state.settings.updateInstallerUrl || '',
      zipUrl: state.settings.updateZipUrl || '',
      releaseNotes: Array.isArray(state.settings.updateReleaseNotes) ? state.settings.updateReleaseNotes : [],
      checkedAt,
      reason: fallbackReleaseUrl
        ? 'No latest.json URL is configured yet. You can still open the release page and download manually.'
        : 'Add the stable latest.json URL before checking for updates.'
    };
    writeState(state);
    return { ...result, settings: state.settings };
  }

  try {
    const manifest = await fetchJsonUrl(manifestUrl);
    const info = normalizeUpdateManifest(manifest, fallbackReleaseUrl);
    const updateAvailable = info.latestVersion ? compareAppVersions(info.latestVersion, currentVersion) > 0 : false;
    state.settings.updateLatestVersion = info.latestVersion;
    state.settings.updateReleasedAt = info.releasedAt;
    state.settings.updateReleaseUrl = info.releaseUrl || fallbackReleaseUrl;
    state.settings.updateInstallerUrl = info.installerUrl;
    state.settings.updateZipUrl = info.zipUrl;
    state.settings.updateReleaseNotes = info.releaseNotes;
    writeState(state);
    return {
      ok: true,
      configured: true,
      currentVersion,
      latestVersion: info.latestVersion,
      releasedAt: info.releasedAt,
      updateAvailable,
      releaseUrl: info.releaseUrl || fallbackReleaseUrl,
      installerUrl: info.installerUrl,
      zipUrl: info.zipUrl,
      downloadUrl: info.downloadUrl,
      releaseNotes: info.releaseNotes,
      checkedAt,
      manifestUrl,
      message: updateAvailable
        ? `Version ${info.latestVersion} is available.`
        : info.latestVersion
          ? 'You’re up to date.'
          : 'latest.json loaded, but no version field was provided.',
      settings: state.settings
    };
  } catch (error) {
    writeState(state);
    return {
      ok: false,
      configured: true,
      currentVersion,
      latestVersion: state.settings.updateLatestVersion || '',
      releasedAt: state.settings.updateReleasedAt || '',
      updateAvailable: false,
      releaseUrl: fallbackReleaseUrl,
      installerUrl: state.settings.updateInstallerUrl || '',
      zipUrl: state.settings.updateZipUrl || '',
      releaseNotes: Array.isArray(state.settings.updateReleaseNotes) ? state.settings.updateReleaseNotes : [],
      checkedAt,
      manifestUrl,
      reason: `Could not check for updates. ${error && error.message ? error.message : String(error)}`,
      settings: state.settings
    };
  }
}

process.on('uncaughtException', (error) => {
  console.error('[Last Call Replay] Uncaught exception:', error);
});

process.on('unhandledRejection', (reason) => {
  console.error('[Last Call Replay] Unhandled rejection:', reason);
});
const PARSER_VERSION = 64;
const APP_SCHEMA_VERSION = 69;
const MIN_SUPPORTED_PVPHELPER_VERSION = '0.12.8';
const MAX_ACTIVE_TAIL_READ_BYTES = 8 * 1024 * 1024;
const STARTUP_ACTIVE_TAIL_READ_BYTES = 512 * 1024;
const LOG_CHUNK_READ_BYTES = 2 * 1024 * 1024;
const MAX_LOG_LINE_TAIL_CHARS = 1024 * 1024;
const MAX_TARGETED_LOG_SYNC_BYTES = 320 * 1024 * 1024;
const MAX_ACTIVE_INITIAL_BACKFILL_BYTES = 1024 * 1024 * 1024;
const MAX_MATCH_TARGETED_LOG_SYNC_BYTES = 1024 * 1024 * 1024;
const LOG_BOUNDARY_READ_BYTES = 1024 * 1024;
const MATCH_LOG_TIME_PAD_MS = 15 * 60 * 1000;
const MATCH_SPECIFIC_LOG_BEFORE_MS = 20 * 60 * 1000;
const MATCH_SPECIFIC_LOG_AFTER_MS = 35 * 60 * 1000;
const LARGE_LOG_FOLDER_COUNT = 800;
const LARGE_LOG_FOLDER_STAT_CANDIDATES = 250;
const MAX_MATCH_WINDOW_RAW_CHARS = 28 * 1024 * 1024;
const MAX_SOLO_SHUFFLE_WINDOW_RAW_CHARS = 72 * 1024 * 1024;
const MAX_MATCH_WINDOW_LINES = 45000;
const MAX_SOLO_SHUFFLE_WINDOW_LINES = 140000;
const MAX_WINDOW_SCAN_BYTES = 192 * 1024 * 1024;
const LOG_APPROX_SEEK_BACK_BYTES = 48 * 1024 * 1024;
const EVENT_FEED_PREVIEW_ROWS = 800;
const EVENT_FEED_LEGACY_MAX_ROWS = 1600;
const EVENT_FEED_CACHE_MAX_ROWS = 12000;
const EVENT_FEED_CACHE_TRIGGER_ROWS = 900;
const STORAGE_HEALTH_PLAYER_LIMIT = 80;
const STORAGE_HEALTH_POINT_LIMIT = 420;
const STORAGE_METRIC_ROW_LIMIT = 80;
const STORAGE_ABILITY_LIMIT = 45;
const STORAGE_ABILITY_EVENT_LIMIT = 70;
const STORAGE_TARGET_LIMIT = 24;
const EMERGENCY_EVENT_FEED_PREVIEW_ROWS = 120;
const EMERGENCY_HEALTH_POINT_LIMIT = 90;
const EMERGENCY_ABILITY_EVENT_LIMIT = 20;
const STARTUP_CHANGED_LOG_SWEEP_LIMIT = 8;
const STARTUP_REPAIR_MAX_MATCHES = 20;
const STARTUP_REPAIR_MAX_FILES_PER_MATCH = 2;
const REFRESH_ACTIVE_MAX_PASSES = 6;
const REFRESH_CHANGED_LOG_SWEEP_LIMIT = 2;
const REFRESH_REPAIR_MAX_MATCHES = 3;
const REFRESH_REPAIR_MAX_FILES_PER_MATCH = 1;
const REFRESH_ACTIVE_TAIL_READ_BYTES = 4 * 1024 * 1024;
const REFRESH_WINDOW_SCAN_BYTES = 96 * 1024 * 1024;


let cachedCombatLogParserTools = null;
function getCombatLogParserTools() {
  if (!cachedCombatLogParserTools) {
    cachedCombatLogParserTools = createCombatLogParserTools({
      hashText,
      uniqueList,
      shortNameKey,
      metaForSpec,
      mapNameFromArenaStart,
      cleanMatchMapName,
      isRawInstanceMapLabel,
      battlegroundInstanceMapName,
      battlegroundMapNameFromSubzone,
      isKnownBattlegroundZone,
      expectedTeamSizeForType,
      teamCountsFromNames,
      maxTeamCount,
      isBattlegroundType,
      isRatedBattlegroundType,
      inferSoloShuffleRoundWinnerFromDeath,
      getParserVersion: () => PARSER_VERSION
    });
  }
  return cachedCombatLogParserTools;
}

function cleanSpellName(...args) { return getCombatLogParserTools().cleanSpellName(...args); }
function parseCombatLine(...args) { return getCombatLogParserTools().parseCombatLine(...args); }
function isKnownOffensivePurgeSpell(...args) { return getCombatLogParserTools().isKnownOffensivePurgeSpell(...args); }
function formatDuration(...args) { return getCombatLogParserTools().formatDuration(...args); }
function durationSecondsFromValue(...args) { return getCombatLogParserTools().durationSecondsFromValue(...args); }
function isUsefulUnitName(...args) { return getCombatLogParserTools().isUsefulUnitName(...args); }
function normalizeMatchType(...args) { return getCombatLogParserTools().normalizeMatchType(...args); }
function processRawText(...args) { return getCombatLogParserTools().processRawText(...args); }

let cachedSoloShuffleTools = null;
function getSoloShuffleTools() {
  if (!cachedSoloShuffleTools) {
    cachedSoloShuffleTools = createSoloShuffleTools({
      normalizeMatchType,
      matchTimeRangeMs,
      normalizedMapKey,
      uniqueList,
      hashText,
      formatDuration,
      mergeUserPreservedMatchFields,
      getParserVersion: () => PARSER_VERSION,
      shortNameKey,
      isUsefulUnitName
    });
  }
  return cachedSoloShuffleTools;
}

function inferSoloShuffleRoundWinnerFromDeath(...args) {
  return getSoloShuffleTools().inferSoloShuffleRoundWinnerFromDeath(...args);
}

function isSoloShuffleMatch(...args) {
  return getSoloShuffleTools().isSoloShuffleMatch(...args);
}

function matchPlayerIdentitySet(...args) {
  return getSoloShuffleTools().matchPlayerIdentitySet(...args);
}

function isSoloShuffleLobbyMatch(...args) {
  return getSoloShuffleTools().isSoloShuffleLobbyMatch(...args);
}

function isSoloShuffleRoundChildMatch(...args) {
  return getSoloShuffleTools().isSoloShuffleRoundChildMatch(...args);
}

function annotateSoloShuffleSessions(...args) {
  return getSoloShuffleTools().annotateSoloShuffleSessions(...args);
}

function soloShuffleSessionRangeMs(...args) {
  return getSoloShuffleTools().soloShuffleSessionRangeMs(...args);
}

function videoGroupRangeForMatch(...args) {
  return getSoloShuffleTools().videoGroupRangeForMatch(...args);
}




let cachedVodIpcTools = null;
function getVodIpcTools() {
  if (!cachedVodIpcTools) {
    cachedVodIpcTools = createVodIpcTools({
      app,
      fs,
      path,
      dialog,
      ipcMain,
      getMainWindow: () => mainWindow,
      readState,
      writeState,
      ensureDir,
      defaultSettings,
      appStorageDir,
      localFileDateTimeStamp,
      bestRecordingPickerPath,
      normalizeFilePathList,
      importVodPathsIntoState,
      sanitizeVodRecord,
      compactMutationCollections,
      refreshVideoLinkIndexes,
      compactRecentMatchesForResponse,
      compactRecordingsForResponse,
      compactVodsForResponse,
      vodClipCandidatesForState,
      uniqueList,
      buildClientStatePayload
    });
  }
  return cachedVodIpcTools;
}

function parseVodStartFromFilename(...args) { return getVodIpcTools().parseVodStartFromFilename(...args); }
function clipsDir(...args) { return getVodIpcTools().clipsDir(...args); }


let cachedVodLinkingTools = null;
function getVodLinkingTools() {
  if (!cachedVodLinkingTools) {
    cachedVodLinkingTools = createVodLinkingTools({
      path,
      fs,
      crypto,
      hashText,
      normalizeMatchType,
      isBattlegroundType,
      isSoloShuffleRoundChildMatch,
      annotateSoloShuffleSessions,
      videoGroupRangeForMatch,
      confidentRecordingMatchOverlap,
      uniqueList,
      parseVodStartFromFilename
    });
  }
  return cachedVodLinkingTools;
}

function looksLikeVodVideoFile(...args) {
  return getVodLinkingTools().looksLikeVodVideoFile(...args);
}

function sanitizeVodRecord(...args) {
  return getVodLinkingTools().sanitizeVodRecord(...args);
}

function defaultVideoPreRollSec(...args) {
  return getVodLinkingTools().defaultVideoPreRollSec(...args);
}

function matchReplayStartMs(...args) {
  return getVodLinkingTools().matchReplayStartMs(...args);
}

function isAddonOnlyTimingMatch(...args) {
  return getVodLinkingTools().isAddonOnlyTimingMatch(...args);
}

function estimatedAddonOnlyDurationSec(...args) {
  return getVodLinkingTools().estimatedAddonOnlyDurationSec(...args);
}

function matchTimeRangeMs(...args) {
  return getVodLinkingTools().matchTimeRangeMs(...args);
}

function boundedMatchTimeRangeMs(...args) {
  return getVodLinkingTools().boundedMatchTimeRangeMs(...args);
}

function vodClipCandidatesForState(...args) {
  return getVodLinkingTools().vodClipCandidatesForState(...args);
}

function recordingSessionVodId(...args) {
  return getVodLinkingTools().recordingSessionVodId(...args);
}

function recordingTimeRangeMs(...args) {
  return getVodLinkingTools().recordingTimeRangeMs(...args);
}

function upsertRecordingSessionVod(...args) {
  return getVodLinkingTools().upsertRecordingSessionVod(...args);
}

function refreshVideoLinkIndexes(...args) {
  return getVodLinkingTools().refreshVideoLinkIndexes(...args);
}

function repairTinyVideoSectionClips(...args) {
  return getVodLinkingTools().repairTinyVideoSectionClips(...args);
}


function linkRecordingSessionToMatches(...args) {
  return getVodLinkingTools().linkRecordingSessionToMatches(...args);
}


let cachedMatchActionTools = null;
function getMatchActionTools() {
  if (!cachedMatchActionTools) {
    cachedMatchActionTools = createMatchActionTools({
      ipcMain,
      readState,
      writeState,
      mergeAddonScoreboardIntoMatch,
      dedupeStateMatches,
      compactRecentMatchesForResponse,
      compactMutationCollections,
      compactRecordingsForResponse,
      uniqueList,
      isSoloShuffleLobbyMatch
    });
  }
  return cachedMatchActionTools;
}

function registerMatchActionIpc(...args) { return getMatchActionTools().registerIpcHandlers(...args); }

let cachedRecordingBackendTools = null;
function getRecordingBackendTools() {
  if (!cachedRecordingBackendTools) {
    cachedRecordingBackendTools = createRecordingBackendTools({
      fs,
      path,
      crypto,
      desktopCapturer,
      dialog,
      ipcMain,
      getMainWindow: () => mainWindow,
      readState,
      writeState,
      defaultSettings,
      ensureDir,
      appStorageDir,
      hashText,
      annotateSoloShuffleSessions,
      linkRecordingSessionToMatches,
      refreshVideoLinkIndexes,
      resolveStateMatchLibrary,
      compactMutationCollections,
      compactRecentMatchesForResponse,
      compactVodsForResponse,
      runQueuedImportJob
    });
  }
  return cachedRecordingBackendTools;
}

function defaultRecordingsFolderPath(...args) { return getRecordingBackendTools().defaultRecordingsFolderPath(...args); }
function ensureDefaultRecordingsFolder(...args) { return getRecordingBackendTools().ensureDefaultRecordingsFolder(...args); }
function recordingsRootDir(...args) { return getRecordingBackendTools().recordingsRootDir(...args); }
function archiveRootDir(state = null) {
  const settings = state && state.settings ? { ...defaultSettings(), ...state.settings } : defaultSettings();
  const dir = settings.archiveDir || path.join(appStorageDir(), 'archives');
  ensureDir(dir);
  return dir;
}
function isVideoFileName(...args) { return getRecordingBackendTools().isVideoFileName(...args); }
function scanVideoFiles(...args) { return getRecordingBackendTools().scanVideoFiles(...args); }
function recordingRecordFromFile(...args) { return getRecordingBackendTools().recordingRecordFromFile(...args); }
function bestRecordingPickerPath(...args) { return getRecordingBackendTools().bestRecordingPickerPath(...args); }
function confidentRecordingMatchOverlap(...args) { return getRecordingBackendTools().confidentRecordingMatchOverlap(...args); }
function autoLinkRecordings(...args) { return getRecordingBackendTools().autoLinkRecordings(...args); }
function localDateStamp(...args) { return getRecordingBackendTools().localDateStamp(...args); }
function localFileDateTimeStamp(...args) { return getRecordingBackendTools().localFileDateTimeStamp(...args); }
function todayStamp(...args) { return getRecordingBackendTools().todayStamp(...args); }
function matchRecordingLabel(...args) { return getRecordingBackendTools().matchRecordingLabel(...args); }
function compactRecordingRecord(...args) { return getRecordingBackendTools().compactRecordingRecord(...args); }
function compactRecordingsForResponse(...args) { return getRecordingBackendTools().compactRecordingsForResponse(...args); }
function getSafeCaptureSources(...args) { return getRecordingBackendTools().getSafeCaptureSources(...args); }
function getSelectedCaptureSourceId(...args) { return getRecordingBackendTools().getSelectedCaptureSourceId(...args); }
function getSelectedCaptureAudio(...args) { return getRecordingBackendTools().getSelectedCaptureAudio(...args); }
function registerRecordingBackendIpc(...args) { return getRecordingBackendTools().registerIpcHandlers(...args); }

let cachedFavoriteBackendTools = null;
function getFavoriteBackendTools() {
  if (!cachedFavoriteBackendTools) {
    cachedFavoriteBackendTools = createFavoriteBackendTools({
      ipcMain,
      crypto,
      readState,
      writeState,
      sanitizeMatchForStorage,
      compactRecentMatchesForResponse
    });
  }
  return cachedFavoriteBackendTools;
}
function registerFavoriteBackendIpc(...args) { return getFavoriteBackendTools().registerIpcHandlers(...args); }

function normalizeFilePathList(...args) {
  return getVodLinkingTools().normalizeFilePathList(...args);
}

function importVodPathsIntoState(...args) {
  return getVodLinkingTools().importVodPathsIntoState(...args);
}



let cachedMatchLibraryTools = null;
function getMatchLibraryTools() {
  if (!cachedMatchLibraryTools) {
    cachedMatchLibraryTools = createMatchLibraryTools({
      sanitizeMatchForStorage,
      isSoloShuffleRoundChildMatch,
      isSoloShuffleLobbyMatch,
      uniqueList
    });
  }
  return cachedMatchLibraryTools;
}

function compactRecentMatchesForResponse(...args) {
  return getMatchLibraryTools().compactRecentMatchesForResponse(...args);
}

function compactVisibleChangedMatchesForResponse(...args) {
  return getMatchLibraryTools().compactVisibleChangedMatchesForResponse(...args);
}

let cachedStartupPayloadTools = null;
function getStartupPayloadTools() {
  if (!cachedStartupPayloadTools) {
    cachedStartupPayloadTools = createStartupPayloadTools({
      app,
      fs,
      path,
      defaultSettings,
      getLogCandidates,
      getLogCandidatesFromFolders,
      getCandidateLogFolders,
      isCombatLogFileName,
      statePath,
      appStorageInfo,
      recordingsRootDir,
      archiveRootDir,
      clipsDir,
      stateBackupsDir,
      localAddonPackageDropDir,
      buildPvPHelperInstallStatus,
      discoverPvPHelperSavedVariables,
      storedEventFeedCount,
      eventFeedCacheStats,
      importJobStatusSnapshot,
      maxActiveTailReadBytes: MAX_ACTIVE_TAIL_READ_BYTES,
      largeLogFolderCount: LARGE_LOG_FOLDER_COUNT
    });
  }
  return cachedStartupPayloadTools;
}

function quickLogSuggestion(...args) {
  return getStartupPayloadTools().quickLogSuggestion(...args);
}

function stateFileStats(...args) {
  return getStartupPayloadTools().stateFileStats(...args);
}

function estimateStoredEventFeedRows(...args) {
  return getStartupPayloadTools().estimateStoredEventFeedRows(...args);
}

function countObjectKeys(...args) {
  return getStartupPayloadTools().countObjectKeys(...args);
}

function buildPerformanceAudit(...args) {
  return getStartupPayloadTools().buildPerformanceAudit(...args);
}

function buildClientStatePayload(...args) {
  return getStartupPayloadTools().buildClientStatePayload(...args);
}

function buildDeferredStartupDiagnostics(...args) {
  return getStartupPayloadTools().buildDeferredStartupDiagnostics(...args);
}

let cachedCombatLogDiscoveryTools = null;
function getCombatLogDiscoveryTools() {
  if (!cachedCombatLogDiscoveryTools) {
    cachedCombatLogDiscoveryTools = createCombatLogDiscoveryTools({
      app,
      fs,
      path,
      processObj: process,
      readRange,
      rootThroughRetail,
      deriveWowRetailRoot,
      defaultSettings,
      logBoundaryReadBytes: LOG_BOUNDARY_READ_BYTES,
      largeLogFolderCount: LARGE_LOG_FOLDER_COUNT,
      largeLogFolderStatCandidates: LARGE_LOG_FOLDER_STAT_CANDIDATES
    });
  }
  return cachedCombatLogDiscoveryTools;
}

function getPreferredRetailLogFolder(...args) { return getCombatLogDiscoveryTools().getPreferredRetailLogFolder(...args); }
function getPotentialLogFolders(...args) { return getCombatLogDiscoveryTools().getPotentialLogFolders(...args); }
function isCombatLogFileName(...args) { return getCombatLogDiscoveryTools().isCombatLogFileName(...args); }
function logFileNameTimeScore(...args) { return getCombatLogDiscoveryTools().logFileNameTimeScore(...args); }
function logFileEntryWeight(...args) { return getCombatLogDiscoveryTools().logFileEntryWeight(...args); }
function logFileNameTimeMs(...args) { return getCombatLogDiscoveryTools().logFileNameTimeMs(...args); }
function logFileApproxTimeMs(...args) { return getCombatLogDiscoveryTools().logFileApproxTimeMs(...args); }
function logFileNameYear(...args) { return getCombatLogDiscoveryTools().logFileNameYear(...args); }
function lineStampTimeMs(...args) { return getCombatLogDiscoveryTools().lineStampTimeMs(...args); }
function readFirstLogLineTimeMs(...args) { return getCombatLogDiscoveryTools().readFirstLogLineTimeMs(...args); }
function readLastLogLineTimeMs(...args) { return getCombatLogDiscoveryTools().readLastLogLineTimeMs(...args); }
function logRegistryKey(...args) { return getCombatLogDiscoveryTools().logRegistryKey(...args); }
function buildLogFileInfo(...args) { return getCombatLogDiscoveryTools().buildLogFileInfo(...args); }
function rememberLogFileInfo(...args) { return getCombatLogDiscoveryTools().rememberLogFileInfo(...args); }
function buildLogFileRoster(...args) { return getCombatLogDiscoveryTools().buildLogFileRoster(...args); }
function logFileCandidatesForStats(...args) { return getCombatLogDiscoveryTools().logFileCandidatesForStats(...args); }
function getLogFileSummaryInFolder(...args) { return getCombatLogDiscoveryTools().getLogFileSummaryInFolder(...args); }
function getLogFilesInFolder(...args) { return getCombatLogDiscoveryTools().getLogFilesInFolder(...args); }
function findBestLogFileInFolder(...args) { return getCombatLogDiscoveryTools().findBestLogFileInFolder(...args); }
function getNearbyLogFolders(...args) { return getCombatLogDiscoveryTools().getNearbyLogFolders(...args); }
function getCandidateLogFolders(...args) { return getCombatLogDiscoveryTools().getCandidateLogFolders(...args); }
function getLogCandidatesFromFolders(...args) { return getCombatLogDiscoveryTools().getLogCandidatesFromFolders(...args); }
function getLogCandidates(...args) { return getCombatLogDiscoveryTools().getLogCandidates(...args); }
function getDefaultLogCandidates(...args) { return getCombatLogDiscoveryTools().getDefaultLogCandidates(...args); }
function getLogPickerDefaultPath(...args) { return getCombatLogDiscoveryTools().getLogPickerDefaultPath(...args); }
function getLogSuggestion(...args) { return getCombatLogDiscoveryTools().getLogSuggestion(...args); }
function autoLocateCombatLog(state = readState()) { return getCombatLogDiscoveryTools().autoLocateCombatLog(state); }
function startupLightLogStatus(...args) { return getCombatLogDiscoveryTools().startupLightLogStatus(...args); }

let cachedLiveLogSessionTools = null;
function getLiveLogSessionTools() {
  if (!cachedLiveLogSessionTools) {
    cachedLiveLogSessionTools = createLiveLogSessionTools({
      path,
      parseCombatLine,
      processRawText,
      cleanSpellName,
      battlegroundInstanceMapName,
      battlegroundMapNameFromSubzone,
      isKnownBattlegroundZone,
      normalizedMapKey
    });
  }
  return cachedLiveLogSessionTools;
}

function resetLiveSession(...args) { return getLiveLogSessionTools().resetLiveSession(...args); }
function processLiveLogLines(...args) { return getLiveLogSessionTools().processLiveLogLines(...args); }
function finalizeLiveSessionAtFileEnd(...args) { return getLiveLogSessionTools().finalizeLiveSessionAtFileEnd(...args); }

let cachedLiveLogSyncTools = null;
function getLiveLogSyncTools() {
  if (!cachedLiveLogSyncTools) {
    const { createLiveLogSyncTools } = require('./modules/liveLogSync.cjs');
    cachedLiveLogSyncTools = createLiveLogSyncTools({
      fs,
      path,
      readState,
      writeState,
      defaultSettings,
      resetLiveSession,
      processRawText,
      importParsedMatchesIntoState,
      importLogFileChunkedIntoState,
      readRange,
      splitCompleteLogLines,
      processLiveLogLines,
      finalizeLiveSessionAtFileEnd,
      isCombatLogFileName,
      findBestLogFileInFolder,
      maxActiveTailReadBytes: MAX_ACTIVE_TAIL_READ_BYTES,
      maxTargetedLogSyncBytes: MAX_TARGETED_LOG_SYNC_BYTES,
      maxActiveInitialBackfillBytes: MAX_ACTIVE_INITIAL_BACKFILL_BYTES,
      sendToRenderer: (channel, payload) => {
        if (mainWindow && mainWindow.webContents) mainWindow.webContents.send(channel, payload);
      }
    });
  }
  return cachedLiveLogSyncTools;
}

function processWatchedFile(...args) { return getLiveLogSyncTools().processWatchedFile(...args); }
function processActiveLogTail(...args) { return getLiveLogSyncTools().processActiveLogTail(...args); }

const WOW_CLASS_COLORS = {
  DeathKnight: '#C41E3A',
  DemonHunter: '#A330C9',
  Druid: '#FF7C0A',
  Evoker: '#33937F',
  Hunter: '#AAD372',
  Mage: '#3FC7EB',
  Monk: '#00FF98',
  Paladin: '#F48CBA',
  Priest: '#FFFFFF',
  Rogue: '#FFF468',
  Shaman: '#0070DD',
  Warlock: '#8788EE',
  Warrior: '#C69B6D'
};


const CLASS_TOKEN_TO_NAME = {
  DEATHKNIGHT: 'DeathKnight',
  DEMONHUNTER: 'DemonHunter',
  DRUID: 'Druid',
  EVOKER: 'Evoker',
  HUNTER: 'Hunter',
  MAGE: 'Mage',
  MONK: 'Monk',
  PALADIN: 'Paladin',
  PRIEST: 'Priest',
  ROGUE: 'Rogue',
  SHAMAN: 'Shaman',
  WARLOCK: 'Warlock',
  WARRIOR: 'Warrior'
};

function normalizeClassKey(value = '') {
  const raw = String(value || '').replace(/[^A-Za-z]/g, '');
  if (!raw) return '';
  const upper = raw.toUpperCase();
  if (CLASS_TOKEN_TO_NAME[upper]) return CLASS_TOKEN_TO_NAME[upper];
  return raw.charAt(0).toUpperCase() + raw.slice(1);
}


let cachedPvPHelperTools = null;
function getPvPHelperTools() {
  if (!cachedPvPHelperTools) {
    cachedPvPHelperTools = createPvPHelperTools({
      app,
      fs,
      path,
      processObj: process,
      dirname: __dirname,
      ensureDir,
      appStorageDir,
      getDefaultLogCandidates,
      objectArrayLikeToArray,
      minimumSupportedVersion: MIN_SUPPORTED_PVPHELPER_VERSION
    });
  }
  return cachedPvPHelperTools;
}

function versionParts(...args) {
  return getPvPHelperTools().versionParts(...args);
}

function compareVersions(...args) {
  return getPvPHelperTools().compareVersions(...args);
}

function firstVersionValue(...args) {
  return getPvPHelperTools().firstVersionValue(...args);
}

function extractPvPHelperVersion(...args) {
  return getPvPHelperTools().extractPvPHelperVersion(...args);
}

function buildPvPHelperVersionStatus(...args) {
  return getPvPHelperTools().buildPvPHelperVersionStatus(...args);
}

function safeExists(...args) {
  return getPvPHelperTools().safeExists(...args);
}

function isPathWritable(...args) {
  return getPvPHelperTools().isPathWritable(...args);
}

function localAddonPackageDropDir(...args) {
  return getPvPHelperTools().localAddonPackageDropDir(...args);
}

function pvpHelperPackageBaseDirs(...args) {
  return getPvPHelperTools().pvpHelperPackageBaseDirs(...args);
}

function pvpHelperPackageCandidates(...args) {
  return getPvPHelperTools().pvpHelperPackageCandidates(...args);
}

function resolveAddonFolderPath(...args) {
  return getPvPHelperTools().resolveAddonFolderPath(...args);
}

function addonFolderLooksValid(...args) {
  return getPvPHelperTools().addonFolderLooksValid(...args);
}

function readAddonTocVersion(...args) {
  return getPvPHelperTools().readAddonTocVersion(...args);
}

function bestPvPHelperPackage(...args) {
  return getPvPHelperTools().bestPvPHelperPackage(...args);
}

function bundledPvPHelperFolder(...args) {
  return getPvPHelperTools().bundledPvPHelperFolder(...args);
}

function rootThroughRetail(...args) {
  return getPvPHelperTools().rootThroughRetail(...args);
}

function deriveWowRetailRoot(...args) {
  return getPvPHelperTools().deriveWowRetailRoot(...args);
}

function pvpHelperInstallPaths(...args) {
  return getPvPHelperTools().pvpHelperInstallPaths(...args);
}

function pvpHelperWtfAccountRoot(...args) {
  return getPvPHelperTools().pvpHelperWtfAccountRoot(...args);
}

function safeStat(...args) {
  return getPvPHelperTools().safeStat(...args);
}

function looksLikePvPHelperSavedVariables(...args) {
  return getPvPHelperTools().looksLikePvPHelperSavedVariables(...args);
}

function pvpHelperCandidateAccountName(...args) {
  return getPvPHelperTools().pvpHelperCandidateAccountName(...args);
}

function summarizePvPHelperSavedVariablesCandidate(...args) {
  return getPvPHelperTools().summarizePvPHelperSavedVariablesCandidate(...args);
}

function selectedPvPHelperSearchRoots(...args) {
  return getPvPHelperTools().selectedPvPHelperSearchRoots(...args);
}

function findPvPHelperSavedVariablesFromSelection(...args) {
  return getPvPHelperTools().findPvPHelperSavedVariablesFromSelection(...args);
}

function discoverPvPHelperSavedVariables(...args) {
  return getPvPHelperTools().discoverPvPHelperSavedVariables(...args);
}

function buildPvPHelperInstallStatus(...args) {
  return getPvPHelperTools().buildPvPHelperInstallStatus(...args);
}


let cachedAppStorageTools = null;
function getAppStorageTools() {
  if (!cachedAppStorageTools) {
    cachedAppStorageTools = createAppStorageTools({
      app,
      fs,
      path,
      processObj: process,
      ensureDir,
      readState,
      writeState,
      sanitizeState,
      defaultSettings,
      buildClientStatePayload
    });
  }
  return cachedAppStorageTools;
}

function normalizePathText(...args) { return getAppStorageTools().normalizePathText(...args); }
function samePath(...args) { return getAppStorageTools().samePath(...args); }
function pathIsInside(...args) { return getAppStorageTools().pathIsInside(...args); }
function copyDirRecursive(...args) { return getAppStorageTools().copyDirRecursive(...args); }
function defaultPortableStorageDir(...args) { return getAppStorageTools().defaultPortableStorageDir(...args); }
function appStorageInfo(...args) { return getAppStorageTools().appStorageInfo(...args); }
function appStorageDir(...args) { return getAppStorageTools().appStorageDir(...args); }
function migrateAppStorageTo(...args) { return getAppStorageTools().migrateAppStorageTo(...args); }
function connectAppStorageTo(...args) { return getAppStorageTools().connectAppStorageTo(...args); }

const SPEC_META = {
  250: ['Blood', 'DeathKnight'], 251: ['Frost', 'DeathKnight'], 252: ['Unholy', 'DeathKnight'],
  577: ['Havoc', 'DemonHunter'], 581: ['Vengeance', 'DemonHunter'],
  102: ['Balance', 'Druid'], 103: ['Feral', 'Druid'], 104: ['Guardian', 'Druid'], 105: ['Restoration', 'Druid'],
  1467: ['Devastation', 'Evoker'], 1468: ['Preservation', 'Evoker'], 1473: ['Augmentation', 'Evoker'],
  253: ['Beast Mastery', 'Hunter'], 254: ['Marksmanship', 'Hunter'], 255: ['Survival', 'Hunter'],
  62: ['Arcane', 'Mage'], 63: ['Fire', 'Mage'], 64: ['Frost', 'Mage'],
  268: ['Brewmaster', 'Monk'], 269: ['Windwalker', 'Monk'], 270: ['Mistweaver', 'Monk'],
  65: ['Holy', 'Paladin'], 66: ['Protection', 'Paladin'], 70: ['Retribution', 'Paladin'],
  256: ['Discipline', 'Priest'], 257: ['Holy', 'Priest'], 258: ['Shadow', 'Priest'],
  259: ['Assassination', 'Rogue'], 260: ['Outlaw', 'Rogue'], 261: ['Subtlety', 'Rogue'],
  262: ['Elemental', 'Shaman'], 263: ['Enhancement', 'Shaman'], 264: ['Restoration', 'Shaman'],
  265: ['Affliction', 'Warlock'], 266: ['Demonology', 'Warlock'], 267: ['Destruction', 'Warlock'],
  71: ['Arms', 'Warrior'], 72: ['Fury', 'Warrior'], 73: ['Protection', 'Warrior']
};

function metaForSpec(specId) {
  const tuple = SPEC_META[Number(specId)];
  if (!tuple) return null;
  const [specName, className] = tuple;
  return { specId: Number(specId), specName, className, classColor: WOW_CLASS_COLORS[className] || '' };
}

function hashText(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

function ensureDir(dir) {
  fs.mkdirSync(dir, { recursive: true });
}

let cachedStateStorageTools = null;
function getStateStorageTools() {
  if (!cachedStateStorageTools) {
    cachedStateStorageTools = createStateStorageTools({
      app,
      fs,
      path,
      hashText,
      appStorageDir,
      ensureDir,
      sanitizeVodRecord,
      cleanBracketName,
      normalizeMatchDataSources,
      resolveStateMatchLibrary,
      constants: {
        EVENT_FEED_PREVIEW_ROWS,
        EVENT_FEED_LEGACY_MAX_ROWS,
        EVENT_FEED_CACHE_MAX_ROWS,
        EVENT_FEED_CACHE_TRIGGER_ROWS,
        STORAGE_HEALTH_PLAYER_LIMIT,
        STORAGE_HEALTH_POINT_LIMIT,
        STORAGE_METRIC_ROW_LIMIT,
        STORAGE_ABILITY_LIMIT,
        STORAGE_ABILITY_EVENT_LIMIT,
        STORAGE_TARGET_LIMIT,
        EMERGENCY_EVENT_FEED_PREVIEW_ROWS,
        EMERGENCY_HEALTH_POINT_LIMIT,
        EMERGENCY_ABILITY_EVENT_LIMIT
      }
    });
  }
  return cachedStateStorageTools;
}

function statePath(...args) { return getStateStorageTools().statePath(...args); }
function stateBackupsDir(...args) { return getStateStorageTools().stateBackupsDir(...args); }
function stateBackupStamp(...args) { return getStateStorageTools().stateBackupStamp(...args); }
function pruneStateBackups(...args) { return getStateStorageTools().pruneStateBackups(...args); }
function createStateBackup(...args) { return getStateStorageTools().createStateBackup(...args); }
function createStateBackupBeforeWrite(...args) { return getStateStorageTools().createStateBackupBeforeWrite(...args); }
function eventFeedCacheDir(...args) { return getStateStorageTools().eventFeedCacheDir(...args); }
function safeEventFeedCacheKey(...args) { return getStateStorageTools().safeEventFeedCacheKey(...args); }
function eventFeedCachePath(...args) { return getStateStorageTools().eventFeedCachePath(...args); }
function storedEventFeedCount(...args) { return getStateStorageTools().storedEventFeedCount(...args); }
function eventFeedCacheStats(...args) { return getStateStorageTools().eventFeedCacheStats(...args); }
function readMatchEventFeedCache(...args) { return getStateStorageTools().readMatchEventFeedCache(...args); }
function writeMatchEventFeedCache(...args) { return getStateStorageTools().writeMatchEventFeedCache(...args); }
function pruneEventFeedCache(...args) { return getStateStorageTools().pruneEventFeedCache(...args); }
function defaultSettings(...args) { return getStateStorageTools().defaultSettings(...args); }
function characterSnapshotDedupeKey(...args) { return getStateStorageTools().characterSnapshotDedupeKey(...args); }
function dedupeCharacterSnapshots(...args) { return getStateStorageTools().dedupeCharacterSnapshots(...args); }
function isUsableStateMatch(...args) { return getStateStorageTools().isUsableStateMatch(...args); }
function sanitizeState(...args) { return getStateStorageTools().sanitizeState(...args); }
function readState(...args) { return getStateStorageTools().readState(...args); }
function writeState(...args) { return getStateStorageTools().writeState(...args); }
function compactEventFeedRows(...args) { return getStateStorageTools().compactEventFeedRows(...args); }
function compactAbilityForStorage(...args) { return getStateStorageTools().compactAbilityForStorage(...args); }
function compactMetricRowsForStorage(...args) { return getStateStorageTools().compactMetricRowsForStorage(...args); }
function compactMetricsObjectForStorage(...args) { return getStateStorageTools().compactMetricsObjectForStorage(...args); }
function compactHealthTimelineForStorage(...args) { return getStateStorageTools().compactHealthTimelineForStorage(...args); }
function emergencyShrinkStateForWrite(...args) { return getStateStorageTools().emergencyShrinkStateForWrite(...args); }
function sanitizeMatchForStorage(...args) { return getStateStorageTools().sanitizeMatchForStorage(...args); }
function pruneStateBeforeWrite(...args) { return getStateStorageTools().pruneStateBeforeWrite(...args); }

function sendRendererProgress(channel, payload) {
  try {
    if (mainWindow && mainWindow.webContents && !mainWindow.webContents.isDestroyed()) {
      mainWindow.webContents.send(channel, payload);
    }
  } catch (_error) {}
}

const {
  importJobStatusSnapshot,
  cancelImportJob,
  runQueuedImportJob
} = createImportJobQueueTools({
  onStatus: (payload) => sendRendererProgress('import-job-status', payload)
});


function matchDedupeKey(match) {
  if (!match || typeof match !== 'object') return '';
  const map = String(match.map || '').toLowerCase().trim();
  const type = String(match.matchType || match.bracket || '').toLowerCase().trim();
  const alt = String(match.alt || '').toLowerCase().trim();
  const participants = Array.isArray(match.participants) ? match.participants : [];
  const participantKey = participants.map((name) => String(name || '').toLowerCase().trim()).filter(Boolean).sort().join('|');
  const start = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0);
  const end = Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0);
  const startBucket = start ? Math.round(start / 1000) : '';
  const endBucket = end ? Math.round(end / 1000) : '';
  if (startBucket && endBucket && (map || type || participantKey)) {
    return `time:${startBucket}:${endBucket}:${map}:${type}:${alt}:${participantKey}`;
  }
  if (Array.isArray(match.linkedAddonFingerprints) && match.linkedAddonFingerprints.length) return `addon-linked:${match.linkedAddonFingerprints.join('|')}`;
  if (match.rawFingerprint) return `raw:${match.rawFingerprint}`;
  return `id:${match.id || ''}`;
}

function matchLooseDedupeKey(match) {
  if (!match || typeof match !== 'object') return '';
  const start = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0);
  if (!Number.isFinite(start) || start <= 0) return '';
  const map = normalizedMapKey(match.map || match.zone || match.subzone || '');
  const normalized = normalizeMatchType(match.matchType || match.bracket || '');
  const type = String(normalized || '').toLowerCase().trim();
  const alt = String(match.alt || match.character || '').toLowerCase().trim();
  const duration = Number(match.durationSec || 0);
  if (normalized === 'Solo Shuffle') {
    const participantKey = Array.from(matchPlayerIdentitySet(match)).sort().join('|');
    const shuffleStartBucket = Math.round(start / 5000);
    return `loose-shuffle-round:${shuffleStartBucket}:${map}:${type}:${alt}:${participantKey}`;
  }
  const startBucket = Math.round(start / 30000);
  const durationBucket = duration > 0 ? Math.round(duration / 15) : '';
  if (!map && !type) return '';
  return `loose:${startBucket}:${durationBucket}:${map}:${type}:${alt}`;
}

function matchTimeMs(match = {}, preferEnd = false) {
  const values = preferEnd
    ? [match.endMs, match.endIso ? Date.parse(match.endIso) : 0, match.capturedAt ? Date.parse(match.capturedAt) : 0, match.startMs, match.startIso ? Date.parse(match.startIso) : 0]
    : [match.startMs, match.startIso ? Date.parse(match.startIso) : 0, match.gameStartMs, match.gameStartIso ? Date.parse(match.gameStartIso) : 0, match.videoSegmentStartMs, match.endMs, match.endIso ? Date.parse(match.endIso) : 0];
  for (const value of values) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 1000000000000) return n;
  }
  return 0;
}

function matchStableLooseKey(match) {
  if (!match || typeof match !== 'object') return '';
  const start = matchTimeMs(match, false);
  if (!start) return '';
  const map = normalizedMapKey(match.map || match.zone || match.subzone || '');
  const type = String(normalizeMatchType(match.matchType || match.bracket || '') || '').toLowerCase().trim();
  const alt = String(match.alt || match.character || match.playerName || '').toLowerCase().trim();
  if (!map && !type) return '';
  const bucketMs = normalizeMatchType(match.matchType || match.bracket || '') === 'Solo Shuffle' ? 15000 : 90000;
  const startBucket = Math.round(start / bucketMs);
  const playerSet = Array.from(matchPlayerIdentitySet(match)).slice(0, 20).sort().join('|');
  return `stable-loose:${startBucket}:${map}:${type}:${alt}:${hashText(playerSet).slice(0, 10)}`;
}

function matchAllDedupeKeys(match) {
  return uniqueList([matchDedupeKey(match), matchLooseDedupeKey(match), matchStableLooseKey(match)]);
}

function uniqueList(values) {
  return Array.from(new Set((values || []).filter(Boolean).map((value) => String(value))));
}


function hasMeaningfulValue(value) {
  if (value === undefined || value === null || value === '') return false;
  if (Array.isArray(value)) return value.length > 0;
  if (typeof value === 'object') return Object.keys(value).length > 0;
  if (typeof value === 'number') return Number.isFinite(value);
  return true;
}

function matchHasCombatLogDetails(match = {}) {
  if (!match || typeof match !== 'object') return false;
  const sources = uniqueList(match.dataSources || []);
  if (match.createdFromRealLog || sources.some((source) => /combat|log|tail/i.test(source))) return true;
  if (storedEventFeedCount(match) > 0 || match.eventFeedCacheRef) return true;
  if (match.healthTimeline && Array.isArray(match.healthTimeline.players) && match.healthTimeline.players.length) return true;
  return false;
}

function preserveExistingCombatDetails(next, old) {
  if (!next || typeof next !== 'object' || !old || typeof old !== 'object') return next;
  const oldHasCombat = matchHasCombatLogDetails(old);
  if (!oldHasCombat) return next;

  const nextHasCombat = matchHasCombatLogDetails(next);
  const oldScore = combatLogSourceScore(old);
  const nextScore = combatLogSourceScore(next);
  if (nextHasCombat && nextScore >= oldScore) return next;

  const combatKeys = [
    'createdFromRealLog', 'parserVersion', 'sourceLabel', 'sourceFile', 'rawFingerprint', 'matchFingerprint',
    'playerGuid', 'ownNames', 'spec', 'myComp', 'enemyComp', 'enemies', 'teams',
    'result', 'resultSource', 'resultAuthority', 'combatLogResult', 'combatLogOwnTeam', 'combatLogWinnerTeam', 'combatLogWinnerTeamSource', 'winnerTeam', 'winnerTeamSource', 'ownTeam', 'resultConflict', 'resultConflictNeedsReview',
    'damage', 'healing', 'taken', 'metrics', 'cooldowns', 'ccChains', 'interrupts', 'death', 'chart',
    'healthTimeline', 'eventFeed', 'rawEvents', 'eventFeedRows', 'eventFeedCachedRows', 'eventFeedCacheRef',
    'eventFeedCachedAt', 'eventFeedCacheError', 'isBracketMatch', 'soloRounds', 'logOnlyReason', 'logOnlyMatch',
    'startMs', 'startIso', 'endMs', 'endIso', 'durationSec', 'duration', 'time', 'endInferred', 'inferredEndTime', 'inferredEndMs', 'captureReason',
    'gameStartMs', 'gameStartIso', 'videoSegmentStartMs', 'videoSegmentStartIso', 'summary', 'danger', 'dataQualityNote'
  ];

  for (const key of combatKeys) {
    if (hasMeaningfulValue(old[key])) next[key] = old[key];
  }
  for (const key of ['classByName', 'specByName']) {
    if (hasMeaningfulValue(old[key]) || hasMeaningfulValue(next[key])) next[key] = { ...(old[key] || {}), ...(next[key] || {}) };
  }
  if (Array.isArray(old.participants) || Array.isArray(next.participants)) {
    next.participants = uniqueList([...(old.participants || []), ...(next.participants || [])]);
  }
  next.dataSources = uniqueList([...(old.dataSources || []), ...(next.dataSources || []), 'combatLog']);
  return next;
}

function mergeUserPreservedMatchFields(incoming, existing) {
  const next = { ...(incoming || {}) };
  const old = existing || {};
  for (const key of ['favorite', 'favorited', 'favoriteFolderId', 'favoriteComment', 'favoriteCommentUpdatedAt', 'videoPath', 'videoLabel', 'videoLinkedAt', 'videoLinkMode', 'vodId', 'vodLinkedAt', 'videoSessionId', 'videoClipStartSec', 'videoClipEndSec', 'videoMatchStartSec', 'videoMatchEndSec', 'videoShuffleStartSec', 'videoShuffleEndSec', 'videoClipPreRollSec', 'videoClipPostRollSec', 'videoSyncAdjustmentSec', 'manualVideoSection', 'videoSectionUpdatedAt', 'notes', 'userNotes', 'manualVideoPath', 'manualVideoLinkedAt', 'scoreboardLinkedToMatchId']) {
    if (old[key] !== undefined && old[key] !== null && old[key] !== '') next[key] = old[key];
  }
  if (Array.isArray(old.userTags) && old.userTags.length) next.userTags = uniqueList([...(next.userTags || []), ...old.userTags]);
  // When a start-only combat-log row later merges with a PvPHelper scoreboard,
  // keep the richer combat data but fill missing completion fields from the scoreboard.
  for (const key of ['endMs', 'endIso', 'durationSec', 'duration', 'result', 'winner', 'winnerTeam', 'rating', 'mmr', 'capturedAt', 'matchLabel', 'playerName', 'character', 'alt']) {
    if ((next[key] === undefined || next[key] === null || next[key] === '' || Number.isNaN(next[key])) && old[key] !== undefined && old[key] !== null && old[key] !== '') next[key] = old[key];
  }
  if ((!next.map || /^unknown/i.test(String(next.map))) && old.map) next.map = old.map;
  if ((!next.matchType || /pvp match|arena/i.test(String(next.matchType))) && old.matchType) next.matchType = old.matchType;
  if ((!next.bracket || /pvp match|arena/i.test(String(next.bracket))) && old.bracket) next.bracket = old.bracket;
  if (old.addonScoreboard && !next.addonScoreboard) next.addonScoreboard = old.addonScoreboard;
  if (Array.isArray(old.scoreboardPlayers) && old.scoreboardPlayers.length && (!Array.isArray(next.scoreboardPlayers) || !next.scoreboardPlayers.length)) next.scoreboardPlayers = old.scoreboardPlayers;
  if (old.addonImportConfidence && !next.addonImportConfidence) next.addonImportConfidence = old.addonImportConfidence;
  if (Array.isArray(old.linkedAddonFingerprints) && old.linkedAddonFingerprints.length) next.linkedAddonFingerprints = uniqueList([...(next.linkedAddonFingerprints || []), ...old.linkedAddonFingerprints]);
  preserveExistingCombatDetails(next, old);
  applyResultAuthority(next);
  next.dataSources = uniqueList([...(old.dataSources || []), ...(next.dataSources || [])]);
  if (old.createdFromAddon) next.createdFromAddon = true;
  if (old.createdFromRealLog) next.createdFromRealLog = true;
  return next;
}


function isRatedBattlegroundType(value) {
  const lower = String(value || '').toLowerCase();
  return /rated\s*(battle|bg)|\brbg\b/.test(lower) && !/blitz/.test(lower);
}

function isBattlegroundType(value) {
  const lower = String(value || '').toLowerCase();
  return isRatedBattlegroundType(lower) || /battlefield|battleground|\bbg\b|blitz/.test(lower);
}

const BATTLEGROUND_TEAM_SIZE_BY_MAP = new Map(Object.entries({
  'arathi basin': 15,
  'deepwind gorge': 15,
  'eye of the storm': 15,
  'warsong gulch': 10,
  'twin peaks': 10,
  'battle for gilneas': 10,
  'silvershard mines': 10,
  'temple of kotmogu': 10,
  'seething shore': 10,
  'deephaul ravine': 10,
  'gilneas': 10,
  'alterac valley': 40,
  'isle of conquest': 40,
  'ashran': 40,
  'korrak': 40,
  'wintergrasp': 40,
  'strand of the ancients': 15
}));

const KNOWN_BATTLEGROUND_ZONE_NAMES = new Set([
  'arathi basin', 'battle for gilneas', 'deepwind gorge', 'eye of the storm', 'silvershard mines', 'temple of kotmogu',
  'twin peaks', 'warsong gulch', 'seething shore', 'deephaul ravine', 'alterac valley', 'isle of conquest',
  'ashran', "korrak's revenge", 'wintergrasp', 'strand of the ancients'
]);

const KNOWN_ARENA_ZONE_NAMES = new Set([
  'nagrand arena', 'black rook hold arena', 'mugambala', 'nokhudon proving grounds', "tol'viron arena",
  'tol’viron arena', 'maldraxxus coliseum', 'empyean domain', 'empyrean domain', 'ruins of lordaeron',
  "tiger's peak", 'tiger’s peak', "blade's edge arena", 'blade’s edge arena', 'dalaran sewers',
  'enigma arena', 'enigma crucible', 'the robodrome', 'cage of carnage', "ashamane's fall", 'ashamane’s fall',
  'hook point', 'the hook point', 'the ring of valor'
]);

const INSTANCE_MAP_NAMES = new Map(Object.entries({
  // Arena/BG instance IDs are emitted by combat logs before the readable map name.
  // Keep this table local so imported logs never show raw IDs like 2547 in match rows.
  '30': 'Alterac Valley',
  '489': 'Warsong Gulch',
  '529': 'Arathi Basin',
  '566': 'Eye of the Storm',
  '572': 'Ruins of Lordaeron',
  '607': 'Strand of the Ancients',
  '617': 'Dalaran Sewers',
  '618': 'The Ring of Valor',
  '628': 'Isle of Conquest',
  '726': 'Twin Peaks',
  '727': 'Silvershard Mines',
  '761': 'The Battle for Gilneas',
  '968': 'Eye of the Storm',
  '980': "Tol'Viron Arena",
  '998': 'Temple of Kotmogu',
  '1105': 'Deepwind Gorge',
  '1134': "Tiger's Peak",
  '1504': 'Black Rook Hold Arena',
  '1505': 'Nagrand Arena',
  '1672': "Blade's Edge Arena",
  '1681': 'Arathi Basin',
  '1803': 'Seething Shore',
  '2106': 'Warsong Gulch',
  '2107': 'Arathi Basin',
  '2167': 'The Robodrome',
  '2177': 'Arathi Basin Comp Stomp',
  '2245': 'Deepwind Gorge',
  '2373': 'Empyrean Domain',
  '2509': 'Maldraxxus Coliseum',
  '2511': 'Enigma Arena',
  '2547': 'Enigma Crucible',
  '2563': 'Nokhudon Proving Grounds',
  '2759': 'Cage of Carnage'
}));

const BATTLEGROUND_INSTANCE_MAP_NAMES = new Map(Object.entries({
  '30': 'Alterac Valley',
  '489': 'Warsong Gulch',
  '529': 'Arathi Basin',
  '566': 'Eye of the Storm',
  '607': 'Strand of the Ancients',
  '628': 'Isle of Conquest',
  '726': 'Twin Peaks',
  '727': 'Silvershard Mines',
  '761': 'The Battle for Gilneas',
  '968': 'Eye of the Storm',
  '998': 'Temple of Kotmogu',
  '1105': 'Deepwind Gorge',
  '1681': 'Arathi Basin',
  '1803': 'Seething Shore',
  '2106': 'Warsong Gulch',
  '2107': 'Arathi Basin',
  '2177': 'Arathi Basin Comp Stomp',
  '2245': 'Deepwind Gorge',
  '2656': 'Deephaul Ravine'
}));

function instanceMapId(value) {
  const raw = String(value || '').trim();
  if (!raw) return '';
  const match = raw.match(/\d+/);
  return match ? match[0] : '';
}

function instanceMapName(value) {
  const id = instanceMapId(value);
  return id ? INSTANCE_MAP_NAMES.get(id) || '' : '';
}

function battlegroundInstanceMapName(value) {
  const id = instanceMapId(value);
  return id ? BATTLEGROUND_INSTANCE_MAP_NAMES.get(id) || '' : '';
}

function isRawInstanceMapLabel(value) {
  const raw = String(value || '').trim();
  return /^\d+$/.test(raw) || /^instance\s+\d+$/i.test(raw);
}

function battlegroundMapNameFromSubzone(value) {
  const key = normalizedMapKey(value);
  if (!key) return '';
  if (KNOWN_BATTLEGROUND_ZONE_NAMES.has(key) || BATTLEGROUND_TEAM_SIZE_BY_MAP.has(key)) return cleanSpellName(value);
  if (/warsong|silverwing/.test(key)) return 'Warsong Gulch';
  if (/twin peaks|wildhammer|dragonmaw/.test(key)) return 'Twin Peaks';
  if (/arathi|blacksmith|stables|gold mine|lumber\s*mill|farm|trollbane|defiler/.test(key)) return 'Arathi Basin';
  if (/gilneas|waterworks|lighthouse/.test(key)) return 'The Battle for Gilneas';
  if (/eye of the storm|draenei ruins|fel reaver|mage tower|blood elf tower/.test(key)) return 'Eye of the Storm';
  if (/silvershard/.test(key)) return 'Silvershard Mines';
  if (/kotmogu/.test(key)) return 'Temple of Kotmogu';
  if (/seething shore/.test(key)) return 'Seething Shore';
  if (/deepwind/.test(key)) return 'Deepwind Gorge';
  if (/deephaul/.test(key)) return 'Deephaul Ravine';
  return '';
}

function mapNameFromArenaStart(event) {
  if (!event || event.event !== 'ARENA_MATCH_START') return '';
  return instanceMapName(event.fields && event.fields[1]);
}

function cleanMatchMapName(value, startMarker = null, instanceId = '') {
  const raw = cleanSpellName(value || '');
  const fromStart = mapNameFromArenaStart(startMarker);
  const fromExplicitId = instanceMapName(instanceId);
  const fromRawId = isRawInstanceMapLabel(raw) ? instanceMapName(raw) : '';
  const fromBgId = battlegroundInstanceMapName(instanceId);
  const fromBgSubzone = battlegroundMapNameFromSubzone(raw);
  if (fromStart && (!raw || isRawInstanceMapLabel(raw) || /^pvp\s+arena$/i.test(raw) || /^arena$/i.test(raw))) return fromStart;
  if (fromBgId && (!raw || isRawInstanceMapLabel(raw) || fromBgSubzone || /battleground/i.test(raw))) return fromBgId;
  if (fromRawId) return fromRawId;
  if (fromExplicitId && (!raw || isRawInstanceMapLabel(raw))) return fromExplicitId;
  if (fromBgSubzone) return fromBgSubzone;
  if (raw && !isRawInstanceMapLabel(raw)) return raw;
  return fromStart || fromExplicitId || fromRawId || raw || 'Unknown map';
}

function normalizedMapKey(value) {
  return String(value || '').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim();
}

function expectedTeamSizeForMap(mapName = '', matchType = '') {
  const lowerType = String(matchType || '').toLowerCase();
  const key = normalizedMapKey(mapName);
  if (/blitz/.test(lowerType)) return 8;
  if (isRatedBattlegroundType(lowerType)) return 10;
  return BATTLEGROUND_TEAM_SIZE_BY_MAP.get(key) || 0;
}

function expectedTeamSizeForType(value, mapName = '') {
  const lower = String(value || '').toLowerCase();
  if (/2v2|\b2s\b|\b2['’]?s\b/.test(lower)) return 2;
  if (/3v3|\b3s\b|\b3['’]?s\b|shuffle|skirm/.test(lower)) return 3;
  if (/blitz/.test(lower)) return 8;
  if (isRatedBattlegroundType(lower)) return 10;
  return expectedTeamSizeForMap(mapName, value);
}

function isKnownBattlegroundZone(name = '') {
  const key = normalizedMapKey(name);
  return KNOWN_BATTLEGROUND_ZONE_NAMES.has(key) || BATTLEGROUND_TEAM_SIZE_BY_MAP.has(key) || /battleground|warsong|arathi|kotmogu|silvershard|gilneas|alterac|conquest|seething|deephaul|deepwind|ashran|wintergrasp/i.test(String(name || ''));
}

function isKnownArenaZone(name = '') {
  const key = normalizedMapKey(name);
  if (!key) return false;
  return KNOWN_ARENA_ZONE_NAMES.has(key) || /arena|mugambala|nokhudon|maldraxxus|empyrean|lordaeron|tiger'?s peak|tiger’s peak|robodrome|cage of carnage|ashamane|hook point|dalaran sewers|ring of valor/i.test(String(name || ''));
}

function isExplicitArenaType(value = '') {
  const normalized = normalizeMatchType(value || '');
  return normalized === '2v2' || normalized === '3v3' || normalized === 'Skirmish' || normalized === 'Solo Shuffle';
}

function isStaleBattlegroundDisplayTag(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return true;
  return /^(random\s*bg'?s?|random\s*battleground|battleground|rated\s*battleground|rbg'?s?|battleground\s*blitz|blitz|isBattleground)$/i.test(raw)
    || /^bg\s*\d*\s*\/\s*\d+$/i.test(raw)
    || /^rbg\s*\d*\s*\/\s*\d+$/i.test(raw);
}

function stripStaleBattlegroundTagsForArena(match = {}) {
  if (!Array.isArray(match.tags)) return match;
  match.tags = match.tags.filter((tag) => !isStaleBattlegroundDisplayTag(tag));
  return match;
}


function normalizedResultValue(value = '') {
  const raw = String(value || '').trim();
  if (!raw || /^parsed$/i.test(raw) || /^unscored$/i.test(raw)) return '';
  if (/^(win|won|winner|victory|victorious|success)$/i.test(raw) || /\b(win|won|victory)\b/i.test(raw)) return 'Win';
  if (/^(loss|lost|lose|loser|defeat|defeated|failure)$/i.test(raw) || /\b(loss|lost|defeat)\b/i.test(raw)) return 'Loss';
  return '';
}

function firstNonEmptyValue(...values) {
  for (const value of values) {
    if (value !== undefined && value !== null && String(value).trim() !== '' && String(value).trim() !== 'Unknown') return value;
  }
  return '';
}

function addonResultForMatch(match = {}) {
  const scoreboard = match && match.addonScoreboard && typeof match.addonScoreboard === 'object' ? match.addonScoreboard : {};
  const scalar = scoreboard.rawFields && scoreboard.rawFields.scalarFields && typeof scoreboard.rawFields.scalarFields === 'object' ? scoreboard.rawFields.scalarFields : {};
  const explicit = normalizedResultValue(firstNonEmptyValue(
    match.addonResult,
    match.addonScoreboardResult,
    scoreboard.result,
    scoreboard.winnerResult,
    scoreboard.outcome,
    scalar.result,
    scalar.winnerResult,
    scalar.outcome
  ));
  if (explicit) return explicit;
  const winner = firstNonEmptyValue(scoreboard.winnerTeam, scoreboard.winner, scoreboard.winnerRaw, scalar.winnerTeam, scalar.winningTeam, scalar.winner);
  const playerTeam = firstNonEmptyValue(scoreboard.playerTeam, scalar.playerTeam, match.ownTeam);
  if (winner !== '' && playerTeam !== '') return String(winner) === String(playerTeam) ? 'Win' : 'Loss';
  return '';
}

function confidentCombatLogResult(match = {}) {
  if (!match || typeof match !== 'object') return null;
  const sources = uniqueList(match.dataSources || []);
  const hasCombatLog = Boolean(match.createdFromRealLog || match.parserVersion || match.isBracketMatch || sources.some((source) => /combat|log|tail/i.test(String(source || ''))));
  if (!hasCombatLog) return null;
  const ownTeam = firstNonEmptyValue(match.ownTeam, match.combatLogOwnTeam, match.playerTeam);
  const winnerTeam = firstNonEmptyValue(match.winnerTeam, match.combatLogWinnerTeam, match.winner);
  if (ownTeam === '' || winnerTeam === '') return null;
  return {
    result: String(winnerTeam) === String(ownTeam) ? 'Win' : 'Loss',
    ownTeam: String(ownTeam),
    winnerTeam: String(winnerTeam),
    source: firstNonEmptyValue(match.winnerTeamSource, match.combatLogWinnerTeamSource, match.resultSource, 'combat-log') || 'combat-log'
  };
}

function markResultConflict(match = {}, combatLog = null, addonResult = '') {
  if (!combatLog || !addonResult || combatLog.result === addonResult) {
    if (match.resultConflict && match.resultConflict.combatLogResult === match.resultConflict.addonResult) delete match.resultConflict;
    if (!match.resultConflict) delete match.resultConflictNeedsReview;
    return match;
  }
  match.resultConflictNeedsReview = true;
  match.resultConflict = {
    type: 'result-source-conflict',
    action: 'kept-combat-log-result',
    combatLogResult: combatLog.result,
    addonResult,
    combatLogOwnTeam: combatLog.ownTeam,
    combatLogWinnerTeam: combatLog.winnerTeam,
    combatLogWinnerTeamSource: combatLog.source,
    reviewed: Boolean(match.resultConflict && match.resultConflict.reviewed),
    detectedAt: match.resultConflict && match.resultConflict.detectedAt || new Date().toISOString()
  };
  match.warning = match.warning || 'Result sources disagree. Combat log result was kept.';
  return match;
}

function applyResultAuthority(match = {}) {
  if (!match || typeof match !== 'object') return match;
  const combatLog = confidentCombatLogResult(match);
  if (!combatLog) {
    const addonResult = addonResultForMatch(match);
    if (addonResult && !normalizedResultValue(match.result)) {
      match.result = addonResult;
      match.resultSource = match.resultSource || 'addonScoreboard';
      match.resultAuthority = match.resultAuthority || 'addonScoreboard';
      match.addonResult = addonResult;
    }
    return match;
  }
  const addonResult = addonResultForMatch(match);
  if (addonResult) match.addonResult = addonResult;
  match.combatLogResult = combatLog.result;
  match.combatLogOwnTeam = combatLog.ownTeam;
  match.combatLogWinnerTeam = combatLog.winnerTeam;
  match.combatLogWinnerTeamSource = combatLog.source;
  match.result = combatLog.result;
  match.resultSource = 'combatLog';
  match.resultAuthority = 'combatLog';
  return markResultConflict(match, combatLog, addonResult);
}

function arenaTypeFromEvidence(match = {}, label = '') {
  const normalized = normalizeMatchType(label || match.matchType || match.bracket || '');
  if (normalized === 'Solo Shuffle' || normalized === 'Skirmish' || normalized === '2v2' || normalized === '3v3') return normalized;
  const counts = Object.keys(match.scoreboardTeamCounts || {}).length ? match.scoreboardTeamCounts : teamCountsFromNames(match.teams || {});
  const maxTeam = maxTeamCount(counts) || Number(match.actualTeamSize || 0) || 0;
  const expected = Number(match.expectedTeamSize || 0) || expectedTeamSizeForType(normalized, match.map || match.subzone || '');
  const participants = Array.isArray(match.participants) ? match.participants.filter(Boolean).length : 0;
  if (expected === 3 || maxTeam === 3 || participants >= 5) return '3v3';
  if (expected === 2 || maxTeam === 2) return '2v2';
  return '';
}

function teamCountsFromNames(teams = {}) {
  const counts = {};
  for (const key of Object.keys(teams || {})) {
    if (key === 'unknown') continue;
    const list = Array.isArray(teams[key]) ? teams[key].filter(Boolean) : [];
    if (list.length) counts[String(key)] = list.length;
  }
  return counts;
}

function teamCountsFromPlayers(players = []) {
  const counts = {};
  for (const player of players || []) {
    const rawTeam = player && (player.team !== undefined && player.team !== null && player.team !== '' ? player.team : player.faction);
    if (rawTeam === undefined || rawTeam === null || rawTeam === '') continue;
    const key = String(rawTeam);
    counts[key] = (counts[key] || 0) + 1;
  }
  return counts;
}

function maxTeamCount(counts = {}) {
  const values = Object.values(counts || {}).map((value) => Number(value) || 0);
  return values.length ? Math.max(...values) : 0;
}

function applyMatchModeMetadata(match) {
  if (!match || typeof match !== 'object') return match;
  const label = match.matchType || match.bracket || match.instanceType || '';
  const normalizedLabel = normalizeMatchType(label || '');
  const participants = Array.isArray(match.participants) ? match.participants.filter(Boolean) : [];
  const counts = Object.keys(match.scoreboardTeamCounts || {}).length ? match.scoreboardTeamCounts : teamCountsFromNames(match.teams || {});
  const maxTeam = maxTeamCount(counts);
  const mapName = match.map || match.subzone || '';
  const expected = expectedTeamSizeForType(label, mapName);
  const largeByRoster = maxTeam >= 6 || participants.length >= 12;
  const arenaMap = isKnownArenaZone(mapName);
  const arenaEvidence = arenaMap || isExplicitArenaType(normalizedLabel);
  const arenaTeamSize = maxTeam > 0 && maxTeam <= 3 && participants.length <= 6;
  const shouldForceArena = arenaEvidence && (isExplicitArenaType(normalizedLabel) || arenaTeamSize || expected === 2 || expected === 3 || /arena/i.test(String(match.instanceType || '')));

  if (shouldForceArena) {
    const arenaType = arenaTypeFromEvidence(match, label) || (normalizedLabel === 'PvP Match' || normalizedLabel === 'Random Battleground' ? '3v3' : normalizedLabel);
    if (arenaType && arenaType !== 'PvP Match' && arenaType !== 'Random Battleground' && arenaType !== 'Rated Battleground' && arenaType !== 'Battleground Blitz') {
      match.matchType = arenaType;
      match.bracket = arenaType;
    }
    match.isRatedBattleground = false;
    match.isBattleground = false;
    const arenaExpected = arenaType === '2v2' ? 2 : (arenaType === 'Solo Shuffle' || arenaType === '3v3' || arenaType === 'Skirmish' ? 3 : expected);
    match.expectedTeamSize = arenaExpected || match.expectedTeamSize || expected || 0;
    match.actualTeamSize = maxTeam || Math.min(Number(match.actualTeamSize || 0) || 0, match.expectedTeamSize || 3) || 0;
    match.teamSizeLabel = match.expectedTeamSize ? `${match.actualTeamSize || '?'} / ${match.expectedTeamSize}` : (match.actualTeamSize ? `${match.actualTeamSize}` : '');
    stripStaleBattlegroundTagsForArena(match);
    return match;
  }

  match.isRatedBattleground = Boolean(match.isRatedBattleground || isRatedBattlegroundType(label));
  match.isBattleground = Boolean(match.isRatedBattleground || isBattlegroundType(label) || largeByRoster);
  match.expectedTeamSize = match.expectedTeamSize || expected || (largeByRoster ? maxTeam : 0);
  match.actualTeamSize = match.actualTeamSize || maxTeam || 0;
  match.teamSizeLabel = match.expectedTeamSize ? `${match.actualTeamSize || '?'} / ${match.expectedTeamSize}` : (match.actualTeamSize ? `${match.actualTeamSize}` : '');
  return match;
}


function countMetricAbilityValue(ability = {}) {
  const events = Array.isArray(ability.events) ? ability.events : [];
  const targets = Array.isArray(ability.targets) ? ability.targets : [];
  return Number(ability.count || ability.amount || ability.hits || ability.actions || events.length || targets.reduce((sum, target) => sum + (Number(target && target.hits) || 0), 0)) || 0;
}

function rebuildCountMetricRows(rows = []) {
  const cleaned = (Array.isArray(rows) ? rows : []).map((row) => {
    if (!row || !isUsefulUnitName(row.name)) return null;
    const abilities = (Array.isArray(row.abilities) ? row.abilities : []).map((ability) => {
      if (!ability || !ability.name) return null;
      const count = countMetricAbilityValue(ability);
      if (!count) return null;
      return {
        ...ability,
        amount: count,
        count,
        hits: Number(ability.hits || count) || count,
        casts: Number(ability.casts || count) || count,
        actions: Number(ability.actions || count) || count,
        targets: Array.isArray(ability.targets) ? ability.targets : [],
        events: Array.isArray(ability.events) ? ability.events : []
      };
    }).filter(Boolean).sort((a, b) => (Number(b.count) || 0) - (Number(a.count) || 0));
    const count = abilities.reduce((sum, ability) => sum + (Number(ability.count) || 0), 0);
    if (!count) return null;
    return {
      ...row,
      amount: count,
      count,
      abilities,
      top: abilities.slice(0, 3).map((ability) => ability.name).join(', ') || 'No abilities found'
    };
  }).filter(Boolean).sort((a, b) => (Number(b.count || b.amount) || 0) - (Number(a.count || a.amount) || 0));
  const total = cleaned.reduce((sum, row) => sum + (Number(row.count || row.amount) || 0), 0) || 1;
  return cleaned.map((row) => ({ ...row, percent: Math.max(1, Math.round(((Number(row.count || row.amount) || 0) / total) * 100)) })).slice(0, 80);
}

function mergeCountMetricRows(...groups) {
  const byActor = new Map();
  const mergeTargets = (left = [], right = []) => {
    const byName = new Map();
    for (const target of [...(Array.isArray(left) ? left : []), ...(Array.isArray(right) ? right : [])]) {
      if (!target || !target.name) continue;
      const key = String(target.name).toLowerCase();
      const current = byName.get(key) || { ...target, hits: 0 };
      current.hits = (Number(current.hits) || 0) + (Number(target.hits) || 0);
      current.isPlayer = Boolean(current.isPlayer || target.isPlayer);
      byName.set(key, current);
    }
    return Array.from(byName.values()).sort((a, b) => (Number(b.hits) || 0) - (Number(a.hits) || 0)).slice(0, 30);
  };
  for (const row of groups.flatMap((group) => Array.isArray(group) ? group : [])) {
    if (!row || !isUsefulUnitName(row.name)) continue;
    const actorKey = String(row.name).toLowerCase();
    const actor = byActor.get(actorKey) || { ...row, abilities: [] };
    const byAbility = new Map((Array.isArray(actor.abilities) ? actor.abilities : []).map((ability) => [String(ability.name || '').toLowerCase(), ability]));
    for (const ability of Array.isArray(row.abilities) ? row.abilities : []) {
      if (!ability || !ability.name) continue;
      const abilityKey = String(ability.name).toLowerCase();
      const current = byAbility.get(abilityKey) || { ...ability, count: 0, amount: 0, hits: 0, casts: 0, actions: 0, events: [], targets: [] };
      const count = countMetricAbilityValue(ability);
      current.count = (Number(current.count) || 0) + count;
      current.amount = (Number(current.amount) || 0) + count;
      current.hits = (Number(current.hits) || 0) + (Number(ability.hits || count) || count);
      current.casts = (Number(current.casts) || 0) + (Number(ability.casts || count) || count);
      current.actions = (Number(current.actions) || 0) + (Number(ability.actions || count) || count);
      current.events = [...(Array.isArray(current.events) ? current.events : []), ...(Array.isArray(ability.events) ? ability.events : [])];
      current.targets = mergeTargets(current.targets, ability.targets);
      byAbility.set(abilityKey, current);
    }
    actor.abilities = Array.from(byAbility.values());
    byActor.set(actorKey, actor);
  }
  return rebuildCountMetricRows(Array.from(byActor.values()));
}

function normalizeStoredPurgeMetrics(match) {
  if (!match || !match.metrics || typeof match.metrics !== 'object') return match;
  const dispelRows = Array.isArray(match.metrics.Dispels) ? match.metrics.Dispels : [];
  if (!dispelRows.length) return match;
  const remainingDispels = [];
  const movedPurges = [];
  for (const row of dispelRows) {
    if (!row || !Array.isArray(row.abilities)) {
      if (row) remainingDispels.push(row);
      continue;
    }
    const keepAbilities = [];
    const purgeAbilities = [];
    for (const ability of row.abilities) {
      const eventSpellNames = (Array.isArray(ability && ability.events) ? ability.events : []).flatMap((event) => [event && event.dispelSpellName, event && event.ability]);
      const isPurgeAbility = isKnownOffensivePurgeSpell(ability && ability.name) || eventSpellNames.some(isKnownOffensivePurgeSpell);
      if (isPurgeAbility) purgeAbilities.push(ability);
      else keepAbilities.push(ability);
    }
    if (keepAbilities.length) remainingDispels.push({ ...row, abilities: keepAbilities });
    if (purgeAbilities.length) movedPurges.push({ ...row, abilities: purgeAbilities });
  }
  if (movedPurges.length) {
    match.metrics.Purges = mergeCountMetricRows(match.metrics.Purges || [], movedPurges);
    match.metrics.Dispels = rebuildCountMetricRows(remainingDispels);
  }
  return match;
}

function normalizeMatchDataSources(match) {
  if (!match || typeof match !== 'object') return match;
  const possibleInstanceId = match.mapID ?? match.mapId ?? match.instanceID ?? match.instanceId ?? match.zoneID ?? match.zoneId ?? '';
  if (match.map || possibleInstanceId) match.map = cleanMatchMapName(match.map || match.zone || match.subzone || match.subZone || '', null, possibleInstanceId);
  if (match.subzone && normalizedMapKey(match.subzone) === normalizedMapKey(match.map)) match.subzone = '';
  normalizeStoredPurgeMetrics(match);
  const sources = uniqueList(match.dataSources || []);
  if (match.createdFromRealLog && !sources.includes('combatLog')) sources.push('combatLog');
  if ((match.createdFromAddon || match.addonScoreboard || (Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length)) && !sources.includes('addonScoreboard')) sources.push('addonScoreboard');
  if (match.videoPath && !sources.includes('video')) sources.push('video');
  match.dataSources = uniqueList(sources);
  return applyResultAuthority(applyMatchModeMetadata(match));
}


function combatLogSourceScore(match = {}) {
  const sources = uniqueList(match.dataSources || []);
  const events = storedEventFeedCount(match);
  const metricRows = match.metrics && typeof match.metrics === 'object'
    ? Object.values(match.metrics).reduce((sum, rows) => sum + (Array.isArray(rows) ? rows.length : 0), 0)
    : 0;
  const players = Array.isArray(match.scoreboardPlayers) ? match.scoreboardPlayers.length : 0;
  const hasEnd = Boolean(match.endMs || match.endIso);
  const hasCompleteArenaEnd = hasEnd && !match.endInferred && String(match.captureReason || '').toLowerCase() === 'arena-end';
  const hasCombat = Boolean(match.createdFromRealLog) || sources.some((source) => /combat|log|tail/i.test(source));
  return (hasCombat ? 5000 : 0) + Math.min(events, 2500) + Math.min(metricRows * 5, 1000) + Math.min(players * 20, 500) + (hasEnd ? 250 : 0) + (hasCompleteArenaEnd ? 250 : 0) + (match.createdFromAddon ? 150 : 0);
}

function matchTimeDistanceMs(a = {}, b = {}) {
  const aStart = matchTimeMs(a, false);
  const bStart = matchTimeMs(b, false);
  const aEnd = matchTimeMs(a, true);
  const bEnd = matchTimeMs(b, true);
  const distances = [];
  if (aStart && bStart) distances.push(Math.abs(aStart - bStart));
  if (aEnd && bEnd) distances.push(Math.abs(aEnd - bEnd));
  if (aStart && bEnd) distances.push(Math.abs(aStart - bEnd));
  if (aEnd && bStart) distances.push(Math.abs(aEnd - bStart));
  return distances.length ? Math.min(...distances) : Infinity;
}

function nearDuplicateCombatScore(a = {}, b = {}) {
  if (!a || !b || a.id === b.id) return 0;
  const aSources = uniqueList(a.dataSources || []);
  const bSources = uniqueList(b.dataSources || []);
  const hasCombat = Boolean(a.createdFromRealLog || b.createdFromRealLog) || [...aSources, ...bSources].some((source) => /combat|log|tail/i.test(source));
  if (!hasCombat) return 0;
  const aType = normalizeMatchType(a.matchType || a.bracket || '');
  const bType = normalizeMatchType(b.matchType || b.bracket || '');
  if (aType && bType && aType !== bType) return 0;
  const aMap = normalizedMapKey(a.map || a.zone || a.subzone || '');
  const bMap = normalizedMapKey(b.map || b.zone || b.subzone || '');
  if (aMap && bMap && aMap !== bMap) return 0;
  const distance = matchTimeDistanceMs(a, b);
  const isShuffle = aType === 'Solo Shuffle' || bType === 'Solo Shuffle';
  // Solo Shuffle emits several arena starts inside one lobby. Nearby rounds share
  // the same six players, so they must not be merged into one combat match here.
  // The lobby parent is built later by annotateSoloShuffleSessions().
  if (isShuffle && Number.isFinite(distance) && distance > 10000) return 0;
  const maxDistance = isShuffle ? 10000 : 180000;
  if (!Number.isFinite(distance) || distance > maxDistance) return 0;
  let score = 55;
  if (distance <= 15000) score += 25;
  else if (distance <= 60000) score += 15;
  const overlap = namesOverlapScore(
    Array.from(matchPlayerIdentitySet(a)),
    Array.from(matchPlayerIdentitySet(b))
  );
  if (overlap >= 2) score += Math.min(35, overlap * 7);
  else if ((a.participants || []).length && (b.participants || []).length) score -= 25;
  if (aMap && bMap) score += 15;
  if (aType && bType) score += 10;
  return score;
}

function mergeNearDuplicateCombatMatches(state) {
  if (!state || !Array.isArray(state.matches) || state.matches.length < 2) return state;
  const removedIds = Array.isArray(state._removedDuplicateMatchIds) ? state._removedDuplicateMatchIds.slice() : [];
  const idRemap = state._duplicateMatchIdRemap && typeof state._duplicateMatchIdRemap === 'object' ? { ...state._duplicateMatchIdRemap } : {};
  let changed = true;
  let guard = 0;
  while (changed && guard < 6) {
    changed = false;
    guard += 1;
    outer: for (let i = 0; i < state.matches.length; i += 1) {
      const a = state.matches[i];
      if (!a) continue;
      for (let j = i + 1; j < state.matches.length; j += 1) {
        const b = state.matches[j];
        if (!b) continue;
        const score = nearDuplicateCombatScore(a, b);
        if (score < 70) continue;
        const aScore = combatLogSourceScore(a);
        const bScore = combatLogSourceScore(b);
        const rich = bScore > aScore ? b : a;
        const old = rich === a ? b : a;
        const keptId = old.id || rich.id;
        const richOriginalId = rich.id || '';
        if (richOriginalId && keptId && richOriginalId !== keptId) {
          removedIds.push(richOriginalId);
          idRemap[richOriginalId] = keptId;
        }
        const merged = normalizeMatchDataSources(mergeUserPreservedMatchFields({ ...rich, id: keptId, favorite: Boolean(old.favorite || rich.favorite) }, old));
        state.matches[i] = rich === a ? merged : null;
        state.matches[j] = rich === b ? merged : null;
        state.matches = state.matches.filter(Boolean);
        changed = true;
        break outer;
      }
    }
  }
  state._removedDuplicateMatchIds = uniqueList(removedIds);
  state._duplicateMatchIdRemap = idRemap;
  return state;
}

function resolveStateMatchLibrary(state, reason = 'match-resolver', options = {}) {
  const safe = state && typeof state === 'object' ? state : {};
  const beforeCount = Array.isArray(safe.matches) ? safe.matches.length : 0;
  safe.matches = Array.isArray(safe.matches) ? safe.matches.filter(Boolean).map((match) => normalizeMatchDataSources({ ...match })) : [];
  // Solo Shuffle needs the raw/source round rows before general dedupe has a chance
  // to collapse them. Build or repair the canonical parent first, then run the
  // normal dedupe pass, then annotate once more to clean up any merged shell rows.
  annotateSoloShuffleSessions(safe);
  dedupeStateMatches(safe);
  annotateSoloShuffleSessions(safe);
  repairTinyVideoSectionClips(safe);
  if (options.autoLink === true) autoLinkRecordings(safe);
  safe.matchResolverLastRun = {
    reason: String(reason || 'match-resolver'),
    ranAt: new Date().toISOString(),
    beforeCount,
    afterCount: Array.isArray(safe.matches) ? safe.matches.length : 0,
    mergedOrRemoved: Math.max(0, beforeCount - (Array.isArray(safe.matches) ? safe.matches.length : 0))
  };
  return safe;
}

function resolveIncomingMatchesIntoState(state, matches = [], reason = 'incoming-matches') {
  const safe = state && typeof state === 'object' ? state : {};
  const beforeKeys = new Set((safe.matches || []).flatMap((match) => matchAllDedupeKeys(match)).filter(Boolean));
  const beforeCount = Array.isArray(safe.matches) ? safe.matches.length : 0;
  const incoming = (matches || [])
    .filter((match) => match && !(safe.deletedMatchIds || []).includes(match.id) && !(safe.deletedMatchIds || []).includes(match.rawFingerprint))
    .map((match) => normalizeMatchDataSources(sanitizeMatchForStorage({ ...match })))
    .filter(Boolean);
  if (!incoming.length) return { incoming: [], created: [], updated: 0, beforeCount, afterCount: beforeCount };

  safe.matches = [...incoming, ...(safe.matches || [])];
  resolveStateMatchLibrary(safe, reason, { autoLink: true });

  const created = incoming.filter((match) => matchAllDedupeKeys(match).some((key) => !beforeKeys.has(key)));
  const afterCount = Array.isArray(safe.matches) ? safe.matches.length : 0;
  return {
    incoming,
    created,
    updated: Math.max(0, incoming.length - created.length),
    beforeCount,
    afterCount,
    mergedOrRemoved: Math.max(0, beforeCount + incoming.length - afterCount)
  };
}

function dedupeStateMatches(state) {
  const safe = state && typeof state === 'object' ? state : {};
  const matches = Array.isArray(safe.matches) ? safe.matches.filter(Boolean) : [];
  const keepByKey = new Map();
  const remap = new Map();
  const deduped = [];

  const registerKeys = (match, target) => {
    for (const key of matchAllDedupeKeys(match)) keepByKey.set(key, target || match);
  };

  for (const match of matches) {
    const keys = matchAllDedupeKeys(match);
    if (!keys.length) continue;
    const existing = keys.map((key) => keepByKey.get(key)).find(Boolean);
    if (!existing) {
      registerKeys(match);
      deduped.push(match);
      continue;
    }

    const existingEvents = storedEventFeedCount(existing);
    const matchEvents = storedEventFeedCount(match);
    const existingMetrics = existing.metrics ? Object.keys(existing.metrics).length : 0;
    const matchMetrics = match.metrics ? Object.keys(match.metrics).length : 0;
    const existingPlayers = Array.isArray(existing.scoreboardPlayers) ? existing.scoreboardPlayers.length : 0;
    const matchPlayers = Array.isArray(match.scoreboardPlayers) ? match.scoreboardPlayers.length : 0;
    const existingHasCombat = matchHasCombatLogDetails(existing);
    const matchHasCombat = matchHasCombatLogDetails(match);
    const existingCombatScore = combatLogSourceScore(existing);
    const matchCombatScore = combatLogSourceScore(match);
    const shouldReplace = (existingHasCombat || matchHasCombat)
      ? (matchHasCombat && (!existingHasCombat || matchCombatScore > existingCombatScore))
      : (matchEvents > existingEvents || (matchEvents === existingEvents && matchMetrics > existingMetrics) || (matchEvents === existingEvents && matchMetrics === existingMetrics && matchPlayers > existingPlayers));

    if (match.id && existing.id && match.id !== existing.id) remap.set(match.id, existing.id);
    if (shouldReplace) {
      const index = deduped.indexOf(existing);
      const replacement = mergeUserPreservedMatchFields({ ...match, id: existing.id || match.id, favorite: Boolean(existing.favorite || match.favorite) }, existing);
      if (index >= 0) deduped[index] = replacement;
      registerKeys(existing, replacement);
      registerKeys(match, replacement);
      if (match.id && replacement.id && match.id !== replacement.id) remap.set(match.id, replacement.id);
    } else {
      registerKeys(match, existing);
    }
  }

  safe.matches = deduped;
  mergeNearDuplicateCombatMatches(safe);
  const nearRemap = safe._duplicateMatchIdRemap && typeof safe._duplicateMatchIdRemap === 'object' ? safe._duplicateMatchIdRemap : {};
  for (const [from, to] of Object.entries(nearRemap)) {
    if (from && to && from !== to) remap.set(from, to);
  }
  if (Array.isArray(safe.recordings) && remap.size) {
    safe.recordings = safe.recordings.map((rec) => {
      if (!rec) return rec;
      const next = { ...rec };
      if (next.matchId && remap.has(next.matchId)) next.matchId = remap.get(next.matchId);
      if (Array.isArray(next.linkedMatchIds)) next.linkedMatchIds = uniqueList(next.linkedMatchIds.map((id) => remap.get(id) || id));
      next.linkedCount = Array.isArray(next.linkedMatchIds) ? next.linkedMatchIds.length : Number(next.linkedCount || 0);
      return next;
    });
  }
  return safe;
}

function matchExistsInState(state, match) {
  const keys = new Set(matchAllDedupeKeys(match));
  if (!keys.size) return false;
  return (state.matches || []).some((existing) => matchAllDedupeKeys(existing).some((key) => keys.has(key)));
}


function readRange(filePath, start, end) {
  if (end <= start) return '';
  const fd = fs.openSync(filePath, 'r');
  try {
    const size = end - start;
    const buffer = Buffer.alloc(size);
    fs.readSync(fd, buffer, 0, size, start);
    return buffer.toString('utf8');
  } finally {
    fs.closeSync(fd);
  }
}

function matchTargetTimeMs(match = {}) {
  const candidates = [
    match.startMs,
    match.gameStartMs,
    match.loadedInMs,
    match.enteredAtMs,
    match.videoSegmentStartMs,
    match.startIso ? Date.parse(match.startIso) : 0,
    match.capturedAt ? Date.parse(match.capturedAt) : 0,
    match.endMs,
    match.endIso ? Date.parse(match.endIso) : 0,
    match.date ? Date.parse(match.date) : 0
  ];
  for (const value of candidates) {
    const n = Number(value);
    if (Number.isFinite(n) && n > 1000000000000) return n;
  }
  return 0;
}

function matchNeedsCombatLog(match = {}) {
  if (!match) return false;
  const eventCount = storedEventFeedCount(match);
  return !match.createdFromRealLog || !eventCount;
}


function matchSpecificLogWindowMs(match = {}) {
  const target = matchTargetTimeMs(match);
  const explicitStart = Number(match.startMs || match.gameStartMs || match.loadedInMs || match.enteredAtMs || (match.startIso ? Date.parse(match.startIso) : 0)) || target;
  const explicitEnd = Number(match.endMs || (match.endIso ? Date.parse(match.endIso) : 0)) || (explicitStart && Number(match.durationSec) ? explicitStart + (Number(match.durationSec) * 1000) : 0) || (target ? target + MATCH_SPECIFIC_LOG_AFTER_MS : 0);
  const start = Math.max(0, (explicitStart || target || 0) - MATCH_SPECIFIC_LOG_BEFORE_MS);
  const end = Math.max(explicitEnd || 0, (target || explicitStart || 0) + MATCH_SPECIFIC_LOG_AFTER_MS) + (5 * 60 * 1000);
  return { targetMs: target || explicitStart || 0, startMs: start, endMs: end };
}

function shouldUseArenaSegmentForMatch(match = {}, segmentStartMs = 0, segmentEndMs = 0) {
  const window = matchSpecificLogWindowMs(match || {});
  const target = Number(window.targetMs || 0) || 0;
  if (!segmentStartMs || !segmentEndMs) return false;
  if (target && target >= (segmentStartMs - MATCH_LOG_TIME_PAD_MS) && target <= (segmentEndMs + MATCH_LOG_TIME_PAD_MS)) return true;
  if (segmentStartMs <= window.endMs && segmentEndMs >= window.startMs) return true;
  return false;
}

function estimateLogReadStartPosition(info = {}, statSize = 0, windowStartMs = 0) {
  const size = Number(statSize || 0) || 0;
  if (!size || size <= (MAX_WINDOW_SCAN_BYTES * 1.25)) return 0;
  const start = Number(info.firstLineMs || info.startMs || info.nameStartMs || 0) || 0;
  const end = Number(info.lastLineMs || info.nextStartMs || info.endMs || info.mtimeMs || 0) || 0;
  if (!start || !end || end <= start || !windowStartMs || windowStartMs <= start) return 0;
  const ratio = Math.max(0, Math.min(1, (windowStartMs - start) / Math.max(1, end - start)));
  const estimated = Math.floor(size * ratio);
  return Math.max(0, Math.min(size - 1, estimated - LOG_APPROX_SEEK_BACK_BYTES));
}

function pushLimitedLogLine(list, line, tracker, limits = {}) {
  if (!Array.isArray(list) || !line) return list;
  const maxLines = Number(limits.maxLines || MAX_MATCH_WINDOW_LINES) || MAX_MATCH_WINDOW_LINES;
  const maxChars = Number(limits.maxChars || MAX_MATCH_WINDOW_RAW_CHARS) || MAX_MATCH_WINDOW_RAW_CHARS;
  const safeLine = String(line).length > 12000 ? String(line).slice(0, 12000) : String(line);
  const addChars = safeLine.length + 1;
  while (list.length && ((tracker.chars + addChars) > maxChars || list.length >= maxLines)) {
    const removed = list.shift();
    tracker.chars = Math.max(0, tracker.chars - (String(removed || '').length + 1));
  }
  if ((tracker.chars + addChars) <= maxChars && list.length < maxLines) {
    list.push(safeLine);
    tracker.chars += addChars;
  }
  return list;
}

function importParsedWindowMatchesIntoState(state, parsedMatches = []) {
  const imported = importParsedMatchesIntoState(state, parsedMatches || []);
  mergeNearDuplicateCombatMatches(state);
  dedupeStateMatches(state);
  return imported;
}

function importLogFileWindowedForMatchIntoState(state, info = {}, match = {}, reason = 'match-window-log-sync', options = {}) {
  const filePath = info.filePath || '';
  if (!filePath || !fs.existsSync(filePath)) return { ok: false, reason: 'File missing', parsed: 0, imported: 0, updated: 0, bytes: 0, windowed: true };
  const stat = fs.statSync(filePath);
  const window = matchSpecificLogWindowMs(match || {});
  if (!window.targetMs || !window.startMs || !window.endMs) {
    return { ok: false, reason: 'This match does not have a usable time yet, so the app skipped the full-log scan to avoid loading a huge file.', parsed: 0, imported: 0, updated: 0, bytes: 0, totalBytes: stat.size, windowed: true };
  }

  const fallbackYear = logFileNameYear(info.name || path.basename(filePath));
  let fd = null;
  const maxScanBytes = Math.max(32 * 1024 * 1024, Math.min(Number(options.maxBytes || MAX_WINDOW_SCAN_BYTES) || MAX_WINDOW_SCAN_BYTES, MAX_MATCH_TARGETED_LOG_SYNC_BYTES));
  let position = estimateLogReadStartPosition(info, stat.size, window.startMs);
  let lineTail = '';
  let bytesReadTotal = 0;
  let windowLines = 0;
  let arenaSegmentsSeen = 0;
  let stoppedAfterWindow = false;
  let activeArenaLines = [];
  let activeArenaChars = { chars: 0 };
  let activeArenaStartMs = 0;
  let activeArenaIsSoloShuffle = false;
  let bestArenaLines = [];
  let bestDistance = Infinity;
  let bestCompleteArena = false;
  let preArenaLines = [];
  let preArenaChars = { chars: 0 };
  const fallbackWindowLines = [];
  const fallbackChars = { chars: 0 };
  const maxFallbackWindowLines = Math.min(25000, MAX_MATCH_WINDOW_LINES);
  const maxArenaSegmentLines = Math.min(45000, MAX_MATCH_WINDOW_LINES);
  const maxSoloShuffleArenaSegmentLines = Math.max(maxArenaSegmentLines, MAX_SOLO_SHUFFLE_WINDOW_LINES);
  const normalArenaSegmentLimits = { maxLines: maxArenaSegmentLines, maxChars: MAX_MATCH_WINDOW_RAW_CHARS };
  const soloShuffleArenaSegmentLimits = { maxLines: maxSoloShuffleArenaSegmentLines, maxChars: MAX_SOLO_SHUFFLE_WINDOW_RAW_CHARS };
  const allowLogOnlyOpenSegments = options.allowLogOnlyOpenSegments !== false;
  const onProgress = typeof options.onProgress === 'function' ? options.onProgress : (() => {});
  let lastProgressEmit = 0;

  function maybeKeepArenaSegment(endMs, complete = true) {
    if (!activeArenaLines.length || !activeArenaStartMs || !endMs) return;
    arenaSegmentsSeen += 1;
    if (!shouldUseArenaSegmentForMatch(match, activeArenaStartMs, endMs)) return;
    const target = Number(window.targetMs || 0) || activeArenaStartMs;
    const distance = target >= activeArenaStartMs && target <= endMs ? 0 : Math.min(Math.abs(target - activeArenaStartMs), Math.abs(target - endMs));
    if (!bestArenaLines.length || (complete && !bestCompleteArena) || (complete === bestCompleteArena && distance < bestDistance)) {
      bestDistance = distance;
      bestCompleteArena = Boolean(complete);
      bestArenaLines = activeArenaLines.slice();
    }
  }

  try {
    fd = fs.openSync(filePath, 'r');
    while (position < stat.size) {
      if (bytesReadTotal >= maxScanBytes) {
        stoppedAfterWindow = true;
        break;
      }
      const readSize = Math.min(LOG_CHUNK_READ_BYTES, maxScanBytes - bytesReadTotal, stat.size - position);
      const buffer = Buffer.allocUnsafe(readSize);
      const bytesRead = fs.readSync(fd, buffer, 0, readSize, position);
      if (!bytesRead) break;
      position += bytesRead;
      bytesReadTotal += bytesRead;
      const progressNow = Date.now();
      if (progressNow - lastProgressEmit > 350 || position >= stat.size) {
        lastProgressEmit = progressNow;
        onProgress({
          detail: `${path.basename(filePath)} · ${Math.round(bytesReadTotal / 1024 / 1024)} MB read`,
          percent: Math.max(8, Math.min(92, Math.round((position / Math.max(1, stat.size)) * 90)))
        });
      }
      const chunkText = buffer.subarray(0, bytesRead).toString('utf8');
      const split = splitCompleteLogLines(chunkText, lineTail);
      lineTail = split.tail || '';

      for (const line of split.lines || []) {
        const stampMs = lineStampTimeMs(line, fallbackYear);
        if (!stampMs) continue;

        if (!activeArenaLines.length && stampMs < window.startMs) {
          pushLimitedLogLine(preArenaLines, line, preArenaChars, { maxLines: 600, maxChars: 1024 * 1024 });
        }

        if (stampMs >= window.startMs && stampMs <= window.endMs && fallbackWindowLines.length < maxFallbackWindowLines) {
          pushLimitedLogLine(fallbackWindowLines, line, fallbackChars, { maxLines: maxFallbackWindowLines, maxChars: MAX_MATCH_WINDOW_RAW_CHARS });
          windowLines += 1;
        }

        const ev = parseCombatLine(line);
        if (ev && ev.event === 'ARENA_MATCH_START') {
          const nextBracket = cleanSpellName(ev.fields && ev.fields[3] ? ev.fields[3] : '');
          const nextIsSoloShuffle = /shuffle/i.test(nextBracket);
          if (activeArenaLines.length && activeArenaStartMs) {
            if (activeArenaIsSoloShuffle && nextIsSoloShuffle) {
              // Solo Shuffle uses one arena lobby with multiple ARENA_MATCH_START rows.
              // Keep the full lobby segment together so targeted repair can rebuild
              // the 6-round parent instead of selecting only the nearest final round.
              pushLimitedLogLine(activeArenaLines, line, activeArenaChars, activeArenaIsSoloShuffle ? soloShuffleArenaSegmentLimits : normalArenaSegmentLimits);
              continue;
            }
            maybeKeepArenaSegment(stampMs, false);
          }
          activeArenaStartMs = stampMs;
          activeArenaIsSoloShuffle = nextIsSoloShuffle;
          activeArenaLines = [];
          activeArenaChars = { chars: 0 };
          for (const keepLine of preArenaLines.slice(-600)) pushLimitedLogLine(activeArenaLines, keepLine, activeArenaChars, nextIsSoloShuffle ? soloShuffleArenaSegmentLimits : normalArenaSegmentLimits);
          pushLimitedLogLine(activeArenaLines, line, activeArenaChars, activeArenaIsSoloShuffle ? soloShuffleArenaSegmentLimits : normalArenaSegmentLimits);
          preArenaLines = [];
          preArenaChars = { chars: 0 };
          continue;
        }

        if (activeArenaLines.length) {
          pushLimitedLogLine(activeArenaLines, line, activeArenaChars, activeArenaIsSoloShuffle ? soloShuffleArenaSegmentLimits : normalArenaSegmentLimits);
        }

        if (ev && ev.event === 'ARENA_MATCH_END' && activeArenaLines.length) {
          maybeKeepArenaSegment(stampMs, true);
          activeArenaLines = [];
          activeArenaChars = { chars: 0 };
          activeArenaStartMs = 0;
          activeArenaIsSoloShuffle = false;
        }

        if (ev && ev.event === 'ZONE_CHANGE' && activeArenaLines.length) {
          const zoneId = String(ev.fields && ev.fields[1] || '');
          const zoneName = cleanSpellName(ev.fields && ev.fields[2] || '');
          const leftArena = zoneId === '0' || (zoneName && !/^arena$/i.test(zoneName) && !isRawInstanceMapLabel(zoneName));
          if (leftArena) {
            maybeKeepArenaSegment(stampMs, false);
            activeArenaLines = [];
            activeArenaChars = { chars: 0 };
            activeArenaStartMs = 0;
            activeArenaIsSoloShuffle = false;
          }
        }

        if (stampMs > window.endMs && !activeArenaLines.length) {
          stoppedAfterWindow = true;
          break;
        }
      }
      if (stoppedAfterWindow) break;
    }

    if (lineTail && lineTail.trim()) {
      const stampMs = lineStampTimeMs(lineTail, fallbackYear);
      if (stampMs && stampMs >= window.startMs && stampMs <= window.endMs && fallbackWindowLines.length < maxFallbackWindowLines) {
        pushLimitedLogLine(fallbackWindowLines, lineTail, fallbackChars, { maxLines: maxFallbackWindowLines, maxChars: MAX_MATCH_WINDOW_RAW_CHARS });
        windowLines += 1;
      }
    }

    if (activeArenaLines.length && activeArenaStartMs && allowLogOnlyOpenSegments) {
      const lastLine = activeArenaLines[activeArenaLines.length - 1] || '';
      const lastMs = lineStampTimeMs(lastLine, fallbackYear) || window.endMs || activeArenaStartMs;
      maybeKeepArenaSegment(lastMs, false);
    }

    const sourceLines = bestArenaLines.length ? bestArenaLines : fallbackWindowLines;
    if (!sourceLines.length) {
      return { ok: true, parsed: 0, imported: 0, updated: 0, bytes: bytesReadTotal, totalBytes: stat.size, chunked: true, windowed: true, windowStartMs: window.startMs, windowEndMs: window.endMs, windowLines: 0, arenaSegmentsSeen, stoppedAfterWindow, reason: 'No log lines were found inside this match window.' };
    }
    const fallbackHasArenaStart = !bestArenaLines.length && sourceLines.some((line) => { const ev = parseCombatLine(line); return ev && ev.event === 'ARENA_MATCH_START'; });
    const fallbackHasArenaEnd = !bestArenaLines.length && sourceLines.some((line) => { const ev = parseCombatLine(line); return ev && ev.event === 'ARENA_MATCH_END'; });
    if (fallbackHasArenaStart && !fallbackHasArenaEnd && !allowLogOnlyOpenSegments) {
      return { ok: true, parsed: 0, imported: 0, updated: 0, bytes: bytesReadTotal, totalBytes: stat.size, chunked: true, windowed: true, preciseArenaSegment: false, windowStartMs: window.startMs, windowEndMs: window.endMs, windowLines: sourceLines.length, arenaSegmentsSeen, stoppedAfterWindow, reason: 'Found arena start, but no completed arena end yet. Waiting for the next log refresh.' };
    }

    const raw = `${sourceLines.join('\n')}\n`;
    const sourceLooksSoloShuffle = sourceLines.some((line) => /ARENA_MATCH_START/.test(String(line || '')) && /shuffle/i.test(String(line || '')));
    const rawLimit = sourceLooksSoloShuffle ? MAX_SOLO_SHUFFLE_WINDOW_RAW_CHARS : MAX_MATCH_WINDOW_RAW_CHARS;
    if (raw.length > rawLimit + 1024) {
      return { ok: false, reason: sourceLooksSoloShuffle ? 'The Solo Shuffle log window was still too large to safely parse. Try importing the copied combat log or syncing after the log rotates.' : 'The focused log window was still too large to safely parse. Try syncing the exact match again after the log file rotates or import a smaller copied slice.', parsed: 0, imported: 0, updated: 0, bytes: bytesReadTotal, totalBytes: stat.size, chunked: true, windowed: true, windowStartMs: window.startMs, windowEndMs: window.endMs, windowLines: sourceLines.length, arenaSegmentsSeen, stoppedAfterWindow };
    }
    const parsedMatches = processRawText(raw, `window:${path.basename(filePath)}:${reason}`, { allowLogOnlyOpenSegments, allowBgAtFileEnd: true, logOnlyReason: bestCompleteArena ? 'log-only-window-sync' : 'arena-zone-out-without-end' });
    const importedMatches = importParsedWindowMatchesIntoState(state, parsedMatches);
    if (parsedMatches.length) autoLinkRecordings(state);
    return { ok: true, parsed: parsedMatches.length, imported: importedMatches.length, updated: Math.max(0, parsedMatches.length - importedMatches.length), bytes: bytesReadTotal, totalBytes: stat.size, chunked: true, windowed: true, preciseArenaSegment: Boolean(bestArenaLines.length), windowStartMs: window.startMs, windowEndMs: window.endMs, windowLines: sourceLines.length, arenaSegmentsSeen, stoppedAfterWindow };
  } catch (error) {
    return { ok: false, reason: error && error.message ? error.message : String(error), parsed: 0, imported: 0, updated: 0, bytes: bytesReadTotal, totalBytes: stat.size, chunked: true, windowed: true, windowStartMs: window.startMs, windowEndMs: window.endMs, windowLines };
  } finally {
    if (fd !== null) {
      try { fs.closeSync(fd); } catch (_error) {}
    }
  }
}


let cachedLogSyncBackendTools = null;
function getLogSyncBackendTools() {
  if (!cachedLogSyncBackendTools) {
    cachedLogSyncBackendTools = createLogSyncBackendTools({
      fs,
      path,
      defaultSettings,
      readState,
      writeState,
      matchTargetTimeMs,
      logFileApproxTimeMs,
      logFileEntryWeight,
      getCandidateLogFolders,
      getLogFileSummaryInFolder,
      startupLightLogStatus,
      buildLogFileRoster,
      rememberLogFileInfo,
      buildLogFileInfo,
      processActiveLogTail,
      importLogFileChunkedIntoState,
      importLogFileWindowedForMatchIntoState,
      normalizeMatchDataSources,
      matchNeedsCombatLog,
      addonMatchScore,
      mergeUserPreservedMatchFields,
      dedupeStateMatches,
      autoLinkRecordings,
      logRegistryKey,
      sanitizeMatchForStorage,
      compactRecentMatchesForResponse,
      uniqueList,
      compactImportedFilesForResponse,
      compactLogRegistryForResponse,
      matchLogTimePadMs: MATCH_LOG_TIME_PAD_MS,
      maxTargetedLogSyncBytes: MAX_TARGETED_LOG_SYNC_BYTES,
      maxMatchTargetedLogSyncBytes: MAX_MATCH_TARGETED_LOG_SYNC_BYTES,
      startupChangedLogSweepLimit: STARTUP_CHANGED_LOG_SWEEP_LIMIT,
      startupRepairMaxMatches: STARTUP_REPAIR_MAX_MATCHES,
      startupRepairMaxFilesPerMatch: STARTUP_REPAIR_MAX_FILES_PER_MATCH,
      refreshActiveMaxPasses: REFRESH_ACTIVE_MAX_PASSES,
      refreshChangedLogSweepLimit: REFRESH_CHANGED_LOG_SWEEP_LIMIT,
      refreshRepairMaxMatches: REFRESH_REPAIR_MAX_MATCHES,
      refreshRepairMaxFilesPerMatch: REFRESH_REPAIR_MAX_FILES_PER_MATCH,
      startupActiveTailReadBytes: STARTUP_ACTIVE_TAIL_READ_BYTES,
      maxActiveTailReadBytes: MAX_ACTIVE_TAIL_READ_BYTES,
      refreshActiveTailReadBytes: REFRESH_ACTIVE_TAIL_READ_BYTES,
      maxWindowScanBytes: MAX_WINDOW_SCAN_BYTES,
      refreshWindowScanBytes: REFRESH_WINDOW_SCAN_BYTES
    });
  }
  return cachedLogSyncBackendTools;
}

function effectiveLogEndMs(...args) { return getLogSyncBackendTools().effectiveLogEndMs(...args); }
function chooseLogInfosForMatch(...args) { return getLogSyncBackendTools().chooseLogInfosForMatch(...args); }
function recordingStartTimeMs(...args) { return getLogSyncBackendTools().recordingStartTimeMs(...args); }
function collectLogSearchTargetTimes(...args) { return getLogSyncBackendTools().collectLogSearchTargetTimes(...args); }
function chooseTargetedLogFilesForMedia(...args) { return getLogSyncBackendTools().chooseTargetedLogFilesForMedia(...args); }
function importFullLogForAutoSync(...args) { return getLogSyncBackendTools().importFullLogForAutoSync(...args); }
function syncOneLogInfoIntoState(...args) { return getLogSyncBackendTools().syncOneLogInfoIntoState(...args); }
function mergeBestCombatLogIntoMatch(...args) { return getLogSyncBackendTools().mergeBestCombatLogIntoMatch(...args); }
function syncLogsForMatchIntoState(...args) { return getLogSyncBackendTools().syncLogsForMatchIntoState(...args); }
function repairMissingLogsIntoState(...args) { return getLogSyncBackendTools().repairMissingLogsIntoState(...args); }
function sweepChangedOlderLogsIntoState(...args) { return getLogSyncBackendTools().sweepChangedOlderLogsIntoState(...args); }
function scanLogsFolderIntoState(...args) { return getLogSyncBackendTools().scanLogsFolderIntoState(...args); }

function metricRowsLookThin(match) {
  const rows = match && match.metrics && match.metrics.Damage;
  if (!Array.isArray(rows) || !rows.length) return true;
  return rows.some((row) => Number(row.amount || 0) > 0 && (!Array.isArray(row.abilities) || row.abilities.length === 0));
}

function reprocessStoredLogsIfNeeded(state) {
  const existingMatches = Array.isArray(state.matches) ? state.matches : [];
  const stale = state.schemaVersion < APP_SCHEMA_VERSION || existingMatches.some((match) => !match.parserVersion || match.parserVersion < PARSER_VERSION || metricRowsLookThin(match) || !match.classByName);
  if (!stale) return state;

  const sourcePaths = [];
  for (const item of state.importedFiles || []) {
    if (item && item.archivePath && fs.existsSync(item.archivePath)) sourcePaths.push(item.archivePath);
    else if (item && item.filePath && fs.existsSync(item.filePath)) sourcePaths.push(item.filePath);
  }
  if (state.settings && state.settings.logFilePath && fs.existsSync(state.settings.logFilePath)) sourcePaths.push(state.settings.logFilePath);

  const uniquePaths = Array.from(new Set(sourcePaths));
  if (!uniquePaths.length) {
    state.schemaVersion = APP_SCHEMA_VERSION;
    return state;
  }

  const rebuilt = [];
  const seen = new Set();
  for (const filePath of uniquePaths) {
    try {
      const raw = fs.readFileSync(filePath, 'utf8');
      const parsed = processRawText(raw, path.basename(filePath));
      for (const match of parsed) {
        const key = match.rawFingerprint || match.id;
        if (seen.has(key) || (state.deletedMatchIds || []).includes(match.id) || (state.deletedMatchIds || []).includes(key)) continue;
        seen.add(key);
        rebuilt.push(match);
      }
    } catch (_error) {
      // Keep going. One missing or locked log should not block app startup.
    }
  }

  if (rebuilt.length) {
    const priorByKey = new Map();
    const addonOnly = [];
    for (const oldMatch of existingMatches) {
      const key = matchDedupeKey(oldMatch);
      if (key) priorByKey.set(key, oldMatch);
      if (oldMatch && oldMatch.createdFromAddon && !oldMatch.createdFromRealLog) addonOnly.push(oldMatch);
    }
    state.matches = rebuilt.map((match) => {
      const oldMatch = priorByKey.get(matchDedupeKey(match));
      return normalizeMatchDataSources(oldMatch ? mergeUserPreservedMatchFields(match, oldMatch) : match);
    });
    for (const addonMatch of addonOnly) {
      if (!matchExistsInState(state, addonMatch)) state.matches.push(normalizeMatchDataSources(addonMatch));
    }
    autoLinkRecordings(state, rebuilt);
  }
  state.schemaVersion = APP_SCHEMA_VERSION;
  return state;
}


let cachedPvPHelperImportTools = null;
function getPvPHelperImportTools() {
  if (!cachedPvPHelperImportTools) {
    cachedPvPHelperImportTools = createPvPHelperImportTools({
      fs,
      path,
      zlib,
      WOW_CLASS_COLORS,
      hashText,
      metaForSpec,
      normalizeClassKey,
      cleanMatchMapName,
      teamCountsFromPlayers,
      expectedTeamSizeForType,
      maxTeamCount,
      isRatedBattlegroundType,
      isBattlegroundType,
      durationSecondsFromValue,
      formatDuration,
      normalizeMatchDataSources,
      uniqueList,
      extractPvPHelperVersion,
      buildPvPHelperVersionStatus,
      matchDedupeKey,
      matchExistsInState,
      resolveStateMatchLibrary,
      dedupeCharacterSnapshots,
      characterSnapshotDedupeKey,
      findPvPHelperSavedVariablesFromSelection,
      discoverPvPHelperSavedVariables,
      defaultSettings,
      writeState,
      autoLinkRecordings
    });
  }
  return cachedPvPHelperImportTools;
}

function cleanBracketName(...args) {
  return getPvPHelperImportTools().cleanBracketName(...args);
}

function strongerMatchType(...args) {
  return getPvPHelperImportTools().strongerMatchType(...args);
}

function firstDefinedNumber(...args) {
  return getPvPHelperImportTools().firstDefinedNumber(...args);
}

function normalizeCharacterSnapshot(...args) {
  return getPvPHelperImportTools().normalizeCharacterSnapshot(...args);
}

function collectCharacterSnapshotsFromObject(...args) {
  return getPvPHelperImportTools().collectCharacterSnapshotsFromObject(...args);
}

function parseCharacterSnapshotText(...args) {
  return getPvPHelperImportTools().parseCharacterSnapshotText(...args);
}

function LuaSavedVariablesParser(...args) {
  const ParserClass = getPvPHelperImportTools().LuaSavedVariablesParser;
  return new ParserClass(...args);
}

function findZipEndOfCentralDirectory(...args) {
  return getPvPHelperImportTools().findZipEndOfCentralDirectory(...args);
}

function extractTextFilesFromZipBuffer(...args) {
  return getPvPHelperImportTools().extractTextFilesFromZipBuffer(...args);
}

function readPvPHelperInputFile(...args) {
  return getPvPHelperImportTools().readPvPHelperInputFile(...args);
}

function parseLuaAssignment(...args) {
  return getPvPHelperImportTools().parseLuaAssignment(...args);
}

function objectArrayLikeToArray(...args) {
  return getPvPHelperImportTools().objectArrayLikeToArray(...args);
}

function firstTextValue(...args) {
  return getPvPHelperImportTools().firstTextValue(...args);
}

function parseBooleanish(...args) {
  return getPvPHelperImportTools().parseBooleanish(...args);
}

function firstBooleanStatus(...args) {
  return getPvPHelperImportTools().firstBooleanStatus(...args);
}

function clonePlainValue(...args) {
  return getPvPHelperImportTools().clonePlainValue(...args);
}

function extractPvPHelperBridgeSchema(...args) {
  return getPvPHelperImportTools().extractPvPHelperBridgeSchema(...args);
}

function addonSnapshotIdentity(...args) {
  return getPvPHelperImportTools().addonSnapshotIdentity(...args);
}

function normalizeTimestampToIso(...args) {
  return getPvPHelperImportTools().normalizeTimestampToIso(...args);
}

function splitPlayerRealm(...args) {
  return getPvPHelperImportTools().splitPlayerRealm(...args);
}

function normalizeAddonScorePlayer(...args) {
  return getPvPHelperImportTools().normalizeAddonScorePlayer(...args);
}

function resultFromAddonSnapshot(...args) {
  return getPvPHelperImportTools().resultFromAddonSnapshot(...args);
}

function rowsFromScoreboardMetric(...args) {
  return getPvPHelperImportTools().rowsFromScoreboardMetric(...args);
}

function scalarSnapshotFields(...args) {
  return getPvPHelperImportTools().scalarSnapshotFields(...args);
}

function preservedPvPHelperSnapshotFields(...args) {
  return getPvPHelperImportTools().preservedPvPHelperSnapshotFields(...args);
}

function characterSnapshotsFromMatchHistory(...args) {
  return getPvPHelperImportTools().characterSnapshotsFromMatchHistory(...args);
}

function normalizeAddonMatchSnapshot(...args) {
  return getPvPHelperImportTools().normalizeAddonMatchSnapshot(...args);
}

function extractPvPHelperAddonStatus(...args) {
  return getPvPHelperImportTools().extractPvPHelperAddonStatus(...args);
}

function parsePvPHelperSavedVariables(...args) {
  return getPvPHelperImportTools().parsePvPHelperSavedVariables(...args);
}

function namesOverlapScore(...args) {
  return getPvPHelperImportTools().namesOverlapScore(...args);
}

function shortNameKey(...args) {
  return getPvPHelperImportTools().shortNameKey(...args);
}

function addonMatchScore(...args) {
  return getPvPHelperImportTools().addonMatchScore(...args);
}

function matchHasAddonSnapshot(...args) {
  return getPvPHelperImportTools().matchHasAddonSnapshot(...args);
}

function mergeAddonScoreboardIntoMatch(...args) {
  return getPvPHelperImportTools().mergeAddonScoreboardIntoMatch(...args);
}

function previewPvPHelperImportIntoState(...args) {
  return getPvPHelperImportTools().previewPvPHelperImportIntoState(...args);
}

function importPvPHelperDataIntoState(...args) {
  return getPvPHelperImportTools().importPvPHelperDataIntoState(...args);
}

function pvphFileMtimeMs(...args) {
  return getPvPHelperImportTools().pvphFileMtimeMs(...args);
}

function previewPvPHelperFilePath(...args) {
  return getPvPHelperImportTools().previewPvPHelperFilePath(...args);
}

function importPvPHelperFileIntoState(...args) {
  return getPvPHelperImportTools().importPvPHelperFileIntoState(...args);
}


function configureElectronSecurity() {
  app.on('web-contents-created', (_event, contents) => {
    contents.setWindowOpenHandler(() => ({ action: 'deny' }));
    contents.on('will-navigate', (event, url) => {
      if (!url.startsWith('file://')) event.preventDefault();
    });
  });

  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => {
    const url = webContents.getURL() || '';
    const isLocalApp = url.startsWith('file://');
    const allowed = isLocalApp && (permission === 'media' || permission === 'display-capture');
    callback(Boolean(allowed));
  });

  // Use Electron's display-media handler instead of the native picker on
  // machines where Chromium reports getDisplayMedia as NotSupported. The renderer
  // still requires the user to choose/approve a source before recording.
  try {
    session.defaultSession.setDisplayMediaRequestHandler(async (_request, callback) => {
      try {
        const sources = await getSafeCaptureSources();
        const selectedCaptureSourceId = getSelectedCaptureSourceId();
        const selected = selectedCaptureSourceId
          ? sources.find((source) => source.id === selectedCaptureSourceId)
          : null;
        const fallbackScreen = sources.find((source) => String(source.id || '').toLowerCase().startsWith('screen:'));
        const source = selected || fallbackScreen;
        if (!source) return callback({});
        const payload = { video: source };
        // System audio is optional and requested only when the user enables it.
        // Electron/Chromium may still decline loopback on some capture paths, so
        // the renderer keeps a video-only fallback.
        if (getSelectedCaptureAudio()) payload.audio = 'loopback';
        callback(payload);
      } catch (error) {
        console.error('[Last Call Replay] Display media handler failed:', error);
        callback({});
      }
    });
  } catch (error) {
    console.error('[Last Call Replay] Could not configure display media handler:', error);
  }
}

function createWindow() {
  const iconPath = process.platform === 'win32'
    ? path.join(__dirname, '..', 'build', 'icon.ico')
    : path.join(__dirname, '..', 'app', 'assets', 'last-call-replay-logo.png');
  mainWindow = new BrowserWindow({
    width: 1520,
    height: 980,
    minWidth: 1100,
    minHeight: 760,
    backgroundColor: '#020617',
    title: 'Last Call Replay',
    icon: fs.existsSync(iconPath) ? iconPath : undefined,
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false
    }
  });

  mainWindow.setMenu(null);
  mainWindow.on('closed', () => {
    try { setRecordingTaskbarIndicator(false); } catch (_) {}
    mainWindow = null;
  });
  mainWindow.loadFile(path.join(__dirname, '..', 'app', 'index.html'));
}





let cachedPvPHelperIpcTools = null;
function getPvPHelperIpcTools() {
  if (!cachedPvPHelperIpcTools) {
    cachedPvPHelperIpcTools = createPvPHelperIpcTools({
      ipcMain,
      dialog,
      fs,
      path,
      getMainWindow: () => mainWindow,
      readState,
      writeState,
      defaultSettings,
      ensureDir,
      safeExists,
      copyDirRecursive,
      buildPvPHelperInstallStatus,
      discoverPvPHelperSavedVariables,
      previewPvPHelperFilePath,
      importPvPHelperFileIntoState,
      parseCharacterSnapshotText,
      characterSnapshotDedupeKey,
      dedupeCharacterSnapshots,
      pvphFileMtimeMs
    });
  }
  return cachedPvPHelperIpcTools;
}

getPvPHelperIpcTools().registerPvPHelperIpcHandlers();

ipcMain.handle('reveal-path', async (_event, filePath) => {
  if (filePath && fs.existsSync(filePath)) shell.showItemInFolder(filePath);
  return { ok: Boolean(filePath && fs.existsSync(filePath)) };
});

function pruneLogFileRegistry(state, keep = 500) {
  if (!state || !state.logFileRegistry || typeof state.logFileRegistry !== 'object') return 0;
  const entries = Object.entries(state.logFileRegistry)
    .map(([key, item]) => ({ key, item: item || {}, sortMs: Date.parse(item && (item.scannedAt || item.processedAt || item.updatedAt || item.indexedAt) || '') || Number(item && (item.mtimeMs || item.lastLineMs || item.startMs || 0)) || 0 }))
    .sort((a, b) => b.sortMs - a.sortMs);
  const remove = entries.slice(Math.max(1, Number(keep) || 500));
  for (const entry of remove) delete state.logFileRegistry[entry.key];
  return remove.length;
}

function compactLocalState(state, reason = 'manual-compact') {
  const safe = state && typeof state === 'object' ? state : {};
  const before = {
    matchCount: Array.isArray(safe.matches) ? safe.matches.length : 0,
    importedFiles: Array.isArray(safe.importedFiles) ? safe.importedFiles.length : 0,
    addonImports: Array.isArray(safe.addonImports) ? safe.addonImports.length : 0,
    logRegistry: countObjectKeys(safe.logFileRegistry),
    eventRows: estimateStoredEventFeedRows(safe.matches || []).rows,
    eventCache: eventFeedCacheStats(),
    stateBytes: stateFileStats().bytes
  };

  safe.importedFiles = Array.isArray(safe.importedFiles) ? safe.importedFiles.slice(0, 200) : [];
  safe.addonImports = Array.isArray(safe.addonImports) ? safe.addonImports.slice(0, 200) : [];
  safe.characterSnapshots = dedupeCharacterSnapshots(safe.characterSnapshots || []);
  const prunedLogs = pruneLogFileRegistry(safe, 500);
  resolveStateMatchLibrary(safe, reason, { autoLink: true });
  pruneStateBeforeWrite(safe);
  const prunedEventCache = pruneEventFeedCache(safe);

  const after = {
    matchCount: Array.isArray(safe.matches) ? safe.matches.length : 0,
    importedFiles: Array.isArray(safe.importedFiles) ? safe.importedFiles.length : 0,
    addonImports: Array.isArray(safe.addonImports) ? safe.addonImports.length : 0,
    logRegistry: countObjectKeys(safe.logFileRegistry),
    eventRows: estimateStoredEventFeedRows(safe.matches || []).rows,
    eventCache: eventFeedCacheStats(),
    stateBytes: stateFileStats().bytes
  };
  safe.maintenanceLastRun = { reason, ranAt: new Date().toISOString(), before, after, prunedLogs, prunedEventCache };
  return { before, after, prunedLogs, prunedEventCache, resolver: safe.matchResolverLastRun || {} };
}

ipcMain.handle('set-recording-taskbar-indicator', async (_event, payload = {}) => setRecordingTaskbarIndicator(Boolean(payload && payload.active)));
ipcMain.handle('check-for-updates', async (_event, payload = {}) => checkForUpdates(payload || {}));
ipcMain.handle('open-external-url', async (_event, url) => {
  const safe = safeUpdateUrl(url);
  if (!safe) return { ok: false, reason: 'Only http:// and https:// links can be opened.' };
  await shell.openExternal(safe);
  return { ok: true, url: safe };
});

ipcMain.handle('get-state', async () => {
  // Keep startup fast: do not rebuild old combat-log archives, rescan WoW folders,
  // or write state during the first app load. Heavy maintenance belongs behind
  // explicit import/scan buttons so opening the app stays snappy.
  const state = readState();
  return buildClientStatePayload(state, { startupLight: true });
});


ipcMain.handle('get-startup-diagnostics', async () => {
  const state = readState();
  return buildDeferredStartupDiagnostics(state);
});

ipcMain.handle('get-import-job-status', async () => ({ ok: true, importJobStatus: importJobStatusSnapshot() }));
ipcMain.handle('cancel-import-job', async (_event, payload = {}) => cancelImportJob(payload && payload.jobId ? payload.jobId : '', payload && payload.reason ? payload.reason : 'Canceled by user.'));


ipcMain.handle('get-match-event-feed', async (_event, payload = {}) => {
  const state = readState();
  const matchId = payload && payload.matchId ? String(payload.matchId) : '';
  const roundNumber = payload && payload.roundNumber ? Number(payload.roundNumber) : 0;
  const match = (state.matches || []).find((item) => item && item.id === matchId);
  if (!match) return { ok: false, reason: 'Match not found.', matchId };
  const target = roundNumber && Array.isArray(match.soloRounds)
    ? (match.soloRounds.find((round) => Number(round && round.roundNumber) === roundNumber) || match)
    : match;
  const cachedRows = readMatchEventFeedCache(target);
  const previewRows = Array.isArray(target.eventFeed) ? target.eventFeed : [];
  const rows = cachedRows.length ? cachedRows : compactEventFeedRows(previewRows, EVENT_FEED_CACHE_MAX_ROWS);
  return {
    ok: true,
    matchId,
    roundNumber: target === match ? 0 : roundNumber,
    eventFeed: rows,
    eventFeedRows: Math.max(rows.length, Number(target.eventFeedRows || target.eventFeedCachedRows || 0) || 0),
    cacheRef: target.eventFeedCacheRef || '',
    fromCache: Boolean(cachedRows.length)
  };
});

ipcMain.handle('create-state-backup', async () => {
  const backup = createStateBackup('manual');
  return { ...backup, appPaths: buildClientStatePayload(readState()).appPaths };
});

ipcMain.handle('repair-library-connections', async () => {
  return runQueuedImportJob('maintenance', 'Repairing Library Links', async (progress) => {
    progress({ detail: 'Checking saved library links', percent: 5 });
    const state = readState();
    const beforeFavoriteCount = Array.isArray(state.matches) ? state.matches.filter((match) => match && (match.favorite || match.favorited)).length : 0;
    const beforeVideoCount = Array.isArray(state.matches) ? state.matches.filter((match) => match && match.videoPath).length : 0;
    const beforeRecordingLinks = Array.isArray(state.recordings) ? state.recordings.reduce((sum, rec) => sum + (Array.isArray(rec && rec.linkedMatchIds) ? rec.linkedMatchIds.length : (rec && rec.matchId ? 1 : 0)), 0) : 0;
    progress({ detail: 'Refreshing match and video links', percent: 30 });
    resolveStateMatchLibrary(state, 'manual-library-connection-repair', { autoLink: true });
    progress({ detail: 'Linking recordings to matches', percent: 55 });
    autoLinkRecordings(state, state.matches || []);
    progress({ detail: 'Refreshing video indexes', percent: 75 });
    refreshVideoLinkIndexes(state);
    progress({ detail: 'Saving repaired library links', percent: 92 });
    writeState(state);
    const afterFavoriteCount = Array.isArray(state.matches) ? state.matches.filter((match) => match && (match.favorite || match.favorited)).length : 0;
    const afterVideoCount = Array.isArray(state.matches) ? state.matches.filter((match) => match && match.videoPath).length : 0;
    const afterRecordingLinks = Array.isArray(state.recordings) ? state.recordings.reduce((sum, rec) => sum + (Array.isArray(rec && rec.linkedMatchIds) ? rec.linkedMatchIds.length : (rec && rec.matchId ? 1 : 0)), 0) : 0;
    return {
      ok: true,
      summary: { beforeFavoriteCount, afterFavoriteCount, beforeVideoCount, afterVideoCount, beforeRecordingLinks, afterRecordingLinks },
      ...compactMutationCollections(state, {
        changedMatches: compactRecentMatchesForResponse(state, 120),
        changedRecordings: compactRecordingsForResponse(state, 160),
        changedVods: compactVodsForResponse(state, 120)
      }),
      favoriteFolders: state.favoriteFolders || [],
      settings: state.settings || {},
      appPaths: buildClientStatePayload(state).appPaths
    };
  }, { key: 'maintenance:repair-library-links', exclusiveGroup: 'maintenance-heavy', groupBusyMessage: 'Another maintenance job is already running. Library repair was skipped safely.' });
});

ipcMain.handle('compact-local-state', async () => {
  return runQueuedImportJob('maintenance', 'Compacting App Data', async (progress) => {
    progress({ detail: 'Reading local app state', percent: 8 });
    const state = readState();
    const summary = compactLocalState(state, 'manual-maintenance-compact');
    progress({ detail: 'Writing compacted app state', percent: 78 });
    writeState(state);
    progress({ detail: 'Verifying compacted state', percent: 92 });
    const updated = readState();
    const afterStats = stateFileStats();
    return {
      ok: true,
      summary: { ...summary, afterStateBytes: afterStats.bytes, afterStateUpdatedAt: afterStats.updatedAt },
      settings: updated.settings || {},
      changedMatches: compactRecentMatchesForResponse(updated, 120),
      importedFiles: compactImportedFilesForResponse(updated),
      logFileRegistry: compactLogRegistryForResponse(updated),
      performanceAudit: buildPerformanceAudit(updated),
      maintenanceLastRun: updated.maintenanceLastRun || state.maintenanceLastRun || null
    };

  }, { key: 'maintenance:compact-local-state', exclusiveGroup: 'maintenance-heavy', groupBusyMessage: 'Another maintenance job is already running. Compact app data was skipped safely.' });
});



function autoSetupSummaryFromResult(setup = {}) {
  const pieces = [];
  const log = setup.log || {};
  const recorder = setup.recorder || {};
  const pvpHelper = setup.pvpHelper || {};

  if (log.ok && log.filePath) {
    const imported = Number(log.tail && log.tail.imported || 0);
    const updated = Number(log.tail && log.tail.updated || 0);
    pieces.push(`Logs connected: ${path.basename(log.filePath)}${imported || updated ? ` (${imported} imported, ${updated} updated)` : ''}`);
  } else {
    pieces.push(`Logs not connected: ${log.reason || 'No WoWCombatLog file was found yet.'}`);
  }

  if (recorder.ok && recorder.folderPath) {
    pieces.push(`Recording folder ready: ${path.basename(recorder.folderPath) || recorder.folderPath}`);
  } else {
    pieces.push(`Recording folder not ready: ${recorder.reason || 'Choose a recording folder.'}`);
  }

  if (pvpHelper.ok && pvpHelper.filePath) {
    const imported = Number(pvpHelper.imported || 0);
    const merged = Number(pvpHelper.merged || 0);
    const ratings = Number(pvpHelper.ratingImported || 0);
    const counts = [];
    if (imported) counts.push(`${imported} imported`);
    if (merged) counts.push(`${merged} merged`);
    if (ratings) counts.push(`${ratings} ratings`);
    pieces.push(`PvPHelper connected: ${path.basename(pvpHelper.filePath)}${counts.length ? ` (${counts.join(', ')})` : ''}`);
  } else {
    pieces.push(`PvPHelper not connected: ${pvpHelper.reason || 'No PvPHelper.lua was found yet.'}`);
  }

  return pieces.join('\n');
}

ipcMain.handle('auto-connect-local-setup', async () => {
  let state = readState();
  state.settings = { ...defaultSettings(), ...(state.settings || {}) };

  const setup = {
    log: autoLocateCombatLog(state),
    recorder: ensureDefaultRecordingsFolder(state),
    pvpHelper: { ok: false, reason: 'PvPHelper.lua was not checked yet.' }
  };

  writeState(state);

  if (setup.log && setup.log.ok && setup.log.filePath) {
    const tail = processActiveLogTail(setup.log.filePath, { maxPasses: 12, reason: 'auto-connect-local-setup' }) || {};
    setup.log.tail = tail;
    state = readState();
  }

  const discovery = discoverPvPHelperSavedVariables(state.settings || {});
  if (discovery.best && discovery.best.filePath) {
    const imported = importPvPHelperFileIntoState(state, discovery.best.filePath, { autoSync: state.settings.pvpHelperAutoSync !== false });
    state = readState();
    setup.pvpHelper = {
      ok: Boolean(imported && imported.ok),
      filePath: discovery.best.filePath,
      accountName: discovery.best.accountName || '',
      discovery,
      imported: Number(imported && imported.imported || 0),
      parsed: Number(imported && imported.parsed || 0),
      merged: Number(imported && imported.merged || 0),
      created: Number(imported && imported.created || 0),
      ratingImported: Number(imported && imported.ratingImported || 0),
      reason: imported && imported.ok ? 'Mapped the newest likely PvPHelper.lua automatically.' : ((imported && imported.reason) || 'Found PvPHelper.lua, but could not sync it.')
    };
  } else {
    state.settings = { ...defaultSettings(), ...(state.settings || {}), pvpHelperSavedVariablesDiscovery: discovery };
    writeState(state);
    setup.pvpHelper = {
      ok: false,
      discovery,
      reason: discovery.reason || 'No PvPHelper.lua found yet. Log into WoW with PvPHelper enabled, then /reload or log out.'
    };
  }

  const finalState = readState();
  setup.summary = autoSetupSummaryFromResult(setup);
  return { ok: true, autoSetup: setup, ...buildClientStatePayload(finalState) };
});

ipcMain.handle('use-default-recordings-folder', async () => {
  const state = readState();
  const result = ensureDefaultRecordingsFolder(state);
  writeState(state);
  return { ok: true, result, settings: state.settings || {}, appPaths: buildClientStatePayload(state).appPaths };
});

ipcMain.handle('select-log-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select WoWCombatLog*.txt',
    defaultPath: getLogPickerDefaultPath(true),
    properties: ['openFile'],
    filters: [{ name: 'WoW Combat Logs', extensions: ['txt', 'log'] }, { name: 'All Files', extensions: ['*'] }]
  });
  if (result.canceled) return null;
  return result.filePaths[0];
});

ipcMain.handle('select-log-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select WoW Logs folder',
    defaultPath: getLogPickerDefaultPath(false),
    properties: ['openDirectory']
  });
  if (result.canceled) return null;
  return findBestLogFileInFolder(result.filePaths[0]);
});


ipcMain.handle('scan-logs-folder', async (_event, payload = {}) => {
  const syncOptions = payload && typeof payload === 'object' ? payload : {};
  const startupLight = Boolean(syncOptions.startupLight || syncOptions.mode === 'startup-light');
  const refreshLight = Boolean(syncOptions.refreshLight || syncOptions.mode === 'refresh-light');
  const jobLabel = startupLight ? 'Startup Light Log Catch-Up' : (refreshLight ? 'Refresh Match History' : 'Sync Active Log');
  const jobKey = `combat-log:scan:${startupLight ? 'startup' : refreshLight ? 'refresh' : 'manual'}`;
  return runQueuedImportJob('combat-log', jobLabel, async (progress) => {
    progress({ detail: 'Preparing log sync', percent: 3 });
    const result = scanLogsFolderIntoState({ ...syncOptions, onProgress: progress });
    progress({ detail: 'Log sync finished', percent: 100 });
    return result;
  }, { key: jobKey, exclusiveGroup: 'combat-log-heavy', groupBusyMessage: 'Another heavy log sync is already running. This request was skipped safely.' });
});



function compactLogRegistryForResponse(state = {}) {
  const registry = state.logFileRegistry && typeof state.logFileRegistry === 'object' ? state.logFileRegistry : {};
  const entries = Object.entries(registry)
    .map(([key, item]) => ({ key, item: item || {}, sortMs: Date.parse(item && (item.scannedAt || item.processedAt || item.updatedAt || item.indexedAt) || '') || Number(item && (item.mtimeMs || item.lastLineMs || item.startMs) || 0) || 0 }))
    .sort((a, b) => b.sortMs - a.sortMs)
    .slice(0, 120);
  return entries.reduce((out, entry) => {
    const item = entry.item || {};
    out[entry.key] = {
      filePath: item.filePath || '',
      name: item.name || (item.filePath ? path.basename(item.filePath) : ''),
      size: Number(item.size || 0),
      bytes: Number(item.bytes || 0),
      mtimeMs: Number(item.mtimeMs || 0),
      nameStartMs: Number(item.nameStartMs || 0),
      firstLineMs: Number(item.firstLineMs || 0),
      lastLineMs: Number(item.lastLineMs || 0),
      startMs: Number(item.startMs || 0),
      endMs: Number(item.endMs || 0),
      nextStartMs: Number(item.nextStartMs || 0),
      status: item.status || '',
      indexedAt: item.indexedAt || '',
      scannedAt: item.scannedAt || '',
      processedAt: item.processedAt || '',
      updatedAt: item.updatedAt || '',
      parsedCount: Number(item.parsedCount || 0),
      importedCount: Number(item.importedCount || 0),
      updatedCount: Number(item.updatedCount || 0),
      lastReason: item.lastReason ? String(item.lastReason).slice(0, 180) : ''
    };
    return out;
  }, {});
}

function compactImportedFilesForResponse(state = {}) {
  if (!Array.isArray(state.importedFiles)) return [];
  return state.importedFiles.slice(0, 40).map((item) => {
    if (!item || typeof item !== 'object') return item;
    return {
      filePath: item.filePath || '',
      archivePath: item.archivePath || '',
      importedAt: item.importedAt || '',
      state: item.state || '',
      parsedCount: Number(item.parsedCount || 0),
      importedCount: Number(item.importedCount || 0),
      updatedCount: Number(item.updatedCount || 0),
      filesScanned: Number(item.filesScanned || 0),
      selectedMatchId: item.selectedMatchId || '',
      skippedLarge: Number(item.skippedLarge || 0),
      chunked: Boolean(item.chunked),
      targetedDetails: Array.isArray(item.targetedDetails) ? item.targetedDetails.slice(0, 8).map((detail) => ({
        matchId: detail && detail.matchId ? detail.matchId : '',
        name: detail && detail.name ? detail.name : '',
        parsed: detail && detail.parsed ? detail.parsed : 0,
        imported: detail && detail.imported ? detail.imported : 0,
        updated: detail && detail.updated ? detail.updated : 0,
        windowLines: detail && detail.windowLines ? detail.windowLines : 0,
        bytes: detail && detail.bytes ? detail.bytes : 0,
        reason: detail && detail.reason ? String(detail.reason).slice(0, 180) : ''
      })) : []
    };
  });
}

function compactLogSyncResponse(result = {}, state = {}, matchId = '') {
  const selectedMatch = result.selectedMatch || (state.matches || []).find((match) => match && match.id === matchId) || null;
  const { merge: _merge, matches: _matches, importedFiles: _importedFiles, ...rest } = result || {};
  return {
    ...rest,
    selectedMatch: selectedMatch ? sanitizeMatchForStorage(selectedMatch) : null,
    removedMatchIds: uniqueList(state._removedDuplicateMatchIds || []),
    importedFiles: compactImportedFilesForResponse(state),
    logFileRegistry: compactLogRegistryForResponse(state),
    settings: state.settings || {}
  };
}

function compactRepairLogsResponse(result = {}, state = {}) {
  const { matches: _matches, importedFiles: _importedFiles, ...rest } = result || {};
  return {
    ...rest,
    repairedMatches: (result.repairedMatches || []).map(sanitizeMatchForStorage),
    removedMatchIds: uniqueList(state._removedDuplicateMatchIds || []),
    importedFiles: compactImportedFilesForResponse(state),
    logFileRegistry: compactLogRegistryForResponse(state),
    settings: state.settings || {}
  };
}

function compactVodsForResponse(state = {}, limit = 100) {
  const rows = Array.isArray(state.vods) ? state.vods : [];
  return rows
    .filter(Boolean)
    .slice()
    .sort((a, b) => {
      const aTime = Date.parse(a && (a.lastLinkedAt || a.importedAt || a.startIso || a.suggestedStartIso) || '') || 0;
      const bTime = Date.parse(b && (b.lastLinkedAt || b.importedAt || b.startIso || b.suggestedStartIso) || '') || 0;
      return bTime - aTime;
    })
    .slice(0, Math.max(1, Number(limit || 100)))
    .map(sanitizeVodRecord)
    .filter(Boolean);
}

function compactChangedMatches(matches = []) {
  return (Array.isArray(matches) ? matches : [])
    .filter(Boolean)
    .map((match) => sanitizeMatchForStorage({ ...match }));
}

function compactMutationCollections(state = {}, extras = {}) {
  const payload = {
    importedFiles: compactImportedFilesForResponse(state),
    logFileRegistry: compactLogRegistryForResponse(state),
    performanceAudit: buildPerformanceAudit(state),
    settings: state.settings || {}
  };
  if (extras.changedMatches) payload.changedMatches = compactChangedMatches(extras.changedMatches);
  if (extras.changedRecordings) payload.changedRecordings = (extras.changedRecordings || []).map(compactRecordingRecord).filter(Boolean);
  if (extras.changedVods) payload.changedVods = (extras.changedVods || []).map(sanitizeVodRecord).filter(Boolean);
  if (extras.removedMatchIds) payload.removedMatchIds = uniqueList(extras.removedMatchIds || []);
  if (extras.removedRecordingIds) payload.removedRecordingIds = uniqueList(extras.removedRecordingIds || []);
  if (extras.removedVodIds) payload.removedVodIds = uniqueList(extras.removedVodIds || []);
  return payload;
}

ipcMain.handle('sync-logs-for-match', async (_event, payload = {}) => {
  return runQueuedImportJob('combat-log', 'Sync Selected Match Logs', async (progress) => {
    try {
      progress({ detail: 'Preparing selected-match log sync', percent: 3 });
      const state = readState();
      const result = syncLogsForMatchIntoState(state, payload && payload.matchId, { ...(payload || {}), onProgress: progress });
      writeState(state);
      if (payload && payload.includeFullState) return { ...result, matches: state.matches || [], importedFiles: state.importedFiles || [], settings: state.settings || {} };
      return compactLogSyncResponse(result, state, payload && payload.matchId);
    } catch (error) {
      const state = readState();
      return { ok: false, reason: error && error.message ? error.message : String(error), importedFiles: compactImportedFilesForResponse(state), settings: state.settings || {} };
    }

  }, { key: `combat-log:match:${payload && payload.matchId ? payload.matchId : 'selected'}`, exclusiveGroup: 'combat-log-heavy', groupBusyMessage: 'Another heavy log sync is already running. This selected-match sync was skipped safely.' });
});

ipcMain.handle('repair-missing-logs', async (_event, payload = {}) => {
  return runQueuedImportJob('combat-log', 'Repair Missing Logs', async (progress) => {
    try {
      progress({ detail: 'Preparing missing-log repair', percent: 3 });
      const state = readState();
      const result = repairMissingLogsIntoState(state, { ...(payload || {}), onProgress: progress });
      writeState(state);
      if (payload && payload.includeFullState) return { ...result, matches: state.matches || [], importedFiles: state.importedFiles || [], settings: state.settings || {} };
      return compactRepairLogsResponse(result, state);
    } catch (error) {
      const state = readState();
      return { ok: false, reason: error && error.message ? error.message : String(error), importedFiles: compactImportedFilesForResponse(state), settings: state.settings || {} };
    }

  }, { key: 'combat-log:repair-missing', exclusiveGroup: 'combat-log-heavy', groupBusyMessage: 'Another heavy log sync is already running. Missing-log repair was skipped safely.' });
});

ipcMain.handle('import-log-file', async (_event, filePath) => {
  return runQueuedImportJob('combat-log', 'Import Previous Combat Log', async (progress) => {
    const fileStat = fs.statSync(filePath);
    const firstChunk = readRange(filePath, 0, Math.min(fileStat.size, 4096));
    const fingerprint = hashText(`${filePath}-${fileStat.size}-${fileStat.mtimeMs}-${firstChunk}`);
    const archiveName = `${new Date().toISOString().replace(/[:.]/g, '-')}-${path.basename(filePath)}`;
    const state = readState();
    const archivePath = path.join(archiveRootDir(state), archiveName);
    fs.copyFileSync(filePath, archivePath);

    progress({ detail: 'Chunk-reading previous combat log', percent: 8 });
    const scan = importLogFileChunkedIntoState(state, filePath, `manual-import:${path.basename(filePath)}`, { maxBytes: 1024 * 1024 * 1024, allowLogOnlyOpenSegments: true, allowBgAtFileEnd: true, onProgress: progress });
    progress({ detail: 'Saving previous-log import', percent: 95 });
    const importState = scan.parsed === 0 ? (scan.ok === false ? `Import failed: ${scan.reason || 'Could not parse log'}` : 'No PvP matches found') : scan.imported ? 'Imported' : (scan.updated ? 'Updated existing matches' : 'Duplicate skipped');
    state.importedFiles = state.importedFiles || [];
    state.importedFiles.unshift({ filePath, archivePath, fingerprint, importedAt: new Date().toISOString(), state: importState, parsedCount: scan.parsed || 0, importedCount: scan.imported || 0, updatedCount: scan.updated || 0, chunked: true });
    writeState(state);
    return {
      filePath,
      archivePath,
      fingerprint,
      changedMatches: compactRecentMatchesForResponse(state, 120),
      importedFiles: compactImportedFilesForResponse(state),
      logFileRegistry: compactLogRegistryForResponse(state),
      settings: state.settings || {},
      parsedCount: scan.parsed || 0,
      importedCount: scan.imported || 0,
      updatedCount: scan.updated || 0,
      state: importState,
      ok: scan.ok !== false,
      reason: scan.reason || ''
    };

  }, { key: `combat-log:import:${filePath || ''}`, exclusiveGroup: 'combat-log-heavy', groupBusyMessage: 'Another heavy log sync is already running. Previous-log import was skipped safely.' });
});


function splitCompleteLogLines(raw, priorTail = '') {
  const safePrior = String(priorTail || '').slice(-MAX_LOG_LINE_TAIL_CHARS);
  const safeRaw = String(raw || '');
  const combined = `${safePrior}${safeRaw}`;
  const parts = combined.split(/\r?\n/);
  const endsWithNewline = /(?:\r?\n)$/.test(combined);
  const rawTail = endsWithNewline ? '' : (parts.pop() || '');
  const tail = rawTail.length > MAX_LOG_LINE_TAIL_CHARS ? rawTail.slice(-MAX_LOG_LINE_TAIL_CHARS) : rawTail;
  return { lines: parts.filter((line) => line.trim().length > 0), tail };
}

function importParsedMatchesIntoState(state, matches = []) {
  const result = resolveIncomingMatchesIntoState(state, matches, 'combat-log-import');
  return compactVisibleChangedMatchesForResponse(state, result.created || [], 80);
}


function importLogFileChunkedIntoState(state, filePath, reason = 'chunked-log-sync', options = {}) {
  if (!filePath || !fs.existsSync(filePath)) return { ok: false, reason: 'File missing', parsed: 0, imported: 0, updated: 0, bytes: 0 };
  const stat = fs.statSync(filePath);
  const maxBytes = Number(options.maxBytes || MAX_TARGETED_LOG_SYNC_BYTES) || MAX_TARGETED_LOG_SYNC_BYTES;
  if (stat.size > maxBytes) {
    return { ok: false, reason: `Skipped huge log over ${Math.round(maxBytes / 1024 / 1024)} MB. Use Import Previous Log for a deliberate full scan.`, parsed: 0, imported: 0, updated: 0, bytes: stat.size, skippedLarge: true };
  }

  const scanKey = `${filePath}#chunked-${hashText(`${reason}:${stat.size}:${stat.mtimeMs}`).slice(0, 8)}-${Date.now()}`;
  const allowLogOnlyOpenSegments = Boolean(options.allowLogOnlyOpenSegments);
  const allowBgAtFileEnd = Boolean(options.allowBgAtFileEnd || allowLogOnlyOpenSegments);
  const onProgress = typeof options.onProgress === 'function' ? options.onProgress : (() => {});
  let lastProgressEmit = 0;
  resetLiveSession(scanKey);

  let fd = null;
  let position = 0;
  let lineTail = '';
  let parsed = 0;
  let imported = 0;
  let finalizedCount = 0;
  let bytesReadTotal = 0;

  try {
    fd = fs.openSync(filePath, 'r');
    while (position < stat.size) {
      const readSize = Math.min(LOG_CHUNK_READ_BYTES, stat.size - position);
      const buffer = Buffer.allocUnsafe(readSize);
      const bytesRead = fs.readSync(fd, buffer, 0, readSize, position);
      if (!bytesRead) break;
      position += bytesRead;
      bytesReadTotal += bytesRead;
      const progressNow = Date.now();
      if (progressNow - lastProgressEmit > 350 || position >= stat.size) {
        lastProgressEmit = progressNow;
        onProgress({
          detail: `${path.basename(filePath)} · ${Math.round(bytesReadTotal / 1024 / 1024)} MB read`,
          percent: Math.max(8, Math.min(92, Math.round((position / Math.max(1, stat.size)) * 90)))
        });
      }
      const chunkText = buffer.subarray(0, bytesRead).toString('utf8');
      const split = splitCompleteLogLines(chunkText, lineTail);
      lineTail = split.tail || '';
      if (split.lines && split.lines.length) {
        const finalized = processLiveLogLines(scanKey, split.lines, { allowLogOnlyOpenSegments, allowBgAtFileEnd, logOnlyReason: 'log-only-file-end' });
        parsed += finalized.length;
        if (finalized.length) {
          finalizedCount += finalized.length;
          imported += importParsedMatchesIntoState(state, finalized).length;
        }
      }
    }

    const eofFinalized = finalizeLiveSessionAtFileEnd(scanKey, 'log-only-file-end', { allowLogOnlyOpenSegments, allowBgAtFileEnd, logOnlyReason: 'log-only-file-end' });
    if (eofFinalized.length) {
      parsed += eofFinalized.length;
      finalizedCount += eofFinalized.length;
      imported += importParsedMatchesIntoState(state, eofFinalized).length;
    }
    resetLiveSession(scanKey);
    if (finalizedCount) autoLinkRecordings(state);
    return { ok: true, parsed, imported, updated: Math.max(0, finalizedCount - imported), bytes: bytesReadTotal, totalBytes: stat.size, chunked: true, changedMatches: compactRecentMatchesForResponse(state, 80), removedMatchIds: uniqueList(state._removedDuplicateMatchIds || []) };
  } catch (error) {
    resetLiveSession(scanKey);
    return { ok: false, reason: error && error.message ? error.message : String(error), parsed, imported, updated: Math.max(0, finalizedCount - imported), bytes: bytesReadTotal || position, totalBytes: stat.size, chunked: true, changedMatches: compactRecentMatchesForResponse(state, 80), removedMatchIds: uniqueList(state._removedDuplicateMatchIds || []) };
  } finally {
    if (fd !== null) {
      try { fs.closeSync(fd); } catch (_error) {}
    }
  }
}

ipcMain.handle('watch-log-file', async (_event, filePath) => getLiveLogSyncTools().watchLogFile(filePath));

ipcMain.handle('stop-watching', async () => getLiveLogSyncTools().stopWatching());

ipcMain.handle('archive-log-file', async (_event, filePath) => {
  if (!fs.existsSync(filePath)) return { ok: false, reason: 'File not found' };
  const archiveName = `manual-archive-${new Date().toISOString().replace(/[:.]/g, '-')}-${path.basename(filePath)}`;
  const state = readState();
  const archivePath = path.join(archiveRootDir(state), archiveName);
  fs.copyFileSync(filePath, archivePath);
  return { ok: true, archivePath };
});



getVodIpcTools().registerVodIpcHandlers();


ipcMain.handle('select-archive-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Select log archive folder',
    properties: ['openDirectory']
  });
  if (result.canceled) return null;
  const state = readState();
  state.settings.archiveDir = result.filePaths[0];
  ensureDir(state.settings.archiveDir);
  writeState(state);
  return { archiveDir: state.settings.archiveDir };
});

ipcMain.handle('select-app-storage-folder', async () => {
  const currentDir = appStorageDir();
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Move Last Call Replay app storage folder',
    defaultPath: currentDir,
    properties: ['openDirectory', 'createDirectory']
  });
  if (result.canceled || !result.filePaths || !result.filePaths[0]) return null;

  try {
    return migrateAppStorageTo(result.filePaths[0], { copyCurrent: true, writePortable: true });
  } catch (error) {
    return { ok: false, reason: error && error.message ? error.message : String(error) };
  }
});

ipcMain.handle('enable-portable-app-storage', async () => {
  try {
    return migrateAppStorageTo(defaultPortableStorageDir(), { copyCurrent: true, portable: true, writePortable: true });
  } catch (error) {
    return { ok: false, reason: error && error.message ? error.message : String(error) };
  }
});

ipcMain.handle('connect-app-storage-folder', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    title: 'Connect existing Last Call Replay storage folder',
    defaultPath: defaultPortableStorageDir(),
    properties: ['openDirectory', 'createDirectory']
  });
  if (result.canceled || !result.filePaths || !result.filePaths[0]) return null;

  try {
    return connectAppStorageTo(result.filePaths[0], { writePortable: true });
  } catch (error) {
    return { ok: false, reason: error && error.message ? error.message : String(error) };
  }
});

ipcMain.handle('save-settings', async (_event, settings) => {
  const state = readState();
  state.settings = { ...state.settings, ...(settings || {}) };
  state.settings.autoLinkWindowMinutes = Math.max(0, Math.min(240, Number(state.settings.autoLinkWindowMinutes) || 0));
  state.settings.pvpHelperSavedVariablesPath = String(state.settings.pvpHelperSavedVariablesPath || '');
  state.settings.clipExportDir = String(state.settings.clipExportDir || '');
  state.settings.updateReleaseUrl = safeUpdateUrl(state.settings.updateReleaseUrl || DEFAULT_UPDATE_RELEASE_URL);
  state.settings.updateManifestUrl = safeUpdateUrl(state.settings.updateManifestUrl || DEFAULT_UPDATE_MANIFEST_URL);
  state.settings.updateInstallerUrl = safeUpdateUrl(state.settings.updateInstallerUrl || '');
  state.settings.updateZipUrl = safeUpdateUrl(state.settings.updateZipUrl || '');
  state.settings.updateReleaseNotes = Array.isArray(state.settings.updateReleaseNotes) ? state.settings.updateReleaseNotes.map((note) => String(note || '').trim()).filter(Boolean).slice(0, 12) : [];
  state.settings.pvpHelperAutoSync = state.settings.pvpHelperAutoSync !== false;
  state.settings.pvpHelperLastSyncMtimeMs = Number(state.settings.pvpHelperLastSyncMtimeMs) || 0;
  state.settings.pvpHelperLastSyncAt = String(state.settings.pvpHelperLastSyncAt || '');
  ensureDir(state.settings.recordingsDir || recordingsRootDir(state));
  ensureDir(state.settings.archiveDir || archiveRootDir(state));
  writeState(state);
  return state.settings;
});



app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  configureElectronSecurity();
  registerRecordingBackendIpc();
  registerFavoriteBackendIpc();
  registerMatchActionIpc();
  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
