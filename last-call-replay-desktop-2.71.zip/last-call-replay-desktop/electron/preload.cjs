const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('lastCallApi', {
  selectLogFile: () => ipcRenderer.invoke('select-log-file'),
  autoConnectLocalSetup: () => ipcRenderer.invoke('auto-connect-local-setup'),
  selectVideoFile: (payload) => ipcRenderer.invoke('select-video-file', payload),
  importVodFile: (payload) => ipcRenderer.invoke('import-vod-file', payload || {}),
  updateVodMeta: (payload) => ipcRenderer.invoke('update-vod-meta', payload),
  linkVodToMatches: (payload) => ipcRenderer.invoke('link-vod-to-matches', payload),
  updateMatchVideoSection: (payload) => ipcRenderer.invoke('update-match-video-section', payload),
  exportVodClip: (payload) => ipcRenderer.invoke('export-vod-clip', payload),
  selectExportFolder: () => ipcRenderer.invoke('select-export-folder'),
  deleteVod: (payload) => ipcRenderer.invoke('delete-vod', payload),
  selectLogFolder: () => ipcRenderer.invoke('select-log-folder'),
  importLogFile: (filePath) => ipcRenderer.invoke('import-log-file', filePath),
  watchLogFile: (filePath) => ipcRenderer.invoke('watch-log-file', filePath),
  stopWatching: () => ipcRenderer.invoke('stop-watching'),
  getState: () => ipcRenderer.invoke('get-state'),
  getImportJobStatus: () => ipcRenderer.invoke('get-import-job-status'),
  cancelImportJob: (payload) => ipcRenderer.invoke('cancel-import-job', payload || {}),
  getStartupDiagnostics: () => ipcRenderer.invoke('get-startup-diagnostics'),
  getMatchEventFeed: (payload) => ipcRenderer.invoke('get-match-event-feed', payload || {}),
  archiveLogFile: (filePath) => ipcRenderer.invoke('archive-log-file', filePath),
  linkVideoFileToMatch: (payload) => ipcRenderer.invoke('link-video-file-to-match', payload),
  selectRecordingsFolder: () => ipcRenderer.invoke('select-recordings-folder'),
  useDefaultRecordingsFolder: () => ipcRenderer.invoke('use-default-recordings-folder'),
  selectArchiveFolder: () => ipcRenderer.invoke('select-archive-folder'),
  selectAppStorageFolder: () => ipcRenderer.invoke('select-app-storage-folder'),
  enablePortableAppStorage: () => ipcRenderer.invoke('enable-portable-app-storage'),
  connectAppStorageFolder: () => ipcRenderer.invoke('connect-app-storage-folder'),
  saveSettings: (settings) => ipcRenderer.invoke('save-settings', settings),
  listCaptureSources: () => ipcRenderer.invoke('list-capture-sources'),
  setCaptureSource: (payload) => ipcRenderer.invoke('set-capture-source', payload),
  saveRecorderSettings: (settings) => ipcRenderer.invoke('save-recorder-settings', settings),
  createRecording: (payload) => ipcRenderer.invoke('create-recording', payload),
  appendRecordingChunk: (payload) => ipcRenderer.invoke('append-recording-chunk', payload),
  finishRecording: (payload) => ipcRenderer.invoke('finish-recording', payload),
  setRecordingTaskbarIndicator: (payload) => ipcRenderer.invoke('set-recording-taskbar-indicator', payload || {}),
  checkForUpdates: (payload) => ipcRenderer.invoke('check-for-updates', payload || {}),
  openExternalUrl: (url) => ipcRenderer.invoke('open-external-url', url),
  getRecordings: () => ipcRenderer.invoke('get-recordings'),
  scanRecordingsFolder: () => ipcRenderer.invoke('scan-recordings-folder'),
  scanLogsFolder: (payload) => ipcRenderer.invoke('scan-logs-folder', payload || {}),
  syncLogsForMatch: (payload) => ipcRenderer.invoke('sync-logs-for-match', payload),
  repairMissingLogs: (payload) => ipcRenderer.invoke('repair-missing-logs', payload),
  compactLocalState: () => ipcRenderer.invoke('compact-local-state'),
  createStateBackup: () => ipcRenderer.invoke('create-state-backup'),
  repairLibraryConnections: () => ipcRenderer.invoke('repair-library-connections'),
  importCharacterSnapshot: () => ipcRenderer.invoke('import-character-snapshot'),
  previewPvPHelperSavedVariables: () => ipcRenderer.invoke('preview-pvph-savedvariables'),
  getPvPHelperSavedVariablesDiscovery: () => ipcRenderer.invoke('get-pvph-savedvariables-discovery'),
  autoPreviewPvPHelperSavedVariables: () => ipcRenderer.invoke('auto-preview-pvph-savedvariables'),
  applyPvPHelperSavedVariablesPreview: (payload) => ipcRenderer.invoke('apply-pvph-savedvariables-preview', payload),
  importPvPHelperSavedVariables: () => ipcRenderer.invoke('import-pvph-savedvariables'),
  syncMappedPvPHelperSavedVariables: (payload) => ipcRenderer.invoke('sync-mapped-pvph-savedvariables', payload),
  getPvPHelperAddonStatus: () => ipcRenderer.invoke('get-pvphelper-addon-status'),
  installPvPHelperAddon: () => ipcRenderer.invoke('install-pvphelper-addon'),
  clearPvPHelperSavedVariablesMapping: () => ipcRenderer.invoke('clear-pvph-savedvariables-mapping'),
  deleteCharacterSnapshot: (payload) => ipcRenderer.invoke('delete-character-snapshot', payload),
  dedupeRecordings: () => ipcRenderer.invoke('dedupe-recordings'),
  deleteRecording: (payload) => ipcRenderer.invoke('delete-recording', payload),
  unlinkRecording: (payload) => ipcRenderer.invoke('unlink-recording', payload),
  unlinkVideoFromMatch: (payload) => ipcRenderer.invoke('unlink-video-from-match', payload),
  deleteMatch: (payload) => ipcRenderer.invoke('delete-match', payload),
  setMatchFavorite: (payload) => ipcRenderer.invoke('set-match-favorite', payload),
  createFavoriteFolder: (payload) => ipcRenderer.invoke('create-favorite-folder', payload),
  deleteFavoriteFolder: (payload) => ipcRenderer.invoke('delete-favorite-folder', payload),
  updateFavoriteMeta: (payload) => ipcRenderer.invoke('update-favorite-meta', payload),
  linkScoreboardToMatch: (payload) => ipcRenderer.invoke('link-scoreboard-to-match', payload),
  hidePlayer: (payload) => ipcRenderer.invoke('hide-player', payload),
  revealPath: (filePath) => ipcRenderer.invoke('reveal-path', filePath),
  getPathForFile: (file) => {
    try { return webUtils && webUtils.getPathForFile ? webUtils.getPathForFile(file) : ''; } catch (_) { return ''; }
  },
  onWatcherChunk: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('watcher-chunk', listener);
    return () => ipcRenderer.removeListener('watcher-chunk', listener);
  },
  onWatcherStatus: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('watcher-status', listener);
    return () => ipcRenderer.removeListener('watcher-status', listener);
  },
  onImportJobStatus: (callback) => {
    const listener = (_event, payload) => callback(payload);
    ipcRenderer.on('import-job-status', listener);
    return () => ipcRenderer.removeListener('import-job-status', listener);
  }
});
