const api = window.lastCallApi || null;

let recordingActionTools = null;
let favoriteActionTools = null;
let lastRailAutoScrollAt = -999;
let railAutoScrollUntil = 0;
let railShiftSeekTimer = null;
let healthWindowRenderTimer = null;
let healthSyncRaf = null;
let railUpdateRaf = null;
let railUpdateTimer = null;
let lastRailUiUpdateMs = 0;
const railFeedCache = new Map();

const appStateManager = (window.LastCallAppState && window.LastCallAppState.createAppStateManager)
  ? window.LastCallAppState.createAppStateManager({ appVersion: '2.71' })
  : null;
if (!appStateManager) throw new Error('LastCallAppState module failed to load.');
const state = appStateManager.state;



const uiHelpers = (window.LastCallUiHelpers && window.LastCallUiHelpers.createUiHelpers)
  ? window.LastCallUiHelpers.createUiHelpers()
  : null;

function readUiPrefs() { return uiHelpers.readUiPrefs(); }
function writeUiPrefs(patch = {}) { return uiHelpers.writeUiPrefs(patch); }
function rememberSelectedCharacterKey(key) { return uiHelpers.rememberSelectedCharacterKey(key); }
function rememberedSelectedCharacterKey() { return uiHelpers.rememberedSelectedCharacterKey(); }
function escapeHtml(value) { return uiHelpers.escapeHtml(value); }
function cssEscape(value = '') { return uiHelpers.cssEscape(value); }
function prettyNumber(value) { return uiHelpers.prettyNumber(value); }
function displayAppVersion(value) { return uiHelpers.displayAppVersion(value); }
function formatElapsed(seconds) { return uiHelpers.formatElapsed(seconds); }
function pad2(value) { return uiHelpers.pad2(value); }
function localDateTimeInputValue(iso) { return uiHelpers.localDateTimeInputValue(iso); }
function isoFromLocalDateTimeInput(value) { return uiHelpers.isoFromLocalDateTimeInput(value); }


function parseVodStartFromFilename(filePath = '') {
  const tools = getVodViewTools();
  return tools ? tools.parseVodStartFromFilename(filePath) : null;
}

function vodSuggestedStart(vod = selectedVod()) {
  const tools = getVodViewTools();
  return tools ? tools.vodSuggestedStart(vod) : null;
}

function formatBytes(bytes) { return uiHelpers.formatBytes(bytes); }
function displayFileName(value = '') { return uiHelpers.displayFileName(value); }
function displayPathTail(value = '', segmentCount = 3) { return uiHelpers.displayPathTail(value, segmentCount); }
function stripRecordingDatePrefix(value = '') { return uiHelpers.stripRecordingDatePrefix(value); }
function cleanRecordingTitleText(value = '') { return uiHelpers.cleanRecordingTitleText(value); }
function pathValueMarkup(value = '', fallback = 'Not selected', segmentCount = 3) { return uiHelpers.pathValueMarkup(value, fallback, segmentCount); }
function filePathToUrl(filePath) { return uiHelpers.filePathToUrl(filePath); }
function pill(text, tone = '') { return uiHelpers.pill(text, tone); }
function normalizeClassNameForColor(value = '') { return uiHelpers.normalizeClassNameForColor(value); }
function classColorByName(value = '') { return uiHelpers.classColorByName(value); }
function pvpHelperSyncHelpIcon(extraClass = '') { return uiHelpers.pvpHelperSyncHelpIcon(extraClass); }

function appStateTools() {
  return {
    clearRailFeedCache,
    dedupeMatches,
    matchDedupeKey,
    isPendingScoreboardSnapshot,
    isUsableSavedMatch,
    dedupeCharacterSnapshots,
    validRecorderPerformanceMode,
    rememberedSelectedCharacterKey
  };
}

function classMetaForName(name, match = selectedMatch()) {
  if (!name || !match || !match.classByName) return null;
  return match.classByName[name] || null;
}

function coloredName(name, match = selectedMatch(), extraClass = '') {
  const safeName = escapeHtml(name || 'Unknown');
  const meta = classMetaForName(name, match);
  const color = meta && meta.classColor ? meta.classColor : '';
  const title = meta && meta.className ? `${meta.specName || ''} ${meta.className}`.trim() : '';
  return `<span class="class-colored-name ${escapeHtml(extraClass)}" ${color ? `style="color:${escapeHtml(color)}"` : ''} ${title ? `title="${escapeHtml(title)}"` : ''}>${safeName}</span>`;
}


function shortCharacterName(name) {
  const raw = String(name || 'Unknown');
  if (!raw || raw === 'Unknown') return raw;
  return raw.split('-')[0] || raw;
}

function shortNameKey(value) {
  return shortCharacterName(value).toLowerCase().replace(/[^a-z0-9]/g, '');
}

function classMetaAcrossMatches(name) {
  for (const match of state.matches || []) {
    const meta = classMetaForName(name, match);
    if (meta) return meta;
    if (match && match.classByName) {
      for (const candidate of Object.keys(match.classByName)) {
        if (namesShareEnemyIdentity(candidate, name)) return match.classByName[candidate];
      }
    }
  }
  return null;
}

function coloredShortNameAny(name) {
  const safeName = escapeHtml(shortCharacterName(name));
  const meta = classMetaAcrossMatches(name);
  const color = meta && meta.classColor ? meta.classColor : '';
  const title = meta && meta.className ? `${meta.specName || ''} ${meta.className}`.trim() : String(name || '');
  return `<span class="class-colored-name" ${color ? `style="color:${escapeHtml(color)}"` : ''} ${title ? `title="${escapeHtml(title)}"` : ''}>${safeName}</span>`;
}

function coloredShortName(name, match = selectedMatch(), extraClass = '') {
  const shortName = shortCharacterName(name);
  const meta = classMetaForName(name, match) || classMetaAcrossMatches(name);
  const color = meta && meta.classColor ? meta.classColor : '';
  const classTitle = meta && meta.className ? `${meta.specName || ''} ${meta.className}`.trim() : '';
  const titleParts = [String(name || 'Unknown')];
  if (classTitle) titleParts.push(classTitle);
  return `<span class="class-colored-name short-name ${escapeHtml(extraClass)}" ${color ? `style="color:${escapeHtml(color)}"` : ''} title="${escapeHtml(titleParts.join(' · '))}">${escapeHtml(shortName)}</span>`;
}

function fullRosterTitle(names = [], match = selectedMatch()) {
  const list = (names || []).filter(Boolean);
  if (!list.length) return 'Unknown team';
  return list.map((name) => {
    const meta = classMetaForName(name, match) || classMetaAcrossMatches(name);
    const classTitle = meta && meta.className ? `${meta.specName || ''} ${meta.className}`.trim() : '';
    return classTitle ? `${name} · ${classTitle}` : String(name);
  }).join('\n');
}

const recorderSourceTools = (window.LastCallRecorderSourceHelpers && typeof window.LastCallRecorderSourceHelpers.createRecorderSourceTools === 'function')
  ? window.LastCallRecorderSourceHelpers.createRecorderSourceTools({
    state,
    formatElapsed,
    saveRecorderSettings,
    recorderIsActive,
    render,
    refreshCaptureSources
  })
  : null;
if (!recorderSourceTools) throw new Error('LastCallRecorderSourceHelpers module failed to load.');

function captureSourceKind(source) { return recorderSourceTools.captureSourceKind(source); }
function sourceLooksLikeWow(source) { return recorderSourceTools.sourceLooksLikeWow(source); }
function normalizedSourceName(value) { return recorderSourceTools.normalizedSourceName(value); }
function isSourceApproved(source) { return recorderSourceTools.isSourceApproved(source); }
function preferredWowSource(sources = state.recorder.sources || []) { return recorderSourceTools.preferredWowSource(sources); }
async function rememberApprovedCaptureSource(source) { return recorderSourceTools.rememberApprovedCaptureSource(source); }
function allowedCaptureSources(sources = state.recorder.sources || []) { return recorderSourceTools.allowedCaptureSources(sources); }
function sourceSort(a, b) { return recorderSourceTools.sourceSort(a, b); }
function validRecorderPerformanceMode(value) { return recorderSourceTools.validRecorderPerformanceMode(value); }
function recorderPerformanceProfile(mode = state.recorder.performanceMode) { return recorderSourceTools.recorderPerformanceProfile(mode); }
function recorderPerformanceLabel(mode = state.recorder.performanceMode) { return recorderSourceTools.recorderPerformanceLabel(mode); }
function recorderPerformanceCaption(mode = state.recorder.performanceMode) { return recorderSourceTools.recorderPerformanceCaption(mode); }
function recorderChunkMs() { return recorderSourceTools.recorderChunkMs(); }
function currentCaptureSource() { return recorderSourceTools.currentCaptureSource(); }
function recorderSetupSummary() { return recorderSourceTools.recorderSetupSummary(); }
function openRecorderSetupFromDashboard() { return recorderSourceTools.openRecorderSetupFromDashboard(); }

const replayTimelineTools = (window.LastCallReplayTimelineHelpers && typeof window.LastCallReplayTimelineHelpers.createReplayTimelineTools === 'function')
  ? window.LastCallReplayTimelineHelpers.createReplayTimelineTools({
    state,
    currentReplayMatch: () => currentReplayMatch(),
    render: () => render(),
    updateVideoEventRail: (...args) => updateVideoEventRail(...args)
  })
  : null;
if (!replayTimelineTools) throw new Error('LastCallReplayTimelineHelpers module failed to load.');


function selectedMatch() {
  const raw = state.matches.find((match) => match.id === state.selectedId) || state.matches[0] || null;
  const parent = findSoloShuffleParentForMatch(raw);
  return parent || raw;
}
function isVideoSectionLink(match = {}) {
  const mode = String(match.videoLinkMode || '');
  return Boolean(match.videoPath) && (mode === 'vod' || mode === 'recording-session' || (Number.isFinite(Number(match.videoClipStartSec)) && Number.isFinite(Number(match.videoClipEndSec))));
}

function videoSectionKindLabel(match = {}) {
  return String(match.videoLinkMode || '') === 'recording-session' ? 'Recording session' : 'VOD section';
}

function activeVodScopeMode(match = currentReplayMatch()) { return replayTimelineTools.activeVodScopeMode(match); }
function vodScopeLabel(mode = activeVodScopeMode()) { return replayTimelineTools.vodScopeLabel(mode); }
function replayScopeBoundsForMatch(match = currentReplayMatch(), video = null) { return replayTimelineTools.replayScopeBoundsForMatch(match, video); }
function isReplayFullVodMode(match = currentReplayMatch()) { return replayTimelineTools.isReplayFullVodMode(match); }

const matchDisplayHelpers = (window.LastCallMatchDisplayHelpers && window.LastCallMatchDisplayHelpers.createMatchDisplayHelpers)
  ? window.LastCallMatchDisplayHelpers.createMatchDisplayHelpers({
    state,
    pill,
    characterNameKey: (value) => characterNameKey(value)
  })
  : null;
if (!matchDisplayHelpers) throw new Error('LastCallMatchDisplayHelpers module failed to load.');

function displayResult(value) { return matchDisplayHelpers.displayResult(value); }
function firstNonEmptyValue(...values) { return matchDisplayHelpers.firstNonEmptyValue(...values); }
function addonScoreboardResult(match) { return matchDisplayHelpers.addonScoreboardResult(match); }
function matchResolvedResult(match) { return matchDisplayHelpers.matchResolvedResult(match); }
function hasResultConflict(match) { return matchDisplayHelpers.hasResultConflict(match); }
function resultToneForResult(result) { return matchDisplayHelpers.resultToneForResult(result); }
function resultMatchesFilter(match) { return matchDisplayHelpers.resultMatchesFilter(match); }
function normalizedMatchType(match) { return matchDisplayHelpers.normalizedMatchType(match); }
function scoreboardMatchType(match) { return matchDisplayHelpers.scoreboardMatchType(match); }
function canonicalMatchTypeLabel(value) { return matchDisplayHelpers.canonicalMatchTypeLabel(value); }
function displayMatchTypeLabel(value) { return matchDisplayHelpers.displayMatchTypeLabel(value); }
function displayBracketLabel(value) { return matchDisplayHelpers.displayBracketLabel(value); }
function displayMatchType(match) { return matchDisplayHelpers.displayMatchType(match); }
function effectiveMatchType(match) { return matchDisplayHelpers.effectiveMatchType(match); }
function displayMatchTags(match) { return matchDisplayHelpers.displayMatchTags ? matchDisplayHelpers.displayMatchTags(match) : ((match && match.tags) || []); }
function matchTypeMatchesFilter(match, filterValue) { return matchDisplayHelpers.matchTypeMatchesFilter(match, filterValue); }
function isRatedBattlegroundMatch(match) { return matchDisplayHelpers.isRatedBattlegroundMatch(match); }
function isBattlegroundMatch(match) { return matchDisplayHelpers.isBattlegroundMatch(match); }
function matchTeamSizePill(match) { return matchDisplayHelpers.matchTeamSizePill(match); }
function combatLogImportHistory() { return matchDisplayHelpers.combatLogImportHistory(); }
function matchDay(match) { return matchDisplayHelpers.matchDay(match); }
function matchClock(match) { return matchDisplayHelpers.matchClock(match); }
function matchTimestampLabel(match) { return matchDisplayHelpers.matchTimestampLabel(match); }
function matchSortTime(match) { return matchDisplayHelpers.matchSortTime(match); }

let searchViewToolsCache = null;
function getSearchViewTools() {
  if (!searchViewToolsCache && window.LastCallSearchView && typeof window.LastCallSearchView.createSearchViewTools === 'function') {
    searchViewToolsCache = window.LastCallSearchView.createSearchViewTools({
      state,
      escapeHtml,
      matchDay,
      effectiveMatchType,
      normalizedMatchType,
      matchScoreboardPlayers,
      isPendingScoreboardSnapshot,
      visibleLibraryMatch,
      resultMatchesFilter,
      matchTypeMatchesFilter,
      displayMatchTypeLabel,
      isFavoriteMatch,
      displayResult,
      matchSortTime,
      render
    });
  }
  if (!searchViewToolsCache) throw new Error('Search view module failed to load.');
  return searchViewToolsCache;
}

function matchSortLabel(value = state.matchSort) { return getSearchViewTools().matchSortLabel(value); }
function sortMatchesForLibrary(matches = []) { return getSearchViewTools().sortMatchesForLibrary(matches); }

function displayInstanceMapName(value = '') { return matchDisplayHelpers.displayInstanceMapName(value); }
function normalizedMapKey(value = '') { return matchDisplayHelpers.normalizedMapKey(value); }
function displayBattlegroundMapName(value = '') { return matchDisplayHelpers.displayBattlegroundMapName(value); }
function cleanDisplayMapName(value = '', match = {}) { return matchDisplayHelpers.cleanDisplayMapName(value, match); }
function normalizeMatchMapForDisplay(match) { return matchDisplayHelpers.normalizeMatchMapForDisplay(match); }
function isUsableSavedMatch(match) { return matchDisplayHelpers.isUsableSavedMatch(match); }
function matchDedupeKey(match) { return matchDisplayHelpers.matchDedupeKey(match); }
function matchLooseDedupeKey(match) { return matchDisplayHelpers.matchLooseDedupeKey(match); }
function dedupeMatches(matches) { return matchDisplayHelpers.dedupeMatches(matches); }

function uniqueValues(values = []) { return getSearchViewTools().uniqueValues(values); }
function toonOptions() { return getSearchViewTools().toonOptions(); }
function dayOptions() { return getSearchViewTools().dayOptions(); }
function matchTypeOptions() { return getSearchViewTools().matchTypeOptions(); }
function classDisplayName(value = '') { return getSearchViewTools().classDisplayName(value); }
function matchClassLabels(match) { return getSearchViewTools().matchClassLabels(match); }
function matchClassOptions() { return getSearchViewTools().matchClassOptions(); }
function matchHasClass(match, classLabel) { return getSearchViewTools().matchHasClass(match, classLabel); }
function filteredMatches() { return getSearchViewTools().filteredMatches(); }

function addMatches(newMatches) {
  return appStateManager.addMatches(newMatches, appStateTools());
}

function mergeBackendMatches(updatedMatches = []) {
  return appStateManager.mergeBackendMatches(updatedMatches, appStateTools());
}

function mergeByIdCollection(existing = [], incoming = []) {
  return appStateManager.mergeByIdCollection(existing, incoming);
}

function mergeBackendRecordings(updatedRecordings = []) {
  return appStateManager.mergeBackendRecordings(updatedRecordings);
}

function mergeBackendVods(updatedVods = []) {
  return appStateManager.mergeBackendVods(updatedVods);
}

function applyBackendCollectionDeltas(result = {}) {
  return appStateManager.applyBackendCollectionDeltas(result, appStateTools());
}



let soloShuffleUiToolsCache = null;
function getSoloShuffleUiTools() {
  if (!soloShuffleUiToolsCache && window.LastCallSoloShuffleUi && typeof window.LastCallSoloShuffleUi.createSoloShuffleUiTools === 'function') {
    soloShuffleUiToolsCache = window.LastCallSoloShuffleUi.createSoloShuffleUiTools({
      state,
      escapeHtml,
      shortNameKey,
      normalizedMatchType,
      normalizedMapKey,
      isPendingScoreboardSnapshot,
      displayResult,
      selectedMatch
    });
  }
  return soloShuffleUiToolsCache;
}

function soloShuffleTool(name, fallback) {
  const tools = getSoloShuffleUiTools();
  return tools && typeof tools[name] === 'function' ? tools[name] : fallback;
}

function ownNameSetForMatch(match = {}) {
  return soloShuffleTool('ownNameSetForMatch', (item = {}) => {
    const names = new Set((item.ownNames || []).filter(Boolean));
    if (item.alt) names.add(item.alt);
    return names;
  })(match || {});
}

function enemyIdentityKey(name) {
  return soloShuffleTool('enemyIdentityKey', (value) => {
    const key = shortNameKey(value);
    return key || String(value || '').trim().toLowerCase();
  })(name);
}

function namesShareEnemyIdentity(left, right) {
  return soloShuffleTool('namesShareEnemyIdentity', (a, b) => Boolean(a && b && enemyIdentityKey(a) === enemyIdentityKey(b)))(left, right);
}

function isSoloShuffleUiMatch(match = {}) {
  return soloShuffleTool('isSoloShuffleUiMatch', (item) => Boolean(item && (item.isSoloShuffle || /shuffle/i.test(normalizedMatchType(item) || item.matchType || item.bracket || ''))))(match);
}

function isSoloShuffleLobbyUiMatch(match = {}) {
  return soloShuffleTool('isSoloShuffleLobbyUiMatch', (item) => Boolean(item && item.isSoloShuffleLobby && Array.isArray(item.soloRounds)))(match);
}

function isSoloShuffleRoundChildUiMatch(match = {}) {
  return soloShuffleTool('isSoloShuffleRoundChildUiMatch', (item) => Boolean(item && item.isSoloShuffleRoundChild))(match);
}

function findSoloShuffleParentForMatch(match = {}) {
  return soloShuffleTool('findSoloShuffleParentForMatch', (item) => {
    if (!item || !isSoloShuffleUiMatch(item)) return null;
    const parentId = String(item.parentLobbyMatchId || '');
    if (parentId) {
      const direct = (state.matches || []).find((candidate) => candidate && String(candidate.id || '') === parentId && isSoloShuffleLobbyUiMatch(candidate));
      if (direct) return direct;
    }
    const matchId = String(item.id || item.roundMatchId || '');
    if (matchId) {
      const byRoundId = (state.matches || []).find((candidate) => candidate && isSoloShuffleLobbyUiMatch(candidate) && soloShuffleRounds(candidate).some((round) => String(round.roundMatchId || round.id || '') === matchId));
      if (byRoundId) return byRoundId;
    }
    return null;
  })(match);
}

function visibleLibraryMatch(match = {}) {
  return soloShuffleTool('visibleLibraryMatch', (item) => Boolean(item && !item.hideFromMatchLibrary && !isPendingScoreboardSnapshot(item) && !isSoloShuffleRoundChildUiMatch(item)))(match);
}

function soloShuffleSummaryText(match = {}) {
  return soloShuffleTool('soloShuffleSummaryText', (item) => `${Number(item.soloShuffleWins || 0) || 0}W - ${Number(item.soloShuffleLosses || 0) || 0}L`)(match || {});
}

function soloShuffleRounds(match = {}) {
  return soloShuffleTool('soloShuffleRounds', (item) => Array.isArray(item && item.soloRounds)
    ? item.soloRounds.filter(Boolean).sort((a, b) => (Number(a.roundNumber) || 0) - (Number(b.roundNumber) || 0))
    : [])(match);
}

function selectedSoloShuffleRoundNumber(match = {}) {
  return soloShuffleTool('selectedSoloShuffleRoundNumber', () => 1)(match);
}

function selectedSoloShuffleRound(match = {}) {
  return soloShuffleTool('selectedSoloShuffleRound', (item) => soloShuffleRounds(item)[0] || null)(match);
}

function soloShuffleRoundTone(result = '') {
  return soloShuffleTool('soloShuffleRoundTone', (value) => {
    const resultText = displayResult(value);
    if (resultText === 'Win') return 'win';
    if (resultText === 'Loss') return 'loss';
    if (/incomplete|unclear/i.test(String(value || ''))) return 'unclear';
    return 'unknown';
  })(result);
}

function renderSoloShuffleRoundDots(match = {}, clickable = false, extraClass = '') {
  return soloShuffleTool('renderSoloShuffleRoundDots', () => '')(match, clickable, extraClass);
}

function soloShuffleRoundVideoBounds(parent = {}, round = {}) {
  return soloShuffleTool('soloShuffleRoundVideoBounds', () => ({ rawStart: 0, rawEnd: 1 }))(parent, round);
}

function soloShuffleRoundContextMatch(parent = {}) {
  return soloShuffleTool('soloShuffleRoundContextMatch', (item) => item)(parent);
}

function soloShuffleStatsMatch(parent = {}) {
  return soloShuffleTool('soloShuffleStatsMatch', (item) => item)(parent);
}

function currentReplayMatch() {
  return soloShuffleTool('currentReplayMatch', () => selectedMatch())();
}

function soloShuffleSessionIdentity(match = {}) {
  return soloShuffleTool('soloShuffleSessionIdentity', () => '')(match);
}

function soloShufflePlayerSeenKey(match = {}, playerName = '') {
  return soloShuffleTool('soloShufflePlayerSeenKey', () => '')(match, playerName);
}

function soloShufflePlayerRoundKey(match = {}, playerName = '') {
  return soloShuffleTool('soloShufflePlayerRoundKey', () => '')(match, playerName);
}

function bestEnemyDisplayName(names = []) {
  const clean = names.filter(Boolean);
  if (!clean.length) return '';
  return clean.slice().sort((a, b) => {
    const dashDiff = (String(b).includes('-') ? 1 : 0) - (String(a).includes('-') ? 1 : 0);
    if (dashDiff !== 0) return dashDiff;
    return String(b).length - String(a).length;
  })[0];
}

function computeMostSeenEnemy(matches = state.matches) {
  const counts = new Map();
  const seenEncounters = new Set();
  for (const match of matches) {
    const ownNames = ownNameSetForMatch(match);
    const ownKeys = new Set(Array.from(ownNames).map(enemyIdentityKey));
    const enemies = match.enemies && match.enemies.length ? match.enemies : [];
    const seenThisMatch = new Set();
    for (const name of enemies) {
      const key = enemyIdentityKey(name);
      const encounterKey = isSoloShuffleUiMatch(match) ? `solo:${soloShufflePlayerSeenKey(match, name)}` : `match:${match.id || playerMeetingDedupeKey(match, name) || ''}:${key}`;
      if (!name || name === 'Unknown' || /^Player-/.test(name) || ownNames.has(name) || ownKeys.has(key) || seenThisMatch.has(key) || seenEncounters.has(encounterKey)) continue;
      seenThisMatch.add(key);
      seenEncounters.add(encounterKey);
      const entry = counts.get(key) || { displayName: name, count: 0, variants: new Set() };
      entry.count += 1;
      entry.variants.add(name);
      entry.displayName = bestEnemyDisplayName([entry.displayName, ...entry.variants]);
      counts.set(key, entry);
    }
  }
  const best = Array.from(counts.values()).sort((a, b) => b.count - a.count || String(a.displayName).localeCompare(String(b.displayName)))[0];
  return best ? [best.displayName, best.count, Array.from(best.variants)] : null;
}

function normalizeRecorderRuntime() {
  return recordingActionTools ? recordingActionTools.normalizeRecorderRuntime() : undefined;
}

function recorderIsActive() {
  return recordingActionTools ? recordingActionTools.recorderIsActive() : false;
}


function getPageScrollTop() {
  return window.scrollY || document.documentElement.scrollTop || document.body.scrollTop || 0;
}

function restorePageScroll(top = 0) {
  const safeTop = Math.max(0, Number(top) || 0);
  window.requestAnimationFrame(() => {
    try { window.scrollTo({ top: safeTop, left: 0, behavior: 'auto' }); }
    catch (_) { window.scrollTo(0, safeTop); }
  });
}

let renderDebounceTimer = null;
function scheduleRender(delay = 80) {
  clearTimeout(renderDebounceTimer);
  renderDebounceTimer = window.setTimeout(() => {
    renderDebounceTimer = null;
    render();
  }, Math.max(16, Number(delay) || 80));
}

let progressClearTimer = null;
let progressOverlayDismissedAt = 0;
let progressOverlayManualHiddenUntil = 0;
const progressOverlayDismissedJobs = new Set();
const PROGRESS_STALE_MS = 45000;

function normalizeProgressStatus(value = '') {
  const raw = String(value || '').toLowerCase();
  if (raw === 'complete') return 'complete';
  if (raw === 'failed' || raw === 'error') return 'failed';
  if (raw === 'canceled' || raw === 'cancelled') return 'canceled';
  if (raw === 'canceling' || raw === 'cancelling') return 'canceling';
  if (raw === 'queued') return 'queued';
  return raw || 'running';
}

function progressUpdatedMs(job = {}) {
  const progress = job && job.progress && typeof job.progress === 'object' ? job.progress : {};
  return Date.parse(progress.updatedAt || job.startedAt || job.queuedAt || job.updatedAt || '') || Date.now();
}

function progressJobIsStale(job = {}) {
  if (!job || !job.id || job.cancelRequested) return false;
  const status = normalizeProgressStatus(job.status || '');
  if (['complete', 'failed', 'canceled'].includes(status)) return false;
  return Date.now() - progressUpdatedMs(job) > PROGRESS_STALE_MS;
}

function scheduleProgressAutoClear(delay = 1800) {
  clearTimeout(progressClearTimer);
  progressClearTimer = window.setTimeout(() => {
    state.heavyWorkBusy = Boolean(state.importJobStatus && state.importJobStatus.active);
    state.performanceProgress = null;
    renderPerformanceProgressOnly();
  }, Math.max(600, Number(delay) || 1800));
}

function updatePerformanceProgressFromJob(payload = {}) {
  applyImportJobStatus(payload || {});
  const status = state.importJobStatus || {};
  const active = status.active || null;
  const queued = Number(status.queued || 0);
  const recent = Array.isArray(status.recent) ? status.recent[0] : null;
  state.heavyWorkBusy = Boolean(active || queued);
  if (active) {
    clearTimeout(progressClearTimer);
    state.performanceProgress = {
      label: active.label || 'Working',
      status: active.status || 'running',
      queued,
      progress: active.progress || null,
      updatedAt: new Date().toISOString()
    };
    return;
  }
  if (queued) {
    state.performanceProgress = { label: 'Queued work', status: `${queued} waiting`, queued, progress: null, updatedAt: new Date().toISOString() };
    return;
  }
  if (recent && recent.finishedAt) {
    const finishedMs = Date.parse(recent.finishedAt || '') || Date.now();
    const justFinished = Date.now() - finishedMs < 9000;
    if (justFinished && finishedMs > progressOverlayDismissedAt) {
      const recentStatus = normalizeProgressStatus(recent.status || (recent.canceled ? 'canceled' : (recent.ok === false ? 'failed' : 'complete')));
      state.performanceProgress = {
        label: recent.label || (recentStatus === 'canceled' ? 'Canceled' : recentStatus === 'failed' ? 'Failed' : 'Completed'),
        status: recentStatus,
        queued: 0,
        progress: recent.progress || { detail: recentStatus === 'failed' ? (recent.reason || 'Job failed') : recentStatus === 'canceled' ? 'Canceled by user.' : 'Completed', percent: recentStatus === 'complete' ? 100 : null },
        updatedAt: recent.finishedAt || new Date().toISOString()
      };
      scheduleProgressAutoClear(recentStatus === 'complete' ? 1800 : 5200);
      return;
    }
  }
  scheduleProgressAutoClear(700);
}

function currentBusyLabels() {
  const labels = [];
  if (state.matchRefreshBusy) labels.push('Refreshing match history');
  if (state.logSyncBusy) labels.push('Processing logs');
  if (state.selectedLogSyncBusy) labels.push('Syncing match data');
  if (state.logRepairBusy) labels.push('Repairing missing log links');
  if (state.pvpHelperSyncBusy) labels.push('Syncing PvPHelper data');
  if (state.addonInstallBusy) labels.push('Installing addon');
  return labels;
}

function renderProgressOverlay() {
  const status = state.importJobStatus || {};
  const active = status.active || null;
  const activeId = active && active.id ? String(active.id) : '';
  if (activeId && progressOverlayDismissedJobs.has(activeId)) return '';
  const progressState = state.performanceProgress || null;
  const busyLabels = currentBusyLabels();
  if (!active && Date.now() < progressOverlayManualHiddenUntil) return '';
  if (!active && !progressState && !busyLabels.length) return '';
  const activeProgress = (active && active.progress) || (progressState && progressState.progress) || {};
  const label = (active && active.label) || (progressState && progressState.label) || busyLabels[0] || 'Working';
  const activeStatus = normalizeProgressStatus((active && active.status) || (progressState && progressState.status) || '');
  const stale = Boolean(active && progressJobIsStale(active));
  let detail = activeProgress && activeProgress.detail ? String(activeProgress.detail) : (state.watchStatus || 'Keeping the app responsive while work finishes.');
  if (stale) detail = 'This is taking longer than expected. You can cancel or keep waiting.';
  if (active && active.cancelRequested) detail = 'Cancel requested. Waiting for a safe stop point.';
  const percent = Number(activeProgress && activeProgress.percent);
  const hasPercent = Number.isFinite(percent) && percent >= 0;
  const safePercent = Math.max(0, Math.min(100, hasPercent ? percent : 12));
  const queued = Number(status.queued || (progressState && progressState.queued) || 0);
  const sub = queued ? `${queued} queued behind this` : (active ? (activeStatus === 'canceling' ? 'canceling' : (active.status || 'running')) : busyLabels.slice(1).join(' · '));
  const statusWord = activeStatus === 'complete' ? 'Completed' : activeStatus === 'failed' ? 'Failed' : activeStatus === 'canceled' ? 'Canceled' : activeStatus === 'canceling' ? 'Canceling' : stale ? 'Still working' : 'Working';
  const canCancel = Boolean(active && active.id && active.canCancel !== false && activeStatus !== 'canceling');
  const showDismiss = Boolean(!active || stale || activeStatus === 'canceling' || active.cancelRequested);
  const keepWaitingLabel = stale ? 'Keep waiting' : 'Dismiss';
  const actionRow = canCancel || showDismiss
    ? `<div class="lcr-progress-actions" style="display:flex;justify-content:flex-end;gap:8px;margin-top:10px;">${canCancel ? `<button class="btn tiny danger" id="lcr-progress-cancel" data-job-id="${escapeHtml(active.id)}" type="button">Cancel</button>` : ''}${showDismiss ? `<button class="btn tiny" id="lcr-progress-dismiss" type="button">${escapeHtml(keepWaitingLabel)}</button>` : ''}</div>`
    : '';
  const title = stale ? 'Long-running job' : (active ? 'Job in progress' : 'Progress status');
  return `<div id="lcr-progress-overlay" title="${escapeHtml(title)}" style="position:fixed;right:18px;bottom:18px;z-index:9999;width:min(380px,calc(100vw - 36px));padding:14px 16px;border:1px solid rgba(148,163,184,.25);border-radius:18px;background:rgba(8,13,24,.94);box-shadow:0 18px 50px rgba(0,0,0,.35);backdrop-filter:blur(14px);color:#e5eefb;pointer-events:auto;">
    <div style="display:flex;justify-content:space-between;gap:12px;align-items:flex-start;"><div><div style="font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:#93c5fd;">${escapeHtml(statusWord)}</div><strong style="display:block;margin-top:2px;font-size:14px;">${escapeHtml(label)}</strong></div>${sub ? `<small style="color:#94a3b8;text-align:right;">${escapeHtml(sub)}</small>` : ''}</div>
    <div style="height:7px;border-radius:999px;background:rgba(148,163,184,.2);overflow:hidden;margin:10px 0 8px;"><div style="height:100%;width:${safePercent}%;border-radius:999px;background:linear-gradient(90deg,#38bdf8,#a78bfa);transition:width .18s ease;"></div></div>
    <div style="display:flex;justify-content:space-between;gap:10px;color:#a8b5c9;font-size:12px;"><span>${escapeHtml(detail)}</span>${hasPercent ? `<b>${Math.round(safePercent)}%</b>` : '<b>chunked</b>'}</div>
    ${actionRow}
  </div>`;
}

function dismissProgressOverlay({ hideActive = false } = {}) {
  progressOverlayDismissedAt = Date.now();
  progressOverlayManualHiddenUntil = Date.now() + 5 * 60 * 1000;
  clearTimeout(progressClearTimer);
  const active = state.importJobStatus && state.importJobStatus.active ? state.importJobStatus.active : null;
  if (hideActive && active && active.id) progressOverlayDismissedJobs.add(String(active.id));
  state.performanceProgress = null;
  state.heavyWorkBusy = Boolean(active);
  const current = document.getElementById('lcr-progress-overlay');
  if (current) current.remove();
}

function requestCancelImportJob(jobId = '') {
  const active = state.importJobStatus && state.importJobStatus.active ? state.importJobStatus.active : null;
  if (active) {
    active.cancelRequested = true;
    active.status = 'canceling';
    active.progress = { ...(active.progress || {}), detail: 'Cancel requested. Waiting for a safe stop point.', updatedAt: new Date().toISOString() };
  }
  state.performanceProgress = {
    label: active && active.label ? active.label : 'Canceling job',
    status: 'canceling',
    progress: { detail: 'Cancel requested. Waiting for a safe stop point.', percent: active && active.progress ? active.progress.percent : null },
    updatedAt: new Date().toISOString()
  };
  renderPerformanceProgressOnly();
  if (api && api.cancelImportJob) {
    api.cancelImportJob({ jobId, reason: 'Canceled by user.' }).then((payload) => {
      if (payload && payload.importJobStatus) updatePerformanceProgressFromJob(payload);
      renderPerformanceProgressOnly();
    }).catch((error) => {
      console.warn('[Last Call Replay] Cancel job request failed.', error);
      state.performanceProgress = {
        label: active && active.label ? active.label : 'Still working',
        status: 'running',
        progress: { detail: 'Could not cancel safely. You can stop waiting and let the app finish in the background.', percent: active && active.progress ? active.progress.percent : null },
        updatedAt: new Date().toISOString()
      };
      renderPerformanceProgressOnly();
    });
  }
}

function bindProgressOverlayActions(node) {
  if (!node) return;
  const cancel = node.querySelector('#lcr-progress-cancel');
  if (cancel) cancel.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    requestCancelImportJob(cancel.dataset.jobId || '');
  });
  const dismiss = node.querySelector('#lcr-progress-dismiss');
  if (dismiss) dismiss.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    dismissProgressOverlay({ hideActive: true });
  });
}

function renderPerformanceProgressOnly() {
  const existing = document.getElementById('lcr-progress-overlay');
  const html = renderProgressOverlay();
  if (existing && !html) {
    existing.remove();
    return;
  }
  if (existing && html) {
    const wrap = document.createElement('div');
    wrap.innerHTML = html.trim();
    if (wrap.firstElementChild) {
      existing.replaceWith(wrap.firstElementChild);
      bindProgressOverlayActions(document.getElementById('lcr-progress-overlay'));
    }
  } else if (html) {
    const appRoot = document.getElementById('app') || document.body;
    appRoot.insertAdjacentHTML('beforeend', html);
    bindProgressOverlayActions(document.getElementById('lcr-progress-overlay'));
  }
  const active = state.importJobStatus && state.importJobStatus.active ? state.importJobStatus.active : null;
  const progressState = state.performanceProgress || null;
  const progressStatus = normalizeProgressStatus(progressState && progressState.status);
  if (!active && progressState && ['complete', 'failed', 'canceled'].includes(progressStatus)) {
    scheduleProgressAutoClear(progressStatus === 'complete' ? 1800 : 5200);
  }
}

function jumpPageToTop() {
  restorePageScroll(0);
}

function rememberGlobalSearchCaret(input) { return getSearchViewTools().rememberGlobalSearchCaret(input); }
function restoreGlobalSearchCaret() { return getSearchViewTools().restoreGlobalSearchCaret(); }
function scheduleGlobalSearchRender(input) { return getSearchViewTools().scheduleGlobalSearchRender(input); }

function openMatchDetail(matchId) {
  if (!matchId) return;
  const raw = (state.matches || []).find((item) => item && String(item.id || '') === String(matchId));
  const parent = findSoloShuffleParentForMatch(raw);
  const targetId = parent && parent.id ? parent.id : matchId;
  const fromMatchList = state.active === 'Matches' && state.matchView !== 'detail';
  if (fromMatchList) state.matchListScrollY = getPageScrollTop();
  else if (state.active !== 'Matches') state.matchListScrollY = 0;
  state.selectedId = targetId;
  state.active = 'Matches';
  state.matchView = 'detail';
  render();
  jumpPageToTop();
}

function returnToMatchList() {
  state.matchView = 'list';
  render();
  restorePageScroll(state.matchListScrollY || 0);
}

function renderPreservingPageScroll() {
  const y = getPageScrollTop();
  render();
  restorePageScroll(y);
}

function openScoreboardForMatch(matchId) {
  if (!matchId) return;
  const raw = (state.matches || []).find((item) => item && String(item.id || '') === String(matchId));
  const match = findSoloShuffleParentForMatch(raw) || raw;
  if (!match || !hasLinkedScoreboard(match)) return;
  state.selectedId = match.id || matchId;
  state.scoreboardModalMode = 'view';
  if (state.active === 'Matches' && state.matchView !== 'detail') state.matchListScrollY = getPageScrollTop();
  renderPreservingPageScroll();
}

function closeScoreboardModal() {
  state.scoreboardModalMode = '';
  if (state.active === 'Matches' && state.matchView !== 'detail') renderPreservingPageScroll();
  else renderKeepingReplay();
}

function render() {
  stopReplayHealthSyncLoop();
  normalizeRecorderRuntime();
  const app = document.getElementById('app');
  app.innerHTML = `
    <div class="app-shell">
      ${renderSidebar()}
      <main class="main">
        ${renderTopbar()}
        <section id="view-root">${renderView()}</section>
      </main>
    </div>
    ${renderSourceQuickModal()}
    ${renderMetricAbilityModal()}
    ${renderPvPHelperImportPreviewModal()}
    ${renderScoreboardModal()}
    ${renderPlayerMeetingsModal()}
    ${renderProgressOverlay()}
  `;
  bindEvents();
  scheduleReplayPanelHeightSync();
  scheduleVideoRailUpdate(false);
  restoreGlobalSearchCaret();
}


function syncReplayPanelHeights() { return replayTimelineTools.syncReplayPanelHeights(); }
function scheduleReplayPanelHeightSync() { return replayTimelineTools.scheduleReplayPanelHeightSync(); }

function sidebarVersionStrip() {
  const appText = `App ${displayAppVersion(state.appVersion || '1.92')}`;
  const settings = state.settings || {};
  const status = settings.pvpHelperStatus || {};
  const install = state.pvpHelperInstallStatus || settings.pvpHelperAddonInstallStatus || {};
  const addonVersion = install.installedVersion || status.addonVersion || install.packageVersion || install.localPackageVersion || install.bundledVersion || '';
  const addonText = addonVersion ? `PvPHelper ${addonVersion}` : (settings.pvpHelperSavedVariablesPath ? 'PvPHelper mapped' : 'PvPHelper not mapped');
  return `<div class="sidebar-version-strip" title="${escapeHtml(`${appText} · ${addonText}`)}"><span>${escapeHtml(appText)}</span><span>${escapeHtml(addonText)}</span></div>`;
}

function sidebarNavBadge(name, setup = recorderSetupSummary()) {
  const settings = state.settings || {};
  const logsReady = Boolean(settings.logFilePath || state.watchPath);
  const pvpHelperMapped = Boolean(settings.pvpHelperSavedVariablesPath && settings.pvpHelperFileExists !== false);
  if (name === 'Matches' && !logsReady) return '<span class="nav-badge warn">Logs not mapped</span>';
  if (name === 'Recorder') {
    if (setup.isRecording) return '<span class="nav-badge live">REC</span>';
    if (!setup.hasFolder) return '<span class="nav-badge warn">Needs folder</span>';
    if (!setup.hasSource || setup.savedSourceMissing || setup.approvalNeeded) return '<span class="nav-badge warn">Needs source</span>';
  }
  if (name === 'Characters' && !pvpHelperMapped) return '<span class="nav-badge warn">Needs Lua</span>';
  return '';
}

function renderSidebar() {
  const nav = [['Dashboard', '📊'], ['Matches', '📖'], ['Favorites', '★'], ['Characters', '🧙'], ['Players', '👥'], ['VOD', '🎬'], ['Recorder', '🎥'], ['Settings', '⚙️']];
  const setup = recorderSetupSummary();
  const isRecording = setup.isRecording;
  const recorderBusy = Boolean(setup.isStarting || setup.isStopping || setup.busy);
  const ready = setup.ready;
  const recorderTitle = setup.title === 'Ready' ? 'Ready to record' : setup.title;
  const recorderText = isRecording ? 'Recording locally' : setup.hint;
  const dotClass = isRecording || setup.isStopping ? 'recording' : ready ? '' : 'warn';
  const primaryDisabled = recorderBusy || isRecording ? 'disabled' : '';
  const recorderPrimaryButton = !setup.hasFolder
    ? `<button class="btn small primary" id="sidebar-recordings-folder" ${primaryDisabled}>Choose Folder</button>`
    : `<button class="btn small" id="sidebar-recorder-source" ${primaryDisabled}>Source</button>`;
  const startDisabled = setup.startDisabled ? 'disabled' : '';
  const stopDisabled = setup.stopDisabled ? 'disabled' : '';
  const startLabel = setup.isStarting ? 'Starting…' : 'Start Rec';
  const stopLabel = setup.isStopping ? 'Saving…' : 'Stop';
  return `
    <aside class="sidebar">
      <div class="brand-card">
        <div class="brand-row">
          <div class="logo brand-logo"><img src="assets/last-call-replay-logo.png" alt="Last Call Replay logo" /></div>
          <div><p class="kicker">Last Call</p><h1 class="brand-title">Replay</h1></div>
        </div>
        <p class="body">PvP match review, local recordings, and player history.</p>
      </div>
      <nav class="nav">${nav.map(([name, icon]) => `<button data-nav="${name}" class="${state.active === name ? 'active' : ''}"><span class="nav-main"><span class="nav-emoji">${icon}</span><span>${name}</span></span>${sidebarNavBadge(name, setup)}</button>`).join('')}</nav>
      <div class="sidebar-recorder-pill ${isRecording || setup.isStopping ? 'recording' : setup.isStarting ? 'starting' : ready ? 'ready' : 'needs-setup'}">
        <div class="sidebar-recorder-status"><span class="dot ${dotClass}"></span><div><p class="watcher-title" id="sidebar-recorder-time">${escapeHtml(recorderTitle)}</p><p class="watcher-path">${escapeHtml(recorderText)}</p></div></div>
        <div class="sidebar-recorder-actions">
          ${recorderPrimaryButton}
          <button class="btn small primary start-recording-btn sidebar-start" id="sidebar-start-recording" ${startDisabled}>${escapeHtml(startLabel)}</button>
          <button class="btn small rose stop-recording-btn sidebar-stop" id="sidebar-stop-recording" ${stopDisabled}>${escapeHtml(stopLabel)}</button>
        </div>
      </div>
      ${sidebarVersionStrip()}
    </aside>
  `;
}

function dashboardAddonStatusSummary() {
  const settings = state.settings || {};
  const mappedPvph = settings.pvpHelperSavedVariablesPath || '';
  const status = settings.pvpHelperStatus || {};
  const install = state.pvpHelperInstallStatus || settings.pvpHelperAddonInstallStatus || {};
  const latestAddon = latestPvPHelperImport();
  const mapped = Boolean(mappedPvph && settings.pvpHelperFileExists !== false && !status.missingFile);
  const installed = Boolean(install.addonInstalled || status.addonFound || status.addonVersion || status.addonNeedsUpdate === false);
  const synced = Boolean(latestAddon || settings.pvpHelperLastSyncAt || status.addonFound);
  const installedVersion = install.installedVersion || status.addonVersion || '';
  const packageVersion = install.packageVersion || install.localPackageVersion || install.bundledVersion || '';
  const versionText = installedVersion ? `PvPHelper ${installedVersion}` : installed ? 'PvPHelper detected' : install.reason || (mapped ? 'Mapped, install not confirmed' : 'Not installed yet');
  const installText = installed
    ? (install.needsUpdate && packageVersion ? `Update available from local package: ${packageVersion}` : (install.reason || (install.installedDir ? displayPathTail(install.installedDir, 3) : 'Installed in AddOns')))
    : (install.canInstall ? (packageVersion ? `Ready to install local package ${packageVersion}` : 'Ready to install from local package') : (install.reason || 'Choose WoW Logs folder first'));
  const syncText = settings.pvpHelperLastSyncAt ? `Last sync ${formatSyncDateTime(settings.pvpHelperLastSyncAt)}` : synced ? 'Synced addon data found' : 'Map PvPHelper folder in Settings';
  const mappingText = mapped ? displayPathTail(mappedPvph, 2) : 'No SavedVariables mapping';
  const mappingTitle = mappedPvph ? ` title="${escapeHtml(mappedPvph)}"` : '';
  const linkedCount = Number(settings.pvpHelperLastMergedCount || (latestAddon && latestAddon.mergedCount) || 0);
  const pendingCount = Number(settings.pvpHelperLastPendingCount || (latestAddon && latestAddon.createdCount) || 0);
  const scoreboardCount = Number(settings.pvpHelperLastScoreboardCount || (latestAddon && latestAddon.parsedCount) || 0);
  const readinessIssues = Array.isArray(status.dataReadinessIssues) ? status.dataReadinessIssues.filter(Boolean) : [];
  const readinessWarnings = Array.isArray(status.dataReadinessWarnings) ? status.dataReadinessWarnings.filter(Boolean) : [];
  const hardSettingIssue = Boolean(status.addonFound && ((status.scoreboardCaptureKnown === true && status.scoreboardCaptureEnabled === false) || (status.advancedCombatLoggingKnown === true && status.advancedCombatLoggingEnabled === false) || (status.combatLogConfigFound === true && status.combatLoggingEnabled === false)));
  const readinessNeedsAttention = Boolean(mapped && (readinessIssues.length || hardSettingIssue));
  const readinessText = readinessIssues[0] || readinessWarnings[0] || (mapped ? 'PvPHelper data settings look ready.' : 'Map PvPHelper folder to verify data settings.');
  return { mapped, installed, synced, versionText, installText, mappingText, mappingTitle, linkedCount, pendingCount, scoreboardCount, install, readinessNeedsAttention, readinessText, readinessIssues, readinessWarnings };
}

function renderAddonInstallActions(addon, context = '') {
  const install = addon && addon.install ? addon.install : (state.pvpHelperInstallStatus || {});
  const busy = Boolean(state.addonInstallBusy);
  const idSuffix = context ? `-${context}` : '';
  const buttons = [];
  if (!install.addonInstalled && install.canInstall) {
    buttons.push(`<button class="btn small emerald install-pvphelper-addon" id="install-pvphelper-addon${idSuffix}" ${busy ? 'disabled' : ''}>${busy ? 'Installing…' : 'Install Addon'}</button>`);
  } else if (install.addonInstalled && install.needsUpdate && install.canInstall) {
    buttons.push(`<button class="btn small violet install-pvphelper-addon" id="install-pvphelper-addon${idSuffix}" ${busy ? 'disabled' : ''}>${busy ? 'Updating…' : 'Update Addon'}</button>`);
  }
  if (!install.wowRoot) {
    buttons.push('<button class="btn small" id="settings-pick-log-folder-addon">Choose Logs Folder</button>');
  }
  buttons.push(`<button class="btn small refresh-pvphelper-addon" id="refresh-pvphelper-addon${idSuffix}">Recheck</button>`);
  if (install.installedDir) buttons.push(`<button class="btn small reveal-pvphelper-addon" data-reveal-pvphelper-addon="${escapeHtml(install.installedDir)}">Open WoW Addon</button>`);
  if (install.packageDropDir) buttons.push(`<button class="btn small reveal-pvphelper-addon" data-reveal-pvphelper-addon="${escapeHtml(install.packageDropDir)}">Open Package Folder</button>`);
  return buttons.length ? `<div class="action-row addon-install-actions">${buttons.join('')}</div>` : '';
}

function renderPvPHelperInstallStatusCard(context = '') {
  const addon = dashboardAddonStatusSummary();
  const install = addon.install || {};
  const tone = install.addonInstalled ? (install.needsUpdate ? 'amber' : 'emerald') : (install.canInstall ? 'amber' : 'rose');
  const title = install.addonInstalled ? (install.needsUpdate ? 'Addon update available' : 'Addon installed') : (install.canInstall ? 'Addon package ready' : 'Addon install needs setup');
  const folder = install.installedDir || install.packageDir || install.packageDropDir || install.addonsDir || install.wowRoot || '';
  return `<div class="addon-install-card status-callout ${tone}"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(addon.installText || install.reason || 'PvPHelper install status unknown.')}</span>${folder ? `<small class="path-value" title="${escapeHtml(folder)}">${escapeHtml(displayPathTail(folder, 4))}</small>` : ''}${renderAddonInstallActions(addon, context)}</div>`;
}


function topbarAddonInstallPill(addon = {}) {
  const install = addon.install || {};
  const busy = Boolean(state.addonInstallBusy);
  if (busy) {
    return { className: 'warn', label: install.addonInstalled ? 'Updating addon…' : 'Installing addon…', title: 'Installing PvPHelper into your WoW Interface\AddOns folder.' };
  }
  if (install.canInstall && !install.addonInstalled) {
    return { className: 'warn', label: 'Install Addon', title: addon.installText || install.reason || 'Install PvPHelper into your WoW Interface\AddOns folder.' };
  }
  if (install.canInstall && install.addonInstalled && install.needsUpdate) {
    return { className: 'warn', label: 'Update Addon', title: addon.installText || install.reason || 'Update the installed PvPHelper folder from the local app package.' };
  }
  if (addon.installed) {
    return { className: install.needsUpdate ? 'warn' : 'good', label: install.needsUpdate ? 'Addon update available' : 'Addon installed', title: addon.installText || install.reason || 'PvPHelper is installed.' };
  }
  if (!install.wowRoot) {
    return { className: 'warn', label: 'Addon needs WoW path', title: 'Choose your WoW Logs folder so the app can find Interface\AddOns.' };
  }
  if (!install.packageAvailable) {
    return { className: 'warn', label: 'Add addon package', title: install.reason || 'Put the unzipped PvPHelper folder in addon-packages\PvPHelper.' };
  }
  return { className: 'warn', label: 'Addon not confirmed', title: addon.installText || install.reason || 'PvPHelper install status unknown.' };
}


function renderTopbar() {
  const addon = dashboardAddonStatusSummary();
  const addonInstallPill = topbarAddonInstallPill(addon);
  return `
    <header class="topbar utility-topbar">
      <div class="utility-status-row addon-only-topbar">
        <button class="utility-pill ${addonInstallPill.className} actionable" id="topbar-addon-install-status" title="${escapeHtml(addonInstallPill.title)}">${escapeHtml(addonInstallPill.label)}</button>
        <button class="utility-pill ${addon.mapped && !addon.readinessNeedsAttention ? 'good' : 'warn'} actionable" id="topbar-addon-map-status" title="${escapeHtml(addon.mapped ? addon.readinessText : addon.mappingText)}">${addon.mapped ? (addon.readinessNeedsAttention ? 'PvPHelper needs setup' : 'PvPHelper mapped') : 'PvPHelper not mapped'}</button>
      </div>
      <div class="controls">
        <div class="search-wrap"><span>⌕</span><input id="global-search" value="${escapeHtml(state.query)}" placeholder="Search players, maps, abilities" /></div>
        <select id="result-filter">
          ${['All', 'Win', 'Loss', 'Unscored'].map((item) => `<option ${state.resultFilter === item ? 'selected' : ''}>${item}</option>`).join('')}
        </select>
      </div>
    </header>
  `;
}

function renderView() {
  if (state.active === 'Dashboard') return renderDashboard();
  if (state.active === 'Matches') return renderMatches();
  if (state.active === 'Favorites') return renderFavorites();
  if (state.active === 'Characters') return renderCharacters();
  if (state.active === 'Players') return renderPlayers();
  if (state.active === 'VOD') return renderVodControls();
  if (state.active === 'Recorder') return renderRecorder();
  if (state.active === 'Settings') return renderSettings();
  if (state.active === 'Import' || state.active === 'Review Lab') state.active = 'Matches';
  return renderDashboard();
}





let recorderViewToolsCache = null;
function getRecorderViewTools() {
  if (!recorderViewToolsCache && window.LastCallRecorderView && typeof window.LastCallRecorderView.createRecorderViewTools === 'function') {
    recorderViewToolsCache = window.LastCallRecorderView.createRecorderViewTools({
      state,
      escapeHtml,
      sourceSort,
      allowedCaptureSources,
      captureSourceKind,
      sourceLooksLikeWow,
      currentCaptureSource,
      recorderSetupSummary,
      recorderPerformanceLabel,
      recorderPerformanceCaption,
      validRecorderPerformanceMode,
      cleanRecordingTitleText,
      displayFileName,
      displayMatchType,
      shortCharacterName,
      matchClock,
      matchDurationForDisplay,
      boundedMatchRangeMsForVod,
      formatElapsed,
      formatBytes,
      renderLoadMoreButton
    });
  }
  return recorderViewToolsCache;
}

function uniqueRecordingCount() { const tools = getRecorderViewTools(); return tools ? tools.uniqueRecordingCount() : 0; }
function renderSourcePicker(context = 'main') { const tools = getRecorderViewTools(); return tools ? tools.renderSourcePicker(context) : ''; }
function renderSourceQuickModal() { const tools = getRecorderViewTools(); return tools ? tools.renderSourceQuickModal() : ''; }
function renderRecorderSettingsModal() { const tools = getRecorderViewTools(); return tools ? tools.renderRecorderSettingsModal() : ''; }
function recordingDisplayLabel(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingDisplayLabel(item) : 'Recording'; }
function recordingLinkedMatchIds(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingLinkedMatchIds(item) : []; }
function recordingSessionVodFor(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingSessionVodFor(item) : null; }
function recordingTitleForItem(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingTitleForItem(item) : 'Recording'; }
function recordingMatchCards(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingMatchCards(item) : ''; }
function recordingLinkedMatchCount(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingLinkedMatchCount(item) : 0; }
function recordingStartMs(item = {}) { const tools = getRecorderViewTools(); return tools ? tools.recordingStartMs(item) : 0; }
function recordingEndMs(item = {}) { const tools = getRecorderViewTools(); return tools ? tools.recordingEndMs(item) : 0; }
function recordingSuggestedMatches(item, limit = 4) { const tools = getRecorderViewTools(); return tools ? tools.recordingSuggestedMatches(item, limit) : []; }
function recordingInWindowMatchIds(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingInWindowMatchIds(item) : []; }
function recordingSuggestedMatchCards(item, expanded = false) { const tools = getRecorderViewTools(); return tools ? tools.recordingSuggestedMatchCards(item, expanded) : ''; }
function recordingStatusTone(item) { const tools = getRecorderViewTools(); return tools ? tools.recordingStatusTone(item) : 'unlinked'; }
function filteredRecordings() { const tools = getRecorderViewTools(); return tools ? tools.filteredRecordings() : []; }
function recordingVisibleLimitForFilter(filter) { const tools = getRecorderViewTools(); return tools ? tools.recordingVisibleLimitForFilter(filter) : 12; }
function renderRecorder() { const tools = getRecorderViewTools(); return tools ? tools.renderRecorder() : ''; }
function renderRecordingItem(item) { const tools = getRecorderViewTools(); return tools ? tools.renderRecordingItem(item) : ''; }



function matchCharacterKey(match) {
  if (!match) return 'Unknown|Spec unknown';
  const name = match.alt || (match.ownNames && match.ownNames[0]) || 'Unknown';
  const meta = classMetaForName(name, match) || {};
  const spec = match.spec && match.spec !== 'Spec unknown' ? match.spec : (meta.specName || 'Spec unknown');
  return characterDisplayKey(name, spec);
}

let dashboardViewToolsCache = null;
function getDashboardViewTools() {
  if (!dashboardViewToolsCache && window.LastCallDashboardView && typeof window.LastCallDashboardView.createDashboardViewTools === 'function') {
    dashboardViewToolsCache = window.LastCallDashboardView.createDashboardViewTools({
      state,
      buildCharacterProfiles,
      characterPrettyName,
      visibleLibraryMatch,
      matchCharacterKey,
      matchTypeMatchesFilter,
      matchResolvedResult,
      effectiveMatchType,
      escapeHtml,
      recorderSetupSummary,
      formatElapsed,
      dashboardAddonStatusSummary,
      renderAddonInstallActions,
      latestCombatLogImport,
      displayPathTail,
      formatSyncDateTime,
      enemyIdentityKey,
      isPendingScoreboardSnapshot,
      ownNameSetForMatch,
      matchSortTime,
      classMetaAcrossMatches,
      matchTimestampLabel,
      displayMatchType,
      displayMatchTypeLabel,
      shortCharacterName,
      coloredShortName,
      fullRosterTitle,
      matchVideoPath,
      isFavoriteMatch,
      isSoloShuffleLobbyUiMatch,
      renderSoloShuffleLobbyPlayers,
      renderSoloShuffleInlineSummary,
      matchClock,
      matchDay,
      pill,
      matchTeamSizePill,
      renderNoDataBox,
      computeMostSeenEnemy,
      uniqueValues
    });
  }
  return dashboardViewToolsCache;
}

function dashboardCharacterOptions() { return getDashboardViewTools().dashboardCharacterOptions(); }
function dashboardScopedMatches() { return getDashboardViewTools().dashboardScopedMatches(); }
function dashboardHistoryMatches() { return getDashboardViewTools().dashboardHistoryMatches(); }
function knownResultsFrom(matches) { return getDashboardViewTools().knownResultsFrom(matches); }
function winRateBreakdownHtml(matches) { return getDashboardViewTools().winRateBreakdownHtml(matches); }
function dashboardSelectedCharacterLabel() { return getDashboardViewTools().dashboardSelectedCharacterLabel(); }
function renderDashboardScopeInline(matches) { return getDashboardViewTools().renderDashboardScopeInline(matches); }
function renderWinRateInline(matches) { return getDashboardViewTools().renderWinRateInline(matches); }
function dashboardRecorderSetupButton(setup) { return getDashboardViewTools().dashboardRecorderSetupButton(setup); }
function renderDashboardRecorderCompact() { return getDashboardViewTools().renderDashboardRecorderCompact(); }
function renderDashboardAddonCompact() { return getDashboardViewTools().renderDashboardAddonCompact(); }
function renderDashboardLogCompact() { return getDashboardViewTools().renderDashboardLogCompact(); }
function renderDashboardHero(matches) { return getDashboardViewTools().renderDashboardHero(matches); }
function dashboardEnemySummary(name, matches) { return getDashboardViewTools().dashboardEnemySummary(name, matches); }
function renderMostSeenEnemyCard(mostSeen, matches) { return getDashboardViewTools().renderMostSeenEnemyCard(mostSeen, matches); }
function renderDashboardTeamCompact(label, names, match, side) { return getDashboardViewTools().renderDashboardTeamCompact(label, names, match, side); }
function resultCardClass(match) { return getDashboardViewTools().resultCardClass(match); }
function renderDashboardVideoThumb(match) { return getDashboardViewTools().renderDashboardVideoThumb(match); }
function renderDashboardMatchCard(match) { return getDashboardViewTools().renderDashboardMatchCard(match); }
function renderDashboardCharacterCard(matches) { return getDashboardViewTools().renderDashboardCharacterCard(matches); }
function renderWinRateCard(matches) { return getDashboardViewTools().renderWinRateCard(matches); }
function renderDashboardRecorderCard() { return getDashboardViewTools().renderDashboardRecorderCard(); }
function dashboardMatchTypeOptions(matches) { return getDashboardViewTools().dashboardMatchTypeOptions(matches); }
function dashboardFunStats(matches) { return getDashboardViewTools().dashboardFunStats(matches); }
function renderDashboardHistoryFilters(scopeMatches) { return getDashboardViewTools().renderDashboardHistoryFilters(scopeMatches); }
function renderDashboard() { return getDashboardViewTools().renderDashboard(); }

function statCard(icon, label, value, caption, attrs = '', rawValue = false) {
  const clickable = attrs ? ' clickable' : '';
  return `<div class="card stat-card${clickable}" ${attrs}><div><p class="small-label">${escapeHtml(label)}</p><p class="big-value">${rawValue ? value : escapeHtml(value)}</p><p class="caption">${escapeHtml(caption)}</p></div><div class="icon">${icon}</div></div>`;
}


function renderNoDataBox() {
  return `<div class="empty"><strong>No PvP matches yet.</strong><br>Auto-locate your WoW setup or import a combat log to begin.<div class="action-row compact-actions" style="justify-content:center;margin-top:12px"><button class="btn emerald auto-connect-local-setup-button">Auto-Locate Setup</button><button class="btn pick-folder-button">Choose Logs Folder</button></div></div>`;
}

let importCenterViewToolsCache = null;
function getImportCenterViewTools() {
  if (!importCenterViewToolsCache) {
    if (!window.LastCallImportCenterView || typeof window.LastCallImportCenterView.createImportCenterViewTools !== 'function') {
      throw new Error('Import center view module failed to load.');
    }
    importCenterViewToolsCache = window.LastCallImportCenterView.createImportCenterViewTools({
      state,
      escapeHtml,
      pill,
      combatLogImportHistory,
      pvpHelperSyncHelpIcon,
      pathValueMarkup,
      displayPathTail,
      displayMatchTypeLabel,
      renderPvPHelperInstallStatusCard
    });
  }
  return importCenterViewToolsCache;
}

function renderImportPanel() { return getImportCenterViewTools().renderImportPanel(); }
function renderImportLaneHistory(items, emptyText) { return getImportCenterViewTools().renderImportLaneHistory(items, emptyText); }
function formatSyncDateTime(value) { return getImportCenterViewTools().formatSyncDateTime(value); }
function latestCombatLogImport() { return getImportCenterViewTools().latestCombatLogImport(); }
function latestPvPHelperImport() { return getImportCenterViewTools().latestPvPHelperImport(); }
function renderLatestImportSummary(item, emptyText, label = 'Most recent') { return getImportCenterViewTools().renderLatestImportSummary(item, emptyText, label); }
function currentPvPHelperSavedVariablesDiscovery() { return getImportCenterViewTools().currentPvPHelperSavedVariablesDiscovery(); }
function renderPvPHelperMappingAssist(mappedPvph = '', context = '') { return getImportCenterViewTools().renderPvPHelperMappingAssist(mappedPvph, context); }
function renderPvPHelperAddonStatus(mappedPvph, settings = {}) { return getImportCenterViewTools().renderPvPHelperAddonStatus(mappedPvph, settings); }
function renderImportCenter() { return getImportCenterViewTools().renderImportCenter(); }
function renderCharacterImportHelpCard(profiles = []) { return getImportCenterViewTools().renderCharacterImportHelpCard(profiles); }
function renderPvPHelperImportPreviewModal() { return getImportCenterViewTools().renderPvPHelperImportPreviewModal(); }


function renderFilterSelect(id, label, value, options, labeler = (item) => item) { return getSearchViewTools().renderFilterSelect(id, label, value, options, labeler); }
function renderSortSelect(id, label, value, options) { return getSearchViewTools().renderSortSelect(id, label, value, options); }
function renderLoadMoreButton(id, shownCount, totalCount, label = 'items') { return getSearchViewTools().renderLoadMoreButton(id, shownCount, totalCount, label); }
function increaseVisibleLimit(key, step = 80, max = 2000) { return getSearchViewTools().increaseVisibleLimit(key, step, max); }
function renderMatchFilters() { return getSearchViewTools().renderMatchFilters(); }

function matchVideoPath(match) {
  if (!match) return '';
  if (match.videoPath) return match.videoPath;
  const rec = (state.recorder.recordings || []).find((item) => item && item.matchId === match.id && item.filePath);
  return rec ? rec.filePath : '';
}

function matchHasExportableClip(match) {
  if (!match || !matchVideoPath(match)) return false;
  const clipStart = Number(match.videoClipStartSec);
  const clipEnd = Number(match.videoClipEndSec);
  return match.videoLinkMode === 'vod' && Number.isFinite(clipStart) && Number.isFinite(clipEnd) && clipEnd > clipStart;
}

function matchScoreboardListButton(match) {
  if (!match || !hasLinkedScoreboard(match)) return '';
  return `<span class="match-list-action scoreboard" role="button" tabindex="0" data-scoreboard-match="${escapeHtml(match.id)}">Scoreboard</span>`;
}

function matchDownloadClipButton(match) {
  if (!match || !matchHasExportableClip(match)) return '';
  return `<span class="match-list-action download subtle-download icon-download" role="button" tabindex="0" aria-label="Download VOD" title="Download VOD" data-download-clip-match="${escapeHtml(match.id)}">↓</span>`;
}

let matchesViewToolsCache = null;
function getMatchesViewTools() {
  if (!matchesViewToolsCache && window.LastCallMatchesView && typeof window.LastCallMatchesView.createMatchesViewTools === 'function') {
    matchesViewToolsCache = window.LastCallMatchesView.createMatchesViewTools({
      state,
      getMatches: () => state.matches || [],
      escapeHtml,
      shortNameKey,
      coloredShortName,
      renderSoloShuffleRoundDots,
      soloShuffleRounds,
      soloShuffleSummaryText,
      isSoloShuffleLobbyUiMatch,
      renderMatchTeams,
      matchScoreboardListButton,
      matchVideoPath,
      isFavoriteMatch,
      resultCardClass,
      matchClock,
      displayMatchType,
      matchTeamSizePill,
      pill,
      matchDownloadClipButton,
      filteredMatches,
      sortMatchesForLibrary,
      visibleLibraryMatch
    });
  }
  return matchesViewToolsCache;
}

let matchDetailViewToolsCache = null;
function getMatchDetailViewTools() {
  if (!matchDetailViewToolsCache && window.LastCallMatchDetailView && typeof window.LastCallMatchDetailView.createMatchDetailViewTools === 'function') {
    matchDetailViewToolsCache = window.LastCallMatchDetailView.createMatchDetailViewTools({
      state,
      escapeHtml,
      pill,
      renderNoDataBox,
      isFavoriteMatch,
      isSoloShuffleLobbyUiMatch,
      soloShuffleRounds,
      selectedSoloShuffleRound,
      selectedSoloShuffleRoundNumber,
      soloShuffleSummaryText,
      renderSoloShuffleRoundDots,
      shortCharacterName,
      displayResult,
      coloredShortName,
      soloShuffleRoundContextMatch,
      soloShuffleStatsMatch,
      renderSyncedReplay,
      renderMetricPanel,
      renderInlineScoreboardPanel,
      renderEvent,
      renderCc,
      renderInterrupt,
      renderMatchDetailNav
    });
  }
  return matchDetailViewToolsCache;
}

function soloShuffleLobbyPlayers(match = {}) {
  const tools = getMatchesViewTools();
  if (tools) return tools.soloShuffleLobbyPlayers(match);
  const fromRounds = soloShuffleRounds(match).flatMap((round) => [
    ...(Array.isArray(round.myComp) ? round.myComp : []),
    ...(Array.isArray(round.enemyComp) ? round.enemyComp : [])
  ]);
  const seen = new Set();
  const players = [];
  for (const name of [
    ...(Array.isArray(match.participants) ? match.participants : []),
    ...(Array.isArray(match.ownNames) ? match.ownNames : []),
    ...fromRounds
  ].filter(Boolean)) {
    const key = shortNameKey(name);
    if (!key || seen.has(key)) continue;
    seen.add(key);
    players.push(name);
  }
  return players.slice(0, 6);
}

function renderSoloShuffleLobbyPlayers(match) {
  const tools = getMatchesViewTools();
  if (tools) return tools.renderSoloShuffleLobbyPlayers(match);
  const players = soloShuffleLobbyPlayers(match);
  return `
    <div class="solo-lobby-player-card">
      <div class="solo-lobby-player-head"><span>Lobby players</span><small>${players.length || 0}/6 seen</small></div>
      <div class="solo-lobby-player-list">
        ${players.map((name) => `<span class="solo-lobby-player-pill">${coloredShortName(name, match)}</span>`).join('') || '<span class="muted">Players unknown</span>'}
      </div>
    </div>
  `;
}

function renderSoloShuffleInlineSummary(match) {
  const tools = getMatchesViewTools();
  if (tools) return tools.renderSoloShuffleInlineSummary(match);
  if (!isSoloShuffleLobbyUiMatch(match)) return '';
  const detected = Number(match.soloShuffleDetectedRoundCount || 0) || soloShuffleRounds(match).length;
  const status = `${detected} round${detected === 1 ? '' : 's'}${match.soloShuffleIncomplete ? ' · incomplete' : ''}`;
  return `
    <div class="solo-lobby-quick-summary">
      <div class="solo-lobby-quick-copy"><strong>${escapeHtml(soloShuffleSummaryText(match))}</strong><span>${escapeHtml(status)}</span></div>
      ${renderSoloShuffleRoundDots(match, false, 'compact')}
    </div>
  `;
}

function matchLibraryTeamArea(match) {
  const tools = getMatchesViewTools();
  if (tools) return tools.matchLibraryTeamArea(match);
  const scoreboard = matchScoreboardListButton(match);
  if (isSoloShuffleLobbyUiMatch(match)) {
    return `<div class="match-library-team-area solo-lobby-match-area">${renderSoloShuffleLobbyPlayers(match)}${renderSoloShuffleInlineSummary(match)}${scoreboard ? `<div class="match-team-inline-actions">${scoreboard}</div>` : ''}</div>`;
  }
  const teamArea = renderMatchTeams(match);
  return `<div class="match-library-team-area">${teamArea}${scoreboard ? `<div class="match-team-inline-actions">${scoreboard}</div>` : ''}</div>`;
}

function isFavoriteMatch(match) {
  return Boolean(match && (match.favorite || match.favorited));
}

let favoritesViewToolsCache = null;
function getFavoritesViewTools() {
  if (!favoritesViewToolsCache && window.LastCallFavoritesView && typeof window.LastCallFavoritesView.createFavoritesViewTools === 'function') {
    favoritesViewToolsCache = window.LastCallFavoritesView.createFavoritesViewTools({
      state,
      escapeHtml,
      isFavoriteMatch,
      visibleLibraryMatch,
      sortMatchesForLibrary,
      matchResolvedResult,
      resultToneForResult,
      pill,
      displayMatchType,
      matchTimestampLabel,
      coloredShortName
    });
  }
  return favoritesViewToolsCache;
}

function favoriteComment(match) {
  const tools = getFavoritesViewTools();
  return tools ? tools.favoriteComment(match) : String((match && (match.favoriteComment || match.userNotes || match.notes)) || '');
}

function favoriteFolderId(match) {
  const tools = getFavoritesViewTools();
  return tools ? tools.favoriteFolderId(match) : String((match && match.favoriteFolderId) || '');
}

function favoriteFolders() {
  const tools = getFavoritesViewTools();
  return tools ? tools.favoriteFolders() : (Array.isArray(state.favoriteFolders) ? state.favoriteFolders.filter((folder) => folder && folder.id && folder.name) : []);
}

function favoriteFolderName(folderId) {
  const tools = getFavoritesViewTools();
  if (tools) return tools.favoriteFolderName(folderId);
  if (!folderId) return 'Unsorted';
  const folder = favoriteFolders().find((item) => item.id === folderId);
  return folder ? folder.name : 'Unsorted';
}

function favoriteMark(match) {
  const tools = getFavoritesViewTools();
  if (tools) return tools.favoriteMark(match);
  if (!isFavoriteMatch(match)) return '';
  const folder = favoriteFolderName(favoriteFolderId(match));
  const comment = favoriteComment(match).trim();
  const title = [comment, folder].filter(Boolean).join(' · ') || 'Favorited';
  return `<span class="favorite-star" title="${escapeHtml(title)}" aria-label="Favorited">★</span>`;
}

function matchDataSourceLabels(match) {
  const labels = [];
  const sources = Array.isArray(match && match.dataSources) ? match.dataSources : [];
  if ((match && match.logOnlyDiscovery) || sources.includes('logOnlyDiscovery')) labels.push(['Log-only', 'amber']);
  else if ((match && match.createdFromRealLog) || sources.includes('combatLog')) labels.push(['Log', 'emerald']);
  if ((match && (match.addonScoreboard || match.createdFromAddon || (Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length))) || sources.includes('addonScoreboard')) labels.push(['Scoreboard', 'violet']);
  if (hasResultConflict(match)) labels.push(['Needs review', 'amber']);
  if (matchVideoPath(match) || sources.includes('video')) labels.push(['Video', 'cyan']);
  if (sources.includes('characterSnapshot')) labels.push(['Snapshot', 'amber']);
  return labels;
}

function renderDataSourcePills(match) {
  const labels = matchDataSourceLabels(match);
  if (!labels.length) return pill('Imported', 'amber');
  return labels.map(([label, tone]) => pill(label, tone)).join('');
}


function rosterColumnCount(names = []) {
  const count = Array.isArray(names) ? names.filter(Boolean).length : 0;
  if (count <= 5) return 1;
  return Math.max(2, Math.ceil(count / 5));
}

function renderTeamMemberList(names, match, fallback) {
  const list = Array.isArray(names) && names.length ? names.filter(Boolean) : [];
  if (!list.length) {
    return `<div class="team-member muted">${escapeHtml(fallback || 'Unknown team')}</div>`;
  }
  const columns = rosterColumnCount(list);
  const style = columns > 1 ? ` style="--roster-columns:${columns}"` : '';
  const extraClass = columns > 1 ? ' roster-columns' : '';
  return `<div class="team-member-list-inner${extraClass}"${style}>${list.map((name) => `<div class="team-member">${coloredName(name, match)}</div>`).join('')}</div>`;
}

function renderTeamBlock(label, names, match, fallback) {
  const count = Array.isArray(names) ? names.filter(Boolean).length : 0;
  const columns = rosterColumnCount(names);
  const columnNote = columns > 1 ? `<small>${count} players · columns of 5</small>` : '';
  return `
    <div class="match-team-block ${columns > 1 ? 'large-roster-team' : ''}" style="--roster-columns:${columns}">
      <span>${escapeHtml(label)}${columnNote}</span>
      <div class="team-member-list">${renderTeamMemberList(names, match, fallback)}</div>
    </div>
  `;
}

function renderMatchTeams(match) {
  const isShuffle = Boolean(match.isSoloShuffle) || /shuffle/i.test(normalizedMatchType(match));
  const activeRound = isSoloShuffleLobbyUiMatch(match) ? (soloShuffleRounds(match)[0] || null) : null;
  const friendlyNames = activeRound && activeRound.myComp && activeRound.myComp.length ? activeRound.myComp : (Array.isArray(match.myComp) && match.myComp.length ? match.myComp : (match.alt ? [match.alt] : []));
  const enemyNames = activeRound && activeRound.enemyComp && activeRound.enemyComp.length ? activeRound.enemyComp : (Array.isArray(match.enemyComp) && match.enemyComp.length ? match.enemyComp : []);
  const isLargeRoster = Math.max(friendlyNames.length, enemyNames.length) > 5;
  const leftLabel = isShuffle ? 'Your round team' : 'Your team';
  const rightLabel = isShuffle ? 'Opposing round team' : 'Enemy team';
  return `
    <div class="match-teams-grid ${isShuffle ? 'shuffle' : ''} ${isLargeRoster ? 'large-roster' : ''}">
      ${renderTeamBlock(leftLabel, friendlyNames, match, match.alt || 'Your team unknown')}
      <div class="match-vs-pill">${isShuffle ? 'Round' : 'vs'}</div>
      ${renderTeamBlock(rightLabel, enemyNames, match, 'Enemy team unknown')}
    </div>
  `;
}


let scoreboardViewToolsCache = null;
function getScoreboardViewTools() {
  if (!scoreboardViewToolsCache && window.LastCallScoreboardView && typeof window.LastCallScoreboardView.createScoreboardViewTools === 'function') {
    scoreboardViewToolsCache = window.LastCallScoreboardView.createScoreboardViewTools({
      state,
      escapeHtml,
      normalizedMatchType,
      shortNameKey,
      pvpHelperSyncHelpIcon,
      prettyNumber,
      classMetaForName,
      classMetaAcrossMatches,
      classColorByName,
      shortCharacterName,
      isBattlegroundMatch,
      pill,
      matchTimestampLabel,
      displayMatchType,
      selectedMatch,
      isFavoriteMatch
    });
  }
  return scoreboardViewToolsCache;
}

function matchScoreboardPlayers(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.matchScoreboardPlayers(match) : (Array.isArray(match && match.scoreboardPlayers) ? match.scoreboardPlayers.filter(Boolean) : []);
}

function hasLinkedScoreboard(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.hasLinkedScoreboard(match) : matchScoreboardPlayers(match).length > 0;
}

function isPendingScoreboardSnapshot(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.isPendingScoreboardSnapshot(match) : Boolean(match && match.createdFromAddon && !match.createdFromRealLog && hasLinkedScoreboard(match) && match.scoreboardLinkedToMatchId && !isFavoriteMatch(match));
}

function matchScoreboardAttachmentId(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.matchScoreboardAttachmentId(match) : String((match && match.id) || '');
}

function scoreboardCandidateScore(target, candidate) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardCandidateScore(target, candidate) : 0;
}

function scoreboardsAvailableToLink(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardsAvailableToLink(match) : [];
}

function scoreboardActionButtons(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardActionButtons(match) : '';
}

function playerIsSelectedToon(player, match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.playerIsSelectedToon(player, match) : false;
}

function scoreValue(player, field) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreValue(player, field) : '0';
}

function ratingValue(player) {
  const tools = getScoreboardViewTools();
  return tools ? tools.ratingValue(player) : '—';
}

function scoreboardPlayerClassColor(player, match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardPlayerClassColor(player, match) : '';
}

function scoreboardPlayerNameHtml(player, match) {
  const tools = getScoreboardViewTools();
  const name = player && (player.fullName || player.name) ? (player.fullName || player.name) : 'Unknown';
  return tools ? tools.scoreboardPlayerNameHtml(player, match) : `<span>${escapeHtml(shortCharacterName(name))}</span>`;
}

function scoreboardPlayerTeamKey(player) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardPlayerTeamKey(player) : 'unknown';
}

function scoreboardPlayerRelation(player, match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardPlayerRelation(player, match) : 'unknown';
}

function scoreboardTeamLabel(teamKey, rows, match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardTeamLabel(teamKey, rows, match) : 'Team unknown';
}

function scoreboardTeamTone(label) {
  const tools = getScoreboardViewTools();
  return tools ? tools.scoreboardTeamTone(label) : 'unknown';
}

function renderScoreboardTable(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.renderScoreboardTable(match) : '<div class="empty slim-empty">No final scoreboard is linked to this match yet.</div>';
}

function renderInlineScoreboardPanel(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.renderInlineScoreboardPanel(match) : '';
}

function renderScoreboardLinkRows(match) {
  const tools = getScoreboardViewTools();
  return tools ? tools.renderScoreboardLinkRows(match) : '';
}

function renderScoreboardModal() {
  const tools = getScoreboardViewTools();
  return tools ? tools.renderScoreboardModal() : '';
}

function renderMatchLibraryCard(match) {
  const tools = getMatchesViewTools();
  if (tools) return tools.renderMatchLibraryCard(match);
  const videoPath = matchVideoPath(match);
  const favoriteClass = isFavoriteMatch(match) ? ' favorite-video-thumb' : '';
  const favoriteTitle = isFavoriteMatch(match) ? ' title="Favorited match" aria-label="Favorited match video status"' : '';
  return `
    <button class="match-library-card ${resultCardClass(match)} ${isSoloShuffleLobbyUiMatch(match) ? 'solo-shuffle-lobby-card' : ''}" data-match="${escapeHtml(match.id)}">
      <div class="match-video-thumb ${videoPath ? 'has-video' : 'no-video'}${favoriteClass}"${favoriteTitle}>
        ${videoPath ? '<span>▶</span><small>Video</small>' : '<span>◇</span><small>No video</small>'}
      </div>
      <div class="match-library-main">
        <div class="match-library-meta">
          <div class="match-library-topline">
            <strong>${escapeHtml(matchClock(match) || 'Unknown time')}</strong>
            ${pill(displayMatchType(match), 'cyan')}
            ${matchTeamSizePill(match)}
          </div>
          <h3>${escapeHtml(match.map || 'Unknown map')}</h3>
        </div>
        ${matchLibraryTeamArea(match)}
      </div>
      <div class="match-library-side">
        <span>${escapeHtml(match.duration || '')}</span>
        ${matchDownloadClipButton(match)}
      </div>
    </button>
  `;
}

function renderMatchLibrary() {
  const allShown = filteredMatches();
  const visibleLimit = Math.max(20, Number(state.matchVisibleLimit || 80));
  const shown = allShown.slice(0, visibleLimit);
  const grouped = new Map();
  for (const match of shown) {
    const day = matchDay(match);
    if (!grouped.has(day)) grouped.set(day, []);
    grouped.get(day).push(match);
  }
  const groupHtml = Array.from(grouped.entries()).map(([day, matches]) => `
    <section class="match-library-day">
      <div class="match-library-day-head"><h3>${escapeHtml(day)}</h3><span>${matches.length} loaded${allShown.length !== shown.length ? ` · ${allShown.filter((match) => matchDay(match) === day).length} total` : ''}</span></div>
      <div class="match-library-list">${matches.map(renderMatchLibraryCard).join('')}</div>
    </section>
  `).join('');
  const refreshLabel = state.matchRefreshBusy ? 'Refreshing…' : 'Refresh';
  return `
    <div class="matches-home grid">
      <div class="card matches-list-header">
        <div class="card-title-row compact-match-history-head">
          <div><p class="small-label">Matches</p><h2>Match History</h2><p class="caption">Choose a game to open the replay, log data, meters, and health timeline. Long histories load in chunks so this page stays quick.</p></div>
          <div class="match-history-refresh-row"><button class="btn emerald" id="match-history-refresh" ${state.matchRefreshBusy ? 'disabled' : ''}>${refreshLabel}</button>${allShown.length ? pill(`${shown.length}/${allShown.length} shown`, 'cyan') : ''}</div>
        </div>
        ${renderMatchFilters()}
      </div>
      ${groupHtml || '<div class="card">' + renderNoDataBox() + '</div>'}
      ${renderLoadMoreButton('load-more-matches', shown.length, allShown.length, 'matches')}
    </div>
  `;
}

function visibleMatchNavigation(selectedId = state.selectedId) {
  const tools = getMatchesViewTools();
  if (tools) return tools.visibleMatchNavigation(selectedId);
  const list = filteredMatches();
  const index = list.findIndex((match) => String(match && match.id || '') === String(selectedId || ''));
  return { prev: index > 0 ? list[index - 1] : null, next: index >= 0 && index < list.length - 1 ? list[index + 1] : null, index: index >= 0 ? index + 1 : 0, total: list.length, list };
}

function renderMatchDetailNav(match) {
  const tools = getMatchesViewTools();
  if (tools) return tools.renderMatchDetailNav(match);
  const nav = visibleMatchNavigation(match && match.id);
  return `<div class="match-detail-nav-group"><button class="btn match-detail-nav-btn" data-match-nav="newer" ${nav.prev ? '' : 'disabled'} title="Next newer match">← Next</button><span class="match-detail-nav-count">${escapeHtml(nav.total ? `${nav.index}/${nav.total}` : '')}</span><button class="btn match-detail-nav-btn" data-match-nav="older" ${nav.next ? '' : 'disabled'} title="Previous older match">Previous →</button></div>`;
}

function navigateMatchDetail(direction = 'next') {
  const nav = visibleMatchNavigation(state.selectedId);
  const value = String(direction || 'next').toLowerCase();
  const target = value === 'newer' || value === 'next' || value === 'prev' ? nav.prev : nav.next;
  if (!target || !target.id) return;
  state.selectedId = target.id;
  state.selectedMetricActor = '';
  state.selectedMetricAbility = '';
  state.soloShuffleStatsMode = 'round';
  render();
  jumpPageToTop();
}

function renderMatchDetailPage() {
  const match = selectedMatch();
  const tools = getMatchDetailViewTools();
  if (tools) return tools.renderMatchDetailPage(match);
  return `
    <div class="grid review-page">
      <div class="match-detail-toolbar compact-match-detail-toolbar">
        <button class="btn" id="back-to-match-list">← All Matches</button>
        ${match ? renderMatchDetailNav(match) : ''}
        <div class="match-detail-spacer"></div>
        ${match ? `<button class="btn favorite-toggle ${isFavoriteMatch(match) ? 'active' : ''}" id="toggle-match-favorite">${isFavoriteMatch(match) ? '★ Favorited' : '☆ Favorite'}</button><button class="btn rose small-danger" id="delete-selected-match">Delete Match</button>` : ''}
      </div>
      ${renderMatchReport(match)}
    </div>
  `;
}

function renderMatches() {
  if (state.matchView === 'detail' && selectedMatch()) return renderMatchDetailPage();
  return renderMatchLibrary();
}

function favoriteFolderOptions(selectedId = '') {
  const tools = getFavoritesViewTools();
  return tools ? tools.favoriteFolderOptions(selectedId) : '<option value="">Unsorted</option>';
}

function favoriteMatches() {
  const tools = getFavoritesViewTools();
  return tools ? tools.favoriteMatches() : sortMatchesForLibrary((state.matches || []).filter((match) => isFavoriteMatch(match) && visibleLibraryMatch(match)));
}

function favoritesForSelectedFolder() {
  const tools = getFavoritesViewTools();
  if (tools) return tools.favoritesForSelectedFolder();
  const folderId = state.selectedFavoriteFolderId || 'all';
  const all = favoriteMatches();
  if (folderId === 'all') return all;
  if (folderId === 'unsorted') return all.filter((match) => !favoriteFolderId(match));
  return all.filter((match) => favoriteFolderId(match) === folderId);
}

function renderFavoriteFolderRail() {
  const tools = getFavoritesViewTools();
  return tools ? tools.renderFavoriteFolderRail() : '';
}

function renderFavoriteCard(match) {
  const tools = getFavoritesViewTools();
  return tools ? tools.renderFavoriteCard(match) : '';
}

function renderFavorites() {
  const tools = getFavoritesViewTools();
  if (tools) return tools.renderFavorites();
  const shown = favoritesForSelectedFolder();
  return `<div class="favorites-page grid"><div class="favorites-list">${shown.map(renderFavoriteCard).join('')}</div></div>`;
}



let metricViewToolsCache = null;
function getMetricViewTools() {
  if (!metricViewToolsCache) {
    if (!window.LastCallMetricsView || typeof window.LastCallMetricsView.createMetricsViewTools !== 'function') {
      throw new Error('Metrics view module failed to load.');
    }
    metricViewToolsCache = window.LastCallMetricsView.createMetricsViewTools({
      state,
      escapeHtml,
      prettyNumber,
      coloredName,
      coloredShortName,
      pill,
      formatElapsed,
      matchScoreboardPlayers,
      hasLinkedScoreboard,
      isBattlegroundMatch,
      selectedMatch,
      isSoloShuffleLobbyUiMatch,
      soloShuffleStatsMatch,
      isReplayFullVodMode
    });
  }
  return metricViewToolsCache;
}

function metricTabSections() { const tools = getMetricViewTools(); return tools ? tools.metricTabSections() : []; }
function metricTabs() { const tools = getMetricViewTools(); return tools ? tools.metricTabs() : []; }
function renderMetricTabSections(sectionFooter = '') { const tools = getMetricViewTools(); return tools ? tools.renderMetricTabSections(sectionFooter) : ''; }
function amountMetricNeedsTargetToggle() { const tools = getMetricViewTools(); return tools ? tools.amountMetricNeedsTargetToggle() : false; }
function scoreboardRowsForMatch(match, field, label = 'Final scoreboard total') { const tools = getMetricViewTools(); return tools ? tools.scoreboardRowsForMatch(match, field, label) : []; }
function metricUsesFinalScoreboard(match) { const tools = getMetricViewTools(); return tools ? tools.metricUsesFinalScoreboard(match) : false; }
function metricRowsForMatch(match) { const tools = getMetricViewTools(); return tools ? tools.metricRowsForMatch(match) : []; }
function rowsFromCcChainsFallback(match) { const tools = getMetricViewTools(); return tools ? tools.rowsFromCcChainsFallback(match) : []; }
function selectedMetricRow(rows) { const tools = getMetricViewTools(); return tools ? tools.selectedMetricRow(rows) : null; }
function selectedAbility(row) { const tools = getMetricViewTools(); return tools ? tools.selectedAbility(row) : null; }
function metricTitle() { const tools = getMetricViewTools(); return tools ? tools.metricTitle() : state.meter; }
function metricValueLabel(row) { const tools = getMetricViewTools(); return tools ? tools.metricValueLabel(row) : '0'; }
function renderMetricPanel(match) { const tools = getMetricViewTools(); return tools ? tools.renderMetricPanel(match) : ''; }
function abilityStatSummary(ability, isCount) { const tools = getMetricViewTools(); return tools ? tools.abilityStatSummary(ability, isCount) : ''; }
function targetRowsForAbility(ability) { const tools = getMetricViewTools(); return tools ? tools.targetRowsForAbility(ability) : []; }
function countMetricActionNoun() { const tools = getMetricViewTools(); return tools ? tools.countMetricActionNoun() : 'actions'; }
function countMetricTargetTitle() { const tools = getMetricViewTools(); return tools ? tools.countMetricTargetTitle() : 'Targets'; }
function countMetricEventLabel(event, ability) { const tools = getMetricViewTools(); return tools ? tools.countMetricEventLabel(event, ability) : ''; }
function renderDeathMetricHealthStrip(row) { const tools = getMetricViewTools(); return tools ? tools.renderDeathMetricHealthStrip(row) : ''; }
function renderMetricDetails(row, ability) { const tools = getMetricViewTools(); return tools ? tools.renderMetricDetails(row, ability) : ''; }
function renderAbilityCard(item, row, isActive, isCount, selectedTargetRow) { const tools = getMetricViewTools(); return tools ? tools.renderAbilityCard(item, row, isActive, isCount, selectedTargetRow) : ''; }
function renderMetricAbilityModal() { const tools = getMetricViewTools(); return tools ? tools.renderMetricAbilityModal() : ''; }
function renderMeterRow(row, index) { const tools = getMetricViewTools(); return tools ? tools.renderMeterRow(row, index) : ''; }
function renderEvent(event) { const tools = getMetricViewTools(); return tools ? tools.renderEvent(event) : ''; }
function renderCc(chain) { const tools = getMetricViewTools(); return tools ? tools.renderCc(chain) : ''; }
function renderInterrupt(item) { const tools = getMetricViewTools(); return tools ? tools.renderInterrupt(item) : ''; }
function renderDeath(death) { const tools = getMetricViewTools(); return tools ? tools.renderDeath(death) : ''; }

function clearRailFeedCache() {
  railFeedCache.clear();
}

function getRailCache(feedBox) {
  if (!feedBox) return { rows: [], times: [], activeIndices: new Set() };
  const childCount = feedBox.querySelectorAll('.feed-event[data-seek-time]').length;
  if (!feedBox.__railCache || feedBox.__railCache.childCount !== childCount) {
    const rows = Array.from(feedBox.querySelectorAll('.feed-event[data-seek-time]'));
    feedBox.__railCache = {
      childCount,
      rows,
      times: rows.map((row) => Number(row.dataset.seekTime || 0)),
      activeIndices: new Set()
    };
  }
  return feedBox.__railCache;
}

function railIndexForTime(times, current) {
  if (!times || !times.length) return -1;
  let lo = 0;
  let hi = times.length - 1;
  let ans = 0;
  while (lo <= hi) {
    const mid = Math.floor((lo + hi) / 2);
    if (Number(times[mid] || 0) <= current) {
      ans = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return ans;
}

function scheduleVideoRailUpdate(force = false) {
  if (force) {
    if (railUpdateRaf) cancelAnimationFrame(railUpdateRaf);
    if (railUpdateTimer) clearTimeout(railUpdateTimer);
    railUpdateRaf = null;
    railUpdateTimer = null;
    updateVideoEventRail(true);
    return;
  }
  const now = performance.now();
  const wait = Math.max(0, 120 - (now - lastRailUiUpdateMs));
  if (railUpdateRaf || railUpdateTimer) return;
  const run = () => {
    railUpdateTimer = null;
    railUpdateRaf = requestAnimationFrame(() => {
      railUpdateRaf = null;
      updateVideoEventRail(false);
    });
  };
  if (wait > 0) railUpdateTimer = setTimeout(run, wait);
  else run();
}

function groupRailFeed(events) {
  const grouped = [];
  const bucketMap = new Map();
  const stickyCategories = new Set(['match', 'death', 'interrupt', 'purge', 'dispel', 'ccdispel']);
  const rankCategory = (category) => ({ match: 9, death: 9, offense: 8, defense: 8, control: 7, interrupt: 7, purge: 7, ccdispel: 7, damage: 5, healing: 5, cast: 4, aura: 3 }[category] || 1);
  for (const ev of events || []) {
    const sec = Number(ev.relativeSec) || 0;
    const category = ev.category || 'other';
    if (stickyCategories.has(category)) {
      grouped.push({ ...ev, comboCount: 1, totalAmount: Number(ev.amount) || 0, critCount: ev.isCritical ? 1 : 0, groupedEvents: [ev], targets: [ev.target || 'Unknown'] });
      continue;
    }
    const bucket = Math.round(sec);
    const abilityKey = ev.ability || ev.event || 'Event';
    const key = `${bucket}|${ev.actor || 'Unknown'}|${abilityKey}`;
    const current = bucketMap.get(key);
    if (current) {
      current.comboCount += 1;
      current.totalAmount += Number(ev.amount) || 0;
      current.critCount += ev.isCritical ? 1 : 0;
      current.groupedEvents.push(ev);
      if ((Number(ev.importance) || 0) > (Number(current.importance) || 0)) current.importance = ev.importance;
      if (rankCategory(category) > rankCategory(current.category)) current.category = category;
      if (!current.targets.includes(ev.target || 'Unknown')) current.targets.push(ev.target || 'Unknown');
    } else {
      const copy = { ...ev, comboCount: 1, totalAmount: Number(ev.amount) || 0, critCount: ev.isCritical ? 1 : 0, groupedEvents: [ev], targets: [ev.target || 'Unknown'] };
      bucketMap.set(key, copy);
      grouped.push(copy);
    }
  }
  return grouped.sort((a, b) => (Number(a.relativeSec) || 0) - (Number(b.relativeSec) || 0) || (Number(b.importance) || 0) - (Number(a.importance) || 0));
}


function storedEventFeedCount(match = {}) {
  return Math.max(
    Array.isArray(match && match.eventFeed) ? match.eventFeed.length : 0,
    Array.isArray(match && match.rawEvents) ? match.rawEvents.length : 0,
    Number(match && match.eventFeedRows || 0),
    Number(match && match.eventFeedCachedRows || 0)
  );
}

function ensureMatchEventFeedLoaded(match) {
  if (!api || !api.getMatchEventFeed || !match || !match.id || !match.eventFeedCacheRef) return;
  const previewCount = Array.isArray(match.eventFeed) ? match.eventFeed.length : 0;
  const expected = Number(match.eventFeedRows || match.eventFeedCachedRows || 0) || 0;
  const roundNumber = match.isSoloShuffleLobbyContext && match.selectedRoundNumber ? Number(match.selectedRoundNumber) : 0;
  const loadingKey = [match.id, roundNumber || '', match.eventFeedCacheRef || ''].join('|');
  if (!expected || expected <= previewCount || match.eventFeedHydrated || state.eventFeedLoadingId === loadingKey) return;
  state.eventFeedLoadingId = loadingKey;
  api.getMatchEventFeed({ matchId: match.id, roundNumber }).then((result) => {
    if (!result || !result.ok || !Array.isArray(result.eventFeed)) return;
    const current = state.matches.find((item) => item && item.id === result.matchId);
    if (!current) return;
    if (result.roundNumber && Array.isArray(current.soloRounds)) {
      const round = current.soloRounds.find((item) => Number(item && item.roundNumber) === Number(result.roundNumber));
      if (!round) return;
      round.eventFeed = result.eventFeed;
      round.eventFeedRows = result.eventFeedRows || result.eventFeed.length;
      round.eventFeedCachedRows = round.eventFeedRows;
      round.eventFeedCacheRef = result.cacheRef || round.eventFeedCacheRef || '';
      round.eventFeedHydrated = true;
    } else {
      current.eventFeed = result.eventFeed;
      current.eventFeedRows = result.eventFeedRows || result.eventFeed.length;
      current.eventFeedCachedRows = current.eventFeedRows;
      current.eventFeedHydrated = true;
    }
    railFeedCache.clear();
    render();
  }).catch(() => {}).finally(() => {
    if (state.eventFeedLoadingId === loadingKey) state.eventFeedLoadingId = '';
  });
}

function railFeedForMatch(match) {
  if (!match) return [];
  ensureMatchEventFeedLoaded(match);
  const rawSource = Array.isArray(match.eventFeed) && match.eventFeed.length ? match.eventFeed : (Array.isArray(match.rawEvents) ? match.rawEvents : []);
  const rawLength = rawSource.length || 0;
  const cacheKey = [match.id || '', match.soloRoundContextKey || '', match.selectedRoundNumber || '', match.roundStartOffsetSec || '', match.roundEndOffsetSec || '', state.soloShuffleStatsMode || '', state.railFilter || 'Important', rawLength, match.updatedAt || match.importedAt || '', match.scoreboardLinkedAt || ''].join('|');
  if (railFeedCache.has(cacheKey)) return railFeedCache.get(cacheKey);
  if (railFeedCache.size > 12) railFeedCache.clear();

  const bg = isBattlegroundMatch(match);
  const rawLimit = bg ? 4000 : 6000;
  const raw = rawSource.slice(0, rawLimit);
  const seen = new Set();
  const deduped = [];
  for (const ev of raw) {
    const bucket = Math.round((Number(ev.relativeSec) || 0) * 2) / 2;
    const key = `${bucket}|${ev.category}|${ev.actor}|${ev.target}|${ev.ability}|${ev.amount || 0}|${ev.event || ''}`;
    if (seen.has(key)) continue;
    seen.add(key);
    deduped.push(ev);
  }
  const filtered = deduped.filter((ev) => {
    const cat = ev.category || 'other';
    if (state.railFilter === 'All') return true;
    if (state.railFilter === 'Important') {
      const eventText = `${ev.event || ''} ${ev.type || ''} ${ev.category || ''} ${ev.ability || ''}`.toLowerCase();
      return (Number(ev.importance) || 0) >= 5
        || ['match', 'death', 'offense', 'defense', 'control', 'interrupt', 'purge', 'dispel', 'ccdispel'].includes(cat)
        || /death|died|interrupt|kick|silence|stun|fear|polymorph|cyclone|trinket|dispell|dispel|purge|cooldown|defensive|offensive|cast_success/.test(eventText);
    }
    if (state.railFilter === 'Cooldowns') return ['offense', 'defense'].includes(cat);
    if (state.railFilter === 'CC + Kicks') return ['control', 'interrupt', 'purge', 'dispel', 'ccdispel'].includes(cat);
    if (state.railFilter === 'Damage + Healing') return ['damage', 'healing'].includes(cat);
    return true;
  });
  const rowLimit = bg ? (state.railFilter === 'All' ? 900 : 1200) : (state.railFilter === 'All' ? 1400 : 1800);
  const result = groupRailFeed(filtered).slice(0, rowLimit);
  railFeedCache.set(cacheKey, result);
  return result;
}

function renderNameList(names, match = selectedMatch()) {
  const list = (names || []).filter(Boolean);
  return list.length ? list.map((name) => coloredName(name, match)).join(' + ') : '';
}

function renderMatchButton(match) {
  const isActive = match.id === state.selectedId;
  const resolved = matchResolvedResult(match);
  const tone = resultToneForResult(resolved);
  return `
    <button class="match-row ${isActive ? 'active' : ''}" data-match="${escapeHtml(match.id)}">
      <div class="match-head">
        <div>
          <div class="tag-row">${pill(resolved, tone)}${hasResultConflict(match) ? pill('Needs review', 'amber') : ''}${pill(displayMatchType(match), 'cyan')}${pill(match.map)}</div>
          <p class="match-title">${renderNameList(match.myComp, match) || coloredName(match.alt || 'Unknown team', match)}</p>
          <p class="match-sub">${renderNameList(match.enemyComp, match) || 'Opponent team unknown'}</p>
        </div>
        <div class="match-meta"><span>${escapeHtml(match.date || '')}</span><span>${escapeHtml(match.time || '')}</span><strong>${escapeHtml(match.duration || '')}</strong></div>
      </div>
      <div class="tag-row" style="margin-top:12px">${displayMatchTags(match).slice(0, 4).map((tag) => pill(tag, 'violet')).join('')}</div>
    </button>
  `;
}

function renderSoloShuffleLobbyPanel(match) {
  const tools = getMatchDetailViewTools();
  if (tools) return tools.renderSoloShuffleLobbyPanel(match);
  return '';
}

function renderMatchReport(match) {
  const tools = getMatchDetailViewTools();
  if (tools) return tools.renderMatchReport(match);
  if (!match) return `<div class="card">${renderNoDataBox()}</div>`;
  return `
    <div class="grid">
      ${renderSyncedReplay(match)}
      ${renderMetricPanel(match)}
      ${renderInlineScoreboardPanel(match)}
    </div>
  `;
}


let replayViewToolsCache = null;
function getReplayViewTools() {
  if (!replayViewToolsCache && window.LastCallReplayView && typeof window.LastCallReplayView.createReplayViewTools === 'function') {
    replayViewToolsCache = window.LastCallReplayView.createReplayViewTools({
      state,
      filePathToUrl,
      isVideoSectionLink,
      replayScopeBoundsForMatch,
      videoSectionKindLabel,
      vodScopeLabel,
      exportFolderLabel,
      escapeHtml,
      formatElapsed,
      pill,
      displayFileName,
      railFeedForMatch,
      matchResolvedResult,
      resultToneForResult,
      matchTimestampLabel,
      displayMatchType,
      coloredName,
      renderDataSourcePills,
      isBattlegroundMatch,
      shortCharacterName,
      selectedMatch,
      renderKeepingReplay,
      prettyNumber,
      getRailCache,
      railIndexForTime,
      setLastRailUiUpdateMs: (value) => { lastRailUiUpdateMs = Number(value) || 0; },
      getLastRailAutoScrollAt: () => lastRailAutoScrollAt,
      setLastRailAutoScrollAt: (value) => { lastRailAutoScrollAt = Number(value) || -999; },
      setRailAutoScrollUntil: (value) => { railAutoScrollUntil = Number(value) || 0; }
    });
  }
  return replayViewToolsCache;
}

function renderSyncedReplay(match) { const tools = getReplayViewTools(); return tools ? tools.renderSyncedReplay(match) : ''; }
function healthTimelineModeForMatch(match) { const tools = getReplayViewTools(); return tools ? tools.healthTimelineModeForMatch(match) : (isBattlegroundMatch(match) ? 'deathWindow' : (state.player.healthTimelineMode === 'deathWindow' ? 'deathWindow' : 'match')); }
function healthDeathsForMatch(match) { const tools = getReplayViewTools(); return tools ? tools.healthDeathsForMatch(match) : []; }
function nextDeathWindowForMatch(match, currentMatchTime = 0, preferredDeathTime = null) { const tools = getReplayViewTools(); return tools ? tools.nextDeathWindowForMatch(match, currentMatchTime, preferredDeathTime) : null; }
function pointsForHealthWindow(points = [], start = 0, end = 10) { const tools = getReplayViewTools(); return tools ? tools.pointsForHealthWindow(points, start, end) : []; }
function healthMarkerPriority(point) { const tools = getReplayViewTools(); return tools ? tools.healthMarkerPriority(point) : 0; }
function clusterHealthMarkerPoints(points = [], spacingSec = 2.5) { const tools = getReplayViewTools(); return tools ? tools.clusterHealthMarkerPoints(points, spacingSec) : []; }
function healthWindowStats(points = []) { const tools = getReplayViewTools(); return tools ? tools.healthWindowStats(points) : { min: 100, max: 100, delta: 0 }; }
function maybeRefreshDeathWindowHealth(currentMatchTime) { const tools = getReplayViewTools(); if (tools) return tools.maybeRefreshDeathWindowHealth(currentMatchTime); }
function renderHealthTimeline(match) { const tools = getReplayViewTools(); return tools ? tools.renderHealthTimeline(match) : ''; }
function stopReplayHealthSyncLoop() { const tools = getReplayViewTools(); if (tools) return tools.stopReplayHealthSyncLoop(); }
function replayVideoTime(video = null) { const tools = getReplayViewTools(); return tools ? tools.replayVideoTime(video) : 0; }
function replayMatchTimeFromVideoTime(videoTime) { const tools = getReplayViewTools(); return tools ? tools.replayMatchTimeFromVideoTime(videoTime) : Math.max(0, Number(videoTime || 0) - (Number(state.player.syncOffsetSec) || 0)); }
function replayTransportBounds(match = selectedMatch(), video = null) { const tools = getReplayViewTools(); return tools ? tools.replayTransportBounds(match, video) : replayScopeBoundsForMatch(match, video); }
function updateReplayTransport(videoTime = null) { const tools = getReplayViewTools(); if (tools) return tools.updateReplayTransport(videoTime); }
function updateReplayAudioControls(video = document.getElementById('replay-video')) { const tools = getReplayViewTools(); if (tools) return tools.updateReplayAudioControls(video); }
function updateReplayClockAndHealth(videoTime = null) { const tools = getReplayViewTools(); return tools ? tools.updateReplayClockAndHealth(videoTime) : 0; }
function startReplayHealthSyncLoop() { const tools = getReplayViewTools(); if (tools) return tools.startReplayHealthSyncLoop(); }
function updateHealthTimelineCursor(current) { const tools = getReplayViewTools(); if (tools) return tools.updateHealthTimelineCursor(current); }
function renderFeedEvent(ev) { const tools = getReplayViewTools(); return tools ? tools.renderFeedEvent(ev) : ''; }
function updateVideoEventRail(force = false) { const tools = getReplayViewTools(); if (tools) return tools.updateVideoEventRail(force); }
function syncVideoToRailPosition(feedBox) { const tools = getReplayViewTools(); if (tools) return tools.syncVideoToRailPosition(feedBox); }


let cachedPlayerProfileTools = null;
function getPlayerProfileTools() {
  if (!cachedPlayerProfileTools) {
    if (!window.LastCallPlayerProfiles || typeof window.LastCallPlayerProfiles.createPlayerProfileTools !== 'function') {
      throw new Error('Player profile module failed to load.');
    }
    cachedPlayerProfileTools = window.LastCallPlayerProfiles.createPlayerProfileTools({
      matchScoreboardPlayers,
      namesShareEnemyIdentity,
      effectiveMatchType,
      isSoloShuffleLobbyUiMatch,
      matchTypeMatchesFilter,
      isSoloShuffleUiMatch,
      ownNameSetForMatch,
      enemyIdentityKey,
      shortCharacterName,
      soloShufflePlayerSeenKey,
      playerMeetingDedupeKey,
      soloShufflePlayerRoundKey,
      playerMeetingTimeMs,
      mergeMeetingMatch,
      isBattlegroundMatch
    });
  }
  return cachedPlayerProfileTools;
}

function buildPlayerProfiles() {
  return getPlayerProfileTools().buildPlayerProfiles(state);
}



let charactersViewToolsCache = null;
function getCharactersViewTools() {
  if (!charactersViewToolsCache) {
    if (!window.LastCallCharactersView || typeof window.LastCallCharactersView.createCharactersViewTools !== 'function') {
      throw new Error('Characters view module failed to load.');
    }
    charactersViewToolsCache = window.LastCallCharactersView.createCharactersViewTools({
      state,
      shortCharacterName,
      classMetaForName,
      playerMeetingDedupeKey,
      ownNameSetForMatch,
      effectiveMatchType,
      displayBracketLabel,
      escapeHtml,
      renderCharacterImportHelpCard,
      renderNoDataBox,
      rememberedSelectedCharacterKey,
      pvpHelperSyncHelpIcon,
      statCard,
      pill,
      displayMatchType,
      displayResult
    });
  }
  return charactersViewToolsCache;
}

function characterNameKey(value) { return getCharactersViewTools().characterNameKey(value); }
function dedupeCharacterSnapshots(list = []) { return getCharactersViewTools().dedupeCharacterSnapshots(list); }
function characterDisplayKey(name, spec) { return getCharactersViewTools().characterDisplayKey(name, spec); }
function characterPrettyName(key) { return getCharactersViewTools().characterPrettyName(key); }
function normalizeBracketForUi(value) { return getCharactersViewTools().normalizeBracketForUi(value); }
function isRatedCharacterRatingBracket(value) { return getCharactersViewTools().isRatedCharacterRatingBracket(value); }
function snapshotHasRatedRating(snap) { return getCharactersViewTools().snapshotHasRatedRating(snap); }
function snapshotCharacterKey(snapshot) { return getCharactersViewTools().snapshotCharacterKey(snapshot); }
function buildCharacterProfiles() { return getCharactersViewTools().buildCharacterProfiles(); }
function buildAllCharactersProfile(profiles = []) { return getCharactersViewTools().buildAllCharactersProfile(profiles); }
function characterBracketOptions(profile) { return getCharactersViewTools().characterBracketOptions(profile); }
function latestSnapshotFor(profile, bracket) { return getCharactersViewTools().latestSnapshotFor(profile, bracket); }
function timeframeStart(timeframe, now = Date.now()) { return getCharactersViewTools().timeframeStart(timeframe, now); }
function filteredCharacterMatches(profile, bracket = 'All', timeframe = 'Season') { return getCharactersViewTools().filteredCharacterMatches(profile, bracket, timeframe); }
function filteredCharacterSnapshots(profile, bracket = 'All', timeframe = 'Season') { return getCharactersViewTools().filteredCharacterSnapshots(profile, bracket, timeframe); }
function filteredRatedCharacterSnapshots(profile, bracket = 'All', timeframe = 'Season') { return getCharactersViewTools().filteredRatedCharacterSnapshots(profile, bracket, timeframe); }
function bestCurrentRatingSnapshot(profile, bracket = 'All') { return getCharactersViewTools().bestCurrentRatingSnapshot(profile, bracket); }
function characterNameHtml(profile) { return getCharactersViewTools().characterNameHtml(profile); }
function ratingAxisDateLabel(time) { return getCharactersViewTools().ratingAxisDateLabel(time); }
function ratingSpecLabel(snap) { return getCharactersViewTools().ratingSpecLabel(snap); }
function ratingSeriesKey(snap) { return getCharactersViewTools().ratingSeriesKey(snap); }
function ratingSeriesLabelFromKey(key) { return getCharactersViewTools().ratingSeriesLabelFromKey(key); }
function stableHash(text) { return getCharactersViewTools().stableHash(text); }
function ratingSeriesColor(key, index = 0) { return getCharactersViewTools().ratingSeriesColor(key, index); }
function ratingSeriesDash(key, index = 0) { return getCharactersViewTools().ratingSeriesDash(key, index); }
function renderRatingSparkline(profile, bracket, timeframe) { return getCharactersViewTools().renderRatingSparkline(profile, bracket, timeframe); }
function renderBracketStatCard(profile, bracket) { return getCharactersViewTools().renderBracketStatCard(profile, bracket); }
function renderCharacters() { return getCharactersViewTools().renderCharacters(); }


let playersViewToolsCache = null;
function getPlayersViewTools() {
  if (!playersViewToolsCache) {
    if (!window.LastCallPlayersView || typeof window.LastCallPlayersView.createPlayersViewTools !== 'function') {
      throw new Error('Players view module failed to load.');
    }
    playersViewToolsCache = window.LastCallPlayersView.createPlayersViewTools({
      state,
      buildPlayerProfiles,
      classMetaForName,
      classDisplayName,
      escapeHtml,
      shortCharacterName,
      renderNoDataBox,
      pill,
      renderFilterSelect,
      matchTypeOptions,
      displayMatchTypeLabel,
      displayMatchType,
      coloredShortName,
      playerMeetingDedupeKey,
      playerMeetingTimeMs,
      mergeMeetingMatch,
      matchResolvedResult,
      resultToneForResult,
      hasLinkedScoreboard,
      matchTimestampLabel,
      formatElapsed,
      isBattlegroundMatch
    });
  }
  return playersViewToolsCache;
}

function playerClassName(profile) { return getPlayersViewTools().playerClassName(profile); }
function renderPlayers() { return getPlayersViewTools().renderPlayers(); }
function renderPlayerMeetingsModal() { return getPlayersViewTools().renderPlayerMeetingsModal(); }


let playerMeetingToolsCache = null;
function getPlayerMeetingTools() {
  if (!playerMeetingToolsCache) {
    if (!window.LastCallPlayerMeetingHelpers || typeof window.LastCallPlayerMeetingHelpers.createPlayerMeetingTools !== 'function') {
      throw new Error('Player meeting helper module failed to load.');
    }
    playerMeetingToolsCache = window.LastCallPlayerMeetingHelpers.createPlayerMeetingTools({
      normalizedMapKey,
      effectiveMatchType,
      normalizedMatchType,
      enemyIdentityKey,
      characterNameKey,
      storedEventFeedCount
    });
  }
  return playerMeetingToolsCache;
}

function playerMeetingTimeMs(match) { return getPlayerMeetingTools().playerMeetingTimeMs(match); }
function playerMeetingDedupeKey(match, playerName = '') { return getPlayerMeetingTools().playerMeetingDedupeKey(match, playerName); }
function meetingDataScore(match) { return getPlayerMeetingTools().meetingDataScore(match); }
function mergeMeetingMatch(existing, incoming, relationship) { return getPlayerMeetingTools().mergeMeetingMatch(existing, incoming, relationship); }



let vodViewToolsCache = null;
function getVodViewTools() {
  if (!vodViewToolsCache && window.LastCallVodView && typeof window.LastCallVodView.createVodViewTools === 'function') {
    vodViewToolsCache = window.LastCallVodView.createVodViewTools({
      state,
      escapeHtml,
      formatElapsed,
      localDateTimeInputValue,
      filteredMatches,
      canonicalMatchTypeLabel,
      normalizedMatchType,
      isBattlegroundMatch,
      matchTimestampLabel,
      matchClock,
      displayMatchType,
      isSoloShuffleLobbyUiMatch,
      soloShuffleRounds,
      soloShuffleSummaryText,
      pill,
      renderLoadMoreButton
    });
  }
  return vodViewToolsCache;
}

function selectedVod() { const tools = getVodViewTools(); return tools ? tools.selectedVod() : null; }
function isAddonOnlyTimingMatch(match = {}) { const tools = getVodViewTools(); return tools ? tools.isAddonOnlyTimingMatch(match) : false; }
function estimatedAddonOnlyDurationSec(match = {}) { const tools = getVodViewTools(); return tools ? tools.estimatedAddonOnlyDurationSec(match) : 0; }
function matchDurationForDisplay(match = {}) { const tools = getVodViewTools(); return tools ? tools.matchDurationForDisplay(match) : (match.duration || formatElapsed(Number(match.durationSec || 0) || 0)); }
function matchRangeMsForVod(match = {}) { const tools = getVodViewTools(); return tools ? tools.matchRangeMsForVod(match) : { start: 0, gameStart: 0, end: 0, estimatedFromScoreboard: false }; }
function boundedMatchRangeMsForVod(match = {}, windowStart = 0, windowEnd = 0) { const tools = getVodViewTools(); return tools ? tools.boundedMatchRangeMsForVod(match, windowStart, windowEnd) : matchRangeMsForVod(match); }
function intervalsOverlapForVod(aStart, aEnd, bStart, bEnd) { const tools = getVodViewTools(); return tools ? tools.intervalsOverlapForVod(aStart, aEnd, bStart, bEnd) : false; }
function confidentVodMatchOverlap(vodStart, vodEnd, matchStart, matchEnd, bufferMs = 90000) { const tools = getVodViewTools(); return tools ? tools.confidentVodMatchOverlap(vodStart, vodEnd, matchStart, matchEnd, bufferMs) : false; }
function defaultVodPreRollSec(match = {}) { const tools = getVodViewTools(); return tools ? tools.defaultVodPreRollSec(match) : 45; }
function matchReplayStartMsForVod(match = {}, fallbackStart = 0) { const tools = getVodViewTools(); return tools ? tools.matchReplayStartMsForVod(match, fallbackStart) : Number(fallbackStart || 0); }
function isSoloShuffleVodMatch(match = {}) { const tools = getVodViewTools(); return tools ? tools.isSoloShuffleVodMatch(match) : false; }
function videoGroupRangeForVodMatch(match = {}) { const tools = getVodViewTools(); return tools ? tools.videoGroupRangeForVodMatch(match) : null; }
function formatDateTimeShort(ms) { const tools = getVodViewTools(); return tools ? tools.formatDateTimeShort(ms) : ''; }
function formatTimeOnly(ms) { const tools = getVodViewTools(); return tools ? tools.formatTimeOnly(ms) : ''; }
function vodRealTimeForClipSec(vod = {}, clipSec = 0) { const tools = getVodViewTools(); return tools ? tools.vodRealTimeForClipSec(vod, clipSec) : 0; }
function vodTimeSummary(vod = {}) { const tools = getVodViewTools(); return tools ? tools.vodTimeSummary(vod) : 'VOD start time is not set.'; }
function renderVodCandidateRow(candidate, vod) { const tools = getVodViewTools(); return tools ? tools.renderVodCandidateRow(candidate, vod) : ''; }
function vodCandidates(vod = selectedVod()) { const tools = getVodViewTools(); return tools ? tools.vodCandidates(vod) : []; }
function renderVodCard(vod) { const tools = getVodViewTools(); return tools ? tools.renderVodCard(vod) : ''; }
function sortedVodsForLibrary() { const tools = getVodViewTools(); return tools ? tools.sortedVodsForLibrary() : [...(state.vods || [])].filter(Boolean); }
function renderVodControls() { const tools = getVodViewTools(); return tools ? tools.renderVodControls() : ''; }


































let settingsViewToolsCache = null;
function getSettingsViewTools() {
  if (!settingsViewToolsCache && window.LastCallSettingsView && typeof window.LastCallSettingsView.createSettingsViewTools === 'function') {
    settingsViewToolsCache = window.LastCallSettingsView.createSettingsViewTools({
      state,
      escapeHtml,
      formatSyncDateTime,
      formatBytes,
      displayFileName,
      displayPathTail,
      latestCombatLogImport,
      latestPvPHelperImport,
      pvpHelperSyncHelpIcon,
      renderPvPHelperInstallStatusCard,
      renderPvPHelperMappingAssist,
      renderPvPHelperAddonStatus,
      renderLatestImportSummary,
      pathValueMarkup,
      exportFolderLabel,
      matchSortTime,
      matchVideoPath,
      isFavoriteMatch,
      recordingLinkedMatchIds,
      recordingTitleForItem,
      favoriteMark,
      matchTimestampLabel,
      displayMatchType,
      pill
    });
  }
  return settingsViewToolsCache;
}

function performanceStatusTone(value, warnAt = 1, dangerAt = Infinity) { const tools = getSettingsViewTools(); return tools ? tools.performanceStatusTone(value, warnAt, dangerAt) : 'emerald'; }
function renderImportJobStatusCard() { const tools = getSettingsViewTools(); return tools ? tools.renderImportJobStatusCard() : ''; }
function renderPerformanceAudit() { const tools = getSettingsViewTools(); return tools ? tools.renderPerformanceAudit() : ''; }
function settingsCategories() { const tools = getSettingsViewTools(); return tools ? tools.settingsCategories() : []; }
function renderSettingsCategoryTabs() { const tools = getSettingsViewTools(); return tools ? tools.renderSettingsCategoryTabs() : ''; }
function logTimeLabel(ms) { const tools = getSettingsViewTools(); return tools ? tools.logTimeLabel(ms) : 'Unknown'; }
function compactLogStatusText(value = '') { const tools = getSettingsViewTools(); return tools ? tools.compactLogStatusText(value) : 'Seen'; }
function logMonitorRows() { const tools = getSettingsViewTools(); return tools ? tools.logMonitorRows() : []; }
function renderLogMonitor() { const tools = getSettingsViewTools(); return tools ? tools.renderLogMonitor() : ''; }
function renderCombatLogsSettingsCard() { const tools = getSettingsViewTools(); return tools ? tools.renderCombatLogsSettingsCard() : ''; }
function renderPvPHelperSettingsCard() { const tools = getSettingsViewTools(); return tools ? tools.renderPvPHelperSettingsCard() : ''; }
function renderVideoFolderSettingsCard() { const tools = getSettingsViewTools(); return tools ? tools.renderVideoFolderSettingsCard() : ''; }
function matchHasCombatLogLink(match = {}) { const tools = getSettingsViewTools(); return tools ? tools.matchHasCombatLogLink(match) : false; }
function matchHasScoreboardLink(match = {}) { const tools = getSettingsViewTools(); return tools ? tools.matchHasScoreboardLink(match) : false; }
function auditTone(ok) { const tools = getSettingsViewTools(); return tools ? tools.auditTone(ok) : (ok ? 'emerald' : 'amber'); }
function renderConnectionsAuditSettingsCard() { const tools = getSettingsViewTools(); return tools ? tools.renderConnectionsAuditSettingsCard() : ''; }
function renderStorageSettingsCard() { const tools = getSettingsViewTools(); return tools ? tools.renderStorageSettingsCard() : ''; }
function renderSettings() { const tools = getSettingsViewTools(); return tools ? tools.renderSettings() : '<div class="card"><h2>Settings</h2><p class="caption">Settings module unavailable.</p></div>'; }



function captureReplaySnapshot() { return replayTimelineTools.captureReplaySnapshot(); }
function restoreReplaySnapshot(snapshot) { return replayTimelineTools.restoreReplaySnapshot(snapshot); }
function renderKeepingReplay() { return replayTimelineTools.renderKeepingReplay(); }

function refreshMetricAbilityModalOnly() {
  const existing = document.getElementById('metric-ability-scrim');
  const html = renderMetricAbilityModal();
  if (existing && !html) existing.remove();
  else if (existing && html) {
    const wrap = document.createElement('div');
    wrap.innerHTML = html.trim();
    existing.replaceWith(wrap.firstElementChild);
  } else if (html) {
    const appRoot = document.getElementById('app') || document.body;
    appRoot.insertAdjacentHTML('beforeend', html);
  }
}

function bindMetricPanelEvents() {
  document.querySelectorAll('[data-meter]').forEach((button) => button.addEventListener('click', () => {
    state.meter = button.dataset.meter;
    state.selectedMetricActor = '';
    state.selectedMetricAbility = '';
    renderMetricPanelOnly();
  }));
  document.querySelectorAll('[data-meter-target]').forEach((button) => button.addEventListener('click', () => {
    state.meterTargetFilter = button.dataset.meterTarget;
    state.selectedMetricActor = '';
    state.selectedMetricAbility = '';
    renderMetricPanelOnly();
  }));
  document.querySelectorAll('[data-meter-target-checkbox]').forEach((box) => box.addEventListener('change', () => {
    state.meterTargetFilter = box.checked ? 'Players' : 'All';
    state.selectedMetricActor = '';
    state.selectedMetricAbility = '';
    renderMetricPanelOnly();
  }));
  document.querySelectorAll('[data-meter-actor]').forEach((button) => button.addEventListener('click', () => {
    state.selectedMetricActor = button.dataset.meterActor;
    state.selectedMetricAbility = '';
    renderMetricPanelOnly();
  }));
  document.querySelectorAll('[data-ability-name]').forEach((button) => button.addEventListener('click', () => {
    const abilityName = button.dataset.abilityName || '';
    state.selectedMetricAbility = state.selectedMetricAbility === abilityName ? '' : abilityName;
    renderMetricPanelOnly();
  }));
  document.querySelectorAll('[data-close-metric-modal]').forEach((button) => button.addEventListener('click', () => {
    state.selectedMetricAbility = '';
    renderMetricPanelOnly();
  }));
  const metricScrim = document.getElementById('metric-ability-scrim');
  if (metricScrim) metricScrim.addEventListener('click', (event) => {
    if (event.target === metricScrim) {
      state.selectedMetricAbility = '';
      renderMetricPanelOnly();
    }
  });
}

function renderMetricPanelOnly() {
  const rawMatch = selectedMatch();
  const match = isSoloShuffleLobbyUiMatch(rawMatch) ? soloShuffleStatsMatch(rawMatch) : rawMatch;
  const current = document.querySelector('.metric-card');
  if (!match || !current) {
    renderKeepingReplay();
    return;
  }
  const wrap = document.createElement('div');
  wrap.innerHTML = renderMetricPanel(match).trim();
  const next = wrap.firstElementChild;
  if (!next) {
    renderKeepingReplay();
    return;
  }
  current.replaceWith(next);
  refreshMetricAbilityModalOnly();
  bindMetricPanelEvents();
}


const vodActionTools = (window.LastCallVodActions && window.LastCallVodActions.createVodActions)
  ? window.LastCallVodActions.createVodActions({
      state,
      api,
      selectedVod,
      applyBackendCollectionDeltas,
      render,
      isoFromLocalDateTimeInput,
      selectedMatch,
      isVideoSectionLink,
      replayScopeBoundsForMatch,
      formatElapsed,
      updateReplayClockAndHealth,
      updateVideoEventRail,
      renderKeepingReplay,
      alert: (message) => window.alert(message)
    })
  : null;
if (!vodActionTools) throw new Error('LastCallVodActions module failed to load.');

function importVodFile(payload = null) { return vodActionTools.importVodFile(payload); }
function vodPathsFromFiles(fileList) { return vodActionTools.vodPathsFromFiles(fileList); }
function vodPathsFromText(text = '') { return vodActionTools.vodPathsFromText(text); }
function importVodFilesFromDrop(fileList, source = 'drop') { return vodActionTools.importVodFilesFromDrop(fileList, source); }
function handleVodPaste(event) { return vodActionTools.handleVodPaste(event); }
function saveVodMeta(renderAfter = true) { return vodActionTools.saveVodMeta(renderAfter); }
function linkVodMatches(matchIds = null, options = {}) { return vodActionTools.linkVodMatches(matchIds, options); }
function deleteVod(vodId) { return vodActionTools.deleteVod(vodId); }
function editableClipBounds(match = selectedMatch()) { return vodActionTools.editableClipBounds(match); }
function seekReplayVideoToTrimTime(seconds) { return vodActionTools.seekReplayVideoToTrimTime(seconds); }
function enforceVodClipBounds(video, match = selectedMatch()) { return vodActionTools.enforceVodClipBounds(video, match); }
function exportFolderLabel() { return vodActionTools.exportFolderLabel(); }
function chooseExportFolder() { return vodActionTools.chooseExportFolder(); }
function exportVodClipByMatchId(matchId, options = {}) { return vodActionTools.exportVodClipByMatchId(matchId, options); }
function exportSelectedVodClip() { return vodActionTools.exportSelectedVodClip(); }
function seekReplayToClipStart(match = selectedMatch()) { return vodActionTools.seekReplayToClipStart(match); }
function saveMatchVideoSection(options = {}) { return vodActionTools.saveMatchVideoSection(options); }
function exportSelectedPartOfMatch() { return vodActionTools.exportSelectedPartOfMatch(); }
function setClipTrimBounds(minValue, maxValue) { return vodActionTools.setClipTrimBounds(minValue, maxValue); }
function setClipTrimMax(maxValue) { return vodActionTools.setClipTrimMax(maxValue); }
function updateClipTrimReadout(start, end) { return vodActionTools.updateClipTrimReadout(start, end); }
function syncClipTrimControls() { return vodActionTools.syncClipTrimControls(); }
function updateClipTrimMaxFromVideo(video) { return vodActionTools.updateClipTrimMaxFromVideo(video); }


const appEvents = (window.LastCallAppEvents && window.LastCallAppEvents.createAppEvents)
  ? window.LastCallAppEvents.createAppEvents({ state, api })
  : null;
if (!appEvents) throw new Error('LastCallAppEvents module failed to load.');

function bindEvents() {
  return appEvents.bindEvents();
}


async function refreshPvPHelperAddonInstallStatus(silent = false) {
  return setupActionTools.refreshPvPHelperAddonInstallStatus(silent);
}

async function installPvPHelperAddon() {
  return setupActionTools.installPvPHelperAddon();
}

async function handleTopbarAddonInstallClick() {
  return setupActionTools.handleTopbarAddonInstallClick();
}

function applyDesktopPayload(payload = {}) {
  return appStateManager.applyDesktopPayload(payload, appStateTools());
}

function applyImportJobStatus(payload = {}) {
  return appStateManager.applyImportJobStatus(payload);
}

const setupActionTools = (window.LastCallSetupActions && window.LastCallSetupActions.createSetupActions)
  ? window.LastCallSetupActions.createSetupActions({
    state,
    api,
    alert: window.alert.bind(window),
    confirm: window.confirm.bind(window),
    render,
    dashboardAddonStatusSummary,
    applyDesktopPayload,
    applyImportJobStatus,
    applyBackendCollectionDeltas,
    dedupeMatches,
    mergeBackendMatches,
    clearRailFeedCache,
    dedupeCharacterSnapshots,
    sortMatchesForLibrary,
    selectedMatch,
    isPendingScoreboardSnapshot,
    scanRecordingsFolder,
    validRecorderPerformanceMode
  })
  : null;
if (!setupActionTools) throw new Error('LastCallSetupActions module failed to load.');

recordingActionTools = (window.LastCallRecordingActions && window.LastCallRecordingActions.createRecordingActions)
  ? window.LastCallRecordingActions.createRecordingActions({
    state,
    api,
    alert: window.alert.bind(window),
    confirm: window.confirm.bind(window),
    render,
    renderKeepingReplay,
    selectedMatch,
    applyBackendCollectionDeltas,
    applyImportJobStatus,
    recordingSessionVodFor,
    recordingTitleForItem,
    vodSuggestedStart,
    linkVodMatches,
    recordingInWindowMatchIds,
    openRecorderSetupFromDashboard,
    formatElapsed,
    allowedCaptureSources,
    sourceSort,
    preferredWowSource,
    isSourceApproved,
    captureSourceKind,
    sourceLooksLikeWow,
    recorderPerformanceProfile,
    recorderChunkMs,
    saveRecorderSettings
  })
  : null;
if (!recordingActionTools) throw new Error('LastCallRecordingActions module failed to load.');


async function autoConnectLocalSetup() {
  return setupActionTools.autoConnectLocalSetup();
}

async function useDefaultRecordingsFolder() {
  return setupActionTools.useDefaultRecordingsFolder();
}

async function useDetectedLogFile() {
  return setupActionTools.useDetectedLogFile();
}

async function pickAndWatchFile() {
  return setupActionTools.pickAndWatchFile();
}

async function pickAndWatchFolder() {
  return setupActionTools.pickAndWatchFolder();
}

async function importOldLog() {
  return setupActionTools.importOldLog();
}


async function linkVideoToSelectedMatch() { return recordingActionTools.linkVideoToSelectedMatch(); }

async function unlinkVideoFromSelectedMatch() { return recordingActionTools.unlinkVideoFromSelectedMatch(); }

async function unlinkRecording(recordingId) { return recordingActionTools.unlinkRecording(recordingId); }

async function deleteRecording(recordingId, deleteFile) { return recordingActionTools.deleteRecording(recordingId, deleteFile); }

async function deleteSelectedRecordings(deleteFiles) { return recordingActionTools.deleteSelectedRecordings(deleteFiles); }


favoriteActionTools = (window.LastCallFavoritesActions && window.LastCallFavoritesActions.createFavoritesActions)
  ? window.LastCallFavoritesActions.createFavoritesActions({
    state,
    api,
    alert: window.alert.bind(window),
    confirm: window.confirm.bind(window),
    render,
    renderKeepingReplay,
    selectedMatch,
    isFavoriteMatch,
    favoriteFolders,
    favoriteMatches,
    favoriteFolderId,
    applyBackendCollectionDeltas
  })
  : null;
if (!favoriteActionTools) throw new Error('LastCallFavoritesActions module failed to load.');

async function updateFavoriteMeta(matchId, updates = {}) { return favoriteActionTools.updateFavoriteMeta(matchId, updates); }

async function createFavoriteFolderPrompt() { return favoriteActionTools.createFavoriteFolderPrompt(); }

async function deleteFavoriteFolder(folderId) { return favoriteActionTools.deleteFavoriteFolder(folderId); }

async function toggleSelectedMatchFavorite() { return favoriteActionTools.toggleSelectedMatchFavorite(); }

async function linkScoreboardToSelectedMatch(scoreboardMatchId) {
  const match = selectedMatch();
  if (!match || !scoreboardMatchId) return;
  if (!api || !api.linkScoreboardToMatch) return alert('Linking scoreboards is only available in the desktop app.');
  const result = await api.linkScoreboardToMatch({ matchId: match.id, scoreboardMatchId });
  if (!result || !result.ok) return alert((result && result.reason) || 'Could not link that scoreboard.');
  applyBackendCollectionDeltas(result || {});
  state.matches = result.matches || state.matches;
  state.selectedId = match.id;
  state.scoreboardModalMode = 'view';
  renderKeepingReplay();
}

async function enterReplayFullscreen() {
  const frame = document.querySelector('.video-frame');
  const video = document.getElementById('replay-video');
  const target = frame || video;
  if (!target) return;
  try {
    if (document.fullscreenElement) {
      await document.exitFullscreen();
      return;
    }
    const request = target.requestFullscreen || target.webkitRequestFullscreen || target.msRequestFullscreen;
    if (request) await request.call(target);
    else if (video && video.webkitEnterFullscreen) video.webkitEnterFullscreen();
    else alert('Fullscreen is not available for this video on this system.');
  } catch (error) {
    alert(`Fullscreen failed: ${error && error.message ? error.message : error}`);
  }
}

async function deleteSelectedMatch() {
  if (!api || !api.deleteMatch) return alert('Deleting matches is only available in the desktop app.');
  const match = selectedMatch();
  if (!match) return;
  if (isFavoriteMatch(match)) return alert('Favorite matches are protected. Unfavorite this match before deleting it.');
  if (!confirm(`Delete match ${match.map || 'selected match'} from the library?`)) return;
  const result = await api.deleteMatch({ matchId: match.id });
  if (!result || !result.ok) return alert((result && result.reason) || 'Could not delete match.');
  applyBackendCollectionDeltas(result || {});
  state.matches = result.matches || state.matches.filter((item) => item.id !== match.id);
  state.recorder.recordings = result.recordings || state.recorder.recordings.map((rec) => rec.matchId === match.id ? { ...rec, matchId: '' } : rec);
  state.selectedId = state.matches[0] ? state.matches[0].id : null;
  state.player.videoPath = '';
  state.player.matchId = '';
  render();
}

async function hidePlayer(playerName) {
  if (!playerName) return;
  if (!confirm(`Hide ${shortCharacterName(playerName)} from the Players tab?`)) return;
  if (api && api.hidePlayer) {
    const result = await api.hidePlayer({ playerName });
    if (result && result.hiddenPlayers) state.hiddenPlayers = result.hiddenPlayers;
  } else {
    state.hiddenPlayers = Array.from(new Set([...(state.hiddenPlayers || []), playerName]));
  }
  render();
}





function applyPvPHelperImportResult(result) {
  return setupActionTools.applyPvPHelperImportResult(result);
}

function pvpHelperImportMessage(result, prefix = 'Synced PvPHelper.lua') {
  return setupActionTools.pvpHelperImportMessage(result, prefix);
}

async function refreshPvPHelperSavedVariablesDiscovery(renderAfter = true) {
  return setupActionTools.refreshPvPHelperSavedVariablesDiscovery(renderAfter);
}

async function autoPreviewPvPHelperSavedVariables() {
  return setupActionTools.autoPreviewPvPHelperSavedVariables();
}

async function importPvPHelperSavedVariables() {
  return setupActionTools.importPvPHelperSavedVariables();
}

async function applyPvPHelperImportPreview() {
  return setupActionTools.applyPvPHelperImportPreview();
}

async function syncMappedPvPHelperSavedVariables(options = {}) {
  return setupActionTools.syncMappedPvPHelperSavedVariables(options);
}

async function clearPvPHelperSavedVariablesMapping() {
  return setupActionTools.clearPvPHelperSavedVariablesMapping();
}

async function updatePvPHelperAutoSync(enabled) {
  return setupActionTools.updatePvPHelperAutoSync(enabled);
}

async function importCharacterSnapshot() {
  return setupActionTools.importCharacterSnapshot();
}

async function deleteCharacterSnapshot(snapshotId) {
  return setupActionTools.deleteCharacterSnapshot(snapshotId);
}

async function dedupeRecordingHistory() {
  return setupActionTools.dedupeRecordingHistory();
}

async function chooseRecordingsFolder() {
  return setupActionTools.chooseRecordingsFolder();
}

async function syncLogsForSelectedMatch() {
  return setupActionTools.syncLogsForSelectedMatch();
}

async function repairMissingLogs() {
  return setupActionTools.repairMissingLogs();
}

async function scanLogsFolder() {
  return setupActionTools.scanLogsFolder();
}

async function syncActiveLogSilently(options = {}) {
  return setupActionTools.syncActiveLogSilently(options);
}


async function scanRecordingsFolder(options = {}) { return recordingActionTools.scanRecordingsFolder(options); }

async function applyRecordingSuggestedMatches(recordingId, matchIds = [], options = {}) { return recordingActionTools.applyRecordingSuggestedMatches(recordingId, matchIds, options); }

async function applyRecordingSuggestedMatch(recordingId, matchId) { return recordingActionTools.applyRecordingSuggestedMatch(recordingId, matchId); }

async function attachSelectedRecordingsInWindow() { return recordingActionTools.attachSelectedRecordingsInWindow(); }

function adjustSyncOffset(delta) {
  state.player.syncOffsetSec = Math.max(-300, Math.min(300, (Number(state.player.syncOffsetSec) || 0) + Number(delta || 0)));
  const input = document.getElementById('sync-offset-input');
  if (input) input.value = Number(state.player.syncOffsetSec || 0).toFixed(1);
  updateVideoEventRail();
}

async function chooseArchiveFolder() {
  return setupActionTools.chooseArchiveFolder();
}

function finishStorageChange(result, title) {
  return setupActionTools.finishStorageChange(result, title);
}

async function chooseAppStorageFolder() {
  return setupActionTools.chooseAppStorageFolder();
}

async function enablePortableAppStorage() {
  return setupActionTools.enablePortableAppStorage();
}

async function connectAppStorageFolder() {
  return setupActionTools.connectAppStorageFolder();
}

async function createStateBackupNow() {
  return setupActionTools.createStateBackupNow();
}

async function repairLibraryConnections() {
  return setupActionTools.repairLibraryConnections();
}

async function compactLocalState() {
  return setupActionTools.compactLocalState();
}

async function saveGeneralSettingsFromForm() {
  return setupActionTools.saveGeneralSettingsFromForm();
}

async function checkForUpdates() {
  return setupActionTools.checkForUpdates();
}

async function openUpdateReleasePage() {
  return setupActionTools.openUpdateReleasePage();
}

async function openUpdateDownloadUrl(url = '') {
  return setupActionTools.openUpdateDownloadUrl(url);
}

async function saveRecorderSettings() {
  return setupActionTools.saveRecorderSettings();
}


async function refreshCaptureSources() { return recordingActionTools.refreshCaptureSources(); }

async function selectCaptureSource(sourceId, sourceName, shouldRender = true, approved = true, approvalRequired = false, sourceKind = '') { return recordingActionTools.selectCaptureSource(sourceId, sourceName, shouldRender, approved, approvalRequired, sourceKind); }

async function applyCapturePreferences(stream) { return recordingActionTools.applyCapturePreferences(stream); }

async function getSelectedCaptureStream() { return recordingActionTools.getSelectedCaptureStream(); }

function captureErrorMessage(error) { return recordingActionTools.captureErrorMessage(error); }

function chooseMimeType() { return recordingActionTools.chooseMimeType(); }

function createMediaRecorder(stream, mimeType) { return recordingActionTools.createMediaRecorder(stream, mimeType); }

async function startRecording() { return recordingActionTools.startRecording(); }

async function stopRecording(reason) { return recordingActionTools.stopRecording(reason); }

async function boot() {
  state.watchStatus = 'Loading saved library';
  state.performanceProgress = { label: 'Starting Last Call Replay', status: 'loading', progress: { detail: 'Loading saved library', percent: 6 }, updatedAt: new Date().toISOString() };
  render();
  if (api) {
    try {
      const saved = await api.getState();
      const bootPayload = appStateManager.applySavedState(saved || {}, appStateTools());
      state.watchStatus = bootPayload.hasLogCandidate ? 'Log ready' : 'Ready';
      state.performanceProgress = null;
      render();
      if (api.getStartupDiagnostics) {
        window.setTimeout(async () => {
          try {
            const diagnostics = await api.getStartupDiagnostics();
            if (diagnostics && diagnostics.ok !== false) {
              appStateManager.applyStartupDiagnostics(diagnostics || {});
              render();
            }
          } catch (error) {
            console.warn('[Last Call Replay] Deferred startup diagnostics failed.', error);
          }
        }, 2600);
      }
      window.setTimeout(() => {
        refreshPvPHelperAddonInstallStatus(true).then(() => render()).catch(() => {});
      }, 1300);
      const firstCandidate = state.settings.logFilePath || state.defaultLogCandidates[0];
      if (state.settings.pvpHelperSavedVariablesPath && state.settings.pvpHelperAutoSync !== false && api.syncMappedPvPHelperSavedVariables) {
        window.setTimeout(() => {
          syncMappedPvPHelperSavedVariables({ force: false, silent: true }).catch((error) => console.warn('[Last Call Replay] PvPHelper auto-sync failed.', error));
        }, 2200);
      }
      if (firstCandidate) {
        state.watchPath = firstCandidate;
        state.watchStatus = 'Opening fast. Log catch-up queued.';
        state.performanceProgress = { label: 'Startup log catch-up', status: 'queued', progress: { detail: 'Watching the active log without deep scanning old files', percent: 18 }, updatedAt: new Date().toISOString() };
        render();
        window.setTimeout(async () => {
          try {
            const firstWatch = await api.watchLogFile(state.settings.logFilePath || firstCandidate);
            state.watchPath = firstWatch && firstWatch.filePath ? firstWatch.filePath : (state.settings.logFilePath || firstCandidate);
            if (firstWatch && firstWatch.folderPath) state.settings.logFolderPath = firstWatch.folderPath;
            state.settings.logFilePath = state.watchPath;
            state.watchStatus = 'Watching logs. Light catch-up starting.';
            render();

            window.setTimeout(async () => {
              try {
                const catchUp = await syncActiveLogSilently({ startupLight: true });
                const watchTarget = (catchUp && catchUp.watchFile) || state.settings.logFilePath || state.watchPath || firstCandidate;
                if (watchTarget && watchTarget !== state.watchPath) {
                  const status = await api.watchLogFile(watchTarget);
                  state.watchPath = status && status.filePath ? status.filePath : watchTarget;
                  if (status && status.folderPath) state.settings.logFolderPath = status.folderPath;
                  state.settings.logFilePath = state.watchPath;
                }
                state.watchStatus = catchUp && catchUp.imported
                  ? `Startup catch-up found ${catchUp.imported} match${catchUp.imported === 1 ? '' : 'es'}`
                  : 'Watching logs. Use Sync Active Log for deeper catch-up.';
                await refreshPvPHelperAddonInstallStatus(true);
                render();
              } catch (catchUpError) {
                console.warn('[Last Call Replay] Startup light catch-up failed.', catchUpError);
                state.watchStatus = 'Watching logs. Startup catch-up skipped safely.';
                render();
              }
            }, 2400);
          } catch (error) {
            console.warn('[Last Call Replay] Could not auto-watch log file.', error);
          }
        }, 500);
      }
      if (api.onImportJobStatus) {
        api.onImportJobStatus((payload) => {
          updatePerformanceProgressFromJob(payload || {});
          renderPerformanceProgressOnly();
        });
      }
      api.onWatcherStatus((payload) => {
        state.watchStatus = (payload.state && String(payload.state).includes('missing')) ? 'Log file missing' : 'Watching logs';
        state.watchPath = payload.filePath || state.watchPath;
        renderPerformanceProgressOnly();
        scheduleRender(140);
      });
      api.onWatcherChunk((payload) => {
        if (payload && (Array.isArray(payload.changedMatches) || Array.isArray(payload.removedMatchIds))) {
          applyBackendCollectionDeltas(payload);
        } else {
          addMatches(payload.matches || []);
        }
        state.watchStatus = payload.hasMoreTail ? `Read ${payload.bytes || 0} bytes, more queued` : `Read ${payload.bytes || 0} bytes`;
        state.watchPath = payload.filePath || state.watchPath;
        state.performanceProgress = {
          label: payload.strategy ? `Log sync · ${payload.strategy}` : 'Log sync',
          status: payload.hasMoreTail ? 'running' : 'complete',
          progress: { detail: state.watchStatus, percent: payload.hasMoreTail ? 50 : 100 },
          updatedAt: new Date().toISOString()
        };
        renderPerformanceProgressOnly();
        scheduleRender(payload.hasMoreTail ? 160 : 90);
      });
    } catch (error) {
      console.error(error);
    }
  }
  render();
  if (api && api.listCaptureSources) {
    window.setTimeout(() => {
      refreshCaptureSources().catch((error) => console.warn('[Last Call Replay] Startup source scan failed.', error));
    }, 3200);
  }
}

window.addEventListener('resize', scheduleReplayPanelHeightSync);
window.setInterval(() => {
  const active = state.importJobStatus && state.importJobStatus.active ? state.importJobStatus.active : null;
  if (active && !progressOverlayDismissedJobs.has(String(active.id || ''))) renderPerformanceProgressOnly();
}, 10000);

boot();
