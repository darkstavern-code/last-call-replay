(function () {
  'use strict';

  function createSearchViewTools(deps = {}) {
    if (!deps || !deps.state) throw new Error('LastCallSearchView requires app state.');

    const state = deps.state;
    const escapeHtml = deps.escapeHtml || ((value) => String(value ?? ''));
    const matchDay = deps.matchDay || (() => 'Unknown day');
    const effectiveMatchType = deps.effectiveMatchType || ((match) => (match && (match.matchType || match.bracket)) || 'PvP Match');
    const normalizedMatchType = deps.normalizedMatchType || ((match) => (match && (match.matchType || match.bracket)) || 'PvP Match');
    const matchScoreboardPlayers = deps.matchScoreboardPlayers || (() => []);
    const isPendingScoreboardSnapshot = deps.isPendingScoreboardSnapshot || (() => false);
    const visibleLibraryMatch = deps.visibleLibraryMatch || ((match) => Boolean(match));
    const resultMatchesFilter = deps.resultMatchesFilter || (() => true);
    const matchTypeMatchesFilter = deps.matchTypeMatchesFilter || (() => true);
    const displayMatchTypeLabel = deps.displayMatchTypeLabel || ((value) => String(value || ''));
    const isFavoriteMatch = deps.isFavoriteMatch || (() => false);
    const displayResult = deps.displayResult || ((value) => String(value || 'Unscored'));
    const matchSortTime = deps.matchSortTime || (() => 0);
    const render = typeof deps.render === 'function' ? deps.render : (() => {});

    let globalSearchRenderTimer = null;
    let pendingGlobalSearchCaret = null;

    function uniqueValues(values = []) {
      return Array.from(new Set((values || []).filter(Boolean))).sort((a, b) => String(a).localeCompare(String(b)));
    }

    function toonOptions() {
      return uniqueValues((state.matches || []).map((match) => match && match.alt).filter(Boolean));
    }

    function dayOptions() {
      return uniqueValues((state.matches || []).map(matchDay));
    }

    function matchTypeOptions() {
      return uniqueValues((state.matches || [])
        .filter((match) => !isPendingScoreboardSnapshot(match))
        .map(effectiveMatchType));
    }

    function classDisplayName(value = '') {
      const raw = String(value || '').trim();
      if (!raw) return '';
      const known = {
        DEATHKNIGHT: 'Death Knight',
        DEMONHUNTER: 'Demon Hunter',
        WARRIOR: 'Warrior',
        PALADIN: 'Paladin',
        HUNTER: 'Hunter',
        ROGUE: 'Rogue',
        PRIEST: 'Priest',
        SHAMAN: 'Shaman',
        MAGE: 'Mage',
        WARLOCK: 'Warlock',
        MONK: 'Monk',
        DRUID: 'Druid',
        EVOKER: 'Evoker'
      };
      const key = raw.replace(/[^A-Za-z]/g, '').toUpperCase();
      if (known[key]) return known[key];
      return raw
        .replace(/_/g, ' ')
        .toLowerCase()
        .replace(/\b\w/g, (char) => char.toUpperCase());
    }

    function matchClassLabels(match) {
      const labels = new Map();
      const add = (value) => {
        const label = classDisplayName(value);
        if (!label) return;
        labels.set(label.toLowerCase(), label);
      };
      Object.values((match && match.classByName) || {}).forEach((meta) => {
        if (!meta) return;
        add(meta.className || meta.classFile);
      });
      matchScoreboardPlayers(match).forEach((player) => add(player.className || player.classFile));
      return Array.from(labels.values()).sort((a, b) => a.localeCompare(b));
    }

    function matchClassOptions() {
      const labels = new Map();
      (state.matches || []).forEach((match) => matchClassLabels(match).forEach((label) => labels.set(label.toLowerCase(), label)));
      return Array.from(labels.values()).sort((a, b) => a.localeCompare(b));
    }

    function matchHasClass(match, classLabel) {
      if (!classLabel || classLabel === 'All') return true;
      const target = String(classLabel || '').toLowerCase();
      return matchClassLabels(match).some((label) => String(label || '').toLowerCase() === target);
    }

    function matchSortLabel(value = state.matchSort) {
      return ({
        newest: 'Newest first',
        oldest: 'Oldest first',
        favorites: 'Favorites first',
        map: 'Map A-Z',
        toon: 'Toon A-Z',
        result: 'Result'
      })[value] || 'Newest first';
    }

    function sortMatchesForLibrary(matches = []) {
      const resultRank = { Win: 0, Loss: 1, Parsed: 2, Unscored: 2 };
      const byNewest = (a, b) => matchSortTime(b) - matchSortTime(a) || String(b && b.id || '').localeCompare(String(a && a.id || ''));
      const safeText = (value) => String(value || '').toLowerCase();
      return (matches || []).slice().sort((a, b) => {
        if (state.matchSort === 'oldest') return matchSortTime(a) - matchSortTime(b) || String(a && a.id || '').localeCompare(String(b && b.id || ''));
        if (state.matchSort === 'favorites') return Number(isFavoriteMatch(b)) - Number(isFavoriteMatch(a)) || byNewest(a, b);
        if (state.matchSort === 'map') return safeText(a && a.map).localeCompare(safeText(b && b.map)) || byNewest(a, b);
        if (state.matchSort === 'toon') return safeText(a && a.alt).localeCompare(safeText(b && b.alt)) || byNewest(a, b);
        if (state.matchSort === 'result') return (resultRank[displayResult(a && a.result)] ?? 9) - (resultRank[displayResult(b && b.result)] ?? 9) || byNewest(a, b);
        return byNewest(a, b);
      });
    }

    function filteredMatches() {
      const needle = String(state.query || '').trim().toLowerCase();
      const matches = (state.matches || []).filter((match) => {
        if (!visibleLibraryMatch(match)) return false;
        const resultOkay = resultMatchesFilter(match);
        const toonOkay = state.toonFilter === 'All' || match.alt === state.toonFilter;
        const dayOkay = state.dayFilter === 'All' || matchDay(match) === state.dayFilter;
        const typeOkay = matchTypeMatchesFilter(match, state.matchTypeFilter);
        const classOkay = matchHasClass(match, state.matchClassFilter);
        const haystack = [
          match.map,
          match.alt,
          effectiveMatchType(match),
          normalizedMatchType(match),
          match.bracket,
          (match.myComp || []).join(' '),
          (match.enemyComp || []).join(' '),
          (match.participants || []).join(' '),
          (match.enemies || []).join(' '),
          matchClassLabels(match).join(' '),
          (match.tags || []).join(' ')
        ].join(' ').toLowerCase();
        return resultOkay && toonOkay && dayOkay && typeOkay && classOkay && (!needle || haystack.includes(needle));
      });
      return sortMatchesForLibrary(matches);
    }

    function rememberGlobalSearchCaret(input) {
      if (!input) return;
      pendingGlobalSearchCaret = {
        value: input.value || '',
        start: Number.isFinite(input.selectionStart) ? input.selectionStart : String(input.value || '').length,
        end: Number.isFinite(input.selectionEnd) ? input.selectionEnd : String(input.value || '').length
      };
    }

    function restoreGlobalSearchCaret() {
      if (!pendingGlobalSearchCaret) return;
      const caret = pendingGlobalSearchCaret;
      pendingGlobalSearchCaret = null;
      window.requestAnimationFrame(() => {
        const input = document.getElementById('global-search');
        if (!input || input.value !== caret.value) return;
        try { input.focus({ preventScroll: true }); }
        catch (_) { input.focus(); }
        try {
          const end = String(input.value || '').length;
          input.setSelectionRange(Math.min(caret.start, end), Math.min(caret.end, end));
        } catch (_) {}
      });
    }

    function scheduleGlobalSearchRender(input) {
      rememberGlobalSearchCaret(input);
      clearTimeout(globalSearchRenderTimer);
      globalSearchRenderTimer = window.setTimeout(() => {
        globalSearchRenderTimer = null;
        render();
      }, 120);
    }

    function renderFilterSelect(id, label, value, options, labeler = (item) => item) {
      const fullOptions = ['All', ...(options || [])];
      return `<label class="filter-control"><span>${escapeHtml(label)}</span><select id="${escapeHtml(id)}">${fullOptions.map((item) => `<option value="${escapeHtml(item)}" ${value === item ? 'selected' : ''}>${escapeHtml(labeler(item))}</option>`).join('')}</select></label>`;
    }

    function renderSortSelect(id, label, value, options) {
      return `<label class="filter-control"><span>${escapeHtml(label)}</span><select id="${escapeHtml(id)}">${(options || []).map((item) => `<option value="${escapeHtml(item)}" ${value === item ? 'selected' : ''}>${escapeHtml(matchSortLabel(item))}</option>`).join('')}</select></label>`;
    }

    function renderLoadMoreButton(id, shownCount, totalCount, label = 'items') {
      const shown = Number(shownCount || 0);
      const total = Number(totalCount || 0);
      if (!total || shown >= total) return '';
      const remaining = Math.max(0, total - shown);
      return `<div class="incremental-list-footer"><span>Showing ${shown.toLocaleString()} of ${total.toLocaleString()} ${escapeHtml(label)}</span><button class="btn small" id="${escapeHtml(id)}">Load More (${remaining.toLocaleString()})</button></div>`;
    }

    function increaseVisibleLimit(key, step = 80, max = 2000) {
      state[key] = Math.min(max, Math.max(step, Number(state[key] || 0) + step));
      render();
    }

    function renderMatchFilters() {
      return `
        <div class="filter-grid match-filter-grid">
          ${renderFilterSelect('toon-filter', 'Toon', state.toonFilter, toonOptions())}
          ${renderFilterSelect('class-filter', 'Class', state.matchClassFilter, matchClassOptions())}
          ${renderFilterSelect('day-filter', 'Day', state.dayFilter, dayOptions())}
          ${renderFilterSelect('match-type-filter', 'Match Type', state.matchTypeFilter, matchTypeOptions(), displayMatchTypeLabel)}
          ${renderSortSelect('match-sort', 'Sort', state.matchSort, ['newest', 'oldest', 'favorites', 'map', 'toon', 'result'])}
        </div>
      `;
    }

    return {
      uniqueValues,
      toonOptions,
      dayOptions,
      matchTypeOptions,
      classDisplayName,
      matchClassLabels,
      matchClassOptions,
      matchHasClass,
      matchSortLabel,
      sortMatchesForLibrary,
      filteredMatches,
      rememberGlobalSearchCaret,
      restoreGlobalSearchCaret,
      scheduleGlobalSearchRender,
      renderFilterSelect,
      renderSortSelect,
      renderLoadMoreButton,
      increaseVisibleLimit,
      renderMatchFilters
    };
  }

  window.LastCallSearchView = { createSearchViewTools };
})();
