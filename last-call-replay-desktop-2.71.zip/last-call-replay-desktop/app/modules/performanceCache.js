(function () {
  'use strict';

  function createPerformanceCacheTools(options = {}) {
    const defaultMaxEntries = Math.max(20, Number(options.maxEntries || 160));
    const shared = window.__LastCallSharedPerformanceCache || (window.__LastCallSharedPerformanceCache = { namespaces: new Map() });
    const namespaces = options.isolated ? new Map() : shared.namespaces;

    function namespaceFor(name, maxEntries = defaultMaxEntries) {
      const key = String(name || 'default');
      if (!namespaces.has(key)) namespaces.set(key, { map: new Map(), maxEntries: Math.max(5, Number(maxEntries || defaultMaxEntries)) });
      return namespaces.get(key);
    }

    function trim(ns) {
      const max = Math.max(5, Number(ns.maxEntries || defaultMaxEntries));
      while (ns.map.size > max) {
        const oldest = ns.map.keys().next().value;
        ns.map.delete(oldest);
      }
    }

    function get(namespace, key) {
      const ns = namespaceFor(namespace);
      const cacheKey = String(key || '');
      if (!ns.map.has(cacheKey)) return undefined;
      const value = ns.map.get(cacheKey);
      ns.map.delete(cacheKey);
      ns.map.set(cacheKey, value);
      return value;
    }

    function set(namespace, key, value, optionsForSet = {}) {
      const ns = namespaceFor(namespace, optionsForSet.maxEntries || defaultMaxEntries);
      const cacheKey = String(key || '');
      if (!cacheKey) return value;
      ns.map.set(cacheKey, value);
      trim(ns);
      return value;
    }

    function memo(namespace, key, builder, optionsForMemo = {}) {
      const existing = get(namespace, key);
      if (existing !== undefined) return existing;
      const value = typeof builder === 'function' ? builder() : builder;
      return set(namespace, key, value, optionsForMemo);
    }

    function clear(namespace = '') {
      if (!namespace) {
        namespaces.clear();
        return;
      }
      namespaces.delete(String(namespace));
    }

    function stats() {
      return Array.from(namespaces.entries()).reduce((out, entry) => {
        out[entry[0]] = entry[1].map.size;
        return out;
      }, {});
    }

    return { get, set, memo, clear, stats };
  }

  window.LastCallPerformanceCache = { createPerformanceCacheTools };
})();
