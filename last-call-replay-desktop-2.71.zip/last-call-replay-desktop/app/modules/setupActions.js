(function () {
  'use strict';

  const DEFAULT_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json';
  const DEFAULT_UPDATE_RELEASE_URL = 'https://github.com/darkstavern-code/last-call-replay/releases';

  function createSetupActions(deps = {}) {
    if (!deps || !deps.state) throw new Error('LastCallSetupActions requires app state.');
    const state = deps.state;
    const api = deps.api || null;
    const alert = deps.alert || ((message) => window.alert(message));
    const confirm = deps.confirm || ((message) => window.confirm(message));
    const render = deps.render || (() => {});
    const dashboardAddonStatusSummary = deps.dashboardAddonStatusSummary || (() => ({}));
    const applyDesktopPayload = deps.applyDesktopPayload || (() => {});
    const applyImportJobStatus = deps.applyImportJobStatus || (() => {});
    const applyBackendCollectionDeltas = deps.applyBackendCollectionDeltas || (() => {});
    const dedupeMatches = deps.dedupeMatches || ((matches) => matches || []);
    const mergeBackendMatches = deps.mergeBackendMatches || (() => {});
    const clearRailFeedCache = deps.clearRailFeedCache || (() => {});
    const dedupeCharacterSnapshots = deps.dedupeCharacterSnapshots || ((snapshots) => snapshots || []);
    const sortMatchesForLibrary = deps.sortMatchesForLibrary || ((matches) => matches || []);
    const selectedMatch = deps.selectedMatch || (() => null);
    const isPendingScoreboardSnapshot = deps.isPendingScoreboardSnapshot || (() => false);
    const scanRecordingsFolder = deps.scanRecordingsFolder || (async () => null);
    const validRecorderPerformanceMode = deps.validRecorderPerformanceMode || ((mode) => mode || 'balanced');

    function heavyLogWorkIsBusy() {
      const job = state.importJobStatus && state.importJobStatus.active;
      const jobType = String(job && job.type || '');
      return Boolean(state.logSyncBusy || state.selectedLogSyncBusy || state.logRepairBusy || state.matchRefreshBusy || (job && /combat-log/i.test(jobType)));
    }

    function guardHeavyLogWork(label = 'Log sync') {
      if (!heavyLogWorkIsBusy()) return false;
      state.watchStatus = `${label} skipped because another heavy log job is already running.`;
      render();
      return true;
    }

    const pvpHelperSetupActions = (window.LastCallPvPHelperSetupActions && typeof window.LastCallPvPHelperSetupActions.createPvPHelperSetupActions === 'function')
      ? window.LastCallPvPHelperSetupActions.createPvPHelperSetupActions({
        state,
        api,
        alert,
        confirm,
        render,
        dashboardAddonStatusSummary,
        applyImportJobStatus,
        clearRailFeedCache,
        dedupeCharacterSnapshots,
        sortMatchesForLibrary,
        dedupeMatches,
        pickAndWatchFolder: () => pickAndWatchFolder()
      })
      : null;
    if (!pvpHelperSetupActions) throw new Error('LastCallPvPHelperSetupActions module failed to load.');

    async function refreshPvPHelperAddonInstallStatus(silent = false) {
      return pvpHelperSetupActions.refreshPvPHelperAddonInstallStatus(silent);
    }

    async function installPvPHelperAddon() {
      return pvpHelperSetupActions.installPvPHelperAddon();
    }

    async function handleTopbarAddonInstallClick() {
      return pvpHelperSetupActions.handleTopbarAddonInstallClick();
    }


    async function autoConnectLocalSetup() {
      if (!api || !api.autoConnectLocalSetup) return alert('Auto-locate is only available in the desktop app.');
      try {
        state.watchStatus = 'Auto-locating setup';
        render();
        const result = await api.autoConnectLocalSetup();
        applyDesktopPayload(result || {});
        const logFile = state.settings.logFilePath || (result && result.autoSetup && result.autoSetup.log && result.autoSetup.log.filePath) || '';
        if (logFile && api.watchLogFile) {
          const status = await api.watchLogFile(logFile);
          state.watchStatus = 'Watching logs';
          state.watchPath = status && status.filePath ? status.filePath : logFile;
          if (status && status.folderPath) state.settings.logFolderPath = status.folderPath;
          state.settings.logFilePath = state.watchPath;
        }
        await refreshPvPHelperAddonInstallStatus(true);
        await refreshPvPHelperSavedVariablesDiscovery(false);
        render();
        const summary = result && result.autoSetup && result.autoSetup.summary ? result.autoSetup.summary : 'Auto-locate finished.';
        alert(summary);
      } catch (error) {
        render();
        alert(`Auto-locate failed: ${error && error.message ? error.message : error}`);
      }
    }


    async function useDefaultRecordingsFolder() {
      if (!api || !api.useDefaultRecordingsFolder) return alert('Default recording folder setup is only available in the desktop app.');
      if (state.recorder) state.recorder.statusText = 'Setting recording folder…';
      render();
      try {
        const result = await api.useDefaultRecordingsFolder();
        if (result && result.settings) state.settings = { ...state.settings, ...result.settings };
        if (result && result.appPaths) state.appPaths = result.appPaths;
        if (state.recorder) state.recorder.statusText = 'Recording folder ready.';
        state.showRecorderSettings = false;
        render();
      } catch (error) {
        alert(`Could not set the default recording folder: ${error && error.message ? error.message : error}`);
      }
    }


    async function useDetectedLogFile() {
      if (!api) return alert('Desktop API unavailable. Run through Electron.');
      const filePath = state.defaultLogCandidates[0];
      if (!filePath) return alert('No WoWCombatLog*.txt found automatically. Choose the file or Logs folder manually.');
      const status = await api.watchLogFile(filePath);
      state.settings.logFilePath = filePath;
      state.settings.logFolderPath = filePath.replace(/[\\/][^\\/]*$/, '');
      state.watchStatus = 'Watching logs';
      state.watchPath = filePath;
      await refreshPvPHelperAddonInstallStatus(true);
      await refreshPvPHelperSavedVariablesDiscovery(false);
      render();
    }


    async function pickAndWatchFile() {
      if (!api) return alert('Desktop API unavailable. Run through Electron.');
      const filePath = await api.selectLogFile();
      if (!filePath) return;
      const status = await api.watchLogFile(filePath);
      state.watchStatus = 'Watching logs';
      state.watchPath = status && status.filePath ? status.filePath : filePath;
      state.settings.logFilePath = state.watchPath;
      if (status && status.folderPath) state.settings.logFolderPath = status.folderPath;
      await refreshPvPHelperAddonInstallStatus(true);
      await refreshPvPHelperSavedVariablesDiscovery(false);
      render();
    }


    async function pickAndWatchFolder() {
      if (!api) return alert('Desktop API unavailable. Run through Electron.');
      const filePath = await api.selectLogFolder();
      if (!filePath) return;
      const status = await api.watchLogFile(filePath);
      state.watchStatus = 'Watching logs';
      state.watchPath = status && status.filePath ? status.filePath : filePath;
      state.settings.logFilePath = state.watchPath;
      if (status && status.folderPath) state.settings.logFolderPath = status.folderPath;
      await refreshPvPHelperAddonInstallStatus(true);
      await refreshPvPHelperSavedVariablesDiscovery(false);
      render();
    }


    async function importOldLog() {
      if (!api) return alert('Desktop API unavailable. Run through Electron.');
      const filePath = await api.selectLogFile();
      if (!filePath) return;
      state.watchStatus = 'Importing';
      state.watchPath = filePath;
      render();
      try {
        const result = await api.importLogFile(filePath);
        applyImportJobStatus(result || {});
        if (result && result.matches) state.matches = dedupeMatches(result.matches || state.matches || []);
        else if (result && result.changedMatches) mergeBackendMatches(result.changedMatches);
        if (result && result.importedFiles) state.importedFiles = result.importedFiles;
        else state.importedFiles.unshift({ filePath, state: result.state || (result.importedCount ? 'Imported' : result.updatedCount ? 'Updated existing matches' : 'No PvP matches found') });
        if (result && result.logFileRegistry) state.logFileRegistry = result.logFileRegistry;
        if (result && result.settings) state.settings = { ...state.settings, ...result.settings };
        state.watchStatus = result.importedCount
          ? `Imported ${result.importedCount} PvP match${result.importedCount === 1 ? '' : 'es'}`
          : (result.state || 'No PvP matches found');
        state.watchPath = filePath;
      } catch (error) {
        state.watchStatus = 'Import failed';
        alert(error.message || String(error));
      }
      render();
    }


    function applyPvPHelperImportResult(result) {
      return pvpHelperSetupActions.applyPvPHelperImportResult(result);
    }


    function pvpHelperImportMessage(result, prefix = 'Synced PvPHelper.lua') {
      return pvpHelperSetupActions.pvpHelperImportMessage(result, prefix);
    }


    async function refreshPvPHelperSavedVariablesDiscovery(renderAfter = true) {
      return pvpHelperSetupActions.refreshPvPHelperSavedVariablesDiscovery(renderAfter);
    }


    async function autoPreviewPvPHelperSavedVariables() {
      return pvpHelperSetupActions.autoPreviewPvPHelperSavedVariables();
    }


    async function importPvPHelperSavedVariables() {
      return pvpHelperSetupActions.importPvPHelperSavedVariables();
    }


    async function applyPvPHelperImportPreview() {
      return pvpHelperSetupActions.applyPvPHelperImportPreview();
    }


    async function syncMappedPvPHelperSavedVariables(options = {}) {
      return pvpHelperSetupActions.syncMappedPvPHelperSavedVariables(options);
    }


    async function clearPvPHelperSavedVariablesMapping() {
      return pvpHelperSetupActions.clearPvPHelperSavedVariablesMapping();
    }


    async function updatePvPHelperAutoSync(enabled) {
      return pvpHelperSetupActions.updatePvPHelperAutoSync(enabled);
    }


    async function importCharacterSnapshot() {
      return pvpHelperSetupActions.importCharacterSnapshot();
    }


    async function deleteCharacterSnapshot(snapshotId) {
      if (!snapshotId || !api || !api.deleteCharacterSnapshot) return;
      if (!confirm('Remove this character snapshot from local history?')) return;
      const result = await api.deleteCharacterSnapshot({ snapshotId });
      if (result && result.snapshots) state.characterSnapshots = dedupeCharacterSnapshots(result.snapshots);
      render();
    }


    async function dedupeRecordingHistory() {
      if (!api || !api.dedupeRecordings) return alert('Recording cleanup is only available in the desktop app.');
      const result = await api.dedupeRecordings();
      applyBackendCollectionDeltas(result || {});
      state.recorder.recordings = result.recordings || state.recorder.recordings || [];
      render();
      if (result.removed) alert(`Removed ${result.removed} duplicate recording entr${result.removed === 1 ? 'y' : 'ies'}.`);
    }


    async function chooseRecordingsFolder() {
      if (!api || !api.selectRecordingsFolder) return;
      if (state.recorder) state.recorder.statusText = 'Opening folder picker…';
      render();
      const result = await api.selectRecordingsFolder();
      if (result && result.recordingsDir) {
        state.settings.recordingsDir = result.recordingsDir;
        state.settings.recordingsDirConfirmed = true;
        if (state.recorder) state.recorder.statusText = 'Recording folder ready.';
      } else if (state.recorder) {
        state.recorder.statusText = state.recorder.statusText === 'Opening folder picker…' ? 'Ready' : state.recorder.statusText;
      }
      render();
    }




    async function syncLogsForSelectedMatch() {
      if (guardHeavyLogWork('Selected match log sync')) return null;
      if (state.selectedLogSyncBusy) {
        state.watchStatus = 'Selected match log sync is already running.';
        render();
        return null;
      }
      if (!api || !api.syncLogsForMatch) return scanLogsFolder();
      const match = selectedMatch();
      if (!match || !match.id) return alert('Pick a match first.');
      state.selectedLogSyncBusy = true;
      state.watchStatus = 'Syncing logs for selected match';
      render();
      try {
        const result = await api.syncLogsForMatch({ matchId: match.id });
        applyImportJobStatus(result || {});
        if (!result || !result.ok) {
          state.watchStatus = (result && result.reason) || 'Could not sync logs for this match.';
          return alert(state.watchStatus);
        }
        if (Array.isArray(result.removedMatchIds) && result.removedMatchIds.length) {
          const removed = new Set(result.removedMatchIds);
          state.matches = (state.matches || []).filter((item) => item && !removed.has(item.id));
        }
        if (result.matches) state.matches = result.matches || state.matches || [];
        else if (result.changedMatches && result.changedMatches.length) mergeBackendMatches(result.changedMatches);
        else if (result.selectedMatch) mergeBackendMatches([result.selectedMatch]);
        state.importedFiles = result.importedFiles || state.importedFiles || [];
        if (result.logFileRegistry) state.logFileRegistry = result.logFileRegistry;
        if (result.settings) state.settings = { ...state.settings, ...result.settings };
        state.selectedId = match.id;
        await refreshPvPHelperAddonInstallStatus(true);
        state.watchStatus = result.linked
          ? `Synced selected match from ${result.filesScanned || 1} log file${(result.filesScanned || 1) === 1 ? '' : 's'}.`
          : `Checked ${result.filesScanned || 0} likely log file${(result.filesScanned || 0) === 1 ? '' : 's'}, but no matching combat segment was found.`;
        return result;
      } catch (error) {
        state.watchStatus = 'Selected match log sync failed';
        alert(error.message || String(error));
        return null;
      } finally {
        state.selectedLogSyncBusy = false;
        render();
      }
    }


    async function repairMissingLogs() {
      if (guardHeavyLogWork('Missing-log repair')) return null;
      if (state.logRepairBusy) {
        state.watchStatus = 'Missing-log repair is already running.';
        render();
        return null;
      }
      if (!api || !api.repairMissingLogs) return alert('Missing-log repair is only available in the desktop app.');
      state.logRepairBusy = true;
      state.watchStatus = 'Repairing missing log links';
      render();
      try {
        const result = await api.repairMissingLogs({});
        applyImportJobStatus(result || {});
        if (!result || !result.ok) {
          state.watchStatus = (result && result.reason) || 'Could not repair missing logs.';
          return alert(state.watchStatus);
        }
        if (Array.isArray(result.removedMatchIds) && result.removedMatchIds.length) {
          const removed = new Set(result.removedMatchIds);
          state.matches = (state.matches || []).filter((item) => item && !removed.has(item.id));
        }
        if (result.matches) state.matches = result.matches || state.matches || [];
        else if (result.repairedMatches && result.repairedMatches.length) mergeBackendMatches(result.repairedMatches);
        state.importedFiles = result.importedFiles || state.importedFiles || [];
        if (result.logFileRegistry) state.logFileRegistry = result.logFileRegistry;
        if (result.settings) state.settings = { ...state.settings, ...result.settings };
        await refreshPvPHelperAddonInstallStatus(true);
        state.watchStatus = result.reason || `Repaired ${result.repaired || 0} of ${result.missing || 0} missing combat-log links.`;
        return result;
      } catch (error) {
        state.watchStatus = 'Missing-log repair failed';
        alert(error.message || String(error));
        return null;
      } finally {
        state.logRepairBusy = false;
        render();
      }
    }


    async function scanLogsFolder() {
      if (guardHeavyLogWork('Active log sync')) return null;
      if (state.logSyncBusy) {
        state.watchStatus = 'Active log sync is already running.';
        render();
        return null;
      }
      if (!api || !api.scanLogsFolder) return alert('Log scanning is only available in the desktop app.');
      state.logSyncBusy = true;
      state.watchStatus = 'Syncing active log';
      render();
      try {
        const result = await api.scanLogsFolder();
        applyImportJobStatus(result || {});
        if (!result || !result.ok) {
          state.watchStatus = (result && result.reason) || 'Could not sync active log.';
          return alert(state.watchStatus);
        }
        if (result.matches) state.matches = result.matches || state.matches || [];
        else if (result.changedMatches && result.changedMatches.length) mergeBackendMatches(result.changedMatches);
        else if (result.selectedMatch) mergeBackendMatches([result.selectedMatch]);
        state.importedFiles = result.importedFiles || state.importedFiles || [];
        if (result.logFileRegistry) state.logFileRegistry = result.logFileRegistry;
        if (result.settings) state.settings = { ...state.settings, ...result.settings };
        await refreshPvPHelperAddonInstallStatus(true);
        if (result.watchFile) {
          state.watchPath = result.watchFile;
          try { await api.watchLogFile(result.watchFile); } catch (_error) {}
        }
        state.watchStatus = result.state || (result.imported
          ? `Found ${result.imported} finalized PvP match${result.imported === 1 ? '' : 'es'}`
          : 'Active log synced. No finalized matches yet.');
        if (!state.selectedId && state.matches[0]) state.selectedId = state.matches[0].id;
        return result;
      } catch (error) {
        state.watchStatus = 'Active log sync failed';
        alert(error.message || String(error));
        return null;
      } finally {
        state.logSyncBusy = false;
        render();
      }
    }


    async function syncActiveLogSilently(options = {}) {
      if (!api || !api.scanLogsFolder) return null;
      const payload = options && options.startupLight
        ? { startupLight: true, mode: 'startup-light' }
        : (options && options.refreshLight ? { refreshLight: true, mode: 'refresh-light' } : {});
      try {
        const result = await api.scanLogsFolder(payload);
        applyImportJobStatus(result || {});
        if (!result || !result.ok) return result || null;
        if (result.matches) state.matches = dedupeMatches(result.matches || state.matches || []);
        else if (result.changedMatches && result.changedMatches.length) mergeBackendMatches(result.changedMatches);
        state.importedFiles = result.importedFiles || state.importedFiles || [];
        if (result.logFileRegistry) state.logFileRegistry = result.logFileRegistry;
        if (result.settings) state.settings = { ...state.settings, ...result.settings };
        if (result.watchFile) state.watchPath = result.watchFile;
        if (result.imported) {
          const newest = sortMatchesForLibrary(state.matches).find((match) => !isPendingScoreboardSnapshot(match));
          if (newest) state.selectedId = newest.id;
          state.watchStatus = `Caught up ${result.imported} new finalized PvP match${result.imported === 1 ? '' : 'es'}`;
        } else {
          state.watchStatus = result.state || state.watchStatus || 'Log ready';
        }
        return result;
      } catch (error) {
        console.warn('[Last Call Replay] Silent active-log catch-up failed.', error);
        return null;
      }
    }


    async function refreshMatchHistory() {
      if (guardHeavyLogWork('Match history refresh')) return;
      if (state.matchRefreshBusy) return;
      state.matchRefreshBusy = true;
      state.watchStatus = 'Refreshing match history';
      render();
      const notes = [];
      try {
        const logResult = await syncActiveLogSilently({ refreshLight: true });
        if (logResult && logResult.ok) notes.push(logResult.imported ? `${logResult.imported} new log match${logResult.imported === 1 ? '' : 'es'}` : 'logs checked');
        else notes.push('logs not ready');

        if (state.settings && state.settings.pvpHelperSavedVariablesPath) {
          await syncMappedPvPHelperSavedVariables({ force: true, silent: true });
          notes.push('PvPHelper checked');
        }

        if (state.settings && state.settings.recordingsDir) {
          const videoResult = await scanRecordingsFolder({ silent: true });
          if (videoResult && videoResult.ok) notes.push(videoResult.added ? `${videoResult.added} new video${videoResult.added === 1 ? '' : 's'}` : 'videos checked');
        }

        state.matchRefreshBusy = false;
        state.watchStatus = `Match history refreshed: ${notes.join(', ')}.`;
      } catch (error) {
        state.matchRefreshBusy = false;
        state.watchStatus = 'Match history refresh failed';
        alert(error && error.message ? error.message : String(error));
      }
      render();
    }



    async function chooseArchiveFolder() {
      if (!api || !api.selectArchiveFolder) return;
      const result = await api.selectArchiveFolder();
      if (result && result.archiveDir) state.settings.archiveDir = result.archiveDir;
      render();
    }


    function finishStorageChange(result, title) {
      if (!result) return;
      if (!result.ok) return alert((result && result.reason) || 'Could not change the app storage folder.');
      const portableNote = result.portablePointerWritten
        ? `

    Portable pointer written:
    ${result.portablePointer || ''}`
        : result.portablePointerWarning
          ? `

    Portable pointer warning:
    ${result.portablePointerWarning}`
          : '';
      alert(`${title}
    ${result.movedTo || result.storage || ''}${portableNote}

    The window will reload so the app reads from that location.`);
      window.location.reload();
    }


    async function chooseAppStorageFolder() {
      if (!api || !api.selectAppStorageFolder) return alert('App storage migration is only available in the desktop app.');
      const result = await api.selectAppStorageFolder();
      finishStorageChange(result, 'App storage is now on:');
    }


    async function enablePortableAppStorage() {
      if (!api || !api.enablePortableAppStorage) return alert('Portable storage is only available in the desktop app.');
      const result = await api.enablePortableAppStorage();
      finishStorageChange(result, 'Portable app storage is now on:');
    }


    async function connectAppStorageFolder() {
      if (!api || !api.connectAppStorageFolder) return alert('Storage connection is only available in the desktop app.');
      const result = await api.connectAppStorageFolder();
      finishStorageChange(result, 'Connected app storage:');
    }


    async function createStateBackupNow() {
      if (!api || !api.createStateBackup) return alert('State backups are only available in the desktop app.');
      try {
        const result = await api.createStateBackup();
        if (result && result.appPaths) state.appPaths = { ...(state.appPaths || {}), ...(result.appPaths || {}) };
        if (!result || !result.ok) return alert((result && result.reason) || 'No state backup was created.');
        alert(`Backup created:\n${result.backupPath}`);
        render();
      } catch (error) {
        alert(error && error.message ? error.message : String(error));
      }
    }


    async function repairLibraryConnections() {
      if (!api || !api.repairLibraryConnections) return alert('Library link repair is only available in the desktop app.');
      state.maintenanceStatus = 'Repairing library links';
      render();
      try {
        const result = await api.repairLibraryConnections();
        applyImportJobStatus(result || {});
        if (!result || !result.ok) {
          state.maintenanceStatus = 'Library link repair failed';
          render();
          return alert((result && result.reason) || 'Could not repair library links.');
        }
        if (result.changedMatches) mergeBackendMatches(result.changedMatches);
        if (result.changedRecordings) state.recorder.recordings = result.changedRecordings;
        if (result.changedVods) state.vods = result.changedVods;
        if (result.favoriteFolders) state.favoriteFolders = result.favoriteFolders;
        if (result.settings) state.settings = { ...state.settings, ...result.settings };
        if (result.appPaths) state.appPaths = { ...(state.appPaths || {}), ...(result.appPaths || {}) };
        const summary = result.summary || {};
        state.maintenanceStatus = `Library links repaired. Videos ${Number(summary.beforeVideoCount || 0)} → ${Number(summary.afterVideoCount || 0)}, recording links ${Number(summary.beforeRecordingLinks || 0)} → ${Number(summary.afterRecordingLinks || 0)}.`;
        render();
      } catch (error) {
        state.maintenanceStatus = 'Library link repair failed';
        render();
        alert(error && error.message ? error.message : String(error));
      }
    }


    async function compactLocalState() {
      if (!api || !api.compactLocalState) return alert('Maintenance compact is only available in the desktop app.');
      state.maintenanceStatus = 'Compacting local app data';
      render();
      try {
        const result = await api.compactLocalState();
        applyImportJobStatus(result || {});
        if (!result || !result.ok) {
          state.maintenanceStatus = 'Compact failed';
          render();
          return alert((result && result.reason) || 'Could not compact local app data.');
        }
        if (result.changedMatches) mergeBackendMatches(result.changedMatches);
        if (result.importedFiles) state.importedFiles = result.importedFiles;
        if (result.logFileRegistry) state.logFileRegistry = result.logFileRegistry;
        if (result.settings) state.settings = { ...state.settings, ...result.settings };
        state.performanceAudit = result.performanceAudit || state.performanceAudit || {};
        state.maintenanceLastRun = result.maintenanceLastRun || result.summary || null;
        const summary = result.summary || {};
        const before = summary.before || {};
        const after = summary.after || {};
        const removedMatches = Math.max(0, Number(before.matchCount || 0) - Number(after.matchCount || 0));
        const prunedLogs = Number(summary.prunedLogs || 0);
        state.maintenanceStatus = `Compact complete. Merged/removed ${removedMatches} duplicate match${removedMatches === 1 ? '' : 'es'} and pruned ${prunedLogs} old log-index row${prunedLogs === 1 ? '' : 's'}.`;
        render();
      } catch (error) {
        state.maintenanceStatus = 'Compact failed';
        render();
        alert(error && error.message ? error.message : String(error));
      }
    }


    async function saveGeneralSettingsFromForm() {
      const autoLink = document.getElementById('settings-auto-link-window');
      if (autoLink) state.settings.autoLinkWindowMinutes = Math.max(0, Math.min(240, Number(autoLink.value) || 0));
      const updateReleaseUrl = document.getElementById('settings-update-release-url');
      const updateManifestUrl = document.getElementById('settings-update-manifest-url');
      if (updateReleaseUrl) state.settings.updateReleaseUrl = String(updateReleaseUrl.value || '').trim() || DEFAULT_UPDATE_RELEASE_URL;
      if (updateManifestUrl) state.settings.updateManifestUrl = String(updateManifestUrl.value || '').trim() || DEFAULT_UPDATE_MANIFEST_URL;
      if (api && api.saveSettings) state.settings = await api.saveSettings(state.settings);
      render();
    }


    async function checkForUpdates() {
      if (!api || !api.checkForUpdates) return alert('Update checking is only available in the desktop app.');
      await saveGeneralSettingsFromForm();
      state.updateStatus = {
        ...(state.updateStatus || {}),
        checking: true,
        currentVersion: state.appVersion || '',
        releaseUrl: state.settings.updateReleaseUrl || DEFAULT_UPDATE_RELEASE_URL,
        manifestUrl: state.settings.updateManifestUrl || DEFAULT_UPDATE_MANIFEST_URL
      };
      render();
      try {
        const result = await api.checkForUpdates({
          releaseUrl: state.settings.updateReleaseUrl || DEFAULT_UPDATE_RELEASE_URL,
          manifestUrl: state.settings.updateManifestUrl || DEFAULT_UPDATE_MANIFEST_URL
        });
        state.updateStatus = { ...(result || {}), checking: false };
        if (result && result.settings) state.settings = { ...state.settings, ...result.settings };
        render();
      } catch (error) {
        state.updateStatus = { ok: false, checking: false, reason: error && error.message ? error.message : String(error), currentVersion: state.appVersion || '' };
        render();
      }
    }


    async function openUpdateReleasePage() {
      const releaseUrl = String((state.updateStatus && (state.updateStatus.releaseUrl || state.updateStatus.downloadUrl)) || (state.settings && state.settings.updateReleaseUrl) || DEFAULT_UPDATE_RELEASE_URL).trim();
      if (!releaseUrl) return alert('Add an official release page URL first.');
      if (!api || !api.openExternalUrl) return alert('Opening links is only available in the desktop app.');
      await api.openExternalUrl(releaseUrl);
    }


    async function openUpdateDownloadUrl(url = '') {
      const target = String(url || '').trim();
      if (!target) return alert('No download link is available for this update yet.');
      if (!api || !api.openExternalUrl) return alert('Opening links is only available in the desktop app.');
      await api.openExternalUrl(target);
    }


    async function saveRecorderSettings() {
      if (!api || !api.saveRecorderSettings) return;
      await api.saveRecorderSettings({
        includeAudio: state.recorder.includeAudio,
        performanceMode: validRecorderPerformanceMode(state.recorder.performanceMode),
        approvedWowSourceNames: state.recorder.approvedWowSourceNames || []
      });
    }


    return {
      refreshPvPHelperAddonInstallStatus,
      installPvPHelperAddon,
      handleTopbarAddonInstallClick,
      autoConnectLocalSetup,
      useDefaultRecordingsFolder,
      useDetectedLogFile,
      pickAndWatchFile,
      pickAndWatchFolder,
      importOldLog,
      applyPvPHelperImportResult,
      pvpHelperImportMessage,
      refreshPvPHelperSavedVariablesDiscovery,
      autoPreviewPvPHelperSavedVariables,
      importPvPHelperSavedVariables,
      applyPvPHelperImportPreview,
      syncMappedPvPHelperSavedVariables,
      clearPvPHelperSavedVariablesMapping,
      updatePvPHelperAutoSync,
      importCharacterSnapshot,
      deleteCharacterSnapshot,
      dedupeRecordingHistory,
      chooseRecordingsFolder,
      syncLogsForSelectedMatch,
      repairMissingLogs,
      scanLogsFolder,
      syncActiveLogSilently,
      refreshMatchHistory,
      chooseArchiveFolder,
      finishStorageChange,
      chooseAppStorageFolder,
      enablePortableAppStorage,
      connectAppStorageFolder,
      createStateBackupNow,
      repairLibraryConnections,
      compactLocalState,
      saveGeneralSettingsFromForm,
      checkForUpdates,
      openUpdateReleasePage,
      openUpdateDownloadUrl,
      saveRecorderSettings
    };
  }

  window.LastCallSetupActions = { createSetupActions };
})();
