(function () {
  'use strict';

  function createMetricsViewTools(deps = {}) {
    const state = deps.state || {};
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const prettyNumber = deps.prettyNumber || ((value) => String(value || 0));
    const coloredName = deps.coloredName || ((name) => escapeHtml(name || 'Unknown'));
    const coloredShortName = deps.coloredShortName || coloredName;
    const pill = deps.pill || ((text) => `<span>${escapeHtml(text)}</span>`);
    const formatElapsed = deps.formatElapsed || ((value) => String(value || 0));
    const matchScoreboardPlayers = deps.matchScoreboardPlayers || (() => []);
    const hasLinkedScoreboard = deps.hasLinkedScoreboard || ((match) => matchScoreboardPlayers(match).length > 0);
    const isBattlegroundMatch = deps.isBattlegroundMatch || (() => false);
    const selectedMatch = deps.selectedMatch || (() => null);
    const isSoloShuffleLobbyUiMatch = deps.isSoloShuffleLobbyUiMatch || (() => false);
    const soloShuffleStatsMatch = deps.soloShuffleStatsMatch || ((match) => match);
    const isReplayFullVodMode = deps.isReplayFullVodMode || (() => false);
    const perfCache = window.LastCallPerformanceCache && typeof window.LastCallPerformanceCache.createPerformanceCacheTools === 'function'
      ? window.LastCallPerformanceCache.createPerformanceCacheTools({ maxEntries: 180 })
      : null;

function metricTabSections() {
  return [
    {
      key: 'core',
      title: 'Meter tools',
      helper: 'Damage, healing, pressure, control, interrupts, offensive purges, friendly dispels, and deaths.',
      items: ['Damage', 'Healing', 'Taken', 'CC Done', 'Interrupts', 'Purges', 'Dispels', 'CC Dispels', 'Deaths']
    }
  ];
}

function metricTabs() {
  return metricTabSections().flatMap((section) => section.items);
}

function renderMetricTabSections(sectionFooter = '') {
  return `
    <div class="lcr-meter-section-stack">
      ${metricTabSections().map((section) => `
        <section class="lcr-meter-section lcr-meter-section-${escapeHtml(section.key)}">
          <div class="lcr-meter-section-head">
            <div>
              <strong>${escapeHtml(section.title)}</strong>
              <small>${escapeHtml(section.helper)}</small>
            </div>
          </div>
          <div class="meter-tabs wide-tabs compact-tabs lcr-meter-section-tabs">
            ${section.items.map((item) => `<button class="meter-tab ${state.meter === item ? 'active' : ''}" data-meter="${escapeHtml(item)}">${escapeHtml(item)}</button>`).join('')}
          </div>
          ${sectionFooter ? `<div class="lcr-meter-section-foot">${sectionFooter}</div>` : ''}
        </section>
      `).join('')}
    </div>
  `;
}

function amountMetricNeedsTargetToggle() {
  return ['Damage', 'Healing', 'Taken'].includes(state.meter);
}

function scoreboardRowsForMatch(match, field, label = 'Final scoreboard total') {
  const players = matchScoreboardPlayers(match);
  const rows = players
    .filter((player) => Number(player && player[field]) > 0)
    .map((player) => ({
      name: player.name || player.fullName || 'Unknown',
      fullName: player.fullName || player.name || 'Unknown',
      amount: Number(player[field]) || 0,
      count: Number(player[field]) || 0,
      abilities: [],
      targets: [],
      top: label,
      scoreboardMetric: true
    }))
    .sort((a, b) => (Number(b.amount) || 0) - (Number(a.amount) || 0));
  const total = rows.reduce((sum, row) => sum + (Number(row.amount) || 0), 0) || 1;
  const max = rows.reduce((highest, row) => Math.max(highest, Number(row.amount) || 0), 1);
  return rows.map((row) => ({
    ...row,
    percent: Math.max(1, Math.round(((Number(row.amount) || 0) / total) * 100)),
    barPercent: Math.max(2, Math.round(((Number(row.amount) || 0) / max) * 100))
  }));
}

function metricUsesFinalScoreboard(match) {
  return Boolean(match && isBattlegroundMatch(match) && hasLinkedScoreboard(match) && ['Damage', 'Healing'].includes(state.meter));
}

function metricRowsCacheKey(match) {
  if (!match) return '';
  const scoreboardPlayers = matchScoreboardPlayers(match) || [];
  const metricRows = match.metrics && match.metrics[state.meter];
  return [
    match.id || match.rawFingerprint || '',
    match.rawFingerprint || '',
    match.parserVersion || '',
    match.updatedAt || match.importedAt || match.startIso || '',
    state.meter || '',
    state.meterTargetFilter || '',
    metricUsesFinalScoreboard(match) ? `scoreboard:${scoreboardPlayers.length}:${scoreboardPlayers.map((player) => `${player.fullName || player.name || ''}:${player.damageDone || 0}:${player.healingDone || 0}:${player.deaths || 0}`).join('|')}` : '',
    Array.isArray(metricRows) ? metricRows.length : 0,
    Array.isArray(match.ccChains) ? match.ccChains.length : 0
  ].join('::');
}

function buildMetricRowsForMatch(match) {
  if (!match) return [];
  if (metricUsesFinalScoreboard(match)) {
    if (state.meter === 'Damage') return scoreboardRowsForMatch(match, 'damageDone');
    if (state.meter === 'Healing') return scoreboardRowsForMatch(match, 'healingDone');
  }
  const metrics = match.metrics || {};
  if (state.meter === 'Damage') return state.meterTargetFilter === 'Players' ? (metrics.DamagePlayers || metrics.Damage || match.damage || []) : (metrics.Damage || match.damage || []);
  if (state.meter === 'Healing') return state.meterTargetFilter === 'Players' ? (metrics.HealingPlayers || metrics.Healing || match.healing || []) : (metrics.Healing || match.healing || []);
  if (state.meter === 'Taken') return state.meterTargetFilter === 'Players' ? (metrics.TakenPlayers || metrics.Taken || match.taken || []) : (metrics.Taken || match.taken || []);
  if (state.meter === 'CC Done') {
    const rows = metrics.CC || [];
    if (rows.length) return rows;
    return rowsFromCcChainsFallback(match);
  }
  if (state.meter === 'Purges') return metrics.Purges || [];
  return metrics[state.meter] || [];
}

function metricRowsForMatch(match) {
  if (!match || !perfCache) return buildMetricRowsForMatch(match);
  const key = metricRowsCacheKey(match);
  return perfCache.memo('metricRows', key, () => buildMetricRowsForMatch(match), { maxEntries: 220 });
}

function rowsFromCcChainsFallback(match) {
  const byActor = new Map();
  for (const cc of (match && match.ccChains) || []) {
    const actor = cc.actor || (String(cc.result || '').split(' controlled ')[0]) || 'Unknown';
    const ability = cc.ability || cc.chain || 'Control';
    if (!actor || actor === 'Unknown') continue;
    const row = byActor.get(actor) || { name: actor, amount: 0, count: 0, abilities: new Map() };
    row.amount += 1;
    row.count += 1;
    const abilityRow = row.abilities.get(ability) || { name: ability, amount: 0, count: 0, hits: 0, casts: 0, targets: new Map(), events: [] };
    abilityRow.amount += 1;
    abilityRow.count += 1;
    abilityRow.hits += 1;
    const targetName = cc.target || 'Unknown';
    const target = abilityRow.targets.get(targetName) || { name: targetName, hits: 0, amount: 0 };
    target.hits += 1;
    abilityRow.targets.set(targetName, target);
    abilityRow.events.push({ time: cc.time || '0:00', relativeSec: cc.relativeSec || 0, ability, target: targetName, source: actor, event: 'CONTROL' });
    row.abilities.set(ability, abilityRow);
    byActor.set(actor, row);
  }
  const rows = Array.from(byActor.values()).map((row) => ({
    ...row,
    abilities: Array.from(row.abilities.values()).map((ability) => ({ ...ability, targets: Array.from(ability.targets.values()) })).sort((a, b) => b.count - a.count),
    top: Array.from(row.abilities.keys()).slice(0, 3).join(', '),
    percent: 1
  })).sort((a, b) => b.amount - a.amount);
  const total = rows.reduce((sum, row) => sum + row.amount, 0) || 1;
  return rows.map((row) => ({ ...row, percent: Math.max(1, Math.round((row.amount / total) * 100)) }));
}

function selectedMetricRow(rows) {
  if (!rows || !rows.length) return null;
  return rows.find((row) => row.name === state.selectedMetricActor) || rows[0];
}

function selectedAbility(row) {
  const abilities = row && row.abilities ? row.abilities : [];
  if (!abilities.length || !state.selectedMetricAbility) return null;
  return abilities.find((ability) => ability.name === state.selectedMetricAbility) || null;
}


function metricTitle() {
  if (state.meter === 'CC Done') return 'CC Done';
  if (state.meter === 'Taken') return 'Damage Taken';
  if (state.meter === 'Purges') return 'Offensive Purges';
  if (state.meter === 'CC Dispels') return 'CC Dispels';
  return state.meter;
}

function metricValueLabel(row) {
  if (!row) return '0';
  if (['CC Done', 'Interrupts', 'Purges', 'Dispels', 'CC Dispels'].includes(state.meter)) return `${row.amount || row.count || 0}`;
  if (state.meter === 'Deaths') return row.scoreboardMetric ? `${row.count || row.amount || 0} deaths` : (row.count ? `${row.count} hits` : prettyNumber(row.amount || 0));
  return prettyNumber(row.amount || 0);
}



function renderMetricPanel(match) {
  const rows = metricRowsForMatch(match);
  const row = selectedMetricRow(rows);
  const ability = selectedAbility(row);
  const hasNumericToggle = amountMetricNeedsTargetToggle();
  const usingScoreboard = metricUsesFinalScoreboard(match);
  const totalRows = rows.length;
  const helperText = usingScoreboard
    ? 'Using linked final scoreboard totals for BG accuracy.'
    : (isBattlegroundMatch(match) && ['Damage', 'Healing'].includes(state.meter) ? 'Combat-log BG meters are partial. Link the final scoreboard for full totals.' : 'Click an ability for target breakdown.');
  const optionControl = hasNumericToggle && !usingScoreboard
    ? `<label class="metric-checkbox compact-check"><input type="checkbox" data-meter-target-checkbox ${state.meterTargetFilter === 'Players' ? 'checked' : ''} /> <span>Hide dmg and healing done to pets, totems, guardians, and objects</span></label>`
    : usingScoreboard ? '<span class="metric-source-note">Final scoreboard source</span>' : '<span class="metric-source-note muted-source-note">No extra meter filter</span>';
  const meterSectionFooter = `<div class="lcr-meter-inline-tools">${optionControl}<span class="metric-count-pill">${totalRows} players</span></div>`;
  const fullVodMode = isReplayFullVodMode(match);
  return `
    <div class="card metric-card metric-card-clean ${ability ? 'has-active-ability' : ''} ${fullVodMode ? 'metric-muted-for-full-vod' : ''}">
      ${fullVodMode ? '<div class="full-vod-data-mask"><strong>Full VOD unlocked</strong><span>Meter data belongs to this selected match only.</span></div>' : ''}
      <div class="card-title-row metric-head metric-head-clean">
        <div>
          <p class="small-label">Meter</p>
          <h2>${escapeHtml(metricTitle())}</h2>
        </div>
        <span class="metric-helper-pill ${usingScoreboard ? 'scoreboard-source' : ''}">${escapeHtml(helperText)}</span>
      </div>
      <div class="metric-top-control-grid">
        <div class="metric-top-tabs-wrap">
          ${renderMetricTabSections(meterSectionFooter)}
        </div>
      </div>
      <div class="metric-layout-clean metric-panels-aligned">
        <aside class="actor-list-panel">
          <div class="panel-label-row metric-panel-topline"><span>Players</span><small>${escapeHtml(metricTitle())}</small></div>
          <div class="meter-list drill-list actor-list-scroll">${rows.map(renderMeterRow).join('') || '<div class="empty">No data yet.</div>'}</div>
        </aside>
        <section class="metric-detail-panel metric-inspector-panel">
          <div class="panel-label-row metric-panel-topline"><span>${escapeHtml(metricTitle())} breakdown</span><small>${row ? escapeHtml(row.name) : 'Select player'}</small></div>
          ${row ? renderMetricDetails(row, ability) : '<div class="empty">Select a player to inspect details.</div>'}
        </section>
      </div>
    </div>
  `;
}

function abilityStatSummary(ability, isCount) {
  if (!ability) return '';
  if (isCount) {
    return `<span><b>${ability.actions || ability.count || ability.hits || 0}</b> ${escapeHtml(countMetricActionNoun())}</span><span><b>${(ability.targets || []).length}</b> targets</span><span><b>${(ability.events || []).length}</b> rows</span>`;
  }
  return `<span><b>${ability.casts || 0}</b> casts</span><span><b>${ability.hits || 0}</b> hits</span><span><b>${ability.min ? prettyNumber(ability.min) : 'n/a'}</b> min</span><span><b>${ability.max ? prettyNumber(ability.max) : 'n/a'}</b> max</span><span><b>${ability.avg ? prettyNumber(ability.avg) : 'n/a'}</b> avg</span>`;
}

function targetRowsForAbility(ability) {
  return (ability && ability.targets ? ability.targets : []).slice().sort((a, b) => Number(b.amount || b.hits || 0) - Number(a.amount || a.hits || 0));
}

function countMetricActionNoun() {
  if (state.meter === 'Interrupts') return 'interrupts';
  if (state.meter === 'Purges') return 'purges';
  if (state.meter === 'Dispels') return 'dispels';
  if (state.meter === 'CC Dispels') return 'CC clears';
  if (state.meter === 'CC Done') return 'CC events';
  return 'actions';
}

function countMetricTargetTitle() {
  if (state.meter === 'Purges') return 'Enemy buffs removed from';
  if (state.meter === 'Dispels') return 'Friendly targets cleaned';
  if (state.meter === 'CC Dispels') return 'CC cleared from';
  if (state.meter === 'Interrupts') return 'Targets interrupted';
  if (state.meter === 'CC Done') return 'Targets controlled';
  return 'Targets';
}

function countMetricEventLabel(event, ability) {
  const spell = event && (event.ability || ability && ability.name) || 'Action';
  const removed = event && (event.removedSpellName || event.extraSpellName) || '';
  const dispelSpell = event && event.dispelSpellName ? event.dispelSpellName : '';
  const interrupted = event && event.interruptedSpellName ? event.interruptedSpellName : '';
  if (state.meter === 'Purges') return removed ? `${dispelSpell || spell} purged ${removed}` : spell;
  if (state.meter === 'Dispels') return removed ? `${dispelSpell || spell} cleansed ${removed}` : spell;
  if (state.meter === 'CC Dispels') return removed ? `${dispelSpell || 'Dispel'} cleared ${removed}` : `${dispelSpell || 'Dispel'} cleared ${spell}`;
  if (state.meter === 'Interrupts') return interrupted ? `${spell} interrupted ${interrupted}` : spell;
  return spell;
}


function renderDeathMetricHealthStrip(row) {
  if (state.meter !== 'Deaths' || !row) return '';
  const hits = Array.isArray(row.lastHits) ? row.lastHits.slice(-12) : [];
  if (!hits.length) return '<div class="death-meter-strip empty-death-strip"><strong>No hit-by-hit health recap found.</strong><span>Import a fuller combat log to see the health drop before death.</span></div>';
  const clampPct = (value) => Math.max(0, Math.min(100, Number(value) || 0));
  const rows = hits.map((hit) => {
    const hasHp = hit.targetHealthPct != null && Number.isFinite(Number(hit.targetHealthPct));
    const hpPct = hasHp ? clampPct(hit.targetHealthPct) : 0;
    const hpText = hasHp ? `${Math.round(hpPct)}% HP` : 'HP unknown';
    return `<div class="death-meter-hit" style="--death-hp:${hpPct}%" title="${escapeHtml(hit.ability || 'Hit')} · ${escapeHtml(hpText)}">
      <span class="death-hit-health-bar" aria-hidden="true"></span>
      <b>${escapeHtml(hit.time || '')}</b>
      <span>${escapeHtml(hit.ability || 'Hit')}</span>
      <small>${coloredName(hit.source || '')}</small>
      <strong>${prettyNumber(hit.amount || 0)}${hasHp ? `<em>${Math.round(hpPct)}% HP</em>` : ''}</strong>
    </div>`;
  }).join('');
  return `<div class="death-meter-strip">
    <div class="death-meter-strip-head"><span>Last hits before death</span><strong>${escapeHtml(row.at || '')}</strong></div>
    <div class="death-meter-hit-list">${rows}</div>
  </div>`;
}


function renderMetricDetails(row, ability) {
  const abilities = row.abilities || [];
  const isCount = ['CC Done', 'Interrupts', 'Purges', 'Dispels', 'CC Dispels'].includes(state.meter);
  const noun = isCount ? 'events' : state.meter === 'Healing' ? 'healing' : state.meter === 'Taken' ? 'taken' : 'damage';
  const topAbility = abilities[0];
  const targetCount = abilities.reduce((sum, item) => sum + ((item.targets || []).length), 0);
  const eventCount = abilities.reduce((sum, item) => sum + ((item.events || []).length), 0);
  return `
    <div class="inspector-stack compact-meter-inspector">
      <div class="detail-heading inspector-heading-clean compact-player-summary">
        <div>
          <p class="small-label">${escapeHtml(metricTitle())} › Player</p>
          <h3>${coloredName(row.name)}</h3>
          <p class="caption">${escapeHtml(row.top || 'Select an ability below to view target breakdown.')}</p>
        </div>
        <div class="detail-total compact-total"><span>${escapeHtml(metricValueLabel(row))}</span><small>${escapeHtml(noun)}</small></div>
      </div>

      <div class="inspector-summary-grid compact-summary-grid">
        <div><p>Total</p><strong>${escapeHtml(metricValueLabel(row))}</strong></div>
        <div><p>Share</p><strong>${escapeHtml(row.percent || 0)}%</strong></div>
        <div><p>Top ability</p><strong>${escapeHtml(topAbility ? topAbility.name : 'n/a')}</strong></div>
        <div><p>Targets</p><strong>${targetCount || 'n/a'}</strong></div>
        <div><p>Events</p><strong>${eventCount || 'n/a'}</strong></div>
      </div>

      ${renderDeathMetricHealthStrip(row)}

      <div class="ability-inspector-header compact-ability-header">
        <div>
          <p class="small-label drill-label">Abilities</p>
          <h4>Ability breakdown</h4>
        </div>
        <span class="pill cyan">${abilities.length} abilities</span>
      </div>

      <div class="ability-card-list compact-ability-list">
        ${abilities.map((item) => renderAbilityCard(item, row, state.selectedMetricAbility === item.name, isCount, null)).join('') || '<div class="empty">No ability details found.</div>'}
      </div>
    </div>
  `;
}


function renderAbilityCard(item, row, isActive, isCount, selectedTargetRow) {
  const itemValue = Number(item.amount || item.count || item.actions || item.hits || 0);
  const rowValue = Number(row.amount || row.count || row.actions || row.hits || 0) || 1;
  const share = Math.max(0, Math.min(100, Math.round((itemValue / rowValue) * 100)));
  return `
    <div class="ability-card-item compact-ability-card ${isActive ? 'active selected' : ''}" style="--ability-share:${share}%">
      <button class="ability-card-button compact-ability-button" data-ability-name="${escapeHtml(item.name)}" title="Open target breakdown for ${escapeHtml(item.name)}">
        <div class="ability-main-line compact-ability-main-line">
          <span class="ability-name-block">${escapeHtml(item.name)}</span>
          <span class="ability-total-block">${isCount ? `${item.count || item.actions || item.hits || 0}x` : prettyNumber(item.amount || 0)} <small>${share}%</small></span>
        </div>
        <div class="ability-stat-line compact-ability-stat-line">${abilityStatSummary(item, isCount)}</div>
      </button>
    </div>
  `;
}


function renderMetricAbilityModal() {
  if (!state.selectedMetricAbility || state.active !== 'Matches') return '';
  const rawMatch = selectedMatch();
  const match = isSoloShuffleLobbyUiMatch(rawMatch) ? soloShuffleStatsMatch(rawMatch) : rawMatch;
  const rows = metricRowsForMatch(match);
  const row = selectedMetricRow(rows);
  const ability = selectedAbility(row);
  if (!row || !ability) return '';
  const isCount = ['CC Done', 'Interrupts', 'Purges', 'Dispels', 'CC Dispels'].includes(state.meter);
  const isAmount = ['Damage', 'Healing', 'Taken'].includes(state.meter);
  const itemValue = Number(ability.amount || ability.count || ability.actions || ability.hits || 0);
  const rowValue = Number(row.amount || row.count || row.actions || row.hits || 0) || 1;
  const share = Math.max(0, Math.min(100, Math.round((itemValue / rowValue) * 100)));
  const targets = targetRowsForAbility(ability);
  const playerTargets = targets.filter((target) => target.isPlayer !== false);
  const targetList = (isAmount && playerTargets.length ? playerTargets : targets).slice(0, 15);
  const events = (ability.events || []).slice().sort((a, b) => (Number(a.relativeSec) || 0) - (Number(b.relativeSec) || 0));
  const showEventList = isCount || state.meter === 'Deaths';
  const modalTitle = isCount ? countMetricTargetTitle() : 'Damage by player target';
  const targetTotal = targetList.reduce((sum, target) => sum + Number(target.amount || target.hits || target.count || 0), 0) || itemValue || 1;
  return `<div class="modal-scrim metric-modal-scrim" id="metric-ability-scrim">
    <div class="metric-ability-modal card" role="dialog" aria-modal="true">
      <div class="metric-modal-head">
        <div>
          <p class="small-label">${escapeHtml(metricTitle())} › ${coloredName(row.name)}</p>
          <h2>${escapeHtml(ability.name)}</h2>
          <p class="caption">${isCount ? `${countMetricTargetTitle()} and event timing for ${countMetricActionNoun()}.` : 'Player-target breakdown only. Pets, totems, guardians, and objects are hidden when player data is available.'}</p>
        </div>
        <button class="modal-close" data-close-metric-modal aria-label="Close">×</button>
      </div>
      <div class="metric-modal-stat-grid">
        <div><p>Total</p><strong>${isCount ? `${ability.count || ability.actions || ability.hits || 0}x` : prettyNumber(ability.amount || 0)}</strong></div>
        <div><p>Share</p><strong>${share}%</strong></div>
        <div><p>Casts</p><strong>${ability.casts || 0}</strong></div>
        <div><p>Hits</p><strong>${ability.hits || ability.count || ability.actions || 0}</strong></div>
        ${isCount ? `<div><p>Targets</p><strong>${targetList.length}</strong></div>` : `<div><p>Max</p><strong>${ability.max ? prettyNumber(ability.max) : 'n/a'}</strong></div><div><p>Avg</p><strong>${ability.avg ? prettyNumber(ability.avg) : 'n/a'}</strong></div>`}
      </div>
      <div class="metric-modal-section">
        <div class="metric-modal-section-head"><h3>${escapeHtml(modalTitle)}</h3><span>${targetList.length} shown</span></div>
        <div class="metric-target-table compact-target-table">
          ${targetList.map((target) => {
            const val = Number(target.amount || target.hits || target.count || 0);
            const pct = Math.round((val / targetTotal) * 100);
            const hits = target.hits || target.count || 0;
            const avg = target.amount && hits ? prettyNumber(Number(target.amount) / Math.max(1, Number(hits))) : '';
            return `<div class="metric-target-row" style="--target-share:${Math.max(2, Math.min(100, pct))}%"><span>${target.isPlayer === false ? escapeHtml(target.name) : coloredName(target.name)}</span><strong>${target.amount ? prettyNumber(target.amount) : `${hits}x`}</strong><small>${pct}%${hits ? ` · ${hits} hits` : ''}${avg ? ` · ${avg} avg` : ''}</small></div>`;
          }).join('') || '<div class="empty">No target data for this ability.</div>'}
        </div>
      </div>
      ${showEventList ? `<div class="metric-modal-section">
        <div class="metric-modal-section-head"><h3>Event timing</h3><span>${Math.min(events.length, 80)} rows</span></div>
        <div class="metric-event-list compact-event-list">
          ${events.slice(0, 80).map((event) => `<div class="metric-event-row"><b>${escapeHtml(event.time || '')}</b><span>${escapeHtml(countMetricEventLabel(event, ability))}</span><span>${coloredShortName(event.source || row.name)} → ${event.targetIsPlayer === false ? escapeHtml(event.target || 'Unknown') : coloredShortName(event.target || 'Unknown')}</span><strong>${event.amount ? prettyNumber(event.amount) : ''}</strong></div>`).join('') || '<div class="empty">No event rows available.</div>'}
        </div>
      </div>` : ''}
    </div>
  </div>`;
}



function renderMeterRow(row, index) {
  const active = (selectedMetricRow(metricRowsForMatch(selectedMatch())) || {}).name === row.name;
  const percent = Math.min(100, Number(row.barPercent || row.percent) || 1);
  const hasPets = !row.scoreboardMetric && row.petBreakdown && row.petBreakdown.length;
  const directLine = hasPets ? `<div class="pet-group-line"><span>Player</span><strong>${prettyNumber(row.directAmount || 0)}</strong></div>` : '';
  const petLines = hasPets ? `<details class="pet-breakdown" onclick="event.stopPropagation()"><summary>${row.petBreakdown.length} pet${row.petBreakdown.length === 1 ? '' : 's'} · ${prettyNumber(row.petAmount || 0)}</summary><div class="pet-breakdown-list">${directLine}${row.petBreakdown.map((pet) => `<div class="pet-group-line"><span>${escapeHtml(pet.name)}${pet.top ? `<small>${escapeHtml(pet.top)}</small>` : ''}</span><strong>${prettyNumber(pet.amount || 0)}</strong></div>`).join('')}</div></details>` : '';
  return `<div class="meter-row-wrap">
    <button class="meter-row drill-row actor-meter-row ${active ? 'active' : ''}" data-meter-actor="${escapeHtml(row.name)}">
      <div class="meter-top">
        <div class="actor-left"><div class="rank">${index + 1}</div><div class="actor-copy"><p class="meter-name">${coloredName(row.name)}</p><p class="meter-detail">${escapeHtml(row.top || '')}</p></div></div>
        <div class="meter-number">${escapeHtml(metricValueLabel(row))}<small>${escapeHtml(row.percent || '')}%</small></div>
      </div>
      <div class="progress"><span style="width:${percent}%"></span></div>
    </button>
    ${petLines}
  </div>`;
}


function renderEvent(event) {
  return `<div class="event ${escapeHtml(event.tone || 'control')}"><div class="time">${escapeHtml(event.time)}</div><div style="flex:1"><div class="who">${coloredName(event.actor)}</div><div class="ability">${escapeHtml(event.ability)}</div></div>${pill(event.team || 'Observed', event.team === 'You' ? 'emerald' : 'amber')}</div>`;
}

function renderCc(chain) {
  const rawResult = String(chain && chain.result || '');
  const parts = rawResult.split(' controlled ');
  const actor = chain.actor || parts[0] || '';
  const target = chain.target || parts[1] || 'Unknown';
  const time = chain.time || (Number.isFinite(Number(chain.relativeSec)) ? formatElapsed(Number(chain.relativeSec)) : '0:00');
  const duration = Number(chain.duration || 0);
  return `<div class="cc-card"><div class="cc-card-head"><h4>${escapeHtml(chain.chain || 'Control')}</h4><span class="cc-card-pills">${pill(time, 'cyan')}${duration ? pill(`${duration}s`, 'violet') : ''}</span></div><p>${actor ? `${coloredShortName(actor)} controlled ` : 'Target: '}${coloredShortName(target)}</p></div>`;
}

function renderInterrupt(item) {
  const time = item.time || (Number.isFinite(Number(item.relativeSec)) ? formatElapsed(Number(item.relativeSec)) : '0:00');
  const interrupted = item.interrupted || item.interruptedSpellName || '';
  return `<div class="cc-card interrupt"><div class="cc-card-head"><h4>Interrupt</h4>${pill(time, 'cyan')}</div><p>${coloredShortName(item.actor)} interrupted ${coloredShortName(item.target)}</p><p>${escapeHtml(item.ability || '')}${interrupted ? ` stopped ${escapeHtml(interrupted)}` : ''}</p></div>`;
}

function renderDeath(death) {
  const hits = death.lastHits || [];
  const recap = death.recap || [];
  const clampPct = (value) => Math.max(0, Math.min(100, Number(value) || 0));
  const hitRows = hits.map((hit) => {
    const hasHp = hit.targetHealthPct != null && Number.isFinite(Number(hit.targetHealthPct));
    const hpPct = hasHp ? clampPct(hit.targetHealthPct) : 0;
    const hpLabel = hasHp ? `${Math.round(hpPct)}% HP` : 'HP unknown';
    return `<div class="death-line death-hit" style="--death-hp:${hpPct}%" title="Target health after hit: ${escapeHtml(hpLabel)}">
      <span class="death-hit-health-bar" aria-hidden="true"></span>
      <span class="death-hit-time">${escapeHtml(hit.time || '')}</span>
      <strong class="death-hit-ability">${escapeHtml(hit.ability || 'Hit')}</strong>
      <span class="death-hit-source">${coloredName(hit.source || '')}</span>
      <span class="death-hit-right"><b>${prettyNumber(hit.amount || 0)}</b>${hasHp ? `<em>${Math.round(hpPct)}% HP</em>` : ''}</span>
    </div>`;
  }).join('');
  const fallback = recap.map((line) => `<div class="death-line">${escapeHtml(line)}</div>`).join('');
  return `<div class="death-victim"><strong>${coloredName(death.victim || 'No death detected')}</strong><br><span class="caption">Death at ${escapeHtml(death.at || 'n/a')}</span></div><div class="death-list">${hitRows || fallback || '<div class="empty">No death recap yet.</div>'}</div><div class="death-note">${escapeHtml(death.note || 'No death note yet.')}</div>`;
}


    return {
      metricTabSections,
      metricTabs,
      renderMetricTabSections,
      amountMetricNeedsTargetToggle,
      scoreboardRowsForMatch,
      metricUsesFinalScoreboard,
      metricRowsForMatch,
      rowsFromCcChainsFallback,
      selectedMetricRow,
      selectedAbility,
      metricTitle,
      metricValueLabel,
      renderMetricPanel,
      abilityStatSummary,
      targetRowsForAbility,
      countMetricActionNoun,
      countMetricTargetTitle,
      countMetricEventLabel,
      renderDeathMetricHealthStrip,
      renderMetricDetails,
      renderAbilityCard,
      renderMetricAbilityModal,
      renderMeterRow,
      renderEvent,
      renderCc,
      renderInterrupt,
      renderDeath
    };
  }

  window.LastCallMetricsView = { createMetricsViewTools };
})();
