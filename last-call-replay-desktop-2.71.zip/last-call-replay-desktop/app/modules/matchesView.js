(function () {
  'use strict';

  function createMatchesViewTools(deps = {}) {
    const state = deps.state || {};
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const shortNameKey = deps.shortNameKey || ((value) => String(value || '').toLowerCase().trim());
    const coloredShortName = deps.coloredShortName || ((name) => escapeHtml(String(name || '').split('-')[0] || 'Unknown'));
    const renderSoloShuffleRoundDots = deps.renderSoloShuffleRoundDots || (() => '');
    const soloShuffleRounds = deps.soloShuffleRounds || (() => []);
    const soloShuffleSummaryText = deps.soloShuffleSummaryText || (() => '0W - 0L');
    const isSoloShuffleLobbyUiMatch = deps.isSoloShuffleLobbyUiMatch || (() => false);
    const renderMatchTeams = deps.renderMatchTeams || (() => '');
    const matchScoreboardListButton = deps.matchScoreboardListButton || (() => '');
    const matchVideoPath = deps.matchVideoPath || (() => '');
    const isFavoriteMatch = deps.isFavoriteMatch || (() => false);
    const resultCardClass = deps.resultCardClass || (() => '');
    const matchClock = deps.matchClock || (() => '');
    const displayMatchType = deps.displayMatchType || (() => 'PvP');
    const matchTeamSizePill = deps.matchTeamSizePill || (() => '');
    const pill = deps.pill || ((text) => `<span>${escapeHtml(text)}</span>`);
    const matchDownloadClipButton = deps.matchDownloadClipButton || (() => '');
    const filteredMatches = deps.filteredMatches || (() => []);
    const sortMatchesForLibrary = deps.sortMatchesForLibrary || ((items) => (items || []).slice());
    const visibleLibraryMatch = deps.visibleLibraryMatch || (() => true);
    const getMatches = deps.getMatches || (() => []);

    function soloShuffleLobbyPlayers(match = {}) {
      const fromRounds = soloShuffleRounds(match).flatMap((round) => [
        ...(Array.isArray(round.myComp) ? round.myComp : []),
        ...(Array.isArray(round.enemyComp) ? round.enemyComp : [])
      ]);
      const seen = new Set();
      const players = [];
      for (const name of [
        ...(Array.isArray(match.participants) ? match.participants : []),
        ...(Array.isArray(match.ownNames) ? match.ownNames : []),
        ...fromRounds
      ].filter(Boolean)) {
        const key = shortNameKey(name);
        if (!key || seen.has(key)) continue;
        seen.add(key);
        players.push(name);
      }
      return players.slice(0, 6);
    }

    function renderSoloShuffleLobbyPlayers(match) {
      const players = soloShuffleLobbyPlayers(match);
      return `
        <div class="solo-lobby-player-card">
          <div class="solo-lobby-player-head"><span>Lobby players</span><small>${players.length || 0}/6 seen</small></div>
          <div class="solo-lobby-player-list">
            ${players.map((name) => `<span class="solo-lobby-player-pill">${coloredShortName(name, match)}</span>`).join('') || '<span class="muted">Players unknown</span>'}
          </div>
        </div>
      `;
    }

    function renderSoloShuffleInlineSummary(match) {
      if (!isSoloShuffleLobbyUiMatch(match)) return '';
      const detected = Number(match.soloShuffleDetectedRoundCount || 0) || soloShuffleRounds(match).length;
      const status = `${detected} round${detected === 1 ? '' : 's'}${match.soloShuffleIncomplete ? ' · incomplete' : ''}`;
      return `
        <div class="solo-lobby-quick-summary">
          <div class="solo-lobby-quick-copy"><strong>${escapeHtml(soloShuffleSummaryText(match))}</strong><span>${escapeHtml(status)}</span></div>
          ${renderSoloShuffleRoundDots(match, false, 'compact')}
        </div>
      `;
    }

    function matchLibraryTeamArea(match) {
      const scoreboard = matchScoreboardListButton(match);
      if (isSoloShuffleLobbyUiMatch(match)) {
        return `<div class="match-library-team-area solo-lobby-match-area">${renderSoloShuffleLobbyPlayers(match)}${renderSoloShuffleInlineSummary(match)}${scoreboard ? `<div class="match-team-inline-actions">${scoreboard}</div>` : ''}</div>`;
      }
      const teamArea = renderMatchTeams(match);
      return `<div class="match-library-team-area">${teamArea}${scoreboard ? `<div class="match-team-inline-actions">${scoreboard}</div>` : ''}</div>`;
    }

    function renderMatchLibraryCard(match) {
      const videoPath = matchVideoPath(match);
      const favoriteClass = isFavoriteMatch(match) ? ' favorite-video-thumb' : '';
      const favoriteTitle = isFavoriteMatch(match) ? ' title="Favorited match" aria-label="Favorited match video status"' : '';
      return `
        <button class="match-library-card ${resultCardClass(match)} ${isSoloShuffleLobbyUiMatch(match) ? 'solo-shuffle-lobby-card' : ''}" data-match="${escapeHtml(match.id)}">
          <div class="match-video-thumb ${videoPath ? 'has-video' : 'no-video'}${favoriteClass}"${favoriteTitle}>
            ${videoPath ? '<span>▶</span><small>Video</small>' : '<span>◇</span><small>No video</small>'}
          </div>
          <div class="match-library-main">
            <div class="match-library-meta">
              <div class="match-library-topline">
                <strong>${escapeHtml(matchClock(match) || 'Unknown time')}</strong>
                ${pill(displayMatchType(match), 'cyan')}
                ${matchTeamSizePill(match)}
              </div>
              <h3>${escapeHtml(match.map || 'Unknown map')}</h3>
            </div>
            ${matchLibraryTeamArea(match)}
          </div>
          <div class="match-library-side">
            <span>${escapeHtml(match.duration || '')}</span>
            ${matchDownloadClipButton(match)}
          </div>
        </button>
      `;
    }

    function visibleMatchNavigation(selectedId = state.selectedId) {
      const selected = String(selectedId || '');
      let list = filteredMatches();
      let index = list.findIndex((match) => String(match && match.id || '') === selected);
      if (index < 0) {
        list = sortMatchesForLibrary((getMatches() || []).filter(visibleLibraryMatch));
        index = list.findIndex((match) => String(match && match.id || '') === selected);
      }
      if (index < 0) return { prev: null, next: null, index: 0, total: list.length, list };
      return {
        prev: index > 0 ? list[index - 1] : null,
        next: index < list.length - 1 ? list[index + 1] : null,
        index: index + 1,
        total: list.length,
        list
      };
    }

    function renderMatchDetailNav(selectedMatch) {
      if (!selectedMatch) return '';
      const nav = visibleMatchNavigation(selectedMatch.id);
      const label = nav.total ? `${nav.index}/${nav.total}` : '';
      return `
        <div class="match-detail-nav-group" aria-label="Match navigation">
          <button class="btn match-detail-nav-btn" data-match-nav="newer" ${nav.prev ? '' : 'disabled'} title="Next newer match">← Next</button>
          <span class="match-detail-nav-count">${escapeHtml(label)}</span>
          <button class="btn match-detail-nav-btn" data-match-nav="older" ${nav.next ? '' : 'disabled'} title="Previous older match">Previous →</button>
        </div>
      `;
    }

    return {
      soloShuffleLobbyPlayers,
      renderSoloShuffleLobbyPlayers,
      renderSoloShuffleInlineSummary,
      matchLibraryTeamArea,
      renderMatchLibraryCard,
      visibleMatchNavigation,
      renderMatchDetailNav
    };
  }

  window.LastCallMatchesView = { createMatchesViewTools };
})();
