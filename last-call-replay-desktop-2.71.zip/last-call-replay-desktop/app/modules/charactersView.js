(function () {
  'use strict';

  function createCharactersViewTools(deps = {}) {
    const state = deps.state || {};
    const shortCharacterName = deps.shortCharacterName || ((value) => String(value || '').split('-')[0] || 'Unknown');
    const classMetaForName = deps.classMetaForName || (() => ({}));
    const playerMeetingDedupeKey = deps.playerMeetingDedupeKey || (() => '');
    const ownNameSetForMatch = deps.ownNameSetForMatch || (() => new Set());
    const effectiveMatchType = deps.effectiveMatchType || ((match) => match && (match.matchType || match.bracket || 'PvP Match') || 'PvP Match');
    const displayBracketLabel = deps.displayBracketLabel || ((value) => value || 'Unknown');
    const escapeHtml = deps.escapeHtml || ((value) => String(value ?? ''));
    const renderCharacterImportHelpCard = deps.renderCharacterImportHelpCard || (() => '');
    const renderNoDataBox = deps.renderNoDataBox || (() => '<div class="empty">No data yet.</div>');
    const rememberedSelectedCharacterKey = deps.rememberedSelectedCharacterKey || (() => '');
    const pvpHelperSyncHelpIcon = deps.pvpHelperSyncHelpIcon || (() => '');
    const statCard = deps.statCard || ((icon, label, value, caption) => `<div class="stat-card"><p>${escapeHtml(label)}</p><b>${escapeHtml(value)}</b><small>${escapeHtml(caption)}</small></div>`);
    const pill = deps.pill || ((text) => `<span class="pill">${escapeHtml(text)}</span>`);
    const displayMatchType = deps.displayMatchType || ((match) => match && (match.matchType || match.bracket || 'PvP Match') || 'PvP Match');
    const displayResult = deps.displayResult || ((value) => value || 'Parsed');

    function normalizeIdentityText(value) {
      return String(value || '').toLowerCase().split('-')[0].replace(/[^a-z0-9]/g, '').trim();
    }

    function sameCharacterIdentity(left, right) {
      const a = normalizeIdentityText(left);
      const b = normalizeIdentityText(right);
      return Boolean(a && b && a === b);
    }

    function characterNameKey(value) {
      return normalizeIdentityText(value || 'Unknown') || 'unknown';
    }

    function dedupeCharacterSnapshots(list = []) {
      const seen = new Set();
      const out = [];
      for (const snap of list || []) {
        if (!snap) continue;
        const stableKey = `${characterNameKey(snap.character)}|${normalizeBracketForUi(snap.bracket)}|${ratingSpecLabel(snap)}|${snap.capturedAt || ''}|${snap.rating ?? ''}|${snap.seasonPlayed ?? ''}|${snap.sourceType || snap.sourceFile || ''}`;
        if (seen.has(stableKey)) continue;
        seen.add(stableKey);
        out.push({ ...snap, bracket: normalizeBracketForUi(snap.bracket) });
      }
      return out;
    }

    function characterDisplayKey(name, spec) {
      return `${shortCharacterName(name || 'Unknown')}|character`;
    }

    function characterPrettyName(key) {
      const [name] = String(key || '').split('|');
      if (String(key || '') === 'All') return 'All Characters';
      return shortCharacterName(name || 'Unknown');
    }

    function normalizeBracketForUi(value) {
      const raw = String(value || '').trim();
      const lower = raw.toLowerCase();
      if (lower.includes('2v2') || lower === '2s' || lower === '2' || /^2['’]?s$/.test(lower)) return '2v2';
      if (lower.includes('3v3') || lower === '3s' || lower === '3' || /^3['’]?s$/.test(lower)) return '3v3';
      if (lower.includes('shuffle')) return 'Solo Shuffle';
      if (lower.includes('blitz')) return 'Blitz';
      if (lower.includes('rated battleground') || lower === 'rbg') return 'Rated Battleground';
      if (lower.includes('random battleground')) return 'Random Battleground';
      if (lower.includes('skirm')) return 'Skirmish';
      return raw || 'Unknown';
    }

    const RATED_CHARACTER_RATING_BRACKETS = new Set(['2v2', '3v3', 'Solo Shuffle', 'Blitz', 'Rated Battleground']);

    function isRatedCharacterRatingBracket(value) {
      return RATED_CHARACTER_RATING_BRACKETS.has(normalizeBracketForUi(value));
    }

    function hasUsableRatingValue(value) {
      return value !== null && value !== undefined && value !== '' && Number.isFinite(Number(value)) && Number(value) > 0;
    }

    function snapshotHasRatedRating(snap) {
      return !!snap && isRatedCharacterRatingBracket(snap.bracket) && hasUsableRatingValue(snap.rating);
    }

    function snapshotCharacterKey(snapshot) {
      return characterDisplayKey(snapshot.character, snapshot.specName || snapshot.spec || 'Spec unknown');
    }

    function classMetaForCharacter(name, match = {}) {
      const exact = classMetaForName(name, match) || classMetaForName(shortCharacterName(name), match);
      if (exact) return exact;
      const wanted = normalizeIdentityText(name);
      if (match && match.classByName && wanted) {
        for (const [candidate, meta] of Object.entries(match.classByName || {})) {
          if (sameCharacterIdentity(candidate, name)) return meta || {};
        }
      }
      for (const row of match && match.scoreboardPlayers || []) {
        if (!row) continue;
        if (sameCharacterIdentity(row.fullName || row.name, name)) {
          const className = row.className || row.classFile || '';
          return {
            className,
            classColor: row.classColor || '',
            specName: row.specName || row.spec || ''
          };
        }
      }
      return {};
    }

    function confidentCharacterNamesForMatch(match = {}) {
      const names = [];
      const add = (value) => {
        const raw = String(value || '').trim();
        if (!raw || /^unknown/i.test(raw)) return;
        if (!names.some((existing) => sameCharacterIdentity(existing, raw))) names.push(raw);
      };
      add(match.alt);
      add(match.character);
      add(match.playerName);
      add(match.playerFullName);
      for (const value of match.ownNames || []) add(value);
      const sb = match.addonScoreboard || {};
      const playerScore = sb.playerScore || {};
      add(playerScore.fullName || playerScore.name);
      add(sb.playerFullName || sb.player || sb.playerName);
      const scalar = sb.rawFields && sb.rawFields.scalarFields ? sb.rawFields.scalarFields : {};
      add(scalar.playerFullName || scalar.player || scalar.playerName);
      return names;
    }

    function matchHasConfidentCharacter(match = {}, character = '') {
      return confidentCharacterNamesForMatch(match).some((name) => sameCharacterIdentity(name, character));
    }

    function matchSortTime(match = {}) {
      const direct = Number(match.startMs || match.gameStartMs || match.endMs || 0);
      if (Number.isFinite(direct) && direct > 0) return direct;
      const parsed = Date.parse(match.startIso || match.gameStartIso || match.endIso || match.capturedAt || '');
      return Number.isFinite(parsed) ? parsed : 0;
    }

    function matchSourceBadges(match = {}) {
      const sources = new Set((match.dataSources || []).map((x) => String(x || '').toLowerCase()));
      const badges = [];
      if (match.createdFromRealLog || sources.has('combatlog') || sources.has('combat-log') || sources.has('log')) badges.push(pill('Log', 'cyan'));
      if (match.createdFromAddon || match.addonScoreboard || sources.has('addonscoreboard')) badges.push(pill('Scoreboard', 'violet'));
      if (match.videoPath || match.vodId || sources.has('video') || sources.has('vod')) badges.push(pill('VOD', 'amber'));
      if (match.resultConflictNeedsReview || match.resultConflict) badges.push(pill('Needs review', 'amber'));
      if (match.endInferred || match.captureReason) badges.push(pill(match.endInferred ? 'Inferred end' : 'Partial', 'amber'));
      if (!badges.length) badges.push(pill('Imported', 'cyan'));
      return `<span class="match-source-badges">${badges.join('')}</span>`;
    }

    function ratedBracketSnapshotGroups(profile, bracket = 'All') {
      const groups = new Map();
      for (const snap of filteredRatedCharacterSnapshots(profile, bracket, 'All Time')) {
        const key = ratingSeriesKey(snap);
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(snap);
      }
      for (const rows of groups.values()) rows.sort((a, b) => Date.parse(a.capturedAt || 0) - Date.parse(b.capturedAt || 0));
      return groups;
    }

    function buildCharacterProfiles() {
      const profiles = new Map();
      const ensure = (key, seed = {}) => {
        const displayName = shortCharacterName(seed.name || String(key).split('|')[0] || 'Unknown');
        if (!profiles.has(key)) {
          profiles.set(key, {
            key,
            name: displayName,
            spec: seed.spec || '',
            specs: new Set(seed.spec && seed.spec !== 'Spec unknown' ? [seed.spec] : []),
            className: seed.className || '',
            classColor: seed.classColor || '',
            matches: [],
            matchIds: new Set(),
            bracketStats: new Map(),
            snapshots: [],
            snapshotIds: new Set()
          });
        }
        const p = profiles.get(key);
        if (!p.className && seed.className) p.className = seed.className;
        if (!p.classColor && seed.classColor) p.classColor = seed.classColor;
        if (seed.spec && seed.spec !== 'Spec unknown') p.specs.add(seed.spec);
        p.spec = p.specs.size > 1 ? 'Multiple specs' : (Array.from(p.specs)[0] || p.spec || 'Spec unknown');
        return p;
      };

      for (const match of state.matches || []) {
        const characterNames = confidentCharacterNamesForMatch(match);
        for (const name of characterNames) {
          const meta = classMetaForCharacter(name, match) || {};
          const spec = match.spec && match.spec !== 'Spec unknown' ? match.spec : (meta.specName || 'Spec unknown');
          const key = characterDisplayKey(name, spec);
          const profile = ensure(key, { name, spec, className: meta.className, classColor: meta.classColor });
          const matchKey = playerMeetingDedupeKey(match, name) || match.id || `${name}|${match.startIso || match.capturedAt || ''}|${match.map || ''}`;
          if (!profile.matchIds.has(matchKey)) {
            profile.matchIds.add(matchKey);
            profile.matches.push(match);
            const bracket = normalizeBracketForUi(effectiveMatchType(match));
            const stats = profile.bracketStats.get(bracket) || { bracket, played: 0, wins: 0, losses: 0, unscored: 0, duration: 0, deaths: 0, kills: 0 };
            stats.played += 1;
            stats.duration += Number(match.durationSec || 0);
            if (match.result === 'Win') stats.wins += 1;
            else if (match.result === 'Loss') stats.losses += 1;
            else stats.unscored += 1;
            profile.bracketStats.set(bracket, stats);
          }
        }
      }

      for (const snap of dedupeCharacterSnapshots(state.characterSnapshots || [])) {
        const key = snapshotCharacterKey(snap);
        const profile = ensure(key, { name: snap.character, spec: snap.specName || 'Spec unknown', className: snap.className, classColor: snap.classColor });
        const snapKey = snap.id || `${key}|${snap.bracket || ''}|${snap.capturedAt || ''}|${snap.rating ?? ''}`;
        if (!profile.snapshotIds.has(snapKey)) {
          profile.snapshotIds.add(snapKey);
          profile.snapshots.push(snap);
        }
      }

      return Array.from(profiles.values()).map((profile) => {
        const { matchIds, snapshotIds, specs, ...clean } = profile;
        return clean;
      }).sort((a, b) => {
        const at = Math.max(...a.matches.map((m) => Date.parse(m.startIso || 0)).filter(Boolean), ...a.snapshots.map((x) => Date.parse(x.capturedAt || 0)).filter(Boolean), 0);
        const bt = Math.max(...b.matches.map((m) => Date.parse(m.startIso || 0)).filter(Boolean), ...b.snapshots.map((x) => Date.parse(x.capturedAt || 0)).filter(Boolean), 0);
        return bt - at || a.name.localeCompare(b.name);
      });
    }

    function buildAllCharactersProfile(profiles = []) {
      const all = {
        key: 'All',
        name: 'All Characters',
        spec: '',
        className: '',
        classColor: '',
        matches: [],
        bracketStats: new Map(),
        snapshots: []
      };
      const matchIds = new Set();
      const snapIds = new Set();
      for (const profile of profiles || []) {
        for (const match of profile.matches || []) {
          const matchKey = playerMeetingDedupeKey(match, match && (match.alt || match.character || 'all')) || (match && match.id);
          if (!match || matchIds.has(matchKey)) continue;
          matchIds.add(matchKey);
          all.matches.push(match);
        }
        for (const snap of profile.snapshots || []) {
          const id = snap && (snap.id || `${snap.character}|${snap.bracket}|${snap.capturedAt}|${snap.rating}`);
          if (!snap || snapIds.has(id)) continue;
          snapIds.add(id);
          all.snapshots.push(snap);
        }
        for (const [bracket, stats] of profile.bracketStats || []) {
          const next = all.bracketStats.get(bracket) || { bracket, played: 0, wins: 0, losses: 0, unscored: 0, duration: 0, deaths: 0, kills: 0 };
          next.played += Number(stats.played || 0);
          next.wins += Number(stats.wins || 0);
          next.losses += Number(stats.losses || 0);
          next.unscored += Number(stats.unscored || 0);
          next.duration += Number(stats.duration || 0);
          next.deaths += Number(stats.deaths || 0);
          next.kills += Number(stats.kills || 0);
          all.bracketStats.set(bracket, next);
        }
      }
      all.matches.sort((a, b) => (Date.parse(b.startIso || 0) || 0) - (Date.parse(a.startIso || 0) || 0));
      all.snapshots.sort((a, b) => (Date.parse(b.capturedAt || 0) || 0) - (Date.parse(a.capturedAt || 0) || 0));
      return all;
    }

    function characterBracketOptions(profile) {
      const values = new Set();
      for (const key of profile.bracketStats.keys()) {
        const normalized = normalizeBracketForUi(key);
        if (isRatedCharacterRatingBracket(normalized)) values.add(normalized);
      }
      for (const snap of profile.snapshots) {
        const normalized = normalizeBracketForUi(snap.bracket);
        if (snapshotHasRatedRating({ ...snap, bracket: normalized })) values.add(normalized);
      }
      const order = ['2v2', '3v3', 'Solo Shuffle', 'Blitz', 'Rated Battleground'];
      return Array.from(values).sort((a, b) => (order.indexOf(a) === -1 ? 999 : order.indexOf(a)) - (order.indexOf(b) === -1 ? 999 : order.indexOf(b)) || a.localeCompare(b));
    }

    function latestSnapshotFor(profile, bracket) {
      const snaps = (profile.snapshots || [])
        .filter((snap) => snapshotHasRatedRating(snap))
        .filter((snap) => bracket === 'All' || normalizeBracketForUi(snap.bracket) === bracket)
        .sort((a, b) => Date.parse(b.capturedAt || 0) - Date.parse(a.capturedAt || 0));
      return snaps[0] || null;
    }

    function timeframeStart(timeframe, now = Date.now()) {
      const day = 24 * 60 * 60 * 1000;
      if (timeframe === 'Session') return now - day;
      if (timeframe === '7 Days') return now - 7 * day;
      if (timeframe === '30 Days') return now - 30 * day;
      if (timeframe === 'Season') return now - 180 * day;
      return 0;
    }

    function filteredCharacterMatches(profile, bracket = 'All', timeframe = 'Season') {
      const start = timeframeStart(timeframe);
      const seen = new Set();
      return (profile.matches || []).filter((match) => {
        const typeOkay = bracket === 'All' || normalizeBracketForUi(effectiveMatchType(match)) === bracket;
        const t = matchSortTime(match);
        const timeOkay = !start || !t || t >= start;
        if (!typeOkay || !timeOkay) return false;
        if (profile.key !== 'All' && !matchHasConfidentCharacter(match, profile.name)) return false;
        const key = playerMeetingDedupeKey(match, match && (match.alt || match.character || profile.name || '')) || match.id;
        if (key && seen.has(key)) return false;
        if (key) seen.add(key);
        return true;
      }).sort((a, b) => matchSortTime(b) - matchSortTime(a));
    }

    function filteredCharacterSnapshots(profile, bracket = 'All', timeframe = 'Season') {
      const start = timeframeStart(timeframe);
      return (profile.snapshots || []).filter((snap) => {
        const typeOkay = bracket === 'All' || normalizeBracketForUi(snap.bracket) === normalizeBracketForUi(bracket);
        const t = Date.parse(snap.capturedAt || 0) || 0;
        const timeOkay = !start || !t || t >= start;
        return typeOkay && timeOkay;
      }).sort((a, b) => Date.parse(a.capturedAt || 0) - Date.parse(b.capturedAt || 0));
    }

    function filteredRatedCharacterSnapshots(profile, bracket = 'All', timeframe = 'Season') {
      return filteredCharacterSnapshots(profile, bracket, timeframe).filter(snapshotHasRatedRating);
    }

    function bestCurrentRatingSnapshot(profile, bracket = 'All') {
      const latestBySeries = new Map();
      for (const snap of filteredRatedCharacterSnapshots(profile, bracket, 'All Time')) {
        const key = ratingSeriesKey(snap);
        const current = latestBySeries.get(key);
        const currentTime = Date.parse((current && current.capturedAt) || 0) || 0;
        const snapTime = Date.parse(snap.capturedAt || 0) || 0;
        if (!current || snapTime >= currentTime) latestBySeries.set(key, snap);
      }
      let best = null;
      for (const [key, snap] of latestBySeries.entries()) {
        if (!best || Number(snap.rating) > Number(best.snap.rating)) best = { key, snap, label: ratingSeriesLabelFromKey(key) };
      }
      return best;
    }

    function characterNameHtml(profile) {
      if (profile && profile.key === 'All') return '<span class="class-colored-name">All Characters</span>';
      const color = profile.classColor || '';
      const title = [profile.spec, profile.className].filter(Boolean).join(' ');
      return `<span class="class-colored-name" ${color ? `style="color:${escapeHtml(color)}"` : ''} ${title ? `title="${escapeHtml(title)}"` : ''}>${escapeHtml(shortCharacterName(profile.name))}</span>`;
    }

    function ratingAxisDateLabel(time) {
      const date = new Date(time);
      if (Number.isNaN(date.getTime())) return 'Unknown';
      return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
    }


    function ratingSpecLabel(snap) {
      const spec = String(snap && (snap.specName || snap.spec || snap.specialization || snap.activeSpecName || '') || '').trim();
      return spec && spec !== 'Spec unknown' ? spec : 'Spec unknown';
    }

    function ratingSeriesKey(snap) {
      const bracket = normalizeBracketForUi(snap && snap.bracket);
      const spec = ratingSpecLabel(snap);
      if (bracket === 'Solo Shuffle' || bracket === 'Blitz') return `${bracket}|${spec}`;
      return bracket || 'Unknown';
    }

    function ratingSeriesLabelFromKey(key) {
      const [bracket, spec] = String(key || '').split('|');
      if ((bracket === 'Solo Shuffle' || bracket === 'Blitz') && spec && spec !== 'Spec unknown') return `${displayBracketLabel(bracket)} · ${spec}`;
      return displayBracketLabel(bracket || 'Unknown');
    }

    function stableHash(text) {
      let hash = 0;
      for (const char of String(text || '')) hash = ((hash << 5) - hash + char.charCodeAt(0)) | 0;
      return Math.abs(hash);
    }

    function ratingSeriesColor(key, index = 0) {
      const bracket = String(key || '').split('|')[0] || 'Unknown';
      const base = {
        '2v2': '#67e8f9',
        '3v3': '#a78bfa',
        'Rated Battleground': '#34d399',
        'Solo Shuffle': '#fbbf24',
        'Blitz': '#fb7185',
        'Unknown': '#94a3b8'
      };
      if ((bracket === 'Solo Shuffle' || bracket === 'Blitz') && String(key || '').includes('|')) {
        const palette = ['#fbbf24', '#fb7185', '#67e8f9', '#a78bfa', '#34d399', '#f472b6', '#38bdf8', '#c084fc'];
        return palette[(stableHash(key) + index) % palette.length];
      }
      return base[bracket] || base.Unknown;
    }

    function ratingSeriesDash(key, index = 0) {
      const bracket = String(key || '').split('|')[0] || 'Unknown';
      if (bracket === 'Solo Shuffle' || bracket === 'Blitz') {
        const patterns = ['7 5', '2 6', '10 4 2 4', '4 4', '12 5'];
        return patterns[(stableHash(key) + index) % patterns.length];
      }
      return '';
    }

    function renderRatingSparkline(profile, bracket, timeframe) {
      const snaps = filteredRatedCharacterSnapshots(profile, bracket, timeframe)
        .filter((snap) => Number.isFinite(Date.parse(snap.capturedAt || 0)));
      if (!snaps.length) return `<div class="empty slim-empty">No rated PvP rating snapshots for this filter yet. Random BGs, skirmishes, and unrated battlegrounds are ignored.</div>`;

      const seriesMap = new Map();
      for (const snap of snaps) {
        const key = ratingSeriesKey(snap);
        if (!seriesMap.has(key)) seriesMap.set(key, []);
        seriesMap.get(key).push(snap);
      }

      const bracketOrder = ['2v2', '3v3', 'Rated Battleground', 'Solo Shuffle', 'Blitz', 'Unknown'];
      const series = Array.from(seriesMap.entries())
        .map(([key, items]) => ({
          key,
          label: ratingSeriesLabelFromKey(key),
          items: items.slice().sort((a, b) => Date.parse(a.capturedAt || 0) - Date.parse(b.capturedAt || 0))
        }))
        .sort((a, b) => {
          const ab = String(a.key).split('|')[0];
          const bb = String(b.key).split('|')[0];
          const ai = bracketOrder.includes(ab) ? bracketOrder.indexOf(ab) : 999;
          const bi = bracketOrder.includes(bb) ? bracketOrder.indexOf(bb) : 999;
          return ai - bi || a.label.localeCompare(b.label);
        });

      const width = 920, height = 306;
      const padLeft = 78, padRight = 28, padTop = 26, padBottom = 58;
      const chartWidth = width - padLeft - padRight;
      const chartHeight = height - padTop - padBottom;
      const times = snaps.map((s) => Date.parse(s.capturedAt || 0));
      const ratings = snaps.map((s) => Number(s.rating));
      const minT = Math.min(...times), maxT = Math.max(...times);
      const minR = Math.min(...ratings), maxR = Math.max(...ratings);
      const ratingPad = Math.max(12, Math.ceil((maxR - minR) * 0.08));
      const axisMinR = Math.max(0, Math.floor((minR - ratingPad) / 10) * 10);
      const axisMaxR = Math.ceil((maxR + ratingPad) / 10) * 10 || axisMinR + 10;
      const spanT = Math.max(1, maxT - minT);
      const spanR = Math.max(1, axisMaxR - axisMinR);
      const x = (t) => padLeft + ((t - minT) / spanT) * chartWidth;
      const y = (r) => padTop + (1 - ((r - axisMinR) / spanR)) * chartHeight;
      const yTicks = [axisMaxR, Math.round((axisMinR + axisMaxR) / 2), axisMinR];
      const xTicks = maxT === minT ? [minT] : [minT, minT + ((maxT - minT) / 2), maxT];
      const yAxis = yTicks.map((tick) => `<g class="rating-tick"><line x1="${padLeft}" x2="${width - padRight}" y1="${y(tick).toFixed(1)}" y2="${y(tick).toFixed(1)}" class="rating-grid"/><text x="${padLeft - 12}" y="${(y(tick) + 4).toFixed(1)}" text-anchor="end">${Math.round(tick).toLocaleString()}</text></g>`).join('');
      const xAxis = xTicks.map((tick) => `<g class="rating-tick"><line x1="${x(tick).toFixed(1)}" x2="${x(tick).toFixed(1)}" y1="${padTop}" y2="${height - padBottom}" class="rating-grid faint"/><text x="${x(tick).toFixed(1)}" y="${height - 20}" text-anchor="middle">${escapeHtml(ratingAxisDateLabel(tick))}</text></g>`).join('');

      const seriesLines = series.map((entry, index) => {
        const color = ratingSeriesColor(entry.key, index);
        const dash = ratingSeriesDash(entry.key, index);
        const points = entry.items.map((snap) => `${x(Date.parse(snap.capturedAt || 0)).toFixed(1)},${y(Number(snap.rating)).toFixed(1)}`).join(' ');
        if (entry.items.length < 2) return '';
        return `<polyline class="rating-line rating-series-line" style="--series-color:${escapeHtml(color)}" ${dash ? `stroke-dasharray="${escapeHtml(dash)}"` : ''} points="${points}"><title>${escapeHtml(entry.label)}</title></polyline>`;
      }).join('');

      const dots = series.map((entry, index) => {
        const color = ratingSeriesColor(entry.key, index);
        return entry.items.map((snap) => {
          const t = Date.parse(snap.capturedAt || 0);
          const r = Number(snap.rating);
          return `<g class="rating-point-wrap"><circle class="rating-point rating-series-point" style="--series-color:${escapeHtml(color)}" cx="${x(t).toFixed(1)}" cy="${y(r).toFixed(1)}" r="5.4"><title>${escapeHtml(entry.label)}: ${r.toLocaleString()} · ${escapeHtml(new Date(t).toLocaleString())}</title></circle></g>`;
        }).join('');
      }).join('');

      const legend = `<div class="rating-legend">${series.map((entry, index) => {
        const latest = entry.items[entry.items.length - 1];
        const color = ratingSeriesColor(entry.key, index);
        const dash = ratingSeriesDash(entry.key, index);
        return `<span class="rating-legend-item" title="${escapeHtml(entry.label)}"><i style="--series-color:${escapeHtml(color)};${dash ? `--legend-dash:${escapeHtml(dash)};` : ''}"></i><b>${escapeHtml(entry.label)}</b><small>${latest && latest.rating != null ? Number(latest.rating).toLocaleString() : 'no CR'}</small></span>`;
      }).join('')}</div>`;

      return `<div class="rating-chart-wrap multi-rating-chart"><svg class="rating-chart" viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" role="img" aria-label="Rating over time chart"><text class="rating-axis-title rating-y-title" x="18" y="${padTop + chartHeight / 2}" transform="rotate(-90 18 ${padTop + chartHeight / 2})">Rating</text><text class="rating-axis-title" x="${padLeft + chartWidth / 2}" y="${height - 2}" text-anchor="middle">Time</text>${yAxis}${xAxis}<line x1="${padLeft}" x2="${width-padRight}" y1="${height-padBottom}" y2="${height-padBottom}" class="rating-axis"/><line x1="${padLeft}" x2="${padLeft}" y1="${padTop}" y2="${height-padBottom}" class="rating-axis"/>${seriesLines}${dots}</svg>${legend}<div class="rating-range"><span>${Math.round(minR).toLocaleString()} low</span><strong>${Math.round(ratings[ratings.length - 1]).toLocaleString()} latest</strong><span>${Math.round(maxR).toLocaleString()} high</span></div></div>`;
    }

    function renderBracketStatCard(profile, bracket) {
      const snaps = filteredRatedCharacterSnapshots(profile, bracket, 'All Time');
      const latest = snaps.slice().sort((a, b) => Date.parse(b.capturedAt || 0) - Date.parse(a.capturedAt || 0))[0] || null;
      const first = snaps[0] || null;
      const source = latest && (latest.sourceType || latest.sourceFile) ? (latest.sourceType || latest.sourceFile) : 'No rated source yet';
      const latestDate = latest && latest.capturedAt ? new Date(latest.capturedAt) : null;
      const delta = latest && first && latest !== first ? Number(latest.rating) - Number(first.rating) : null;
      return `<div class="character-bracket-card"><div class="bracket-card-head"><strong>${escapeHtml(displayBracketLabel(bracket))}</strong>${latest && latest.rating != null ? `<span class="rating-pill">${Number(latest.rating).toLocaleString()} CR</span>` : '<span class="rating-pill muted">No rating</span>'}</div><div class="stat-strip compact"><div><p>Rated points</p><b>${snaps.length}</b><small>${latestDate && !Number.isNaN(latestDate.getTime()) ? latestDate.toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : 'No timestamp'}</small></div><div><p>Change</p><b>${delta == null ? 'Not enough data' : `${delta >= 0 ? '+' : ''}${delta}`}</b><small>first to latest point</small></div><div><p>Source</p><b>${escapeHtml(source.includes('PvPHelper') ? 'PvPHelper' : source)}</b><small>rated data only</small></div></div></div>`;
    }

    function renderCharacters() {
      const profiles = buildCharacterProfiles();
      if (!profiles.length) return `<div class="grid characters-view" style="max-width:1180px">${renderCharacterImportHelpCard(profiles)}<div class="card">${renderNoDataBox()}</div></div>`;
      const profileKeys = new Set(profiles.map((p) => p.key));
      if (!state.selectedCharacterKey) {
        const remembered = rememberedSelectedCharacterKey();
        state.selectedCharacterKey = remembered && profileKeys.has(remembered) ? remembered : (profiles[0] && profiles[0].key) || '';
      }
      if (state.selectedCharacterKey !== 'All' && !profileKeys.has(state.selectedCharacterKey)) {
        const remembered = rememberedSelectedCharacterKey();
        state.selectedCharacterKey = remembered && profileKeys.has(remembered) ? remembered : (profiles[0] && profiles[0].key) || 'All';
      }
      const profile = state.selectedCharacterKey === 'All' ? buildAllCharactersProfile(profiles) : (profiles.find((p) => p.key === state.selectedCharacterKey) || profiles[0]);
      const brackets = characterBracketOptions(profile);
      if (state.characterBracketFilter !== 'All' && !brackets.includes(state.characterBracketFilter)) state.characterBracketFilter = 'All';
      const bracket = state.characterBracketFilter;
      const matches = filteredCharacterMatches(profile, bracket, state.characterTimeframe);
      const bestCurrentRating = bestCurrentRatingSnapshot(profile, bracket);
      const currentRatingSnap = bestCurrentRating && bestCurrentRating.snap ? bestCurrentRating.snap : null;
      const currentRatingLabel = bestCurrentRating && bestCurrentRating.label ? bestCurrentRating.label : (currentRatingSnap ? displayBracketLabel(normalizeBracketForUi(currentRatingSnap.bracket)) : 'Sync PvPHelper.lua');
      const hasBlizzardSeason = Boolean(currentRatingSnap && currentRatingSnap.seasonPlayed != null);
      const blizzardSeasonValue = hasBlizzardSeason ? `${currentRatingSnap.seasonWon || 0}W ${(currentRatingSnap.seasonLost || 0)}L` : 'Not captured';
      const blizzardSeasonCaption = hasBlizzardSeason ? `${currentRatingSnap.seasonPlayed} played · ${currentRatingLabel}` : (currentRatingSnap ? 'Current PvPHelper data has rating only' : 'Sync PvPHelper.lua');
      const ratedSnaps = filteredRatedCharacterSnapshots(profile, bracket, 'All Time');
      const ratedGroups = ratedBracketSnapshotGroups(profile, bracket);
      const allBracketCards = (bracket === 'All' ? brackets : [bracket]).filter(isRatedCharacterRatingBracket).map((b) => renderBracketStatCard(profile, b)).join('');
      return `<div class="grid characters-view">
        <div class="card character-picker-card">
          <div class="card-title-row"><div><p class="small-label">Characters</p><h2>Your Characters ${pvpHelperSyncHelpIcon()}</h2><p class="caption">Characters pull from the mapped PvPHelper.lua when rating/character data exists in SavedVariables.</p></div><div class="action-row">${state.settings && state.settings.pvpHelperSavedVariablesPath ? `<button class="btn emerald" id="sync-pvph-savedvariables" ${state.pvpHelperSyncBusy ? 'disabled' : ''}>${state.pvpHelperSyncBusy ? 'Syncing…' : 'Sync Now'}</button><button class="btn" id="import-pvph-savedvariables">Change Folder</button>` : '<button class="btn violet" id="import-pvph-savedvariables">Map PvPHelper.lua</button>'}${pvpHelperSyncHelpIcon('inline-action-help')}</div></div>
          <div class="character-control-grid">
            <label class="filter-control"><span>Character</span><select id="character-select"><option value="All" ${state.selectedCharacterKey === 'All' ? 'selected' : ''}>All Characters</option>${profiles.map((p) => `<option value="${escapeHtml(p.key)}" ${profile.key === p.key && state.selectedCharacterKey !== 'All' ? 'selected' : ''}>${escapeHtml(characterPrettyName(p.key))}</option>`).join('')}</select></label>
            <label class="filter-control"><span>Bracket</span><select id="character-bracket-filter"><option>All</option>${brackets.map((b) => `<option value="${escapeHtml(b)}" ${bracket === b ? 'selected' : ''}>${escapeHtml(displayBracketLabel(b))}</option>`).join('')}</select></label>
            <label class="filter-control"><span>Timeframe</span><select id="character-timeframe">${['Session','7 Days','30 Days','Season','All Time'].map((t) => `<option ${state.characterTimeframe === t ? 'selected' : ''}>${t}</option>`).join('')}</select></label>
          </div>
        </div>
        <div class="card character-hero-card">
          <div class="card-title-row"><div><p class="small-label">Selected character</p><h2>${characterNameHtml(profile)}</h2><p class="caption">${escapeHtml([profile.spec, profile.className].filter(Boolean).join(' · ') || 'Spec unknown')}</p></div><div class="icon-bubble">📈</div></div>
          <div class="grid stats-grid tiny-stats">
            ${statCard('⚔️', 'Recent Matches', `${matches.length}`, 'confident character matches')}
            ${statCard('🏆', 'Best Current Rating', currentRatingSnap && currentRatingSnap.rating != null ? Number(currentRatingSnap.rating).toLocaleString() : 'Not captured', currentRatingLabel)}
            ${statCard('📜', 'Rated Sources', `${ratedGroups.size}`, ratedGroups.size ? 'rated brackets with data' : 'No rated bracket data yet')}
            ${statCard('🧭', 'Rating Points', `${ratedSnaps.length}`, 'rated snapshots only')}
          </div>
          ${renderRatingSparkline(profile, bracket, state.characterTimeframe)}
        </div>
        <div class="card"><div class="card-title-row"><div><p class="small-label">Rated brackets</p><h2>Rating sources</h2><p class="caption">Random BGs and unrated modes are hidden from rating cards.</p></div>${pill(`${brackets.length} rated bracket${brackets.length === 1 ? '' : 's'}`, 'cyan')}</div><div class="character-bracket-grid">${allBracketCards || '<div class="empty">No rated bracket data yet. Sync PvPHelper.lua or import rated match data.</div>'}</div></div>
        <div class="card"><div class="card-title-row"><div><p class="small-label">Games</p><h2>Recent matches on this character</h2><p class="caption">Only matches confidently tied to this character are shown.</p></div>${pill(`${matches.length} shown`, 'cyan')}</div><div class="match-table">${matches.slice(0, 40).map((match) => `<button class="match-table-row" data-match="${escapeHtml(match.id)}"><span>${escapeHtml(match.date || '')}</span><strong>${escapeHtml(displayMatchType(match))}</strong><span>${escapeHtml(match.map || '')}</span><span>${escapeHtml(match.duration || '')}</span>${pill(displayResult(match.combatLogResult || match.result), (match.combatLogResult || match.result) === 'Win' ? 'emerald' : (match.combatLogResult || match.result) === 'Loss' ? 'rose' : 'amber')}${matchSourceBadges(match)}</button>`).join('') || '<div class="empty">No recent matches found for this character yet.</div>'}</div></div>
      </div>`;
    }

    return {
      characterNameKey,
      dedupeCharacterSnapshots,
      characterDisplayKey,
      characterPrettyName,
      normalizeBracketForUi,
      isRatedCharacterRatingBracket,
      snapshotHasRatedRating,
      snapshotCharacterKey,
      confidentCharacterNamesForMatch,
      matchHasConfidentCharacter,
      matchSourceBadges,
      ratedBracketSnapshotGroups,
      buildCharacterProfiles,
      buildAllCharactersProfile,
      characterBracketOptions,
      latestSnapshotFor,
      timeframeStart,
      filteredCharacterMatches,
      filteredCharacterSnapshots,
      filteredRatedCharacterSnapshots,
      bestCurrentRatingSnapshot,
      characterNameHtml,
      ratingAxisDateLabel,
      ratingSpecLabel,
      ratingSeriesKey,
      ratingSeriesLabelFromKey,
      stableHash,
      ratingSeriesColor,
      ratingSeriesDash,
      renderRatingSparkline,
      renderBracketStatCard,
      renderCharacters
    };
  }

  window.LastCallCharactersView = { createCharactersViewTools };
})();
