(function () {
  'use strict';

  function createVodActions(deps = {}) {
    if (!deps || !deps.state) throw new Error('LastCallVodActions requires app state.');
    const state = deps.state;
    const api = deps.api || null;
    const alert = deps.alert || ((message) => window.alert(message));
    const selectedVod = deps.selectedVod || (() => null);
    const applyBackendCollectionDeltas = deps.applyBackendCollectionDeltas || (() => {});
    const render = deps.render || (() => {});
    const isoFromLocalDateTimeInput = deps.isoFromLocalDateTimeInput || (() => '');
    const selectedMatch = deps.selectedMatch || (() => null);
    const isVideoSectionLink = deps.isVideoSectionLink || (() => false);
    const replayScopeBoundsForMatch = deps.replayScopeBoundsForMatch || (() => ({ min: 0, max: 0, mode: 'full' }));
    const formatElapsed = deps.formatElapsed || ((value) => String(value || 0));
    const updateReplayClockAndHealth = deps.updateReplayClockAndHealth || (() => {});
    const updateVideoEventRail = deps.updateVideoEventRail || (() => {});
    const renderKeepingReplay = deps.renderKeepingReplay || render;

    async function importVodFile(payload = null) {
      if (!api || !api.importVodFile) return alert('VOD import is only available in the desktop app.');
      const result = await api.importVodFile(payload || {});
      if (!result) return;
      if (!result.ok) return alert(result.reason || 'Could not import VOD.');
      applyBackendCollectionDeltas(result || {});
      state.vods = result.vods || state.vods || [];
      const imported = Array.isArray(result.imported) ? result.imported : (result.vod ? [result.vod] : []);
      const firstVod = imported[0] || result.vod || null;
      state.selectedVodId = firstVod && firstVod.id ? firstVod.id : state.selectedVodId;
      const importedCount = imported.length || (result.vod ? 1 : 0);
      const skippedCount = Array.isArray(result.skipped) ? result.skipped.length : 0;
      const baseStatus = importedCount > 1
        ? `Added ${importedCount} VOD files.`
        : (firstVod && firstVod.startIso ? 'VOD added. Start time was suggested from the filename, including seconds. Review it, then link matching matches.' : 'VOD added. Set its real start time, then link matching matches.');
      state.vodStatus = skippedCount ? `${baseStatus} Skipped ${skippedCount} unsupported or missing file${skippedCount === 1 ? '' : 's'}.` : baseStatus;
      render();
    }

    async function vodPathsFromFiles(fileList) {
      const files = Array.from(fileList || []);
      const paths = [];
      for (const file of files) {
        let filePath = '';
        try {
          if (api && api.getPathForFile) filePath = await api.getPathForFile(file);
        } catch (_) {}
        if (!filePath && file && file.path) filePath = file.path;
        if (filePath) paths.push(filePath);
      }
      return [...new Set(paths)];
    }

    function vodPathsFromText(text = '') {
      return String(text || '')
        .split(/\r?\n+/)
        .map((line) => line.trim().replace(/^file:\/\//i, '').replace(/^['"]|['"]$/g, ''))
        .filter((line) => /\.(mp4|mkv|mov|webm|avi)$/i.test(line));
    }

    async function importVodFilesFromDrop(fileList, source = 'drop') {
      const filePaths = await vodPathsFromFiles(fileList);
      if (!filePaths.length) {
        state.vodStatus = source === 'paste' ? 'No video file paths found in the paste.' : 'No video files found in that drop.';
        render();
        return;
      }
      await importVodFile({ filePaths, source });
    }

    async function handleVodPaste(event) {
      const files = event.clipboardData && event.clipboardData.files;
      if (files && files.length) {
        event.preventDefault();
        await importVodFilesFromDrop(files, 'paste');
        return;
      }
      const drop = document.getElementById('vod-import-drop');
      const activeInDrop = drop && drop.contains(document.activeElement);
      const text = event.clipboardData && event.clipboardData.getData ? event.clipboardData.getData('text') : '';
      const filePaths = activeInDrop ? vodPathsFromText(text) : [];
      if (filePaths.length) {
        event.preventDefault();
        await importVodFile({ filePaths, source: 'paste-text' });
      }
    }

    async function saveVodMeta(renderAfter = true) {
      const vod = selectedVod();
      if (!vod || !api || !api.updateVodMeta) return;
      const labelInput = document.getElementById('vod-label');
      const startInput = document.getElementById('vod-start-time');
      const offsetInput = document.getElementById('vod-sync-offset');
      const preInput = document.getElementById('vod-pre-roll');
      const postInput = document.getElementById('vod-post-roll');
      const label = labelInput ? (labelInput.value || vod.label || '') : (vod.label || '');
      const startIso = startInput ? isoFromLocalDateTimeInput(startInput.value || '') : (vod.startIso || '');
      const syncOffsetSec = offsetInput ? (Number(offsetInput.value || 0) || 0) : (Number(vod.syncOffsetSec || 0) || 0);
      state.vodPreRollSec = Math.max(0, Number(preInput ? preInput.value : state.vodPreRollSec || 0) || 0);
      state.vodPostRollSec = Math.max(0, Number(postInput ? postInput.value : state.vodPostRollSec || 0) || 0);
      const result = await api.updateVodMeta({ vodId: vod.id, label, startIso, syncOffsetSec });
      if (!result || !result.ok) return alert((result && result.reason) || 'Could not save VOD timing.');
      applyBackendCollectionDeltas(result || {});
      state.vods = result.vods || state.vods || [];
      state.vodStatus = startIso ? 'Timing saved. Preview candidates below, then link matches.' : 'VOD timing saved, but start time is still blank.';
      if (renderAfter) render();
    }

    async function linkVodMatches(matchIds = null, options = {}) {
      const vod = selectedVod();
      if (!vod || !api || !api.linkVodToMatches) return alert('VOD linking is only available in the desktop app.');
      await saveVodMeta(false);
      const freshVod = selectedVod();
      if (!freshVod || !freshVod.startIso) {
        state.vodStatus = 'Set and save the VOD start time before linking matches.';
        render();
        return;
      }
      const cleanIds = Array.isArray(matchIds) ? matchIds.filter(Boolean) : null;
      const result = await api.linkVodToMatches({ vodId: freshVod.id, matchIds: cleanIds, preRollSec: state.vodPreRollSec, postRollSec: state.vodPostRollSec });
      if (!result || !result.ok) {
        state.vodStatus = (result && result.reason) || 'No matches linked.';
        state.matches = result && result.matches || state.matches || [];
        if (options.renderAfter !== false) render();
        return;
      }
      applyBackendCollectionDeltas(result || {});
      state.matches = result.matches || state.matches || [];
      state.vods = result.vods || state.vods || [];
      state.recorder.recordings = result.recordings || state.recorder.recordings || [];
      const one = cleanIds && cleanIds.length === 1;
      state.vodStatus = one ? 'Applied this VOD section to the selected match.' : `Linked ${Number(result.linked || 0)} match section${Number(result.linked || 0) === 1 ? '' : 's'} to this VOD.`;
      if (options.renderAfter !== false) render();
    }


    async function deleteVod(vodId) {
      const vod = (state.vods || []).find((item) => item && item.id === vodId);
      if (!vod || !api || !api.deleteVod) return alert('VOD delete is only available in the desktop app.');
      const linkedCount = (state.matches || []).filter((match) => match && match.vodId === vodId).length;
      const label = vod.label || 'this VOD';
      const message = linkedCount
        ? `Remove ${label} from the VOD library?\n\nThis will unlink ${linkedCount} match section${linkedCount === 1 ? '' : 's'} from this VOD. It will not delete the original video file from your PC.`
        : `Remove ${label} from the VOD library?\n\nThis will not delete the original video file from your PC.`;
      if (!window.confirm(message)) return;
      const result = await api.deleteVod({ vodId });
      if (!result || !result.ok) return alert((result && result.reason) || 'Could not delete VOD.');
      applyBackendCollectionDeltas(result || {});
      state.matches = result.matches || state.matches || [];
      state.recorder.recordings = result.recordings || state.recorder.recordings || [];
      state.vods = result.vods || state.vods || [];
      if (state.selectedVodId === vodId) state.selectedVodId = (state.vods[0] && state.vods[0].id) || '';
      state.vodStatus = Number(result.unlinked || 0)
        ? `Removed VOD from library and unlinked ${Number(result.unlinked || 0)} match section${Number(result.unlinked || 0) === 1 ? '' : 's'}. Original video file was not deleted.`
        : 'Removed VOD from library. Original video file was not deleted.';
      render();
    }


    function editableClipBounds(match = selectedMatch()) {
      const startInput = document.getElementById('match-video-clip-start');
      const endInput = document.getElementById('match-video-clip-end');
      const editor = document.querySelector('[data-clip-editor]');
      const minBound = Number(editor && editor.dataset ? editor.dataset.clipMin : NaN);
      const maxBound = Number(editor && editor.dataset ? editor.dataset.clipMax : NaN);
      const rawStart = Number(startInput && startInput.value);
      const rawEnd = Number(endInput && endInput.value);
      const fallbackStart = Number(match && match.videoClipStartSec);
      const fallbackEnd = Number(match && match.videoClipEndSec);
      let start = Number.isFinite(rawStart) ? rawStart : fallbackStart;
      let end = Number.isFinite(rawEnd) ? rawEnd : fallbackEnd;
      if (Number.isFinite(minBound)) start = Math.max(minBound, start);
      if (Number.isFinite(maxBound)) end = Math.min(maxBound, end);
      if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) return null;
      return { start, end };
    }

    function seekReplayVideoToTrimTime(seconds) {
      const video = document.getElementById('replay-video');
      const target = Number(seconds);
      if (!video || !Number.isFinite(target)) return;
      try { video.currentTime = Math.max(0, target); } catch (_) {}
      state.player.currentTime = video.currentTime || target;
      updateReplayClockAndHealth(state.player.currentTime);
      updateVideoEventRail();
    }

    function enforceVodClipBounds(video, match = selectedMatch()) {
      if (!video || !match || !isVideoSectionLink(match)) return;
      const bounds = replayScopeBoundsForMatch(match, video);
      if (!bounds || bounds.mode === 'full') return;
      const clipStart = Math.max(0, Number(bounds.min || 0));
      const clipEnd = Math.max(clipStart + 0.5, Number(bounds.max || clipStart + 1));
      const current = Number(video.currentTime || 0);
      if (current < Math.max(0, clipStart - 0.15)) {
        try { video.currentTime = Math.max(0, clipStart); } catch (_) {}
        state.player.currentTime = video.currentTime || clipStart;
        return;
      }
      if (current > clipEnd + 0.2) {
        try { video.currentTime = clipEnd; } catch (_) {}
        try { video.pause(); } catch (_) {}
        state.player.currentTime = clipEnd;
      }
    }

    function exportFolderLabel() {
      const settings = state.settings || {};
      if (settings.clipExportDir) return settings.clipExportDir;
      if (state.appPaths && state.appPaths.clips) return state.appPaths.clips;
      if (settings.recordingsDir && settings.recordingsDirConfirmed) {
        const sep = String(settings.recordingsDir).includes('\\') ? '\\' : '/';
        return `${String(settings.recordingsDir).replace(/[\\/]+$/, '')}${sep}vod-exports`;
      }
      return 'Default app storage / vod-exports';
    }

    async function chooseExportFolder() {
      if (!api || !api.selectExportFolder) return alert('Choosing an export folder is only available in the desktop app.');
      const result = await api.selectExportFolder();
      if (!result) return;
      if (!result.ok) return alert(result.reason || 'Could not choose export folder.');
      if (result.settings) state.settings = { ...(state.settings || {}), ...(result.settings || {}) };
      if (result.appPaths) state.appPaths = { ...(state.appPaths || {}), ...(result.appPaths || {}) };
      state.player.showExportPanel = true;
      renderKeepingReplay();
    }

    async function exportVodClipByMatchId(matchId, options = {}) {
      if (!matchId || !api || !api.exportVodClip) return alert('VOD export is only available in the desktop app.');
      const includeAudio = options.includeAudio !== undefined ? Boolean(options.includeAudio) : true;
      const outputDir = (state.settings && state.settings.clipExportDir) || '';
      const inlineStatus = options.inlineStatus === true;
      const payload = { matchId, includeAudio, outputDir };
      if (Number.isFinite(Number(options.startSec))) payload.startSec = Math.max(0, Number(options.startSec));
      if (Number.isFinite(Number(options.endSec))) payload.endSec = Math.max(0, Number(options.endSec));
      if (options.scopeMode) payload.scopeMode = String(options.scopeMode);
      const result = await api.exportVodClip(payload);
      if (result && result.settings) state.settings = { ...(state.settings || {}), ...(result.settings || {}) };
      if (!result || !result.ok) {
        const message = (result && result.reason) || 'VOD export failed.';
        if (inlineStatus) {
          state.player.exportStatus = { ok: false, matchId, message };
          state.player.showExportPanel = true;
          renderKeepingReplay();
          return null;
        }
        return alert(message);
      }
      if (inlineStatus) {
        state.player.exportStatus = {
          ok: true,
          matchId,
          message: `Saved ${formatElapsed(result.durationSec || 0)}${includeAudio ? ' with sound' : ' without sound'}.`,
          outputPath: result.outputPath || ''
        };
        state.player.showExportPanel = true;
        renderKeepingReplay();
        return result;
      }
      alert(`Match exported${includeAudio ? '' : ' without sound'}:
    ${result.outputPath}`);
      if (api.revealPath) api.revealPath(result.outputPath);
      return result;
    }

    async function exportSelectedVodClip() {
      const match = selectedMatch();
      if (!match) return alert('No match selected.');
      const audioBox = document.getElementById('export-clip-include-audio');
      const includeAudio = audioBox ? audioBox.checked : true;
      const bounds = replayScopeBoundsForMatch(match, document.getElementById('replay-video'));
      return exportVodClipByMatchId(match.id, { includeAudio, inlineStatus: true, startSec: bounds.min, endSec: bounds.max, scopeMode: bounds.mode });
    }

    function seekReplayToClipStart(match = selectedMatch()) {
      const video = document.getElementById('replay-video');
      const bounds = replayScopeBoundsForMatch(match, video);
      const start = Number(bounds && bounds.min);
      if (!video || !Number.isFinite(start)) return;
      video.currentTime = Math.max(0, start);
      state.player.currentTime = video.currentTime;
      updateReplayClockAndHealth(state.player.currentTime);
      updateVideoEventRail();
    }

    async function saveMatchVideoSection(options = {}) {
      const { renderAfter = true } = options || {};
      const match = selectedMatch();
      if (!match || !api || !api.updateMatchVideoSection) { alert('Video section editing is only available in the desktop app.'); return false; }
      const editor = document.querySelector('[data-clip-editor]');
      const trimMin = Number(editor && editor.dataset ? editor.dataset.clipMin : NaN);
      const trimMax = Number(editor && editor.dataset ? editor.dataset.clipMax : NaN);
      const minBound = Number.isFinite(trimMin) ? trimMin : 0;
      const maxBound = Number.isFinite(trimMax) && trimMax > minBound ? trimMax : Infinity;
      let clipStart = Number(document.getElementById('match-video-clip-start')?.value || 0);
      let clipEnd = Number(document.getElementById('match-video-clip-end')?.value || 0);
      if (Number.isFinite(clipStart)) clipStart = Math.max(minBound, Math.min(maxBound - 0.25, clipStart));
      if (Number.isFinite(clipEnd)) clipEnd = Math.max(clipStart + 0.25, Math.min(maxBound, clipEnd));
      const matchStart = Number(document.getElementById('match-video-match-start')?.value || minBound || clipStart || 0);
      const syncAdjustment = Number(document.getElementById('match-video-sync-adjust')?.value || 0);
      if (!Number.isFinite(clipStart) || !Number.isFinite(clipEnd) || clipEnd <= clipStart) { alert('VOD end needs to be after VOD start.'); return false; }
      const duration = Math.max(1, Number(match.durationSec || 0) || Math.max(1, clipEnd - clipStart));
      const matchEnd = Math.max(matchStart + 1, matchStart + duration);
      const result = await api.updateMatchVideoSection({
        matchId: match.id,
        clipStartSec: clipStart,
        clipEndSec: clipEnd,
        matchStartSec: matchStart,
        matchEndSec: matchEnd,
        syncAdjustmentSec: syncAdjustment
      });
      if (!result || !result.ok) { alert((result && result.reason) || 'Could not save the video section.'); return false; }
      applyBackendCollectionDeltas(result || {});
      state.matches = result.matches || state.matches || [];
      state.recorder.recordings = result.recordings || state.recorder.recordings || [];
      state.vods = result.vods || state.vods || [];
      const updated = (state.matches || []).find((item) => item && item.id === match.id) || match;
      state.player.syncOffsetSec = Number(updated.videoMatchStartSec || matchStart || 0) + (Number(updated.videoSyncAdjustmentSec || 0) || 0);
      if (renderAfter) renderKeepingReplay();
      return true;
    }

    async function exportSelectedPartOfMatch() {
      const saved = await saveMatchVideoSection({ renderAfter: false });
      if (!saved) return;
      await exportSelectedVodClip();
      renderKeepingReplay();
    }

    function setClipTrimBounds(minValue, maxValue) {
      const min = Math.max(0, Number(minValue) || 0);
      const max = Math.max(min + 0.25, Number(maxValue) || min + 1);
      const startRange = document.getElementById('match-video-clip-start-range');
      const endRange = document.getElementById('match-video-clip-end-range');
      const startInput = document.getElementById('match-video-clip-start');
      const endInput = document.getElementById('match-video-clip-end');
      const minLabel = document.getElementById('clip-range-min-label');
      const maxLabel = document.getElementById('clip-range-max-label');
      [startRange, endRange, startInput, endInput].forEach((input) => {
        if (!input) return;
        input.min = String(min);
        input.max = String(max);
      });
      if (minLabel) minLabel.textContent = formatElapsed(min);
      if (maxLabel) maxLabel.textContent = formatElapsed(max);
    }

    function setClipTrimMax(maxValue) {
      const startRange = document.getElementById('match-video-clip-start-range');
      const min = Number(startRange && startRange.min) || 0;
      setClipTrimBounds(min, maxValue);
    }

    function updateClipTrimReadout(start, end) {
      const safeStart = Math.max(0, Number(start) || 0);
      const safeEnd = Math.max(safeStart + 0.25, Number(end) || safeStart + 0.25);
      const pairs = [
        ['clip-start-display', formatElapsed(safeStart)],
        ['clip-end-display', formatElapsed(safeEnd)],
        ['clip-length-display', formatElapsed(Math.max(0.25, safeEnd - safeStart))],
        ['clip-range-readout', `${formatElapsed(safeStart)} → ${formatElapsed(safeEnd)}`],
        ['clip-start-human', `video time ${formatElapsed(safeStart)}`],
        ['clip-end-human', `video time ${formatElapsed(safeEnd)}`]
      ];
      pairs.forEach(([id, text]) => {
        const node = document.getElementById(id);
        if (node) node.textContent = text;
      });
    }

    function syncClipTrimControls() {
      const startInput = document.getElementById('match-video-clip-start');
      const endInput = document.getElementById('match-video-clip-end');
      const startRange = document.getElementById('match-video-clip-start-range');
      const endRange = document.getElementById('match-video-clip-end-range');
      if (!startInput || !endInput || !startRange || !endRange) return;
      const minGap = 0.25;
      const editor = document.querySelector('[data-clip-editor]');
      const minFromEditor = Number(editor && editor.dataset ? editor.dataset.clipMin : NaN);
      const maxFromEditor = Number(editor && editor.dataset ? editor.dataset.clipMax : NaN);
      const minBound = Number.isFinite(minFromEditor) ? minFromEditor : (Number(startRange.min) || 0);
      const maxBound = Number.isFinite(maxFromEditor) ? maxFromEditor : Math.max(Number(startRange.max) || 0, Number(endRange.max) || 0, Number(endInput.value) || minBound + 1);
      setClipTrimBounds(minBound, maxBound);
      const apply = (changed, shouldSeek = false) => {
        const min = Number(startRange.min) || minBound || 0;
        const max = Math.max(min + minGap, Number(startRange.max) || Number(endRange.max) || maxBound || min + 1);
        let start = changed === 'startRange' ? Number(startRange.value) : Number(startInput.value);
        let end = changed === 'endRange' ? Number(endRange.value) : Number(endInput.value);
        if (!Number.isFinite(start)) start = min;
        if (!Number.isFinite(end)) end = start + 1;
        start = Math.max(min, Math.min(max - minGap, start));
        end = Math.max(start + minGap, Math.min(max, end));
        if (changed === 'endRange' || changed === 'endInput') start = Math.max(min, Math.min(start, end - minGap));
        if (changed === 'startRange' || changed === 'startInput') end = Math.min(max, Math.max(end, start + minGap));
        startInput.value = start.toFixed(2);
        endInput.value = end.toFixed(2);
        startRange.value = start.toFixed(2);
        endRange.value = end.toFixed(2);
        updateClipTrimReadout(start, end);
        if (changed !== 'init' && shouldSeek) {
          const seekTarget = (changed === 'endRange' || changed === 'endInput') ? end : start;
          seekReplayVideoToTrimTime(seekTarget);
        }
      };
      if (!startRange.dataset.clipTrimBound) {
        startRange.dataset.clipTrimBound = '1';
        endRange.dataset.clipTrimBound = '1';
        startInput.dataset.clipTrimBound = '1';
        endInput.dataset.clipTrimBound = '1';
        startRange.addEventListener('input', () => apply('startRange', false));
        endRange.addEventListener('input', () => apply('endRange', false));
        startInput.addEventListener('input', () => apply('startInput', false));
        endInput.addEventListener('input', () => apply('endInput', false));
        startRange.addEventListener('change', () => apply('startRange', true));
        endRange.addEventListener('change', () => apply('endRange', true));
        startInput.addEventListener('change', () => apply('startInput', true));
        endInput.addEventListener('change', () => apply('endInput', true));
      }
      apply('init', false);
    }

    function updateClipTrimMaxFromVideo(video) {
      const editor = document.querySelector('[data-clip-editor]');
      if (editor && editor.dataset && editor.dataset.clipLock === 'match') {
        syncClipTrimControls();
        return;
      }
      if (!video || !Number.isFinite(Number(video.duration)) || Number(video.duration) <= 0) return;
      const currentMax = Math.max(
        Number(document.getElementById('match-video-clip-start-range')?.max) || 0,
        Number(document.getElementById('match-video-clip-end-range')?.max) || 0
      );
      const nextMax = Math.max(currentMax, Number(video.duration));
      setClipTrimMax(nextMax);
    }


    return {
      importVodFile,
      vodPathsFromFiles,
      vodPathsFromText,
      importVodFilesFromDrop,
      handleVodPaste,
      saveVodMeta,
      linkVodMatches,
      deleteVod,
      editableClipBounds,
      seekReplayVideoToTrimTime,
      enforceVodClipBounds,
      exportFolderLabel,
      chooseExportFolder,
      exportVodClipByMatchId,
      exportSelectedVodClip,
      seekReplayToClipStart,
      saveMatchVideoSection,
      exportSelectedPartOfMatch,
      setClipTrimBounds,
      setClipTrimMax,
      updateClipTrimReadout,
      syncClipTrimControls,
      updateClipTrimMaxFromVideo
    };
  }

  window.LastCallVodActions = { createVodActions };
})();
