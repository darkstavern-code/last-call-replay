(function () {
  'use strict';

  function createSettingsViewTools(deps = {}) {
    const state = deps.state || {};
    const escapeHtml = deps.escapeHtml || ((value) => String(value ?? ''));
    const formatSyncDateTime = deps.formatSyncDateTime || ((value) => String(value || ''));
    const formatBytes = deps.formatBytes || ((value) => String(value || 0));
    const displayFileName = deps.displayFileName || ((value) => String(value || '').split(/[\\/]/).pop() || '');
    const displayPathTail = deps.displayPathTail || ((value) => String(value || ''));
    const latestCombatLogImport = deps.latestCombatLogImport || (() => null);
    const latestPvPHelperImport = deps.latestPvPHelperImport || (() => null);
    const pvpHelperSyncHelpIcon = deps.pvpHelperSyncHelpIcon || (() => '');
    const renderPvPHelperInstallStatusCard = deps.renderPvPHelperInstallStatusCard || (() => '');
    const renderPvPHelperMappingAssist = deps.renderPvPHelperMappingAssist || (() => '');
    const renderPvPHelperAddonStatus = deps.renderPvPHelperAddonStatus || (() => '');
    const renderLatestImportSummary = deps.renderLatestImportSummary || (() => '');
    const pathValueMarkup = deps.pathValueMarkup || ((value, fallback = '') => `<strong>${escapeHtml(value || fallback)}</strong>`);
    const exportFolderLabel = deps.exportFolderLabel || (() => '');
    const matchSortTime = deps.matchSortTime || (() => 0);
    const matchVideoPath = deps.matchVideoPath || (() => '');
    const isFavoriteMatch = deps.isFavoriteMatch || (() => false);
    const recordingLinkedMatchIds = deps.recordingLinkedMatchIds || (() => []);
    const recordingTitleForItem = deps.recordingTitleForItem || (() => 'Recording');
    const favoriteMark = deps.favoriteMark || (() => '');
    const matchTimestampLabel = deps.matchTimestampLabel || (() => 'Unknown day');
    const displayMatchType = deps.displayMatchType || (() => 'PvP');
    const pill = deps.pill || ((text) => `<span class="pill">${escapeHtml(text)}</span>`);

function performanceStatusTone(value, warnAt = 1, dangerAt = Infinity) {
  const n = Number(value) || 0;
  if (n >= dangerAt) return 'rose';
  if (n >= warnAt) return 'amber';
  return 'emerald';
}


function renderImportJobStatusCard() {
  const status = state.importJobStatus || (state.performanceAudit && state.performanceAudit.importJobStatus) || {};
  const active = status.active || null;
  const queued = Number(status.queued || 0);
  const recent = Array.isArray(status.recent) ? status.recent.slice(0, 4) : [];
  const activeText = active ? `${active.label || 'Working'} · ${active.status || 'running'}` : 'Idle';
  const recentRows = recent.length
    ? recent.map((job) => `<div class="job-history-row"><span>${escapeHtml(job.label || job.type || 'Job')}</span><b>${escapeHtml(job.status || '')}</b><small>${job.durationMs ? escapeHtml(`${Math.round(Number(job.durationMs || 0) / 1000)}s`) : escapeHtml(job.finishedAt ? formatSyncDateTime(job.finishedAt) : '')}</small></div>`).join('')
    : '<p class="caption">No queued jobs have run this session yet.</p>';
  return `<div class="settings-inline-card maintenance-card job-queue-card">
    <div><p class="small-label">Import queue</p><h3>${escapeHtml(activeText)}</h3><p class="caption">Heavy work runs one job at a time so log repair, active sync, video scans, and compacting do not pile onto each other.</p>${queued ? `<p class="caption">${escapeHtml(String(queued))} waiting behind the current job.</p>` : ''}</div>
    <div class="job-history-list">${recentRows}</div>
  </div>`;
}

function renderPerformanceAudit() {
  const audit = state.performanceAudit || {};
  const riskFlags = Array.isArray(audit.riskFlags) ? audit.riskFlags : [];
  const pendingBytes = Number(audit.pendingBytes || 0);
  const folderCount = Number(audit.folderLogCount || 0);
  const stateBytes = Number(audit.stateFileBytes || 0);
  const eventRows = Number(audit.storedEventRows || 0);
  const eventPreviewRows = Number(audit.storedEventPreviewRows || 0);
  const eventCacheFiles = Number(audit.eventFeedCacheFiles || 0);
  const eventCacheBytes = Number(audit.eventFeedCacheBytes || 0);
  const activeMode = audit.activeTailOnly ? 'Active tail only' : 'Needs review';
  const startupMode = audit.startupOptimized ? 'Fast startup' : 'Needs review';
  const folderNote = audit.folderStatLimited
    ? 'Large folder mode: only newest candidates are checked.'
    : 'Normal folder size.';
  return `<div class="card performance-audit-card">
    <div class="card-title-row"><div><p class="small-label">Performance audit</p><h2>What loads automatically</h2><p class="caption">This checks the big lag traps: startup scans, active log tails, folder size, local state size, and stored event feed rows.</p></div><div class="icon-bubble">🧪</div></div>
    <div class="performance-audit-grid">
      <div class="info-box"><p class="label">Startup</p><p class="value">${escapeHtml(startupMode)}</p><p class="caption">No archive rebuild or historical log import on app open.</p></div>
      <div class="info-box"><p class="label">Combat log sync</p><p class="value">${escapeHtml(activeMode)}</p><p class="caption">Sync Active Log reads only new appended data.</p></div>
      <div class="info-box"><p class="label">Active log backlog</p><p class="value">${escapeHtml(formatBytes(pendingBytes))}</p><p class="caption">Reads max ${escapeHtml(formatBytes(audit.maxActiveTailReadBytes || 0))} per pass.</p></div>
      <div class="info-box"><p class="label">Logs in folder</p><p class="value">${escapeHtml(folderCount.toLocaleString())}</p><p class="caption">${escapeHtml(folderNote)}</p></div>
      <div class="info-box"><p class="label">Saved matches</p><p class="value">${escapeHtml(Number(audit.matchCount || 0).toLocaleString())}</p><p class="caption">Render lists stay filtered/capped where possible.</p></div>
      <div class="info-box"><p class="label">Event feed rows</p><p class="value">${escapeHtml(eventRows.toLocaleString())}</p><p class="caption">Only ${escapeHtml(eventPreviewRows.toLocaleString())} preview rows stay in match summaries.</p></div>
      <div class="info-box"><p class="label">Event cache</p><p class="value">${escapeHtml(eventCacheFiles.toLocaleString())}</p><p class="caption">${escapeHtml(formatBytes(eventCacheBytes))} stored outside the main state file.</p></div>
      <div class="info-box"><p class="label">Local state file</p><p class="value">${escapeHtml(formatBytes(stateBytes))}</p><p class="caption">Match summaries stay lighter while selected replays can hydrate cached feeds.</p></div>
      <div class="info-box"><p class="label">History rows</p><p class="value">${escapeHtml(Number(audit.importedHistoryCount || 0).toLocaleString())}</p><p class="caption">Combat/PvPHelper summaries, not full log files.</p></div>
    </div>
    ${renderImportJobStatusCard()}
    <div class="settings-inline-card maintenance-card">
      <div><p class="small-label">Maintenance</p><h3>Compact local state</h3><p class="caption">Runs the shared match resolver, trims oversized history lists, prunes old log-index rows, moves heavy event feeds into cache files, and keeps favorites/video links intact.</p>${state.maintenanceStatus ? `<p class="caption">${escapeHtml(state.maintenanceStatus)}</p>` : ''}</div>
      <button class="btn violet" id="settings-compact-local-state">Compact App Data</button>
    </div>
    ${riskFlags.length ? `<div class="performance-risk-list">${riskFlags.map((flag) => `<div class="status-callout amber"><strong>Watch item</strong><span>${escapeHtml(flag)}</span></div>`).join('')}</div>` : '<div class="status-callout emerald"><strong>Looks safe</strong><span>No major loading risks detected from the saved app state.</span></div>'}
  </div>`;
}

function settingsCategories() {
  return [
    { id: 'logs', label: 'Logs', icon: '📜' },
    { id: 'data', label: 'PvPHelper', icon: '🧩' },
    { id: 'video', label: 'Video & Folders', icon: '🎥' },
    { id: 'connections', label: 'Connections', icon: '🧷' },
    { id: 'storage', label: 'Storage', icon: '🗂️' },
    { id: 'performance', label: 'Performance', icon: '🧪' },
    { id: 'updates', label: 'Updates', icon: '⬆️' }
  ];
}

function renderSettingsCategoryTabs() {
  const active = state.settingsCategory || 'logs';
  return `<div class="settings-category-tabs">${settingsCategories().map((item) => `<button class="settings-category-tab ${active === item.id ? 'active' : ''}" data-settings-category="${escapeHtml(item.id)}"><span>${escapeHtml(item.icon)}</span>${escapeHtml(item.label)}</button>`).join('')}</div>`;
}

function logTimeLabel(ms) {
  const n = Number(ms || 0);
  if (!Number.isFinite(n) || n <= 0) return 'Unknown';
  return formatSyncDateTime(n);
}

function compactLogStatusText(value = '') {
  const raw = String(value || '').trim();
  if (!raw) return 'Seen';
  return raw.replace(/-/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase());
}

function logMonitorRows() {
  const registry = state.logFileRegistry && typeof state.logFileRegistry === 'object' ? state.logFileRegistry : {};
  const activePath = String((state.settings && state.settings.logFilePath) || state.watchPath || '').toLowerCase();
  const rows = Object.values(registry).filter(Boolean).map((item) => {
    const filePath = item.filePath || '';
    const startMs = Number(item.firstLineMs || item.startMs || item.nameStartMs || 0) || 0;
    const endMs = Number(item.lastLineMs || item.endMs || item.nextStartMs || item.mtimeMs || 0) || 0;
    return {
      ...item,
      filePath,
      name: item.name || displayFileName(filePath),
      startMs,
      endMs,
      isActive: activePath && filePath && String(filePath).toLowerCase() === activePath,
      sortMs: Date.parse(item.scannedAt || item.processedAt || item.updatedAt || item.indexedAt || '') || Number(item.mtimeMs || endMs || startMs || 0) || 0
    };
  });
  return rows.sort((a, b) => (Number(b.isActive) - Number(a.isActive)) || (b.sortMs - a.sortMs) || String(b.name || '').localeCompare(String(a.name || '')));
}

function renderLogMonitor() {
  const rows = logMonitorRows();
  const logLimit = Math.max(10, Number(state.logMonitorVisibleLimit || 60));
  const visible = state.showAllLogMonitor ? rows.slice(0, logLimit) : rows.slice(0, 1);
  const hiddenCount = Math.max(0, rows.length - visible.length);
  if (!rows.length) {
    return `<div class="empty slim-empty">No indexed combat logs yet. Choose your WoW Logs folder, then Sync Active Log or Repair Missing Logs.</div>`;
  }
  return `<div class="log-monitor-panel">
    <div class="log-monitor-head"><div><p class="small-label">Log monitor</p><h3>${state.showAllLogMonitor ? 'Processed and discovered logs' : 'Latest processed log'}</h3><p class="caption">Shows lightweight tracking only. The app does not load whole historical logs just to display this list.</p></div>${rows.length > 1 ? `<button class="btn small" id="toggle-log-monitor-list">${state.showAllLogMonitor ? 'Show Latest Only' : `Show Rest (${hiddenCount})`}</button>` : ''}</div>
    <div class="log-monitor-table">
      ${visible.map((row) => `<div class="log-monitor-row ${row.isActive ? 'active-log-row' : ''}">
        <div><strong>${escapeHtml(row.name || 'Combat log')}</strong><span title="${escapeHtml(row.filePath || '')}">${escapeHtml(displayPathTail(row.filePath || '', 3) || row.filePath || '')}</span></div>
        <div><small>Status</small><b>${escapeHtml(row.isActive ? 'Active' : compactLogStatusText(row.status || row.lastStatus || 'indexed'))}</b></div>
        <div><small>Window</small><b>${escapeHtml(logTimeLabel(row.startMs))}</b><span>${escapeHtml(row.endMs ? `to ${logTimeLabel(row.endMs)}` : 'end unknown')}</span></div>
        <div><small>Size</small><b>${escapeHtml(formatBytes(row.size || row.bytes || 0))}</b><span>${row.parsedCount || row.importedCount || row.updatedCount ? escapeHtml(`${Number(row.parsedCount || 0)} parsed · ${Number(row.importedCount || 0)} new · ${Number(row.updatedCount || 0)} updated`) : escapeHtml(row.lastReason || '')}</span></div>
      </div>`).join('')}
    </div>
  </div>`;
}

function renderCombatLogsSettingsCard() {
  const settings = state.settings || {};
  const connectedPath = settings.logFilePath || state.watchPath || '';
  const connectedFolder = settings.logFolderPath || (connectedPath ? connectedPath.replace(/[\\/][^\\/]*$/, '') : '');
  const latestLog = latestCombatLogImport();
  const missingCount = (state.matches || []).filter((match) => match && (!match.createdFromRealLog && !((Array.isArray(match.eventFeed) ? match.eventFeed.length : 0) || (Array.isArray(match.rawEvents) ? match.rawEvents.length : 0)))).length;
  const activeName = displayFileName(connectedPath || '') || 'Not selected';
  return `<div class="card import-center-card">
    <div class="card-title-row"><div><p class="small-label">Combat logs</p><h2>Log mapping and repair</h2><p class="caption">Active sync reads only appended log data. Match sync and repair use focused windows so big historical logs do not get loaded whole.</p></div><div class="icon-bubble gradient-bubble">📜</div></div>
    <div class="settings-summary-grid">
      <div class="info-box"><p class="label">Logs folder</p><p class="value path-value">${escapeHtml(connectedFolder || 'Not selected')}</p></div>
      <div class="info-box"><p class="label">Active log</p><p class="value path-value">${escapeHtml(activeName)}</p><p class="caption">${escapeHtml(settings.logLastSyncAt ? `Last sync ${formatSyncDateTime(settings.logLastSyncAt)}` : 'Never synced')}</p></div>
      <div class="info-box"><p class="label">Missing log links</p><p class="value">${escapeHtml(String(missingCount))}</p><p class="caption">Repair works oldest missing matches in small batches.</p></div>
      <div class="info-box"><p class="label">Latest result</p><p class="value">${escapeHtml(latestLog ? (latestLog.state || 'Imported') : 'No imports yet')}</p><p class="caption">${escapeHtml(latestLog ? formatSyncDateTime(latestLog.importedAt) : 'No combat log imports yet.')}</p></div>
    </div>
    <div class="action-row settings-primary-actions"><button class="btn emerald" id="settings-auto-connect-local-setup">Auto-Locate Setup</button><button class="btn" id="settings-scan-logs" ${state.logSyncBusy ? 'disabled' : ''}>${state.logSyncBusy ? 'Syncing…' : 'Sync Active Log'}</button><button class="btn violet" id="settings-pick-log-folder">Choose Logs Folder</button><button class="btn" id="settings-import-old-log">Import Previous Combat Log</button><button class="btn violet" id="settings-repair-missing-logs" ${state.logRepairBusy ? 'disabled' : ''}>${state.logRepairBusy ? 'Repairing…' : 'Repair Missing Logs'}</button></div>
    ${renderLogMonitor()}
  </div>`;
}

function renderPvPHelperSettingsCard() {
  const settings = state.settings || {};
  const mappedPvph = settings.pvpHelperSavedVariablesPath || '';
  const latestAddon = latestPvPHelperImport();
  const ratingCount = (state.characterSnapshots || []).length;
  const lastSync = settings.pvpHelperLastSyncAt ? new Date(settings.pvpHelperLastSyncAt).toLocaleString() : 'Never';
  const scoreboardCount = Number(settings.pvpHelperLastScoreboardCount || (latestAddon && latestAddon.parsedCount) || 0);
  const pendingCount = Number(settings.pvpHelperLastPendingCount || (latestAddon && latestAddon.createdCount) || 0);
  const linkedCount = Number(settings.pvpHelperLastMergedCount || (latestAddon && latestAddon.mergedCount) || 0);
  const schemaVersion = Number(settings.pvpHelperMatchHistorySchemaVersion || (settings.pvpHelperStatus && settings.pvpHelperStatus.matchHistorySchemaVersion) || 0);
  return `<div class="card import-center-card">
    <div class="card-title-row"><div><p class="small-label">PvPHelper SavedVariables ${pvpHelperSyncHelpIcon()}</p><h2>Addon data bridge</h2><p class="caption">Map the SavedVariables folder once. PvPHelper scoreboards attach to matches and rating snapshots feed the character timeline.</p></div><div class="icon-bubble">🧩</div></div>
    <div class="import-lane-status"><span>Mapped file</span>${pathValueMarkup(mappedPvph, 'Not mapped yet', 3)}</div>
    <div class="import-lane-status"><span>Last sync</span><strong>${escapeHtml(lastSync)}</strong></div>
    <div class="sync-count-strip"><span>${scoreboardCount} scoreboards found</span><span>${linkedCount} linked</span><span>${pendingCount} pending</span><span>${ratingCount} rating snapshots</span>${schemaVersion ? `<span>schema ${schemaVersion}</span>` : ''}</div>
    <div class="addon-status-grid addon-install-grid">${renderPvPHelperInstallStatusCard('settings')}</div>
    ${renderPvPHelperMappingAssist(mappedPvph, 'settings')}
    ${renderPvPHelperAddonStatus(mappedPvph, settings)}
    <label class="toggle-row slim-toggle"><input type="checkbox" id="pvphelper-auto-sync" ${settings.pvpHelperAutoSync !== false ? 'checked' : ''}/> <span>Auto-sync this file after startup when it changed</span></label>
    <div class="action-row">${mappedPvph ? `<button class="btn emerald" id="sync-pvph-savedvariables" ${state.pvpHelperSyncBusy ? 'disabled' : ''}>${state.pvpHelperSyncBusy ? 'Syncing…' : 'Sync Now'}</button><button class="btn" id="import-pvph-savedvariables">Change Folder</button><button class="btn" id="clear-pvph-savedvariables">Clear Mapping</button>` : '<button class="btn violet" id="import-pvph-savedvariables">Map PvPHelper.lua</button>'}${pvpHelperSyncHelpIcon('inline-action-help')}</div>
    ${renderLatestImportSummary(latestAddon, 'No PvPHelper syncs yet.', 'Most recent PvPHelper sync')}
    <details class="legacy-details"><summary>Legacy one-off rating export</summary><p class="caption">Only use this if you have an older standalone character/rating export. Normal setup should use the mapped PvPHelper.lua above.</p><div class="action-row"><button class="btn" id="import-character-snapshot">Import Legacy Rating Export</button></div></details>
  </div>`;
}

function renderVideoFolderSettingsCard() {
  const settings = state.settings || {};
  return `<div class="card">
    <div class="card-title-row"><div><p class="small-label">Video and folders</p><h2>Recording storage and auto-linking</h2><p class="caption">Recording folders and video-match timing live here so the log screen stays focused.</p></div><div class="icon-bubble">🎥</div></div>
    <div class="grid two-col" style="margin-top:16px">
      <div class="info-box"><p class="label">Recordings folder</p><p class="value path-value">${escapeHtml(settings.recordingsDir && settings.recordingsDirConfirmed ? settings.recordingsDir : 'Not selected')}</p><div class="action-row"><button class="btn emerald" id="settings-default-recordings-folder">Use Default Folder</button><button class="btn violet" id="settings-recordings-folder">Choose Folder</button><button class="btn" id="settings-scan-recordings">Scan Videos</button></div></div>
      <div class="info-box"><p class="label">VOD export folder</p><p class="value path-value">${escapeHtml(exportFolderLabel())}</p><div class="action-row"><button class="btn violet" id="choose-export-folder">Choose Folder</button>${exportFolderLabel() ? `<button class="btn" data-reveal-path="${escapeHtml(exportFolderLabel())}">Show Folder</button>` : ''}</div></div>
      <div class="info-box"><p class="label">Log archive folder</p><p class="value path-value">${escapeHtml(settings.archiveDir || 'Default archive folder')}</p><div class="action-row"><button class="btn violet" id="settings-archive-folder">Change Folder</button></div></div>
    </div>
    <div class="settings-inline-card">
      <div><p class="small-label">Fallback link window</p><h3>Match video matching</h3><p class="caption">Default is 0. Finished recordings use exact overlap from video time and match/log time. Raise this only for loose recordings without reliable timing.</p></div>
      <label class="setting-row compact-setting-row"><span>Fallback minutes</span><input id="settings-auto-link-window" type="number" min="0" max="240" value="${escapeHtml(Number.isFinite(Number(settings.autoLinkWindowMinutes)) ? Number(settings.autoLinkWindowMinutes) : 0)}" /></label>
    </div>
  </div>`;
}

function matchHasCombatLogLink(match = {}) {
  const sources = Array.isArray(match.dataSources) ? match.dataSources.map((item) => String(item || '').toLowerCase()) : [];
  const rowCount = Math.max(
    Number(match.eventFeedRows || 0),
    Number(match.eventFeedCachedRows || 0),
    Number(match.eventFeedPreviewRows || 0),
    Array.isArray(match.eventFeed) ? match.eventFeed.length : 0,
    Array.isArray(match.rawEvents) ? match.rawEvents.length : 0
  );
  return Boolean(match.createdFromRealLog || match.logOnlyDiscovery || rowCount > 0 || sources.includes('combatlog') || sources.includes('logonlydiscovery'));
}

function matchHasScoreboardLink(match = {}) {
  const sources = Array.isArray(match.dataSources) ? match.dataSources.map((item) => String(item || '').toLowerCase()) : [];
  return Boolean(match.addonScoreboard || match.createdFromAddon || sources.includes('addonscoreboard') || (Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length));
}

function auditTone(ok) {
  return ok ? 'emerald' : 'amber';
}

function renderConnectionsAuditSettingsCard() {
  const matches = state.matches || [];
  const recordings = state.recorder.recordings || [];
  const vods = state.vods || [];
  const favoriteCount = matches.filter(isFavoriteMatch).length;
  const matchVideoCount = matches.filter((match) => match && matchVideoPath(match)).length;
  const matchLogCount = matches.filter(matchHasCombatLogLink).length;
  const matchScoreboardCount = matches.filter(matchHasScoreboardLink).length;
  const recordingLinkedCount = recordings.filter((rec) => recordingLinkedMatchIds(rec).length).length;
  const vodLinkedCount = vods.filter((vod) => (matches || []).some((match) => match && match.vodId === vod.id)).length;
  const recentMatches = [...matches].filter(Boolean).sort((a, b) => matchSortTime(b) - matchSortTime(a)).slice(0, 60);
  const recentRecordings = [...recordings].filter(Boolean).sort((a, b) => (Date.parse(b.startedAt || b.endedAt || 0) || 0) - (Date.parse(a.startedAt || a.endedAt || 0) || 0)).slice(0, 40);
  const recentVods = [...vods].filter(Boolean).sort((a, b) => (Date.parse(b.importedAt || b.lastLinkedAt || 0) || 0) - (Date.parse(a.importedAt || a.lastLinkedAt || 0) || 0)).slice(0, 30);
  const matchRows = recentMatches.map((match) => {
    const video = Boolean(matchVideoPath(match));
    const logs = matchHasCombatLogLink(match);
    const board = matchHasScoreboardLink(match);
    const fav = isFavoriteMatch(match);
    return `<div class="connection-row">
      <div><strong>${favoriteMark(match)}${escapeHtml(match.map || match.matchLabel || 'Unknown match')}</strong><span>${escapeHtml(matchTimestampLabel(match))} · ${escapeHtml(displayMatchType(match))}</span></div>
      ${pill(video ? 'Video' : 'No video', auditTone(video))}
      ${pill(logs ? 'Logs' : 'No logs', auditTone(logs))}
      ${pill(board ? 'Scoreboard' : 'No board', auditTone(board))}
      ${pill(fav ? 'Favorite' : 'Not favorite', fav ? 'amber' : '')}
    </div>`;
  }).join('');
  const recordingRows = recentRecordings.map((rec) => {
    const linkedIds = recordingLinkedMatchIds(rec);
    const audio = rec.audioTrackCount > 0 || rec.audioCaptured === true ? 'Audio captured' : rec.includeAudio === true ? 'Audio requested' : 'Audio off';
    return `<div class="connection-row media-row">
      <div><strong>${escapeHtml(recordingTitleForItem(rec))}</strong><span>${escapeHtml(displayPathTail(rec.filePath || '', 3) || rec.filePath || '')}</span></div>
      ${pill(linkedIds.length ? `${linkedIds.length} match${linkedIds.length === 1 ? '' : 'es'}` : 'Unlinked', linkedIds.length ? 'cyan' : 'amber')}
      ${pill(audio, rec.audioTrackCount > 0 || rec.audioCaptured === true ? 'emerald' : rec.includeAudio === true ? 'cyan' : 'amber')}
      ${pill(formatBytes(rec.bytes || 0), '')}
    </div>`;
  }).join('');
  const vodRows = recentVods.map((vod) => {
    const linked = matches.filter((match) => match && match.vodId === vod.id).length || Number(vod.lastLinkedCount || 0);
    return `<div class="connection-row media-row">
      <div><strong>${escapeHtml(vod.label || 'Imported VOD')}</strong><span>${escapeHtml(displayPathTail(vod.filePath || '', 3) || vod.filePath || '')}</span></div>
      ${pill(linked ? `${linked} match${linked === 1 ? '' : 'es'}` : 'Unlinked', linked ? 'cyan' : 'amber')}
      ${pill(vod.sourceType === 'recording-session' ? 'Recording session' : 'VOD', 'violet')}
    </div>`;
  }).join('');
  return `<div class="card connections-audit-card">
    <div class="card-title-row"><div><p class="small-label">Connections</p><h2>Library connection audit</h2><p class="caption">Matches are the hub. Logs, scoreboards, VODs, recordings, and favorites should connect to matches instead of directly to each other.</p></div><div class="icon-bubble">🧷</div></div>
    <div class="sync-count-strip"><span>${matches.length} matches</span><span>${matchVideoCount} with video</span><span>${matchLogCount} with logs</span><span>${matchScoreboardCount} with scoreboards</span><span>${favoriteCount} favorites</span><span>${recordingLinkedCount}/${recordings.length} recordings linked</span><span>${vodLinkedCount}/${vods.length} VODs linked</span></div>
    <div class="action-row settings-primary-actions"><button class="btn violet" id="settings-repair-library-links">Repair Library Links</button><button class="btn" id="settings-scan-recordings">Scan Videos</button><button class="btn" id="settings-repair-missing-logs">Repair Missing Logs</button></div>
    <div class="status-callout neutral" style="margin-top:12px"><strong>How this should work</strong><span>Recordings and VODs do not need combat logs attached to them directly. They attach to matches. Combat logs also attach to matches. The match becomes the clean meeting table.</span></div>
    <div class="connection-audit-section"><h3>Recent matches</h3><div class="connection-table">${matchRows || '<div class="empty slim-empty">No matches found yet.</div>'}</div></div>
    <div class="grid two-col connection-media-grid">
      <div class="connection-audit-section"><h3>Recent recordings</h3><div class="connection-table">${recordingRows || '<div class="empty slim-empty">No recordings found yet.</div>'}</div></div>
      <div class="connection-audit-section"><h3>Recent VODs</h3><div class="connection-table">${vodRows || '<div class="empty slim-empty">No VODs found yet.</div>'}</div></div>
    </div>
  </div>`;
}

function renderStorageSettingsCard() {
  return `<div class="card">
    <div class="card-title-row"><div><p class="small-label">App storage</p><h2>Local Files</h2><p class="caption">Move the local library, settings, reports, archives, and default recordings to another drive. Use portable mode when the app and storage should travel together on an external drive.</p></div><div class="icon-bubble">🗂️</div></div>
    ${state.appPaths && state.appPaths.storageWarning ? `<div class="status-callout amber" style="margin-top:12px"><strong>Storage warning</strong><span>${escapeHtml(state.appPaths.storageWarning)}</span></div>` : ''}
    <div class="grid two-col" style="margin-top:16px">
      <div class="info-box"><p class="label">App storage folder</p><p class="value path-value">${escapeHtml((state.appPaths && state.appPaths.storage) || '')}</p><p class="caption">${state.appPaths && state.appPaths.portableStorageActive ? 'Portable storage is active. This app folder can carry its data to another computer.' : state.appPaths && state.appPaths.customStorageActive ? 'Custom storage is active on this computer.' : 'Using the default Windows app-data folder.'}</p><div class="action-row"><button class="btn violet" id="settings-app-storage-folder">Change Storage Folder</button><button class="btn" id="settings-portable-storage-folder">Use Portable Folder</button><button class="btn" id="settings-connect-storage-folder">Connect Existing Storage</button><button class="btn" id="settings-create-state-backup">Backup Now</button>${state.appPaths && state.appPaths.storage ? `<button class="btn" data-reveal-path="${escapeHtml(state.appPaths.storage)}">Show Folder</button>` : ''}</div></div>
      <div class="info-box"><p class="label">Settings file</p><p class="value path-value">${escapeHtml((state.appPaths && state.appPaths.state) || '')}</p><p class="caption">This is the active app data file the current window is reading.</p></div><div class="info-box"><p class="label">Backups folder</p><p class="value path-value">${escapeHtml((state.appPaths && state.appPaths.backups) || '')}</p><p class="caption">The app now creates a safety copy before the first state write each run.</p></div>
      <div class="info-box"><p class="label">Portable app folder</p><p class="value path-value">${escapeHtml((state.appPaths && state.appPaths.portableRoot) || '')}</p><p class="caption">Portable mode creates ${escapeHtml((state.appPaths && state.appPaths.defaultPortableStorage) || 'LastCallReplayData')} and stores a portable pointer beside the app.</p></div>
      <div class="info-box"><p class="label">Active storage pointer</p><p class="value path-value">${escapeHtml((state.appPaths && state.appPaths.activeStoragePointer) || (state.appPaths && state.appPaths.storagePointer) || '')}</p><p class="caption">Source: ${escapeHtml((state.appPaths && state.appPaths.storagePointerSource) || 'default')}</p></div>
      <div class="info-box"><p class="label">Default Windows storage</p><p class="value path-value">${escapeHtml((state.appPaths && state.appPaths.defaultStorage) || '')}</p></div>
      <div class="info-box"><p class="label">Portable pointer</p><p class="value path-value">${escapeHtml((state.appPaths && state.appPaths.portableStoragePointer) || '')}</p></div>
    </div>
  </div>`;
}


function renderUpdateSettingsCard() {
  const settings = state.settings || {};
  const status = state.updateStatus || {};
  const currentVersion = status.currentVersion || state.appVersion || 'Unknown';
  const latestVersion = status.latestVersion || settings.updateLatestVersion || '';
  const releasedAt = status.releasedAt || settings.updateReleasedAt || '';
  const releaseUrl = status.releaseUrl || settings.updateReleaseUrl || 'https://github.com/darkstavern-code/last-call-replay/releases';
  const installerUrl = status.installerUrl || settings.updateInstallerUrl || '';
  const zipUrl = status.zipUrl || settings.updateZipUrl || '';
  const checkedAt = status.checkedAt || settings.updateLastCheckedAt || '';
  const rawNotes = Array.isArray(status.releaseNotes) ? status.releaseNotes : (Array.isArray(settings.updateReleaseNotes) ? settings.updateReleaseNotes : []);
  const releaseNotes = rawNotes.map((note) => String(note || '').trim()).filter(Boolean).slice(0, 12);
  const configured = status.configured !== false && Boolean((settings.updateManifestUrl || status.manifestUrl || 'https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json').trim());
  const statusTone = status.updateAvailable ? 'amber' : status.ok === false ? 'rose' : !configured ? 'neutral' : latestVersion ? 'emerald' : 'neutral';
  const statusTitle = status.checking
    ? 'Checking for updates…'
    : status.updateAvailable
      ? 'Update available'
      : status.ok === false
        ? 'Update check failed'
        : !configured
          ? 'latest.json URL missing'
          : latestVersion
            ? 'You’re up to date'
            : 'Ready to check';
  const statusText = status.checking
    ? 'Looking for the hosted latest.json file.'
    : status.reason || status.message || (latestVersion ? `Latest version: ${latestVersion}` : 'Paste the stable latest.json URL, then click Check for updates.');
  const notesMarkup = releaseNotes.length
    ? `<div class="update-release-notes"><p class="small-label">Release notes</p><ul>${releaseNotes.map((note) => `<li>${escapeHtml(note)}</li>`).join('')}</ul></div>`
    : '';
  const downloadButtons = status.updateAvailable
    ? `<div class="action-row settings-primary-actions update-download-actions">
        ${installerUrl ? `<button class="btn violet" data-update-download-url="${escapeHtml(installerUrl)}">Download Installer</button>` : ''}
        ${zipUrl ? `<button class="btn" data-update-download-url="${escapeHtml(zipUrl)}">Download Zip</button>` : ''}
        ${releaseUrl ? `<button class="btn" id="settings-open-release-page">Open Release Page</button>` : ''}
      </div>`
    : `${releaseUrl ? `<div class="action-row settings-primary-actions update-download-actions"><button class="btn" id="settings-open-release-page">Open Release Page</button></div>` : ''}`;
  return `<div class="card update-settings-card">
    <div class="card-title-row"><div><p class="small-label">Updates</p><h2>Manual update checker</h2><p class="caption">Option 1 only: checks a hosted latest.json file and opens download links. It does not auto-install, replace files, move folders, or touch recordings, mappings, local state, SavedVariables links, or addon packages.</p></div><div class="icon-bubble">⬆️</div></div>
    <div class="settings-summary-grid">
      <div class="info-box"><p class="label">Current installed version</p><p class="value">${escapeHtml(currentVersion)}</p></div>
      <div class="info-box"><p class="label">Latest available version</p><p class="value">${escapeHtml(latestVersion || 'Not checked')}</p><p class="caption">${escapeHtml(releasedAt ? `Released ${releasedAt}` : checkedAt ? `Checked ${formatSyncDateTime(checkedAt)}` : 'No update check run yet.')}</p></div>
    </div>
    <div class="status-callout ${escapeHtml(statusTone)}" style="margin-top:12px"><strong>${escapeHtml(statusTitle)}</strong><span>${escapeHtml(statusText)}</span></div>
    ${status.updateAvailable ? `<div class="settings-inline-card update-available-card"><div><p class="small-label">Available download</p><h3>${escapeHtml(`Last Call Replay Desktop ${latestVersion}`)}</h3><p class="caption">Choose the installer for normal users or the zip for portable/manual installs.</p></div></div>${notesMarkup}${downloadButtons}` : `${notesMarkup}${downloadButtons}`}
    <div class="settings-inline-card">
      <div><p class="small-label">latest.json feed</p><h3>Stable manifest URL</h3><p class="caption">Host this at one URL that always points to the newest version info. GitHub Pages or a GitHub raw file works well.</p></div>
      <label class="setting-row compact-setting-row"><span>latest.json URL</span><input id="settings-update-manifest-url" type="url" placeholder="https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json" value="${escapeHtml(settings.updateManifestUrl || 'https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json')}" /></label>
    </div>
    <div class="settings-inline-card">
      <div><p class="small-label">Fallback link</p><h3>Release page</h3><p class="caption">Used if latest.json has no release page link, or if you want users to browse all releases manually.</p></div>
      <label class="setting-row compact-setting-row"><span>Release page URL</span><input id="settings-update-release-url" type="url" placeholder="https://github.com/darkstavern-code/last-call-replay/releases" value="${escapeHtml(settings.updateReleaseUrl || 'https://github.com/darkstavern-code/last-call-replay/releases')}" /></label>
    </div>
    <div class="action-row settings-primary-actions"><button class="btn violet" id="settings-check-updates" ${status.checking ? 'disabled' : ''}>${status.checking ? 'Checking…' : 'Check for Updates'}</button></div>
    <div class="status-callout neutral" style="margin-top:12px"><strong>latest.json shape</strong><span>{ version, releasedAt, installerUrl, zipUrl, releaseNotes }. Downloads open in the browser. Nothing installs inside the app yet.</span></div>
  </div>`;
}

function renderSettings() {
  const active = state.settingsCategory || 'logs';
  const content = active === 'logs'
    ? renderCombatLogsSettingsCard()
    : active === 'data'
      ? renderPvPHelperSettingsCard()
      : active === 'video'
        ? renderVideoFolderSettingsCard()
        : active === 'connections'
          ? renderConnectionsAuditSettingsCard()
          : active === 'storage'
            ? renderStorageSettingsCard()
            : active === 'performance'
              ? renderPerformanceAudit()
              : renderUpdateSettingsCard();
  return `
    <div class="grid settings-shell" style="max-width:1180px">
      <div class="card settings-hero-card">
        <div class="card-title-row"><div><p class="small-label">Settings</p><h2>Setup center</h2><p class="caption">Split into smaller rooms: logs, PvPHelper, video folders, storage, and performance. Same features, less attic clutter.</p></div><div class="icon-bubble">⚙️</div></div>
        ${renderSettingsCategoryTabs()}
      </div>
      ${content}
    </div>
  `;
}


    return {
      performanceStatusTone,
      renderImportJobStatusCard,
      renderPerformanceAudit,
      settingsCategories,
      renderSettingsCategoryTabs,
      logTimeLabel,
      compactLogStatusText,
      logMonitorRows,
      renderLogMonitor,
      renderCombatLogsSettingsCard,
      renderPvPHelperSettingsCard,
      renderVideoFolderSettingsCard,
      matchHasCombatLogLink,
      matchHasScoreboardLink,
      auditTone,
      renderConnectionsAuditSettingsCard,
      renderStorageSettingsCard,
      renderUpdateSettingsCard,
      renderSettings
    };
  }

  window.LastCallSettingsView = { createSettingsViewTools };
})();
