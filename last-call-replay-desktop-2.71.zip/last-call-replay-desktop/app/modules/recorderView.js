(function () {
  'use strict';

  function createRecorderViewTools(deps = {}) {
    const state = deps.state || { recorder: { recordings: [] }, settings: {}, matches: [], vods: [] };
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const sourceSort = deps.sourceSort || (() => 0);
    const allowedCaptureSources = deps.allowedCaptureSources || ((sources) => sources || []);
    const captureSourceKind = deps.captureSourceKind || (() => 'program');
    const sourceLooksLikeWow = deps.sourceLooksLikeWow || (() => false);
    const currentCaptureSource = deps.currentCaptureSource || (() => null);
    const recorderSetupSummary = deps.recorderSetupSummary || (() => ({ ready: false, hasFolder: false, isRecording: false, title: 'Needs setup', sourceText: 'No source selected' }));
    const recorderPerformanceLabel = deps.recorderPerformanceLabel || (() => 'Balanced');
    const recorderPerformanceCaption = deps.recorderPerformanceCaption || (() => 'Recommended default.');
    const validRecorderPerformanceMode = deps.validRecorderPerformanceMode || ((value) => value || 'balanced');
    const cleanRecordingTitleText = deps.cleanRecordingTitleText || ((value) => String(value || '').trim());
    const displayFileName = deps.displayFileName || ((value) => String(value || '').split(/[\/]/).pop() || '');
    const displayMatchType = deps.displayMatchType || (() => 'PvP');
    const shortCharacterName = deps.shortCharacterName || ((value) => String(value || '').split('-')[0] || 'Unknown');
    const matchClock = deps.matchClock || (() => '');
    const matchDurationForDisplay = deps.matchDurationForDisplay || ((match) => match && match.duration || '0:00');
    const boundedMatchRangeMsForVod = deps.boundedMatchRangeMsForVod || (() => ({ start: 0, gameStart: 0, end: 0 }));
    const formatElapsed = deps.formatElapsed || ((value) => String(value || 0));
    const formatBytes = deps.formatBytes || ((value) => String(value || 0));
    const renderLoadMoreButton = deps.renderLoadMoreButton || (() => '');

    function uniqueRecordingCount() {
      const keys = new Set();
      for (const rec of state.recorder.recordings || []) {
        if (!rec) continue;
        keys.add((rec.filePath || `${rec.sourceName || ''}|${rec.startedAt || ''}|${rec.bytes || 0}`).toLowerCase());
      }
      return keys.size;
    }

    function renderSourcePicker(context = 'main') {
      const sources = allowedCaptureSources(state.recorder.sources || []).sort(sourceSort);
      const programs = sources.filter((source) => captureSourceKind(source) === 'program' && sourceLooksLikeWow(source));
      const screens = sources.filter((source) => captureSourceKind(source) === 'screen');
      const selected = currentCaptureSource();
      const approvalNeeded = Boolean(state.recorder.sourceApprovalRequired && !state.recorder.sourceApproved);
      const wowStatus = programs.length ? 'Detected' : 'Not detected';
      const cardFor = (source, extra = '') => {
        const kind = captureSourceKind(source);
        const selectedClass = source.id === state.recorder.selectedSourceId ? 'active' : '';
        const thumb = source.thumbnail ? `<img src="${escapeHtml(source.thumbnail)}" alt="" />` : `<div class="source-card-thumb ${kind}">${kind === 'screen' ? '🖥️' : '🎮'}</div>`;
        return `<button class="source-choice-card ${selectedClass} ${extra}" data-source-id="${escapeHtml(source.id)}" data-source-name="${escapeHtml(source.name)}" data-source-kind="${escapeHtml(kind)}">
          ${thumb}
          <div class="source-choice-copy"><strong>${escapeHtml(source.name || source.id)}</strong><span>${kind === 'screen' ? 'Screen / monitor' : 'World of Warcraft window'}</span></div>
          <b>${source.id === state.recorder.selectedSourceId ? '✓' : ''}</b>
        </button>`;
      };
      return `<div class="source-picker-panel">
        <div class="source-picker-header"><div><p class="label">Capture source</p><h3>Choose what to record</h3></div><span class="source-count">WoW ${wowStatus} · ${screens.length} screen${screens.length === 1 ? '' : 's'}</span></div>
        <div class="source-section"><p class="small-label">World of Warcraft</p>${programs.length ? programs.map((source) => cardFor(source)).join('') : `<div class="source-choice-card disabled"><div class="source-card-thumb program">🎮</div><div class="source-choice-copy"><strong>World of Warcraft</strong><span>Not detected. Open WoW, then Scan Again.</span></div></div>`}</div>
        <div class="source-section"><p class="small-label">Screens</p>${screens.length ? screens.map((source) => cardFor(source)).join('') : '<div class="empty slim-empty">No screens returned by Windows yet.</div>'}</div>
        ${selected ? `<div class="source-picked-note ${approvalNeeded ? 'warn' : 'good'}"><strong>${approvalNeeded ? 'Suggested source needs approval' : 'Selected'}:</strong> ${escapeHtml(selected.name || state.recorder.selectedSourceName)}</div>` : '<div class="source-picked-note warn">No source selected yet.</div>'}
      </div>`;
    }

    function renderSourceQuickModal() {
      if (!state.showSourceQuickPicker) return '';
      const approvalNeeded = Boolean(state.recorder.sourceApprovalRequired && !state.recorder.sourceApproved);
      const doneLabel = approvalNeeded ? 'Approve Source' : 'Done';
      return `<div class="modal-scrim" id="source-quick-scrim">
        <div class="quick-source-modal card">
          <div class="card-title-row"><div><p class="small-label">Recording source</p><h2>Choose capture source</h2><p class="caption">Only World of Warcraft and screens are shown. Use a screen if window capture acts cursed.</p></div><button class="btn" id="close-source-quick">Close</button></div>
          <div class="quick-source-picker">${renderSourcePicker('quick')}</div>
          <div class="action-row" style="margin-top:14px"><button class="btn violet" id="quick-refresh-sources">Scan Again</button><button class="btn primary" id="quick-source-done">${doneLabel}</button></div>
        </div>
      </div>`;
    }

    function renderRecorderSettingsModal() {
      if (!state.showRecorderSettings) return '';
      const rec = state.recorder;
      const hasRecordingFolder = Boolean(state.settings.recordingsDir && state.settings.recordingsDirConfirmed);
      return `<div class="modal-scrim" id="recorder-settings-scrim">
        <div class="quick-source-modal card recorder-settings-modal">
          <div class="card-title-row"><div><p class="small-label">Recording settings</p><h2>Storage and rules</h2><p class="caption">These options stay out of the main recorder so the Start button can breathe.</p></div><button class="btn" id="close-recorder-settings">Close</button></div>
          <div class="grid two-col" style="margin-top:16px">
            <div class="info-box"><p class="label">Storage folder</p><p class="value path-value">${escapeHtml(hasRecordingFolder ? state.settings.recordingsDir : 'Not selected')}</p><div class="action-row"><button class="btn emerald" id="settings-default-recordings-folder">Use Default Folder</button><button class="btn violet" id="settings-recordings-folder">Choose Folder</button></div></div>
            <div class="info-box"><p class="label">Fallback link window</p><p class="value">${escapeHtml(Number.isFinite(Number(state.settings.autoLinkWindowMinutes)) ? Number(state.settings.autoLinkWindowMinutes) : 0)} minutes</p><p class="caption">0 means exact overlap only for normal matching.</p></div>
          </div>
          <label class="setting-row"><span>Recording performance</span><select id="rec-performance-mode" class="compact-select"><option value="low" ${validRecorderPerformanceMode(rec.performanceMode) === 'low' ? 'selected' : ''}>Low impact</option><option value="balanced" ${validRecorderPerformanceMode(rec.performanceMode) === 'balanced' ? 'selected' : ''}>Balanced</option><option value="quality" ${validRecorderPerformanceMode(rec.performanceMode) === 'quality' ? 'selected' : ''}>High quality</option></select></label>
          <p class="caption recorder-performance-note">${escapeHtml(recorderPerformanceCaption(rec.performanceMode))}</p>
          <label class="setting-row"><input type="checkbox" id="rec-audio" ${rec.includeAudio ? 'checked' : ''} /> <span>Try to include system audio when supported</span></label>
          <p class="caption recorder-audio-note">System audio is desktop/game sound in the recording file. It must be enabled before recording starts, and Windows/Electron may only allow it for some screen-capture paths.</p>
        </div>
      </div>`;
    }

    function recordingDisplayLabel(item) {
      if (!item) return 'Recording';
      const linkedIds = recordingLinkedMatchIds(item);
      if (linkedIds.length > 1) return `${linkedIds.length} matches attached`;
      const linkedMatch = linkedIds.length === 1 ? state.matches.find((match) => match.id === linkedIds[0]) : null;
      if (linkedMatch) return `${displayMatchType(linkedMatch)} · ${linkedMatch.map || 'Match'} · ${shortCharacterName(linkedMatch.alt || 'Unknown')}`;
      const base = cleanRecordingTitleText(item.label || item.sourceName || 'Recording');
      const source = item.sourceName && !base.toLowerCase().includes(String(item.sourceName).toLowerCase()) ? ` · ${item.sourceName}` : '';
      return `${base}${source}`;
    }

    function recordingLinkedMatchIds(item) {
      if (!item) return [];
      const ids = [];
      if (Array.isArray(item.linkedMatchIds)) ids.push(...item.linkedMatchIds.filter(Boolean));
      if (item.matchId) ids.push(item.matchId);
      const norm = item.filePath ? String(item.filePath).toLowerCase().replace(/\\/g, '/') : '';
      for (const match of state.matches || []) {
        if (!match || !match.id) continue;
        const matchNorm = match.videoPath ? String(match.videoPath).toLowerCase().replace(/\\/g, '/') : '';
        if ((item.id && match.videoSessionId === item.id) || (norm && matchNorm === norm)) ids.push(match.id);
      }
      return Array.from(new Set(ids.filter(Boolean)));
    }

    function recordingSessionVodFor(item) {
      if (!item) return null;
      const norm = item.filePath ? String(item.filePath).toLowerCase().replace(/\\/g, '/') : '';
      return (state.vods || []).find((vod) => vod && ((item.id && vod.recordingId === item.id) || (norm && vod.filePath && String(vod.filePath).toLowerCase().replace(/\\/g, '/') === norm))) || null;
    }

    function recordingTitleForItem(item) {
      if (!item) return 'Recording';
      const vod = recordingSessionVodFor(item);
      const linkedCount = recordingLinkedMatchIds(item).length;
      if ((vod && vod.sourceType === 'recording-session') || item.sourceName || item.filePath) {
        const source = String(item.sourceName || '').trim();
        const sourceLooksGeneric = !source || /^screen|^window|^entire screen/i.test(source);
        const sourceLabel = sourceLooksGeneric ? '' : cleanRecordingTitleText(source).replace(/\s+recorder\s+session$/i, '').trim();
        if (linkedCount > 1) return sourceLabel ? `${sourceLabel} Recording` : 'Recording Session';
        if (linkedCount === 1) return sourceLabel ? `${sourceLabel} Match Recording` : 'Match Recording';
        return sourceLabel ? `${sourceLabel} Recording` : 'Recording Session';
      }
      const rawTitle = cleanRecordingTitleText((vod && vod.label) || item.label || 'Recording');
      const fileTitle = cleanRecordingTitleText(displayFileName(item.filePath || ''));
      if (fileTitle && rawTitle.toLowerCase().includes(fileTitle.toLowerCase())) return 'Recording Session';
      return rawTitle || 'Recording';
    }

    function recordingMatchCards(item) {
      const ids = recordingLinkedMatchIds(item);
      const matches = ids.map((id) => (state.matches || []).find((match) => match && match.id === id)).filter(Boolean);
      if (!matches.length) return '<div class="recording-match-empty">No matches attached yet.</div>';
      const rows = matches.slice(0, 5).map((match) => {
        const title = `${matchClock(match) || ''} · ${match.map || 'Unknown map'}`.replace(/^\s*·\s*/, '');
        const meta = `${displayMatchType(match)} · ${matchDurationForDisplay(match)}`;
        return `<button class="recording-match-chip" data-recording-open-match="${escapeHtml(match.id)}" title="Open attached match"><strong>${escapeHtml(title)}</strong><small>${escapeHtml(meta)}</small></button>`;
      }).join('');
      const more = matches.length > 5 ? `<span class="recording-more-matches">+${matches.length - 5} more</span>` : '';
      return `<div class="recording-match-list">${rows}${more}</div>`;
    }

    function recordingLinkedMatchCount(item) {
      return recordingLinkedMatchIds(item).length;
    }

    function recordingStartMs(item = {}) {
      const values = [item.startedAt, item.importedAt, item.createdAt].map((value) => value ? Date.parse(value) : 0).filter((value) => Number.isFinite(value) && value > 0);
      return values[0] || 0;
    }

    function recordingEndMs(item = {}) {
      const end = item.endedAt ? Date.parse(item.endedAt) : 0;
      if (Number.isFinite(end) && end > 0) return end;
      const start = recordingStartMs(item);
      const duration = Number(item.durationSec || item.duration || 0);
      if (start && Number.isFinite(duration) && duration > 0) return start + duration * 1000;
      return 0;
    }

    function recordingSuggestedMatches(item, limit = 4) {
      if (!item) return [];
      const linkedIds = new Set(recordingLinkedMatchIds(item));
      const recStart = recordingStartMs(item);
      if (!recStart) return [];
      const recEnd = recordingEndMs(item);
      const configuredWindow = Number(state.settings && state.settings.autoLinkWindowMinutes);
      const windowMs = Math.max(0, Number.isFinite(configuredWindow) ? configuredWindow : 0) * 60 * 1000;
      const normPath = item.filePath ? String(item.filePath).toLowerCase().replace(/\\/g, '/') : '';
      const rows = (state.matches || []).map((match) => {
        if (!match || !match.id || linkedIds.has(match.id)) return null;
        if (match.scoreboardPendingLink || match.pendingScoreboardLink) return null;
        const range = boundedMatchRangeMsForVod(match, recStart, recEnd || 0);
        const start = range.start || range.gameStart || 0;
        const end = range.end || (start ? start + Math.max(60, Number(match.durationSec || 120)) * 1000 : 0);
        if (!start) return null;
        const matchPath = match.videoPath ? String(match.videoPath).toLowerCase().replace(/\\/g, '/') : '';
        if (matchPath && normPath && matchPath !== normPath) return null;
        const overlaps = recEnd && recEnd > recStart && start <= recEnd && recStart <= end;
        const distance = Math.min(Math.abs(start - recStart), recEnd ? Math.abs(start - recEnd) : Math.abs(start - recStart));
        const close = windowMs > 0 && distance <= windowMs;
        if (!overlaps && !close) return null;
        const score = (overlaps ? 1000000000 : 0) - distance;
        return { match, overlaps, distance, score };
      }).filter(Boolean).sort((a, b) => b.score - a.score);
      const cap = Number(limit);
      return Number.isFinite(cap) && cap > 0 ? rows.slice(0, cap) : rows;
    }

    function recordingInWindowMatchIds(item) {
      return recordingSuggestedMatches(item, 0).filter((row) => row && row.overlaps && row.match && row.match.id).map((row) => row.match.id);
    }

    function recordingSuggestedMatchCards(item, expanded = false) {
      if (!expanded) return '';
      const suggestions = recordingSuggestedMatches(item, 24);
      if (!suggestions.length) {
        return `<div class="recording-suggestions open"><div class="recording-suggestions-head"><span>Recommended matches</span><small>nothing close yet</small></div><div class="recording-match-empty">No recommended matches found for this video yet. Try Match History → Refresh after logs, scoreboards, or videos finish syncing.</div></div>`;
      }
      const inWindowCount = recordingInWindowMatchIds(item).length;
      const rows = suggestions.map(({ match, overlaps, distance }) => {
        const title = `${matchClock(match) || ''} · ${match.map || 'Unknown map'}`.replace(/^\s*·\s*/, '');
        const meta = `${displayMatchType(match)} · ${overlaps ? 'inside recording window' : `${Math.max(1, Math.round(distance / 60000))} min away`}`;
        return `<div class="recording-suggestion-chip"><label class="recording-suggestion-check" title="Select for bulk attach"><input type="checkbox" data-recording-suggestion-select="${escapeHtml(item.id || '')}" value="${escapeHtml(match.id)}" ${overlaps ? 'checked' : ''} /></label><button class="recording-match-chip suggestion" data-recording-open-match="${escapeHtml(match.id)}" title="Open recommended match"><strong>${escapeHtml(title)}</strong><small>${escapeHtml(meta)}</small></button><button class="btn tiny violet" data-recording-apply-recording="${escapeHtml(item.id || '')}" data-recording-apply-match="${escapeHtml(match.id)}">Map one</button></div>`;
      }).join('');
      return `<div class="recording-suggestions open"><div class="recording-suggestions-head"><span>Recommended matches</span><div class="recording-suggestion-actions"><button class="btn tiny violet" data-recording-attach-window="${escapeHtml(item.id || '')}" ${inWindowCount ? '' : 'disabled'}>Attach window (${inWindowCount})</button><button class="btn tiny" data-recording-attach-selected="${escapeHtml(item.id || '')}">Attach selected</button></div></div><div class="recording-match-list suggested">${rows}</div></div>`;
    }

    function recordingStatusTone(item) {
      const raw = `${item && item.status || ''} ${item && item.stopReason || ''}`.toLowerCase();
      if (raw.includes('fail') || Number(item && item.bytes || 0) === 0) return 'failed';
      if (recordingLinkedMatchCount(item)) return 'linked';
      return 'unlinked';
    }

    function filteredRecordings() {
      const list = state.recorder.recordings || [];
      const filter = state.recordingHistoryFilter || 'Recent';
      const sort = state.recordingHistorySort || 'Newest';
      const byFilter = list.filter((item) => {
        const tone = recordingStatusTone(item);
        if (filter === 'Failed') return tone === 'failed';
        if (filter === 'Linked') return tone === 'linked';
        if (filter === 'Unlinked') return tone === 'unlinked';
        return true;
      });
      return [...byFilter].sort((a, b) => {
        const at = recordingStartMs(a) || (a && a.filePath ? 1 : 0);
        const bt = recordingStartMs(b) || (b && b.filePath ? 1 : 0);
        return sort === 'Oldest' ? at - bt : bt - at;
      });
    }

    function recordingVisibleLimitForFilter(filter) {
      const base = filter === 'Recent' ? 12 : Number(state.recordingVisibleLimit || 24);
      return Math.max(12, base);
    }

    function renderRecorder() {
      const rec = state.recorder;
      const setup = recorderSetupSummary();
      const isRecording = setup.isRecording;
      const isStarting = Boolean(setup.isStarting);
      const isStopping = Boolean(setup.isStopping);
      const recorderBusy = Boolean(setup.busy);
      const hasRecordingFolder = setup.hasFolder;
      const selected = setup.selected;
      const ready = setup.ready;
      const sourceLabel = setup.sourceText && setup.sourceText !== 'No source selected' ? setup.sourceText : 'No source selected';
      const consoleStatus = isRecording || isStarting || isStopping ? setup.title : setup.ready ? 'Ready' : setup.title;
      const startLabel = isStarting ? 'Starting…' : 'Start Recording';
      const stopLabel = isStopping ? 'Stopping…' : 'Stop Recording';
      const allHistory = filteredRecordings();
      const historyFilter = state.recordingHistoryFilter || 'Recent';
      const historySort = state.recordingHistorySort || 'Newest';
      const historyLimit = recordingVisibleLimitForFilter(historyFilter);
      const history = allHistory.slice(0, historyLimit);
      const selectedCount = (state.selectedRecordingIds || []).length;
      return `
        <div class="grid recorder-page">
          <div class="card recorder-console ${isRecording || isStopping ? 'recording' : isStarting ? 'starting' : ready ? 'ready' : ''}">
            <div class="recorder-console-head"><div><p class="small-label">Recorder</p><h2>${escapeHtml(consoleStatus)}</h2><p class="caption">Pick World of Warcraft or a screen, then start. Storage and rules live in the cog.</p></div><button class="btn recorder-cog" id="open-recorder-settings" title="Recording settings">⚙️</button></div>
            <div class="recorder-console-body">
              <div class="recorder-preview-panel ${isRecording || isStarting || isStopping ? 'recording' : ''}">
                <div class="recorder-preview-icon">${isRecording || isStarting || isStopping ? '●' : selected && captureSourceKind(selected) === 'screen' ? '🖥️' : '🎮'}</div>
                <div><p class="small-label">Selected source</p><h3>${escapeHtml(sourceLabel)}</h3><p class="caption">${hasRecordingFolder ? `Saving to ${escapeHtml(state.settings.recordingsDir)}` : 'Storage folder required before recording.'}</p><p class="caption">Mode: ${escapeHtml(recorderPerformanceLabel(rec.performanceMode))} · ${escapeHtml(recorderPerformanceCaption(rec.performanceMode))}</p><p class="caption recorder-sound-status ${rec.includeAudio ? 'on' : 'off'}">Sound: ${rec.includeAudio ? 'On, when Windows allows system audio' : 'Off, enable in ⚙️ settings before recording'}</p></div>
              </div>
              <div class="recorder-console-actions">
                ${!hasRecordingFolder ? `<button class="btn primary" id="recorder-default-folder-main" ${recorderBusy || isRecording ? 'disabled' : ''}>Use Default Folder</button>` : `<button class="btn violet" id="open-source-picker-main" ${recorderBusy || isRecording ? 'disabled' : ''}>Choose Source</button>`}
                <button class="btn primary start-recording-btn hero-start" id="start-recording" ${setup.startDisabled ? 'disabled' : ''}>${escapeHtml(startLabel)}</button>
                <button class="btn rose stop-recording-btn hero-stop" id="stop-recording" ${setup.stopDisabled ? 'disabled' : ''}>${escapeHtml(stopLabel)}</button>
              </div>
            </div>
            <div class="recorder-console-foot"><span>${escapeHtml(rec.statusText || 'Ready')}</span><span>${isRecording ? `Elapsed ${formatElapsed(rec.elapsed)}` : isStarting ? 'Preparing capture' : isStopping ? 'Saving file' : ready ? 'Ready to record' : 'Needs setup'}</span></div>
          </div>

          <div class="card recording-history-card">
            <div class="card-title-row"><div><p class="small-label">Saved locally</p><h2>Recording History</h2><p class="caption">${uniqueRecordingCount()} unique file${uniqueRecordingCount() === 1 ? '' : 's'} · ${rec.recordings.length} saved entr${rec.recordings.length === 1 ? 'y' : 'ies'}</p></div><div class="action-row"><button class="btn" id="dedupe-recordings">Remove Duplicates</button><div class="icon-bubble">🎞️</div></div></div>
            <div class="history-toolbar">
              <div class="filter-pills">${['Recent','All','Linked','Unlinked','Failed'].map((item) => `<button class="filter-pill ${historyFilter === item ? 'active' : ''}" data-recording-filter="${item}">${item}</button>`).join('')}</div>
              <label class="filter-control recording-sort-control"><span>Order</span><select id="recording-history-sort"><option value="Newest" ${historySort === 'Newest' ? 'selected' : ''}>Newest first</option><option value="Oldest" ${historySort === 'Oldest' ? 'selected' : ''}>Oldest first</option></select></label>
              <div class="action-row"><button class="btn small" id="select-failed-recordings">Select Failed</button><button class="btn small" id="select-unlinked-recordings">Select Unlinked</button><button class="btn small" id="clear-recording-selection">Clear</button></div>
            </div>
            ${selectedCount ? `<div class="bulk-delete-bar"><strong>${selectedCount} selected</strong><button class="btn small violet" id="attach-selected-recordings-window">Attach in-window matches</button><button class="btn small" id="delete-selected-recordings-history">Remove from history</button><button class="btn small rose" id="delete-selected-recordings-files">Delete files too</button></div>` : ''}
            <div class="recording-list compact-history">${history.map(renderRecordingItem).join('') || '<div class="empty">No recordings in this view.</div>'}</div>
            ${renderLoadMoreButton('load-more-recordings', history.length, allHistory.length, 'recordings')}
            ${(state.recorder.recordings || []).length > history.length ? `<p class="caption history-footnote">Only the visible recording cards are rendered. Filters still search the full local history.</p>` : ''}
          </div>
          ${renderRecorderSettingsModal()}
        </div>
      `;
    }

    function renderRecordingItem(item) {
      const tone = recordingStatusTone(item);
      const checked = (state.selectedRecordingIds || []).includes(item.id || '');
      const linkedIds = recordingLinkedMatchIds(item);
      const linked = linkedIds.length > 1 ? `<span class="pill cyan">${linkedIds.length} matches</span>` : linkedIds.length === 1 ? '<span class="pill cyan">Linked</span>' : tone === 'failed' ? '<span class="pill rose">Failed</span>' : '<span class="pill">Unlinked</span>';
      const title = recordingTitleForItem(item);
      const label = recordingDisplayLabel(item);
      const showSubtitle = label && label !== title;
      const suggestionsOpen = state.recordingSuggestionOpenId === (item.id || '');
      const suggestionCount = recordingSuggestedMatches(item, 0).length;
      const inWindowCount = recordingInWindowMatchIds(item).length;
      const suggestionLabel = `${suggestionsOpen ? 'Hide Recommended' : inWindowCount ? 'Attach Matches' : 'Recommended Matches'}${suggestionCount ? ` (${suggestionCount})` : ''}`;
      const endLabel = item.endedAt ? ` → ${new Date(item.endedAt).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' })}` : '';
      const audioLabel = item.audioTrackCount > 0 || item.audioCaptured === true ? 'sound captured' : item.includeAudio === true ? 'sound requested' : item.includeAudio === false ? 'sound off' : 'sound unknown';
      const meta = `${item.startedAt ? new Date(item.startedAt).toLocaleString([], { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : 'Unknown time'}${endLabel} · ${escapeHtml(item.stopReason || item.status || '')} · ${audioLabel} · ${formatBytes(item.bytes || 0)}`;
      const fileName = displayFileName(item.filePath || '');
      return `<div class="recording-item compact ${tone}">
        <label class="recording-select"><input type="checkbox" data-recording-select="${escapeHtml(item.id || '')}" ${checked ? 'checked' : ''} /></label>
        <div class="recording-copy">
          <div class="recording-title-row"><p class="recording-title">${escapeHtml(title)}</p>${linked}</div>
          ${showSubtitle ? `<p class="caption recording-subtitle">${escapeHtml(label)}</p>` : ''}
          <p class="caption ${tone === 'failed' ? 'recording-failed-text' : ''}">${meta}</p>
          <p class="caption path-value" title="${escapeHtml(item.filePath || '')}">${escapeHtml(fileName || item.filePath || '')}</p>
          ${recordingMatchCards(item)}
          ${recordingSuggestedMatchCards(item, suggestionsOpen)}
        </div>
        <div class="action-row recording-row-actions"><button class="btn violet" data-toggle-recording-suggestions="${escapeHtml(item.id || '')}">${escapeHtml(suggestionLabel)}</button>${linkedIds.length ? `<button class="btn" data-unlink-recording="${escapeHtml(item.id || '')}">Unlink</button>` : ''}<button class="btn" data-reveal-recording="${escapeHtml(item.filePath || '')}">Show File</button></div>
      </div>`;
    }

    return {
      uniqueRecordingCount,
      renderSourcePicker,
      renderSourceQuickModal,
      renderRecorderSettingsModal,
      recordingDisplayLabel,
      recordingLinkedMatchIds,
      recordingSessionVodFor,
      recordingTitleForItem,
      recordingMatchCards,
      recordingLinkedMatchCount,
      recordingStartMs,
      recordingEndMs,
      recordingSuggestedMatches,
      recordingInWindowMatchIds,
      recordingSuggestedMatchCards,
      recordingStatusTone,
      filteredRecordings,
      recordingVisibleLimitForFilter,
      renderRecorder,
      renderRecordingItem
    };
  }

  window.LastCallRecorderView = { createRecorderViewTools };
})();
