(function () {
  'use strict';

  function createReplayTimelineTools(deps = {}) {
    const state = deps.state || { player: {} };
    const currentReplayMatch = deps.currentReplayMatch || (() => null);
    const render = deps.render || (() => {});
    const updateVideoEventRail = deps.updateVideoEventRail || (() => {});

    function activeVodScopeMode(match = currentReplayMatch()) {
      const mode = String(state.player && state.player.vodScopeMode || 'match');
      if (!match || !match.videoPath) return 'match';
      return ['match', 'room', 'full'].includes(mode) ? mode : 'match';
    }

    function vodScopeLabel(mode = activeVodScopeMode()) {
      if (mode === 'room') return 'Starting room';
      if (mode === 'full') return 'Full VOD';
      return 'Match start';
    }

    function replayScopeBoundsForMatch(match = currentReplayMatch(), video = null) {
      const source = video || document.getElementById('replay-video');
      const mode = activeVodScopeMode(match);
      const clipStart = Number(match && match.videoClipStartSec);
      const clipEnd = Number(match && match.videoClipEndSec);
      const matchStart = Number(match && match.videoMatchStartSec);
      const matchEnd = Number(match && match.videoMatchEndSec);
      const shuffleStart = Number(match && match.videoShuffleStartSec);
      const shuffleEnd = Number(match && match.videoShuffleEndSec);
      const segmentStart = Number.isFinite(shuffleStart) ? shuffleStart : (Number.isFinite(matchStart) ? matchStart : (Number.isFinite(clipStart) ? clipStart : 0));
      const segmentEnd = Number.isFinite(shuffleEnd) ? shuffleEnd : (Number.isFinite(matchEnd) ? matchEnd : (Number.isFinite(clipEnd) ? clipEnd : segmentStart + Math.max(1, Number(match && match.durationSec || 60))));
      const duration = source && Number.isFinite(Number(source.duration)) && Number(source.duration) > 0
        ? Number(source.duration)
        : Math.max(1, Number.isFinite(clipEnd) ? clipEnd : 0, Number.isFinite(segmentEnd) ? segmentEnd : 0, Number(state.player && state.player.currentTime || 0));

      if (mode === 'full') return { mode, min: 0, max: Math.max(1, duration), matchStart: segmentStart, matchEnd: segmentEnd };

      const baseStart = mode === 'room' ? Math.max(0, segmentStart - 45) : Math.max(0, segmentStart);
      const baseEnd = Math.max(baseStart + 0.5, Number.isFinite(clipEnd) ? clipEnd : segmentEnd);
      return { mode, min: baseStart, max: baseEnd, matchStart: segmentStart, matchEnd: segmentEnd };
    }

    function isReplayFullVodMode(match = currentReplayMatch()) {
      return activeVodScopeMode(match) === 'full' && Boolean(match && match.videoPath);
    }

    function syncReplayPanelHeights() {
      const rail = document.querySelector('.replay-card:not(.rail-hidden) .replay-rail-panel');
      if (!rail) return;
      const card = rail.closest('.replay-card');
      const mainColumn = card ? card.querySelector('.replay-main-column') : null;
      const healthCard = card ? card.querySelector('.health-timeline-card') : null;
      const videoFrame = card ? card.querySelector('.video-frame') : null;
      const feedWrap = rail.querySelector('.feed-wrap');
      const combatFeed = rail.querySelector('.combat-feed');
      const reset = () => {
        rail.style.height = '';
        rail.style.maxHeight = '';
        rail.style.minHeight = '';
        if (feedWrap) {
          feedWrap.style.height = '';
          feedWrap.style.minHeight = '';
          feedWrap.style.maxHeight = '';
        }
        if (combatFeed) {
          combatFeed.style.height = '';
          combatFeed.style.maxHeight = '';
          combatFeed.style.minHeight = '';
        }
      };
      if (!card || !mainColumn || window.matchMedia('(max-width: 1180px)').matches) {
        reset();
        return;
      }
      const railRect = rail.getBoundingClientRect();
      const feedRect = feedWrap ? feedWrap.getBoundingClientRect() : railRect;
      const targetRect = healthCard ? healthCard.getBoundingClientRect() : (card && card.classList.contains('bg-health-hidden') && videoFrame ? videoFrame.getBoundingClientRect() : mainColumn.getBoundingClientRect());
      const targetBottom = Math.ceil(targetRect.bottom);
      const railHeight = Math.max(260, targetBottom - Math.floor(railRect.top));
      const feedHeight = Math.max(160, targetBottom - Math.floor(feedRect.top));
      if (!Number.isFinite(railHeight) || railHeight <= 0) return;
      rail.style.height = `${railHeight}px`;
      rail.style.maxHeight = `${railHeight}px`;
      rail.style.minHeight = '0px';
      rail.style.alignSelf = 'start';
      if (feedWrap) {
        feedWrap.style.height = `${feedHeight}px`;
        feedWrap.style.maxHeight = `${feedHeight}px`;
        feedWrap.style.minHeight = '0px';
      }
      if (combatFeed) {
        combatFeed.style.height = '100%';
        combatFeed.style.maxHeight = '100%';
        combatFeed.style.minHeight = '0px';
      }
    }

    function scheduleReplayPanelHeightSync() {
      window.requestAnimationFrame(() => {
        syncReplayPanelHeights();
        window.setTimeout(syncReplayPanelHeights, 80);
        window.setTimeout(syncReplayPanelHeights, 260);
      });
    }

    function captureReplaySnapshot() {
      const video = document.getElementById('replay-video');
      return {
        videoPath: state.player.videoPath,
        matchId: state.player.matchId,
        time: video ? video.currentTime : state.player.currentTime,
        wasPlaying: video ? (!video.paused && !video.ended) : false,
        muted: video ? video.muted : state.player.videoMuted,
        volume: video ? video.volume : state.player.videoVolume
      };
    }

    function restoreReplaySnapshot(snapshot) {
      if (!snapshot) return;
      const video = document.getElementById('replay-video');
      if (!video) return;
      const sameVideo = !snapshot.videoPath || !state.player.videoPath || snapshot.videoPath === state.player.videoPath;
      if (!sameVideo) return;
      const apply = () => {
        const t = Number(snapshot.time);
        if (Number.isFinite(t) && Math.abs((video.currentTime || 0) - t) > 0.25) {
          try { video.currentTime = t; } catch (_) {}
        }
        const restoredVolume = Math.max(0, Math.min(1, Number(snapshot.volume ?? state.player.videoVolume ?? 1) || 0));
        video.volume = restoredVolume;
        video.muted = snapshot.muted !== undefined ? Boolean(snapshot.muted) : Boolean(state.player.videoMuted);
        state.player.videoVolume = restoredVolume;
        state.player.videoMuted = video.muted;
        if (snapshot.wasPlaying) video.play().catch(() => {});
        else video.pause();
        state.player.currentTime = video.currentTime || t || 0;
        updateVideoEventRail();
      };
      if (video.readyState >= 1) apply();
      else video.addEventListener('loadedmetadata', apply, { once: true });
    }

    function renderKeepingReplay() {
      const snapshot = captureReplaySnapshot();
      render();
      window.setTimeout(() => restoreReplaySnapshot(snapshot), 0);
    }

    return {
      activeVodScopeMode,
      vodScopeLabel,
      replayScopeBoundsForMatch,
      isReplayFullVodMode,
      syncReplayPanelHeights,
      scheduleReplayPanelHeightSync,
      captureReplaySnapshot,
      restoreReplaySnapshot,
      renderKeepingReplay
    };
  }

  window.LastCallReplayTimelineHelpers = { createReplayTimelineTools };
})();
