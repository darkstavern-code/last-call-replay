(function () {
  'use strict';

  function createPlayersViewTools(deps = {}) {
    const state = deps.state || { matches: [] };
    const buildPlayerProfiles = deps.buildPlayerProfiles || (() => []);
    const classMetaForName = deps.classMetaForName || (() => null);
    const classDisplayName = deps.classDisplayName || ((value) => value || 'Unknown');
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const shortCharacterName = deps.shortCharacterName || ((value) => String(value || '').split('-')[0] || 'Unknown');
    const renderNoDataBox = deps.renderNoDataBox || (() => '<div class="empty">No data yet.</div>');
    const pill = deps.pill || ((text) => `<span class="pill">${escapeHtml(text)}</span>`);
    const renderFilterSelect = deps.renderFilterSelect || (() => '');
    const matchTypeOptions = deps.matchTypeOptions || (() => ['All']);
    const displayMatchTypeLabel = deps.displayMatchTypeLabel || ((value) => value || 'PvP');
    const displayMatchType = deps.displayMatchType || ((match) => match && (match.matchType || match.bracket || 'PvP') || 'PvP');
    const coloredShortName = deps.coloredShortName || ((name) => `<span>${escapeHtml(shortCharacterName(name))}</span>`);
    const playerMeetingDedupeKey = deps.playerMeetingDedupeKey || (() => '');
    const playerMeetingTimeMs = deps.playerMeetingTimeMs || (() => 0);
    const mergeMeetingMatch = deps.mergeMeetingMatch || ((existing, incoming, relationship) => ({ ...(existing || incoming || {}), relationship }));
    const matchResolvedResult = deps.matchResolvedResult || ((match) => match && match.result || 'Unknown');
    const resultToneForResult = deps.resultToneForResult || (() => 'amber');
    const hasLinkedScoreboard = deps.hasLinkedScoreboard || (() => false);
    const matchTimestampLabel = deps.matchTimestampLabel || (() => 'Unknown day');
    const formatElapsed = deps.formatElapsed || ((seconds) => String(seconds || '0'));
    const isBattlegroundMatch = deps.isBattlegroundMatch || (() => false);

    function classMetaForProfile(profile) {
      for (const match of profile.related || []) {
        const meta = classMetaForName(profile.name, match);
        if (meta) return meta;
      }
      return null;
    }

    function playerClassName(profile) {
      const meta = classMetaForProfile(profile);
      return classDisplayName(meta && (meta.className || meta.classFile)) || 'Unknown';
    }

    function playerClassOptionsFromProfiles(profiles) {
      const labels = new Map();
      for (const profile of profiles || []) {
        const label = playerClassName(profile);
        if (label && label !== 'Unknown') labels.set(label.toLowerCase(), label);
      }
      return Array.from(labels.values()).sort((a, b) => a.localeCompare(b));
    }

    function playerRecordFilterOkay(profile) {
      const filter = state.playerRecordFilter || 'All';
      if (filter === 'All') return true;
      if (filter === 'Seen 2+') return Number(profile.seen || 0) >= 2;
      const againstKnown = Number(profile.winsAgainst || 0) + Number(profile.lossesAgainst || 0);
      const withKnown = Number(profile.winsWith || 0) + Number(profile.lossesWith || 0);
      if (filter === 'Winning vs them') return againstKnown > 0 && Number(profile.winsAgainst || 0) > Number(profile.lossesAgainst || 0);
      if (filter === 'Losing vs them') return againstKnown > 0 && Number(profile.lossesAgainst || 0) > Number(profile.winsAgainst || 0);
      if (filter === 'Winning with them') return withKnown > 0 && Number(profile.winsWith || 0) > Number(profile.lossesWith || 0);
      if (filter === 'Losing with them') return withKnown > 0 && Number(profile.lossesWith || 0) > Number(profile.winsWith || 0);
      return true;
    }

    function playerSortLabel(value) {
      const labels = {
        mostSeen: 'Most Seen',
        recent: 'Last Seen',
        name: 'Name A-Z',
        mostEnemies: 'Most Enemy Meetings',
        bestAgainst: 'Best Record vs Them',
        worstAgainst: 'Worst Record vs Them',
        className: 'Class A-Z'
      };
      return labels[value] || value || 'Most Seen';
    }

    function renderPlayerSortSelect() {
      const options = ['mostSeen', 'recent', 'name', 'className', 'mostEnemies', 'bestAgainst', 'worstAgainst'];
      const value = state.playerSort || 'mostSeen';
      return `<label class="filter-control"><span>Sort</span><select id="player-sort">${options.map((item) => `<option value="${escapeHtml(item)}" ${value === item ? 'selected' : ''}>${escapeHtml(playerSortLabel(item))}</option>`).join('')}</select></label>`;
    }

    function applyPlayerSorting(profiles) {
      const list = [...profiles];
      const sort = state.playerSort || 'mostSeen';
      const byName = (a, b) => shortCharacterName(a.name).localeCompare(shortCharacterName(b.name));
      const againstRate = (p) => {
        const known = Number(p.winsAgainst || 0) + Number(p.lossesAgainst || 0);
        return known ? Number(p.winsAgainst || 0) / known : -1;
      };
      list.sort((a, b) => {
        if (state.focusPlayer) {
          const af = a.name === state.focusPlayer ? 1 : 0;
          const bf = b.name === state.focusPlayer ? 1 : 0;
          if (af !== bf) return bf - af;
        }
        if (sort === 'recent') return (Number(b.lastSeenMs || 0) - Number(a.lastSeenMs || 0)) || byName(a, b);
        if (sort === 'name') return byName(a, b);
        if (sort === 'className') return playerClassName(a).localeCompare(playerClassName(b)) || byName(a, b);
        if (sort === 'mostEnemies') return (Number(b.enemySeen || 0) - Number(a.enemySeen || 0)) || (Number(b.seen || 0) - Number(a.seen || 0)) || byName(a, b);
        if (sort === 'bestAgainst') return (againstRate(b) - againstRate(a)) || (Number(b.winsAgainst || 0) - Number(a.winsAgainst || 0)) || byName(a, b);
        if (sort === 'worstAgainst') return (againstRate(a) - againstRate(b)) || (Number(b.lossesAgainst || 0) - Number(a.lossesAgainst || 0)) || byName(a, b);
        return (Number(b.seen || 0) - Number(a.seen || 0)) || (Number(b.lastSeenMs || 0) - Number(a.lastSeenMs || 0)) || byName(a, b);
      });
      return list;
    }

    function coloredProfileName(profile) {
      const meta = classMetaForProfile(profile);
      const color = meta && meta.classColor ? meta.classColor : '';
      const title = meta && meta.className ? `${meta.specName || ''} ${meta.className}`.trim() : '';
      return `<span class="class-colored-name" ${color ? `style="color:${escapeHtml(color)}"` : ''} ${title ? `title="${escapeHtml(title)}"` : ''}>${escapeHtml(profile.name)}</span>`;
    }

    function dedupePlayerRelatedMatches(matches = [], playerName = '') {
      const byKey = new Map();
      for (const match of matches || []) {
        if (!match) continue;
        const key = playerMeetingDedupeKey(match, playerName);
        if (!key) continue;
        byKey.set(key, mergeMeetingMatch(byKey.get(key), match, match.relationship));
      }
      return Array.from(byKey.values()).sort((a, b) => playerMeetingTimeMs(b) - playerMeetingTimeMs(a) || String(b.id || '').localeCompare(String(a.id || '')));
    }

    function playerRelatedMatches(profile) {
      return dedupePlayerRelatedMatches(profile.related || [], profile.name);
    }

    function renderCompNames(compEntry, profile) {
      const entry = compEntry && Array.isArray(compEntry) ? { names: String(compEntry[0] || '').split(/\s+\+\s+/).filter(Boolean), matchId: '' } : (compEntry || {});
      const names = Array.isArray(entry.names) && entry.names.length ? entry.names : String(entry.key || '').split(/\s+\+\s+/).filter(Boolean);
      if (!names.length) return escapeHtml(entry.key || 'Enemy team');
      const match = (profile.related || []).find((m) => m.id === entry.matchId) || (profile.related || [])[0] || null;
      return names.map((name) => coloredShortName(name, match, 'comp-name')).join('<span class="comp-plus">+</span>');
    }

    function resultToneForMatch(match) {
      return resultToneForResult(matchResolvedResult(match));
    }

    function meetingDurationLabel(match) {
      if (!match) return 'Duration unknown';
      if (match.duration) return String(match.duration);
      const seconds = Number(match.durationSec || 0);
      return seconds > 0 ? formatElapsed(seconds) : 'Duration unknown';
    }

    function meetingStartLabel(match) {
      const label = matchTimestampLabel(match);
      return label && label !== 'Unknown day' ? label : 'Start unknown';
    }

    function renderMeetingRow(match, compact = false) {
      const startLabel = meetingStartLabel(match);
      const durationLabel = meetingDurationLabel(match);
      const title = [match.relationship, displayMatchType(match), match.map || 'Unknown map'].filter(Boolean).join(' · ');
      const meta = `Start: ${startLabel} · Duration: ${durationLabel}`;
      const scoreboard = hasLinkedScoreboard(match) ? `<span class="match-list-action scoreboard player-scoreboard-action" role="button" tabindex="0" data-scoreboard-match="${escapeHtml(match.id)}">Scoreboard</span>` : '';
      return `<div class="related-match ${compact ? 'last-meeting' : 'history-meeting'}" role="button" tabindex="0" data-match="${escapeHtml(match.id)}"><div class="related-match-main"><span>${escapeHtml(title)}</span><small>${escapeHtml(meta)}</small></div><div class="related-match-actions">${scoreboard}${pill(matchResolvedResult(match), resultToneForMatch(match))}</div></div>`;
    }

    function isLargeTeamMatch(match) {
      if (!match) return false;
      const participantCount = Array.isArray(match.participants) ? match.participants.length : 0;
      const teamOne = match.teams && Array.isArray(match.teams['1']) ? match.teams['1'].length : 0;
      const teamZero = match.teams && Array.isArray(match.teams['0']) ? match.teams['0'].length : 0;
      const compCount = Math.max((match.myComp || []).length, (match.enemyComp || match.enemies || []).length);
      const expected = Number(match.expectedTeamSize) || 0;
      const actual = Number(match.actualTeamSize) || 0;
      return Boolean(isBattlegroundMatch(match) || expected > 3 || actual > 3 || participantCount > 6 || teamOne > 3 || teamZero > 3 || compCount > 3);
    }

    function teamNamesForMatch(match, side) {
      if (!match) return [];
      if (match.teams && Array.isArray(match.teams[side])) return match.teams[side].filter(Boolean);
      if (side === '1') return (match.myComp || match.ownNames || []).filter(Boolean);
      return (match.enemyComp || match.enemies || []).filter(Boolean);
    }

    function renderRosterPreviewList(names, match) {
      const clean = Array.from(new Set((names || []).filter(Boolean)));
      const shown = clean.slice(0, 12).map((name) => coloredShortName(name, match)).join('');
      const more = clean.length > 12 ? `<span class="roster-more">+${clean.length - 12} more</span>` : '';
      return shown || more ? `${shown}${more}` : '<span class="caption">No names captured.</span>';
    }

    function renderLargeTeamRosterNote(profile, match) {
      if (!match) return '';
      const friendly = teamNamesForMatch(match, '1');
      const enemy = teamNamesForMatch(match, '0');
      const type = displayMatchType(match);
      const map = match.map || 'Large-team match';
      return `<div class="note neutral comp-note roster-hover-note" tabindex="0"><p class="small-label">Large-team roster</p><p>${escapeHtml(type)} · ${escapeHtml(map)} · hover for teams</p><div class="hover-panel roster-hover-panel"><p class="small-label">Roster preview</p><div class="roster-hover-columns"><div><strong>Your side</strong><div class="roster-chip-list">${renderRosterPreviewList(friendly, match)}</div></div><div><strong>Enemy side</strong><div class="roster-chip-list">${renderRosterPreviewList(enemy, match)}</div></div></div></div></div>`;
    }

    function playerRatingSummary(profile) {
      const samples = (profile && profile.ratingSamples || []).filter((sample) => (Number(sample.rating) > 0) || (Number(sample.mmr) > 0));
      if (!samples.length) return { value: 'No rating', note: 'scoreboard not captured' };
      const best = samples.slice().sort((a, b) => (Number(b.rating || b.mmr || 0) - Number(a.rating || a.mmr || 0)) || (Number(b.seenMs || 0) - Number(a.seenMs || 0)))[0];
      const value = Number(best.rating) > 0 ? Number(best.rating).toLocaleString() : `MMR ${Number(best.mmr).toLocaleString()}`;
      const change = Number(best.ratingChange);
      const changeText = Number.isFinite(change) && change ? ` · ${change > 0 ? '+' : ''}${change}` : '';
      const note = `${displayMatchTypeLabel(best.bracket || 'PvP')}${Number(best.mmr) > 0 && Number(best.rating) > 0 ? ` · MMR ${Number(best.mmr).toLocaleString()}` : ''}${changeText}`;
      return { value, note };
    }

    function renderPlayerProfile(profile) {
      const withKnown = profile.winsWith + profile.lossesWith;
      const againstKnown = profile.winsAgainst + profile.lossesAgainst;
      const soloWithKnown = profile.soloWinsWith + profile.soloLossesWith;
      const soloAgainstKnown = profile.soloWinsAgainst + profile.soloLossesAgainst;
      const againstRecord = againstKnown ? `${profile.winsAgainst}W ${profile.lossesAgainst}L` : 'Unknown';
      const soloRecord = soloWithKnown || soloAgainstKnown
        ? `With ${profile.soloWinsWith}W ${profile.soloLossesWith}L · Against ${profile.soloWinsAgainst}W ${profile.soloLossesAgainst}L`
        : 'No solo rounds yet';
      const commonCompEntry = Array.from(profile.comps.entries()).map(([key, value]) => ({ key, ...(value && typeof value === 'object' ? value : { count: Number(value || 0), names: key.split(/\s+\+\s+/).filter(Boolean) }) })).sort((a, b) => Number(b.count || 0) - Number(a.count || 0))[0] || null;
      const relationshipText = Array.from(profile.relationships).join(' / ') || 'Observed';
      const relatedMatches = playerRelatedMatches(profile);
      const lastMatch = relatedMatches[0] || null;
      const largeTeamMatch = relatedMatches.find(isLargeTeamMatch);
      const commonCompNote = commonCompEntry
        ? `<div class="note good comp-note"><p class="small-label">Most common arena comp</p><p>${renderCompNames(commonCompEntry, profile)}</p></div>`
        : (!largeTeamMatch ? `<div class="note neutral comp-note"><p class="small-label">Team context</p><p>No stable arena comp captured yet.</p></div>` : '');
      const ratingInfo = playerRatingSummary(profile);
      const meetingHistory = lastMatch ? `<div class="player-meetings"><p class="small-label">Last match</p>${renderMeetingRow(lastMatch, true)}${relatedMatches.length > 1 ? `<button class="btn small player-history-btn" data-player-history="${escapeHtml(profile.name)}">View all ${relatedMatches.length} meetings</button>` : ''}</div>` : '';
      return `<div class="card opponent-card"><div class="card-title-row"><div><p class="small-label">${escapeHtml(relationshipText)}</p><h3>${coloredProfileName(profile)}</h3><p class="spec">${escapeHtml(profile.lastSeen || 'Seen in match history')}</p></div><button class="btn" data-hide-player="${escapeHtml(profile.name)}">Hide</button></div><div class="mini-stats"><div class="mini"><p class="label">Rating</p><p class="value">${escapeHtml(ratingInfo.value)}</p><small>${escapeHtml(ratingInfo.note)}</small></div><div class="mini"><p class="label">Against</p><p class="value">${escapeHtml(againstRecord)}</p></div><div class="mini"><p class="label">Seen</p><p class="value">${profile.seen}</p></div></div><div class="mini solo-mini"><p class="label">Solo rounds</p><p class="value">${escapeHtml(soloRecord)}</p></div>${commonCompNote}${meetingHistory}</div>`;
    }

    function renderPlayers() {
      const baseProfiles = buildPlayerProfiles();
      const classOptions = playerClassOptionsFromProfiles(baseProfiles);
      if (state.playerClassFilter !== 'All' && !classOptions.includes(state.playerClassFilter)) state.playerClassFilter = 'All';
      let profiles = baseProfiles;
      const playerNeedle = String(state.query || '').trim().toLowerCase();
      if (playerNeedle) profiles = profiles.filter((profile) => profile.name.toLowerCase().includes(playerNeedle) || shortCharacterName(profile.name).toLowerCase().includes(playerNeedle));
      if (state.playerClassFilter !== 'All') profiles = profiles.filter((profile) => playerClassName(profile) === state.playerClassFilter);
      profiles = profiles.filter(playerRecordFilterOkay);
      profiles = applyPlayerSorting(profiles).slice(0, 120);
      if (!baseProfiles.length) return `<div class="card">${renderNoDataBox()}</div>`;
      const shownText = `${profiles.length} shown${baseProfiles.length !== profiles.length ? ` / ${baseProfiles.length}` : ''}`;
      return `
        <div class="grid players-page">
          <div class="card player-filter-card">
            <div class="card-title-row"><div><p class="small-label">Players</p><h2>Players</h2><p class="caption">Sort and filter player cards without rebuilding your matches. Class data appears when combat logs or PvPHelper scoreboards exposed it.</p></div>${pill(shownText, 'cyan')}</div>
            <div class="player-filter-row">
              <div class="filter-pills">
                ${['All', 'Friendlies', 'Enemies'].map((item) => `<button class="filter-pill ${state.playerFilter === item ? 'active' : ''}" data-player-filter="${item}">${item}</button>`).join('')}
              </div>
              <div class="player-filter-grid">
                ${renderFilterSelect('player-match-type-filter', 'Match Type', state.playerMatchTypeFilter, matchTypeOptions(), displayMatchTypeLabel)}
                ${renderFilterSelect('player-class-filter', 'Class', state.playerClassFilter, classOptions)}
                ${renderFilterSelect('player-record-filter', 'Record', state.playerRecordFilter || 'All', ['Seen 2+', 'Winning vs them', 'Losing vs them', 'Winning with them', 'Losing with them'])}
                ${renderPlayerSortSelect()}
              </div>
            </div>
          </div>
          <div class="grid three-col">${profiles.map(renderPlayerProfile).join('') || '<div class="empty slim-empty">No players match those filters.</div>'}</div>
        </div>
      `;
    }

    function renderPlayerMeetingsModal() {
      if (!state.playerMeetingHistoryName) return '';
      const profile = buildPlayerProfiles().find((item) => item.name === state.playerMeetingHistoryName);
      if (!profile) return '';
      const matches = playerRelatedMatches(profile);
      const known = matches.filter((match) => ['Win', 'Loss'].includes(matchResolvedResult(match)));
      const wins = known.filter((match) => matchResolvedResult(match) === 'Win').length;
      const losses = known.filter((match) => matchResolvedResult(match) === 'Loss').length;
      return `<div class="modal-scrim player-history-scrim" id="player-history-scrim">
        <div class="quick-source-modal card player-history-modal" role="dialog" aria-modal="true">
          <div class="modal-head">
            <div><p class="small-label">Meeting history</p><h2>${coloredProfileName(profile)}</h2><p class="caption">${matches.length} meeting${matches.length === 1 ? '' : 's'} · ${wins}W ${losses}L against/with them in this view.</p></div>
            <button class="modal-close" id="close-player-history" aria-label="Close">×</button>
          </div>
          <div class="player-history-list">${matches.map((match) => renderMeetingRow(match)).join('') || '<div class="empty slim-empty">No meetings found.</div>'}</div>
        </div>
      </div>`;
    }

    return {
      playerClassName,
      playerClassOptionsFromProfiles,
      playerRecordFilterOkay,
      playerSortLabel,
      renderPlayerSortSelect,
      applyPlayerSorting,
      playerRelatedMatches,
      renderMeetingRow,
      renderPlayerProfile,
      renderPlayers,
      renderPlayerMeetingsModal
    };
  }

  window.LastCallPlayersView = { createPlayersViewTools };
})();
