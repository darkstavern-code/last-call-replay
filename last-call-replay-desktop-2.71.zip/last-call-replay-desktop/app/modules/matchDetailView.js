(function () {
  'use strict';

  function createMatchDetailViewTools(deps = {}) {
    const state = deps.state || {};
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const pill = deps.pill || ((text) => `<span>${escapeHtml(text)}</span>`);
    const renderNoDataBox = deps.renderNoDataBox || (() => '<div class="empty">No data yet.</div>');
    const isFavoriteMatch = deps.isFavoriteMatch || (() => false);
    const isSoloShuffleLobbyUiMatch = deps.isSoloShuffleLobbyUiMatch || (() => false);
    const soloShuffleRounds = deps.soloShuffleRounds || (() => []);
    const selectedSoloShuffleRound = deps.selectedSoloShuffleRound || (() => null);
    const selectedSoloShuffleRoundNumber = deps.selectedSoloShuffleRoundNumber || (() => 1);
    const soloShuffleSummaryText = deps.soloShuffleSummaryText || (() => '0W - 0L');
    const renderSoloShuffleRoundDots = deps.renderSoloShuffleRoundDots || (() => '');
    const shortCharacterName = deps.shortCharacterName || ((name) => String(name || '').split('-')[0]);
    const displayResult = deps.displayResult || ((result) => result || 'Unknown');
    const coloredShortName = deps.coloredShortName || ((name) => escapeHtml(shortCharacterName(name || 'Unknown')));
    const soloShuffleRoundContextMatch = deps.soloShuffleRoundContextMatch || ((match) => match);
    const soloShuffleStatsMatch = deps.soloShuffleStatsMatch || ((match) => match);
    const renderSyncedReplay = deps.renderSyncedReplay || (() => '');
    const renderMetricPanel = deps.renderMetricPanel || (() => '');
    const renderInlineScoreboardPanel = deps.renderInlineScoreboardPanel || (() => '');
    const renderEvent = deps.renderEvent || (() => '');
    const renderCc = deps.renderCc || (() => '');
    const renderInterrupt = deps.renderInterrupt || (() => '');
    const renderMatchDetailNav = deps.renderMatchDetailNav || (() => '');

    function renderSoloShuffleLobbyPanel(match) {
      if (!isSoloShuffleLobbyUiMatch(match)) return '';
      const rounds = soloShuffleRounds(match);
      const activeRound = selectedSoloShuffleRound(match);
      const selected = Number(activeRound && activeRound.roundNumber || selectedSoloShuffleRoundNumber(match));
      const statsMode = state.soloShuffleStatsMode === 'full' ? 'full' : 'round';
      const endedBy = activeRound && (activeRound.endVictim || activeRound.firstDeath) ? `${shortCharacterName(activeRound.endVictim || activeRound.firstDeath)} died` : 'Unknown end condition';
      const friendly = activeRound && activeRound.myComp ? activeRound.myComp : [];
      const enemy = activeRound && activeRound.enemyComp ? activeRound.enemyComp : [];
      const roundNumbers = rounds.map((round) => Number(round.roundNumber || 0)).filter(Boolean).sort((a, b) => a - b);
      const currentIndex = Math.max(0, roundNumbers.indexOf(selected));
      const prevRound = currentIndex > 0 ? roundNumbers[currentIndex - 1] : 0;
      const nextRound = currentIndex >= 0 && currentIndex < roundNumbers.length - 1 ? roundNumbers[currentIndex + 1] : 0;
      return `
        <div class="card solo-shuffle-lobby-panel">
          <div class="card-title-row solo-lobby-head">
            <div>
              <p class="small-label">Solo Shuffle lobby</p>
              <h2>Solo Shuffle · ${escapeHtml(soloShuffleSummaryText(match))}</h2>
              <p class="caption">${Number(match.soloShuffleDetectedRoundCount || 0) || rounds.length} rounds detected${match.soloShuffleIncomplete ? ' · Leaver / incomplete' : ''}. VOD stays linked to the lobby, and each round becomes a jump point.</p>
            </div>
            <div class="tag-row">${pill(match.soloShuffleIncomplete ? 'Incomplete' : 'Complete', match.soloShuffleIncomplete ? 'amber' : 'emerald')}${pill(`${rounds.length}/6 rounds`, 'cyan')}</div>
          </div>
          <div class="solo-round-rail">
            <div class="solo-round-nav-row">
              <button class="solo-round-arrow" data-solo-round-nav="prev" ${prevRound ? '' : 'disabled'} title="Previous Solo Shuffle round">←</button>
              ${renderSoloShuffleRoundDots(match, true)}
              <button class="solo-round-arrow" data-solo-round-nav="next" ${nextRound ? '' : 'disabled'} title="Next Solo Shuffle round">→</button>
            </div>
            <div class="solo-stats-toggle" role="group" aria-label="Solo Shuffle stats scope">
              <span>Stats:</span>
              <button class="solo-stat-mode ${statsMode === 'round' ? 'active' : ''}" data-solo-stats-mode="round">Selected Round</button>
              <button class="solo-stat-mode ${statsMode === 'full' ? 'active' : ''}" data-solo-stats-mode="full">Full Lobby</button>
            </div>
          </div>
          <div class="solo-round-summary-grid">
            <div><span>Selected round</span><strong>Round ${escapeHtml(String(selected))} · ${escapeHtml(displayResult(activeRound && activeRound.result || ''))}</strong></div>
            <div><span>Ended by</span><strong>${escapeHtml(endedBy)}</strong></div>
            <div><span>Your team</span><strong>${friendly.map((name) => coloredShortName(name, match)).join('') || 'Unknown'}</strong></div>
            <div><span>Enemy team</span><strong>${enemy.map((name) => coloredShortName(name, match)).join('') || 'Unknown'}</strong></div>
          </div>
        </div>
      `;
    }

    function renderMatchReport(match) {
      if (!match) return `<div class="card">${renderNoDataBox()}</div>`;
      const isLobby = isSoloShuffleLobbyUiMatch(match);
      const replayMatch = isLobby ? soloShuffleRoundContextMatch(match) : match;
      const statsMatch = isLobby ? soloShuffleStatsMatch(match) : match;
      const logContextMatch = isLobby ? replayMatch : match;
      return `
        <div class="grid">
          ${isLobby ? renderSoloShuffleLobbyPanel(match) : ''}
          ${renderSyncedReplay(replayMatch)}
          ${renderMetricPanel(statsMatch)}
          ${renderInlineScoreboardPanel(logContextMatch)}
          <div class="grid three-col">
            <div class="card"><div class="card-title-row"><div><p class="small-label">Trades</p><h2>Detected Cooldowns</h2></div><div class="icon-bubble">⚡</div></div><div class="event-list">${(logContextMatch.cooldowns || []).map(renderEvent).join('') || '<div class="empty">No cooldowns found yet.</div>'}</div></div>
            <div class="card"><div class="card-title-row"><div><p class="small-label">Control</p><h2>CC and Interrupts</h2></div><div class="icon-bubble">🌀</div></div><div class="cc-list">${(logContextMatch.ccChains || []).map(renderCc).join('') || '<div class="empty">No CC found yet.</div>'}${(logContextMatch.interrupts || []).map(renderInterrupt).join('')}</div></div>
          </div>
        </div>
      `;
    }

    function renderMatchDetailPage(match) {
      return `
        <div class="grid review-page">
          <div class="match-detail-toolbar compact-match-detail-toolbar">
            <button class="btn" id="back-to-match-list">← All Matches</button>
            ${match ? renderMatchDetailNav(match) : ''}
            <div class="match-detail-spacer"></div>
            ${match ? `<button class="btn favorite-toggle ${isFavoriteMatch(match) ? 'active' : ''}" id="toggle-match-favorite">${isFavoriteMatch(match) ? '★ Favorited' : '☆ Favorite'}</button><button class="btn rose small-danger" id="delete-selected-match">Delete Match</button>` : ''}
          </div>
          ${renderMatchReport(match)}
        </div>
      `;
    }

    return {
      renderSoloShuffleLobbyPanel,
      renderMatchReport,
      renderMatchDetailPage
    };
  }

  window.LastCallMatchDetailView = { createMatchDetailViewTools };
})();
