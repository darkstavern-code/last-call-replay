(function () {
  function createAppEvents(deps = {}) {
    if (!deps || !deps.state) throw new Error('LastCallAppEvents requires app state.');

    function bindEvents() {
      const { state, api } = deps;

  document.querySelectorAll('[data-stat-nav]').forEach((card) => card.addEventListener('click', () => { state.active = card.dataset.statNav; if (state.active === 'Matches') state.matchView = 'list'; render(); }));
  document.querySelectorAll('#dashboard-character-select').forEach((el) => el.addEventListener('change', () => {
    state.dashboardCharacterKey = el.value || 'All';
    state.toonFilter = 'All';
    if (state.dashboardCharacterKey !== 'All') {
      const rawName = String(state.dashboardCharacterKey).split('|')[0];
      state.toonFilter = rawName || 'All';
    }
    render();
  }));
  document.querySelectorAll('#dashboard-history-type-filter').forEach((el) => el.addEventListener('change', () => { state.dashboardHistoryTypeFilter = el.value || 'All'; render(); }));
  document.querySelectorAll('#dashboard-history-result-filter').forEach((el) => el.addEventListener('change', () => { state.dashboardHistoryResultFilter = el.value || 'All'; render(); }));

  document.querySelectorAll('#character-select').forEach((el) => el.addEventListener('change', () => {
    state.selectedCharacterKey = el.value;
    if (state.selectedCharacterKey && state.selectedCharacterKey !== 'All') rememberSelectedCharacterKey(state.selectedCharacterKey);
    render();
  }));
  document.querySelectorAll('#character-bracket-filter').forEach((el) => el.addEventListener('change', () => { state.characterBracketFilter = el.value; render(); }));
  document.querySelectorAll('#character-timeframe').forEach((el) => el.addEventListener('change', () => { state.characterTimeframe = el.value; render(); }));
  document.querySelectorAll('#import-character-snapshot').forEach((button) => button.addEventListener('click', importCharacterSnapshot));
  document.querySelectorAll('#import-pvph-savedvariables').forEach((button) => button.addEventListener('click', importPvPHelperSavedVariables));
  document.querySelectorAll('.import-pvph-manual').forEach((button) => button.addEventListener('click', importPvPHelperSavedVariables));
  document.querySelectorAll('.auto-preview-pvph-savedvariables').forEach((button) => button.addEventListener('click', autoPreviewPvPHelperSavedVariables));
  document.querySelectorAll('.refresh-pvph-discovery').forEach((button) => button.addEventListener('click', () => refreshPvPHelperSavedVariablesDiscovery(true)));
  document.querySelectorAll('[data-reveal-pvphelper-savedvars]').forEach((button) => button.addEventListener('click', () => api && api.revealPath(button.dataset.revealPvphelperSavedvars)));
  document.querySelectorAll('[data-reveal-path]').forEach((button) => button.addEventListener('click', () => api && api.revealPath(button.dataset.revealPath)));
  document.querySelectorAll('#sync-pvph-savedvariables').forEach((button) => button.addEventListener('click', () => syncMappedPvPHelperSavedVariables({ force: true, silent: false })));
  document.querySelectorAll('#clear-pvph-savedvariables').forEach((button) => button.addEventListener('click', clearPvPHelperSavedVariablesMapping));
  document.querySelectorAll('#pvphelper-auto-sync').forEach((input) => input.addEventListener('change', () => updatePvPHelperAutoSync(input.checked)));
  const closePvPHelperPreview = document.getElementById('close-pvphelper-preview');
  if (closePvPHelperPreview) closePvPHelperPreview.addEventListener('click', () => { state.pvpHelperImportPreview = null; render(); });
  const cancelPvPHelperPreview = document.getElementById('cancel-pvphelper-preview');
  if (cancelPvPHelperPreview) cancelPvPHelperPreview.addEventListener('click', () => { state.pvpHelperImportPreview = null; render(); });
  const applyPvPHelperPreview = document.getElementById('apply-pvphelper-preview');
  if (applyPvPHelperPreview) applyPvPHelperPreview.addEventListener('click', applyPvPHelperImportPreview);
  const pvpHelperPreviewScrim = document.getElementById('pvphelper-preview-scrim');
  if (pvpHelperPreviewScrim) pvpHelperPreviewScrim.addEventListener('click', (event) => { if (event.target === pvpHelperPreviewScrim) { state.pvpHelperImportPreview = null; render(); } });
  const playerHistoryScrim = document.getElementById('player-history-scrim');
  if (playerHistoryScrim) playerHistoryScrim.addEventListener('click', (event) => { if (event.target === playerHistoryScrim) { state.playerMeetingHistoryName = ''; render(); } });
  const closePlayerHistory = document.getElementById('close-player-history');
  if (closePlayerHistory) closePlayerHistory.addEventListener('click', () => { state.playerMeetingHistoryName = ''; render(); });
  document.querySelectorAll('[data-player-history]').forEach((button) => button.addEventListener('click', () => { state.playerMeetingHistoryName = button.dataset.playerHistory || ''; render(); }));
  document.querySelectorAll('[data-delete-character-snapshot]').forEach((button) => button.addEventListener('click', () => deleteCharacterSnapshot(button.dataset.deleteCharacterSnapshot)));
  document.querySelectorAll('[data-most-seen-enemy]').forEach((card) => card.addEventListener('click', () => { state.active = 'Players'; state.playerFilter = 'Enemies'; state.focusPlayer = card.dataset.mostSeenEnemy || ''; state.query = ''; render(); }));
  document.querySelectorAll('[data-nav]').forEach((button) => button.addEventListener('click', () => { state.active = button.dataset.nav; if (state.active === 'Matches') state.matchView = 'list'; render(); if (state.active === 'Recorder' && (!state.recorder.sources || !state.recorder.sources.length)) window.setTimeout(refreshCaptureSources, 80); }));
  document.querySelectorAll('[data-import-vod-file]').forEach((button) => button.addEventListener('click', () => importVodFile()));
  const vodDrop = document.getElementById('vod-import-drop');
  if (vodDrop) {
    const setDropActive = (active) => vodDrop.classList.toggle('drag-active', Boolean(active));
    ['dragenter', 'dragover'].forEach((name) => vodDrop.addEventListener(name, (event) => {
      event.preventDefault();
      event.stopPropagation();
      setDropActive(true);
      if (event.dataTransfer) event.dataTransfer.dropEffect = 'copy';
    }));
    ['dragleave', 'dragend'].forEach((name) => vodDrop.addEventListener(name, (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (event.currentTarget === vodDrop) setDropActive(false);
    }));
    vodDrop.addEventListener('drop', (event) => {
      event.preventDefault();
      event.stopPropagation();
      setDropActive(false);
      importVodFilesFromDrop(event.dataTransfer && event.dataTransfer.files, 'drop');
    });
  }
  const vodPage = document.getElementById('vod-page');
  if (vodPage) vodPage.addEventListener('paste', handleVodPaste);
  const toggleVodLibraryMore = document.getElementById('toggle-vod-library-more');
  if (toggleVodLibraryMore) toggleVodLibraryMore.addEventListener('click', () => { state.showAllVods = !state.showAllVods; render(); });
  document.querySelectorAll('[data-select-vod]').forEach((button) => button.addEventListener('click', (event) => {
    if (event.target && event.target.closest('[data-delete-vod]')) return;
    state.selectedVodId = button.dataset.selectVod || '';
    state.vodStatus = '';
    render();
  }));
  document.querySelectorAll('[data-delete-vod]').forEach((button) => button.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    deleteVod(button.dataset.deleteVod || '');
  }));
  const saveVodButton = document.getElementById('save-vod-meta');
  if (saveVodButton) saveVodButton.addEventListener('click', saveVodMeta);
  const useVodFilenameTime = document.getElementById('use-vod-filename-time');
  if (useVodFilenameTime) useVodFilenameTime.addEventListener('click', () => {
    const suggestion = vodSuggestedStart(selectedVod());
    const input = document.getElementById('vod-start-time');
    if (suggestion && input) { input.value = suggestion.localValue; state.vodStatus = 'Filename time applied. Save timing, then link matches.'; render(); }
  });
  const linkVodButton = document.getElementById('link-vod-matches');
  if (linkVodButton) linkVodButton.addEventListener('click', () => linkVodMatches());
  document.querySelectorAll('[data-link-vod-match]').forEach((button) => button.addEventListener('click', () => linkVodMatches([button.dataset.linkVodMatch])));
  document.querySelectorAll('[data-favorite-folder]').forEach((button) => button.addEventListener('click', () => { state.selectedFavoriteFolderId = button.dataset.favoriteFolder || 'all'; state.favoriteVisibleLimit = 20; render(); }));
  document.querySelectorAll('[data-delete-favorite-folder]').forEach((button) => button.addEventListener('click', (event) => { event.preventDefault(); deleteFavoriteFolder(button.dataset.deleteFavoriteFolder); }));
  const loadMoreFavorites = document.getElementById('load-more-favorites');
  if (loadMoreFavorites) loadMoreFavorites.addEventListener('click', () => { state.favoriteVisibleLimit = (Number(state.favoriteVisibleLimit) || 20) + 20; render(); });
  const favoriteFolderNameInput = document.getElementById('favorite-folder-name');
  if (favoriteFolderNameInput) favoriteFolderNameInput.addEventListener('input', () => { state.favoriteFolderDraft = favoriteFolderNameInput.value || ''; });
  const favoriteFolderForm = document.getElementById('favorite-folder-form');
  if (favoriteFolderForm) favoriteFolderForm.addEventListener('submit', (event) => { event.preventDefault(); createFavoriteFolderPrompt(); });
  const createFavoriteFolder = document.getElementById('create-favorite-folder');
  if (createFavoriteFolder) createFavoriteFolder.addEventListener('click', (event) => { event.preventDefault(); createFavoriteFolderPrompt(); });
  document.querySelectorAll('[data-favorite-folder-match]').forEach((select) => select.addEventListener('change', () => updateFavoriteMeta(select.dataset.favoriteFolderMatch, { folderId: select.value || '' })));
  document.querySelectorAll('[data-favorite-comment-match]').forEach((box) => box.addEventListener('change', () => updateFavoriteMeta(box.dataset.favoriteCommentMatch, { comment: box.value || '' })));
  document.querySelectorAll('[data-unfavorite-match]').forEach((button) => button.addEventListener('click', () => updateFavoriteMeta(button.dataset.unfavoriteMatch, { favorite: false })));
  document.querySelectorAll('[data-scoreboard-match]').forEach((button) => {
    const open = (event) => { event.stopPropagation(); event.preventDefault(); openScoreboardForMatch(button.dataset.scoreboardMatch); };
    button.addEventListener('click', open);
    button.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') open(event); });
  });
  document.querySelectorAll('[data-download-clip-match]').forEach((button) => {
    const download = (event) => { event.stopPropagation(); event.preventDefault(); exportVodClipByMatchId(button.dataset.downloadClipMatch); };
    button.addEventListener('click', download);
    button.addEventListener('keydown', (event) => { if (event.key === 'Enter' || event.key === ' ') download(event); });
  });
  document.querySelectorAll('[data-match]').forEach((button) => button.addEventListener('click', () => openMatchDetail(button.dataset.match)));
  const backToMatchList = document.getElementById('back-to-match-list');
  if (backToMatchList) backToMatchList.addEventListener('click', () => returnToMatchList());
  document.querySelectorAll('[data-match-nav]').forEach((button) => button.addEventListener('click', () => navigateMatchDetail(button.dataset.matchNav || 'next')));
  const matchSelect = document.getElementById('match-select');
  if (matchSelect) matchSelect.addEventListener('change', (event) => { state.selectedId = event.target.value; state.selectedMetricActor = ''; state.selectedMetricAbility = ''; render(); });
  document.querySelectorAll('[data-player-filter]').forEach((button) => button.addEventListener('click', () => { state.playerFilter = button.dataset.playerFilter; state.playerClassFilter = 'All'; render(); }));
  const playerClassFilter = document.getElementById('player-class-filter');
  if (playerClassFilter) playerClassFilter.addEventListener('change', (event) => { state.playerClassFilter = event.target.value || 'All'; render(); });
  const playerRecordFilter = document.getElementById('player-record-filter');
  if (playerRecordFilter) playerRecordFilter.addEventListener('change', (event) => { state.playerRecordFilter = event.target.value || 'All'; render(); });
  const playerSort = document.getElementById('player-sort');
  if (playerSort) playerSort.addEventListener('change', (event) => { state.playerSort = event.target.value || 'mostSeen'; render(); });
  const selectSoloRound = (round) => {
    const match = selectedMatch();
    if (!match) return;
    const nextRound = Number(round || 1) || 1;
    state.soloShuffleSelectedRounds = { ...(state.soloShuffleSelectedRounds || {}), [match.id]: nextRound };
    state.selectedMetricActor = '';
    state.selectedMetricAbility = '';
    const roundMatch = soloShuffleRoundContextMatch(match);
    const video = document.getElementById('replay-video');
    const target = Number(roundMatch.videoMatchStartSec);
    if (video && Number.isFinite(target)) {
      try { video.currentTime = Math.max(0, target); } catch (_) {}
      state.player.currentTime = video.currentTime || target;
    } else if (Number.isFinite(target)) {
      state.player.currentTime = target;
    }
    renderKeepingReplay();
  };
  document.querySelectorAll('[data-solo-round]').forEach((button) => button.addEventListener('click', () => selectSoloRound(button.dataset.soloRound)));
  document.querySelectorAll('[data-solo-round-nav]').forEach((button) => button.addEventListener('click', () => {
    const match = selectedMatch();
    if (!match) return;
    const rounds = soloShuffleRounds(match).map((round) => Number(round.roundNumber || 0)).filter(Boolean).sort((a, b) => a - b);
    const selected = selectedSoloShuffleRoundNumber(match);
    const index = Math.max(0, rounds.indexOf(selected));
    const target = button.dataset.soloRoundNav === 'prev' ? rounds[Math.max(0, index - 1)] : rounds[Math.min(rounds.length - 1, index + 1)];
    if (target) selectSoloRound(target);
  }));
  document.querySelectorAll('[data-solo-stats-mode]').forEach((button) => button.addEventListener('click', () => {
    state.soloShuffleStatsMode = button.dataset.soloStatsMode === 'full' ? 'full' : 'round';
    state.selectedMetricActor = '';
    state.selectedMetricAbility = '';
    renderKeepingReplay();
  }));
  bindMetricPanelEvents();
  document.querySelectorAll('[data-rail-filter]').forEach((button) => button.addEventListener('click', () => { state.railFilter = button.dataset.railFilter; lastRailAutoScrollAt = -999; clearRailFeedCache(); renderKeepingReplay(); }));
  document.querySelectorAll('[data-health-mode]').forEach((button) => button.addEventListener('click', () => {
    state.player.healthTimelineMode = button.dataset.healthMode === 'deathWindow' ? 'deathWindow' : 'match';
    state.player.healthDeathFocusTime = null;
    renderKeepingReplay();
  }));
  document.querySelectorAll('[data-health-death-jump]').forEach((button) => button.addEventListener('click', (event) => {
    event.preventDefault();
    event.stopPropagation();
    const deathTime = Number(button.dataset.healthDeathJump || 0);
    const startTime = Math.max(0, Number(button.dataset.healthDeathStart || Math.max(0, deathTime - 10)) || 0);
    if (!Number.isFinite(deathTime)) return;
    state.player.healthDeathFocusTime = deathTime;
    const video = document.getElementById('replay-video');
    const seek = startTime + (Number(state.player.syncOffsetSec) || 0);
    if (video) {
      video.currentTime = Math.max(0, seek);
      state.player.currentTime = video.currentTime;
      updateVideoEventRail();
    } else {
      state.player.currentTime = Math.max(0, seek);
    }
    renderKeepingReplay();
  }));
  document.querySelectorAll('[data-health-click]').forEach((plot) => plot.addEventListener('click', (event) => {
    if (event.target && event.target.closest && event.target.closest('[data-seek-time]')) return;
    const video = document.getElementById('replay-video');
    const holder = plot.closest('.health-timeline');
    if (!video || !holder) return;
    const rect = plot.getBoundingClientRect();
    const duration = Math.max(1, Number(holder.dataset.healthDuration || 1));
    const start = Math.max(0, Number(holder.dataset.healthStart || 0));
    const ratio = Math.max(0, Math.min(1, (event.clientX - rect.left) / Math.max(1, rect.width)));
    const seek = start + ratio * duration + (Number(state.player.syncOffsetSec) || 0);
    video.currentTime = Math.max(0, seek);
    state.player.currentTime = video.currentTime;
    updateVideoEventRail();
  }));
  document.querySelectorAll('[data-seek-time]').forEach((button) => button.addEventListener('click', () => { const video = document.getElementById('replay-video'); const seek = Number(button.dataset.seekTime || 0) + (Number(state.player.syncOffsetSec) || 0); if (video) { video.currentTime = Math.max(0, seek); state.player.currentTime = video.currentTime; updateVideoEventRail(); } }));
  const liveFollowToggle = document.getElementById('toggle-rail-follow');
  if (liveFollowToggle) liveFollowToggle.addEventListener('click', () => {
    state.player.railLiveFollow = !state.player.railLiveFollow;
    lastRailAutoScrollAt = -999;
    updateVideoEventRail();
  });
  const feedBox = document.getElementById('combat-feed');
  if (feedBox) {
    feedBox.addEventListener('wheel', (event) => {
      if (event.shiftKey) {
        event.preventDefault();
        feedBox.scrollTop += event.deltaY;
        clearTimeout(railShiftSeekTimer);
        railShiftSeekTimer = setTimeout(() => syncVideoToRailPosition(feedBox), 15);
      }
    }, { passive: false });
  }
  const exportVodClip = document.getElementById('export-vod-clip');
  if (exportVodClip) exportVodClip.addEventListener('click', exportSelectedVodClip);
  const chooseExportFolderButton = document.getElementById('choose-export-folder');
  if (chooseExportFolderButton) chooseExportFolderButton.addEventListener('click', chooseExportFolder);
  const jumpClipStart = document.getElementById('jump-vod-clip-start');
  if (jumpClipStart) jumpClipStart.addEventListener('click', () => seekReplayToClipStart(currentReplayMatch()));
  const saveVideoSection = document.getElementById('save-match-video-section');
  if (saveVideoSection) saveVideoSection.addEventListener('click', exportSelectedPartOfMatch);
  syncClipTrimControls();
  const replaySoundToggle = document.getElementById('replay-sound-toggle');
  if (replaySoundToggle) replaySoundToggle.addEventListener('click', () => {
    const video = document.getElementById('replay-video');
    const currentlyMuted = Boolean(state.player.videoMuted || (video && video.muted) || Number(state.player.videoVolume || 0) <= 0.005);
    if (currentlyMuted) {
      const restore = Math.max(0.05, Math.min(1, Number(state.player.lastVideoVolume || state.player.videoVolume || 1) || 1));
      state.player.videoMuted = false;
      state.player.videoVolume = restore;
      if (video) { video.muted = false; video.volume = restore; }
    } else {
      state.player.lastVideoVolume = Math.max(0.05, Math.min(1, Number(video ? video.volume : state.player.videoVolume) || 1));
      state.player.videoMuted = true;
      state.player.videoVolume = 0;
      if (video) { video.volume = 0; video.muted = true; }
    }
    updateReplayAudioControls(video);
    updateReplayTransport(video ? video.currentTime : state.player.currentTime);
  });
  const replayVolumeRange = document.getElementById('replay-volume-range');
  if (replayVolumeRange) replayVolumeRange.addEventListener('input', () => {
    const video = document.getElementById('replay-video');
    const volume = Math.max(0, Math.min(1, Number(replayVolumeRange.value) || 0));
    state.player.videoVolume = volume <= 0.005 ? 0 : volume;
    if (state.player.videoVolume > 0) state.player.lastVideoVolume = state.player.videoVolume;
    state.player.videoMuted = state.player.videoVolume <= 0;
    if (video) {
      video.volume = state.player.videoVolume;
      video.muted = state.player.videoMuted;
    }
    updateReplayAudioControls(video);
  });
  const replayPlayToggle = document.getElementById('replay-play-toggle');
  if (replayPlayToggle) replayPlayToggle.addEventListener('click', () => {
    const video = document.getElementById('replay-video');
    if (!video) return;
    if (video.readyState < 2) {
      const overlay = document.getElementById('replay-video-loading');
      if (overlay) {
        overlay.classList.add('active');
        const text = overlay.querySelector('span');
        if (text) text.textContent = 'Loading video…';
      }
      try { video.load(); } catch (_) {}
      updateReplayTransport(video.currentTime || state.player.currentTime || 0);
      return;
    }
    if (video.paused || video.ended) video.play().catch(() => {});
    else video.pause();
    updateReplayTransport(video.currentTime || state.player.currentTime || 0);
  });
  const replaySeekRange = document.getElementById('replay-seek-range');
  if (replaySeekRange) replaySeekRange.addEventListener('input', () => {
    const video = document.getElementById('replay-video');
    const target = Number(replaySeekRange.value);
    if (!video || !Number.isFinite(target)) return;
    try { video.currentTime = Math.max(0, target); } catch (_) {}
    state.player.currentTime = video.currentTime || target;
    updateReplayClockAndHealth(state.player.currentTime);
    scheduleVideoRailUpdate(true);
  });
  const video = document.getElementById('replay-video');
  if (video) {
    const setReplayVideoLoading = (active, message = '') => {
      const overlay = document.getElementById('replay-video-loading');
      if (!overlay) return;
      overlay.classList.toggle('active', Boolean(active));
      const text = overlay.querySelector('span');
      if (text && message) text.textContent = message;
    };
    const markVideoReady = () => {
      setReplayVideoLoading(false);
      updateReplayTransport(video.currentTime || state.player.currentTime || 0);
      scheduleReplayPanelHeightSync();
    };
    const markVideoBuffering = (message = 'Buffering video…') => {
      setReplayVideoLoading(true, message);
      updateReplayTransport(video.currentTime || state.player.currentTime || 0);
    };
    video.muted = Boolean(state.player.videoMuted);
    video.volume = Math.max(0, Math.min(1, Number(state.player.videoMuted ? 0 : (state.player.videoVolume ?? 0)) || 0));
    if (video.readyState < 2) markVideoBuffering('Preparing smooth playback before the first jump.');
    updateReplayAudioControls(video);
    video.addEventListener('click', () => {
      if (video.readyState < 2) { markVideoBuffering('Loading video…'); try { video.load(); } catch (_) {} return; }
      if (video.paused || video.ended) video.play().catch(() => markVideoBuffering('Waiting for video data…'));
      else video.pause();
      updateReplayTransport(video.currentTime || state.player.currentTime || 0);
    });
    video.addEventListener('volumechange', () => {
      const volume = Math.max(0, Math.min(1, Number(video.volume || 0)));
      state.player.videoMuted = Boolean(video.muted || volume <= 0.005);
      state.player.videoVolume = state.player.videoMuted ? 0 : volume;
      if (!state.player.videoMuted && volume > 0) state.player.lastVideoVolume = volume;
      updateReplayAudioControls(video);
    });
    video.addEventListener('loadedmetadata', () => {
      updateClipTrimMaxFromVideo(video);
      syncClipTrimControls();
      const match = currentReplayMatch();
      if (match && isVideoSectionLink(match)) {
        const scope = replayScopeBoundsForMatch(match, video);
        const clipStart = Number(scope.min || 0);
        const matchStart = Number(match.videoMatchStartSec);
        const syncAdjustment = Number(match.videoSyncAdjustmentSec || 0) || 0;
        if (Number.isFinite(matchStart)) state.player.syncOffsetSec = matchStart + syncAdjustment;
        if (Number.isFinite(clipStart) && (!state.player.matchId || state.player.matchId !== match.id || (video.currentTime || 0) < 1 || (video.currentTime || 0) < clipStart || (video.currentTime || 0) > Number(scope.max || clipStart + 1))) {
          try { video.currentTime = Math.max(0, clipStart); } catch (_) {}
          state.player.currentTime = video.currentTime || clipStart;
          state.player.matchId = match.id;
          state.player.videoPath = match.videoPath || state.player.videoPath;
        }
        enforceVodClipBounds(video, match);
      }
      state.player.currentTime = video.currentTime || state.player.currentTime || 0;
      updateReplayClockAndHealth(state.player.currentTime);
      scheduleVideoRailUpdate(false);
      scheduleReplayPanelHeightSync();
    });
    video.addEventListener('loadstart', () => markVideoBuffering('Loading linked video…'));
    video.addEventListener('loadeddata', markVideoReady);
    video.addEventListener('canplay', markVideoReady);
    video.addEventListener('canplaythrough', markVideoReady);
    video.addEventListener('playing', markVideoReady);
    video.addEventListener('waiting', () => markVideoBuffering('Buffering video…'));
    video.addEventListener('stalled', () => markVideoBuffering('Waiting for video data…'));
    video.addEventListener('error', () => markVideoBuffering('Video could not load. Check the linked file.')); 
    video.addEventListener('seeking', () => {
      state.player.currentTime = video.currentTime || 0;
      updateReplayClockAndHealth(state.player.currentTime);
      scheduleVideoRailUpdate(true);
    });
    video.addEventListener('seeked', () => {
      enforceVodClipBounds(video, currentReplayMatch());
      state.player.currentTime = video.currentTime || 0;
      updateReplayClockAndHealth(state.player.currentTime);
      scheduleVideoRailUpdate(true);
    });
    video.addEventListener('timeupdate', () => {
      const match = currentReplayMatch();
      enforceVodClipBounds(video, match);
      state.player.currentTime = video.currentTime;
      const currentMatchTime = updateReplayClockAndHealth(state.player.currentTime);
      maybeRefreshDeathWindowHealth(currentMatchTime);
      scheduleVideoRailUpdate();
    });
    video.addEventListener('play', () => { lastRailAutoScrollAt = -999; updateReplayTransport(video.currentTime || 0); startReplayHealthSyncLoop(); scheduleReplayPanelHeightSync(); scheduleVideoRailUpdate(false); });
    video.addEventListener('pause', () => { stopReplayHealthSyncLoop(); updateReplayClockAndHealth(video.currentTime || 0); updateReplayTransport(video.currentTime || 0); scheduleVideoRailUpdate(true); });
    video.addEventListener('ended', () => { stopReplayHealthSyncLoop(); updateReplayClockAndHealth(video.currentTime || 0); updateReplayTransport(video.currentTime || 0); scheduleVideoRailUpdate(true); });
  }
  const videoSelect = document.getElementById('video-select');
  if (videoSelect) videoSelect.addEventListener('change', (event) => {
    const match = selectedMatch();
    state.player.videoPath = event.target.value;
    state.player.matchId = match ? match.id : '';
    state.player.currentTime = 0;
    renderKeepingReplay();
  });
  const linkVideo = document.getElementById('link-video-file');
  if (linkVideo) linkVideo.addEventListener('click', linkVideoToSelectedMatch);
  const unlinkVideo = document.getElementById('unlink-selected-video');
  if (unlinkVideo) unlinkVideo.addEventListener('click', unlinkVideoFromSelectedMatch);
  const favoriteToggle = document.getElementById('toggle-match-favorite');
  if (favoriteToggle) favoriteToggle.addEventListener('click', toggleSelectedMatchFavorite);
  const deleteMatch = document.getElementById('delete-selected-match');
  if (deleteMatch) deleteMatch.addEventListener('click', deleteSelectedMatch);
  const openMatchScoreboard = document.getElementById('open-match-scoreboard');
  if (openMatchScoreboard) openMatchScoreboard.addEventListener('click', () => { state.scoreboardModalMode = 'view'; renderKeepingReplay(); });
  const openScoreboardLinker = document.getElementById('open-scoreboard-linker');
  if (openScoreboardLinker) openScoreboardLinker.addEventListener('click', () => { state.scoreboardModalMode = 'link'; renderKeepingReplay(); });
  const closeScoreboardModalButton = document.getElementById('close-scoreboard-modal');
  if (closeScoreboardModalButton) closeScoreboardModalButton.addEventListener('click', closeScoreboardModal);
  const closeScoreboardModalBottomButton = document.getElementById('close-scoreboard-modal-bottom');
  if (closeScoreboardModalBottomButton) closeScoreboardModalBottomButton.addEventListener('click', closeScoreboardModal);
  const scoreboardScrim = document.getElementById('scoreboard-modal-scrim');
  if (scoreboardScrim) scoreboardScrim.addEventListener('click', (event) => { if (event.target === scoreboardScrim) closeScoreboardModal(); });
  document.querySelectorAll('[data-link-scoreboard-match]').forEach((button) => button.addEventListener('click', () => linkScoreboardToSelectedMatch(button.dataset.linkScoreboardMatch)));
  const realFullscreen = document.getElementById('video-real-fullscreen');
  if (realFullscreen) realFullscreen.addEventListener('click', enterReplayFullscreen);
  document.querySelectorAll('[data-vod-scope]').forEach((button) => button.addEventListener('click', () => {
    const mode = String(button.dataset.vodScope || 'match');
    state.player.vodScopeMode = ['match', 'room', 'full'].includes(mode) ? mode : 'match';
    const match = selectedMatch();
    const video = document.getElementById('replay-video');
    const bounds = replayScopeBoundsForMatch(match, video);
    if (video && Number.isFinite(Number(bounds.min))) {
      try { video.currentTime = Math.max(0, Number(bounds.min)); } catch (_) {}
      state.player.currentTime = video.currentTime || Number(bounds.min) || 0;
    }
    renderKeepingReplay();
  }));
  const fullscreenToggle = document.getElementById('replay-fullscreen-toggle');
  if (fullscreenToggle) fullscreenToggle.addEventListener('click', () => { state.player.theaterMode = !state.player.theaterMode; renderKeepingReplay(); });
  const railToggle = document.getElementById('replay-rail-toggle');
  if (railToggle) railToggle.addEventListener('click', () => { state.player.showRail = !state.player.showRail; renderKeepingReplay(); });
  const exportToggle = document.getElementById('toggle-export-panel');
  if (exportToggle) exportToggle.addEventListener('click', () => { state.player.showExportPanel = !state.player.showExportPanel; renderKeepingReplay(); });
  const videoSyncToggle = document.getElementById('toggle-video-sync-panel');
  if (videoSyncToggle) videoSyncToggle.addEventListener('click', () => { state.player.showVideoSyncPanel = !state.player.showVideoSyncPanel; renderKeepingReplay(); });
  const syncLogsFromReplay = document.getElementById('sync-logs-from-replay');
  if (syncLogsFromReplay) syncLogsFromReplay.addEventListener('click', syncLogsForSelectedMatch);

  const syncMinus = document.getElementById('sync-minus');
  if (syncMinus) syncMinus.addEventListener('click', () => adjustSyncOffset(-0.25));
  const syncPlus = document.getElementById('sync-plus');
  if (syncPlus) syncPlus.addEventListener('click', () => adjustSyncOffset(0.25));
  const syncInput = document.getElementById('sync-offset-input');
  if (syncInput) syncInput.addEventListener('change', () => { state.player.syncOffsetSec = Number(syncInput.value) || 0; updateVideoEventRail(); });
  const syncSetZero = document.getElementById('sync-set-zero');
  if (syncSetZero) syncSetZero.addEventListener('click', () => { const video = document.getElementById('replay-video'); if (video) { state.player.syncOffsetSec = video.currentTime || 0; renderKeepingReplay(); } });

  document.querySelectorAll('[data-settings-category]').forEach((button) => button.addEventListener('click', () => {
    state.settingsCategory = button.dataset.settingsCategory || 'logs';
    render();
  }));
  const toggleLogMonitorList = document.getElementById('toggle-log-monitor-list');
  if (toggleLogMonitorList) toggleLogMonitorList.addEventListener('click', () => {
    state.showAllLogMonitor = !state.showAllLogMonitor;
    render();
  });
  const settingsPickLog = document.getElementById('settings-pick-log');
  if (settingsPickLog) settingsPickLog.addEventListener('click', pickAndWatchFile);
  const settingsAutoConnect = document.getElementById('settings-auto-connect-local-setup');
  if (settingsAutoConnect) settingsAutoConnect.addEventListener('click', autoConnectLocalSetup);
  const settingsImportOldLog = document.getElementById('settings-import-old-log');
  if (settingsImportOldLog) settingsImportOldLog.addEventListener('click', importOldLog);
  const settingsScanRecordings = document.getElementById('settings-scan-recordings');
  if (settingsScanRecordings) settingsScanRecordings.addEventListener('click', scanRecordingsFolder);
  const settingsScanLogs = document.getElementById('settings-scan-logs');
  if (settingsScanLogs) settingsScanLogs.addEventListener('click', scanLogsFolder);
  const settingsRepairMissingLogs = document.getElementById('settings-repair-missing-logs');
  if (settingsRepairMissingLogs) settingsRepairMissingLogs.addEventListener('click', repairMissingLogs);
  const settingsCompactLocalState = document.getElementById('settings-compact-local-state');
  if (settingsCompactLocalState) settingsCompactLocalState.addEventListener('click', compactLocalState);
  const settingsBackupState = document.getElementById('settings-create-state-backup');
  if (settingsBackupState) settingsBackupState.addEventListener('click', createStateBackupNow);
  const settingsRepairLibraryLinks = document.getElementById('settings-repair-library-links');
  if (settingsRepairLibraryLinks) settingsRepairLibraryLinks.addEventListener('click', repairLibraryConnections);
  const matchHistoryRefresh = document.getElementById('match-history-refresh');
  if (matchHistoryRefresh) matchHistoryRefresh.addEventListener('click', refreshMatchHistory);
  const loadMoreMatches = document.getElementById('load-more-matches');
  if (loadMoreMatches) loadMoreMatches.addEventListener('click', () => increaseVisibleLimit('matchVisibleLimit', 80, 5000));
  const loadMoreLogs = document.getElementById('load-more-logs');
  if (loadMoreLogs) loadMoreLogs.addEventListener('click', () => increaseVisibleLimit('logMonitorVisibleLimit', 60, 5000));
  const loadMoreRecordings = document.getElementById('load-more-recordings');
  if (loadMoreRecordings) loadMoreRecordings.addEventListener('click', () => increaseVisibleLimit('recordingVisibleLimit', 24, 5000));
  const loadMoreVods = document.getElementById('load-more-vods');
  if (loadMoreVods) loadMoreVods.addEventListener('click', () => increaseVisibleLimit('vodLibraryVisibleLimit', 40, 5000));
  const loadMoreVodCandidates = document.getElementById('load-more-vod-candidates');
  if (loadMoreVodCandidates) loadMoreVodCandidates.addEventListener('click', () => increaseVisibleLimit('vodCandidateVisibleLimit', 60, 5000));
  const listScanRecordings = document.getElementById('scan-recordings-folder');
  if (listScanRecordings) listScanRecordings.addEventListener('click', scanRecordingsFolder);
  const listScanLogs = document.getElementById('scan-logs-folder');
  if (listScanLogs) listScanLogs.addEventListener('click', scanLogsFolder);
  const settingsPickLogFolder = document.getElementById('settings-pick-log-folder');
  if (settingsPickLogFolder) settingsPickLogFolder.addEventListener('click', pickAndWatchFolder);
  const settingsRecordingsDefault = document.getElementById('settings-default-recordings-folder');
  if (settingsRecordingsDefault) settingsRecordingsDefault.addEventListener('click', useDefaultRecordingsFolder);
  const settingsRecordings = document.getElementById('settings-recordings-folder');
  if (settingsRecordings) settingsRecordings.addEventListener('click', chooseRecordingsFolder);
  const settingsArchive = document.getElementById('settings-archive-folder');
  if (settingsArchive) settingsArchive.addEventListener('click', chooseArchiveFolder);
  const settingsAppStorage = document.getElementById('settings-app-storage-folder');
  if (settingsAppStorage) settingsAppStorage.addEventListener('click', chooseAppStorageFolder);
  const settingsPortableStorage = document.getElementById('settings-portable-storage-folder');
  if (settingsPortableStorage) settingsPortableStorage.addEventListener('click', enablePortableAppStorage);
  const settingsConnectStorage = document.getElementById('settings-connect-storage-folder');
  if (settingsConnectStorage) settingsConnectStorage.addEventListener('click', connectAppStorageFolder);
  const autoLinkWindow = document.getElementById('settings-auto-link-window');
  if (autoLinkWindow) autoLinkWindow.addEventListener('change', saveGeneralSettingsFromForm);
  const updateReleaseUrl = document.getElementById('settings-update-release-url');
  if (updateReleaseUrl) updateReleaseUrl.addEventListener('change', saveGeneralSettingsFromForm);
  const updateManifestUrl = document.getElementById('settings-update-manifest-url');
  if (updateManifestUrl) updateManifestUrl.addEventListener('change', saveGeneralSettingsFromForm);
  const settingsCheckUpdates = document.getElementById('settings-check-updates');
  if (settingsCheckUpdates) settingsCheckUpdates.addEventListener('click', checkForUpdates);
  const settingsOpenReleasePage = document.getElementById('settings-open-release-page');
  if (settingsOpenReleasePage) settingsOpenReleasePage.addEventListener('click', openUpdateReleasePage);
  document.querySelectorAll('[data-update-download-url]').forEach((button) => button.addEventListener('click', () => openUpdateDownloadUrl(button.dataset.updateDownloadUrl || '')));
  const search = document.getElementById('global-search');
  if (search) search.addEventListener('input', (event) => { state.query = event.target.value; scheduleGlobalSearchRender(event.target); });
  const filter = document.getElementById('result-filter');
  if (filter) filter.addEventListener('change', (event) => { state.resultFilter = event.target.value; render(); });
  const toonFilter = document.getElementById('toon-filter');
  if (toonFilter) toonFilter.addEventListener('change', (event) => { state.toonFilter = event.target.value; state.matchVisibleLimit = 80; render(); });
  const dayFilter = document.getElementById('day-filter');
  if (dayFilter) dayFilter.addEventListener('change', (event) => { state.dayFilter = event.target.value; state.matchVisibleLimit = 80; render(); });
  const matchTypeFilter = document.getElementById('match-type-filter');
  if (matchTypeFilter) matchTypeFilter.addEventListener('change', (event) => { state.matchTypeFilter = event.target.value; state.matchVisibleLimit = 80; render(); });
  const classFilter = document.getElementById('class-filter');
  if (classFilter) classFilter.addEventListener('change', (event) => { state.matchClassFilter = event.target.value || 'All'; state.matchVisibleLimit = 80; render(); });
  const matchSort = document.getElementById('match-sort');
  if (matchSort) matchSort.addEventListener('change', (event) => { state.matchSort = event.target.value || 'newest'; state.matchVisibleLimit = 80; render(); });
  const playerMatchTypeFilter = document.getElementById('player-match-type-filter');
  if (playerMatchTypeFilter) playerMatchTypeFilter.addEventListener('change', (event) => { state.playerMatchTypeFilter = event.target.value; state.playerClassFilter = 'All'; render(); });
  document.querySelectorAll('.auto-connect-local-setup-button').forEach((button) => button.addEventListener('click', autoConnectLocalSetup));
  const autoConnectButton = document.getElementById('auto-connect-local-setup');
  if (autoConnectButton) autoConnectButton.addEventListener('click', autoConnectLocalSetup);
  const useDetectedLog = document.getElementById('use-detected-log');
  if (useDetectedLog) useDetectedLog.addEventListener('click', useDetectedLogFile);
  const pickFile = document.getElementById('pick-file');
  if (pickFile) pickFile.addEventListener('click', pickAndWatchFile);
  document.querySelectorAll('.pick-folder-button').forEach((button) => button.addEventListener('click', pickAndWatchFolder));
  const pickFolder = document.getElementById('pick-folder');
  if (pickFolder) pickFolder.addEventListener('click', pickAndWatchFolder);
  const importFile = document.getElementById('import-file');
  if (importFile) importFile.addEventListener('click', importOldLog);
  const refreshSources = document.getElementById('refresh-sources');
  if (refreshSources) refreshSources.addEventListener('click', refreshCaptureSources);
  const dashboardRefreshSources = document.getElementById('dashboard-refresh-sources');
  if (dashboardRefreshSources) dashboardRefreshSources.addEventListener('click', refreshCaptureSources);
  const captureSelect = document.getElementById('capture-source-select');
  if (captureSelect) captureSelect.addEventListener('change', () => { const option = captureSelect.selectedOptions && captureSelect.selectedOptions[0]; selectCaptureSource(captureSelect.value, option ? (option.dataset.sourceName || option.textContent || '') : 'Selected source', true, true, false, option ? option.dataset.sourceKind : ''); });
  const quickCaptureSelect = document.getElementById('quick-capture-source-select');
  if (quickCaptureSelect) quickCaptureSelect.addEventListener('change', () => { const option = quickCaptureSelect.selectedOptions && quickCaptureSelect.selectedOptions[0]; selectCaptureSource(quickCaptureSelect.value, option ? (option.dataset.sourceName || option.textContent || '') : 'Selected source', true, true, false, option ? option.dataset.sourceKind : ''); });
  const dashboardCaptureSelect = document.getElementById('dashboard-capture-source-select');
  if (dashboardCaptureSelect) dashboardCaptureSelect.addEventListener('change', () => { const option = dashboardCaptureSelect.selectedOptions && dashboardCaptureSelect.selectedOptions[0]; selectCaptureSource(dashboardCaptureSelect.value, option ? (option.dataset.sourceName || option.textContent || '') : 'Selected source', true, true, false, option ? option.dataset.sourceKind : ''); });
  document.querySelectorAll('[data-source-id]').forEach((button) => button.addEventListener('click', async () => {
    const isQuickPicker = Boolean(button.closest('#source-quick-scrim'));
    await selectCaptureSource(button.dataset.sourceId, button.dataset.sourceName, !isQuickPicker, true, false, button.dataset.sourceKind || '');
    if (isQuickPicker) {
      state.showSourceQuickPicker = false;
      render();
    }
  }));
  const approveSource = document.getElementById('approve-source');
  if (approveSource) approveSource.addEventListener('click', async () => { state.recorder.sourceApproved = true; await selectCaptureSource(state.recorder.selectedSourceId, state.recorder.selectedSourceName, true, true, false, state.recorder.selectedSourceKind); });
  const dashboardApproveSource = document.getElementById('dashboard-approve-source');
  if (dashboardApproveSource) dashboardApproveSource.addEventListener('click', async () => { state.recorder.sourceApproved = true; await selectCaptureSource(state.recorder.selectedSourceId, state.recorder.selectedSourceName, true, true, false, state.recorder.selectedSourceKind); });
  const quickApproveSource = document.getElementById('quick-approve-source');
  if (quickApproveSource) quickApproveSource.addEventListener('click', async () => { state.recorder.sourceApproved = true; await selectCaptureSource(state.recorder.selectedSourceId, state.recorder.selectedSourceName, true, true, false, state.recorder.selectedSourceKind); });
  const startRecordingButton = document.getElementById('start-recording');
  if (startRecordingButton) startRecordingButton.addEventListener('click', startRecording);
  const stopRecordingButton = document.getElementById('stop-recording');
  if (stopRecordingButton) stopRecordingButton.addEventListener('click', () => stopRecording('Manual stop'));
  const dashboardRecorderSourceButton = document.getElementById('dashboard-recorder-source');
  if (dashboardRecorderSourceButton) dashboardRecorderSourceButton.addEventListener('click', openRecorderSetupFromDashboard);
  const dashboardRecorderSetupHint = document.getElementById('dashboard-recorder-setup-hint');
  if (dashboardRecorderSetupHint) dashboardRecorderSetupHint.addEventListener('click', openRecorderSetupFromDashboard);
  const topbarLogStatus = document.getElementById('topbar-log-status');
  if (topbarLogStatus) topbarLogStatus.addEventListener('click', () => { state.active = 'Settings'; render(); });
  const topbarRecorderStatus = document.getElementById('topbar-recorder-status');
  if (topbarRecorderStatus) topbarRecorderStatus.addEventListener('click', openRecorderSetupFromDashboard);
  const topbarAddonInstallStatus = document.getElementById('topbar-addon-install-status');
  if (topbarAddonInstallStatus) topbarAddonInstallStatus.addEventListener('click', handleTopbarAddonInstallClick);
  const topbarAddonMapStatus = document.getElementById('topbar-addon-map-status');
  if (topbarAddonMapStatus) topbarAddonMapStatus.addEventListener('click', () => {
    const mapped = Boolean(state.settings && state.settings.pvpHelperSavedVariablesPath && state.settings.pvpHelperFileExists !== false);
    if (!mapped) {
      autoPreviewPvPHelperSavedVariables();
      return;
    }
    state.active = 'Settings';
    render();
  });
  const dashboardStartRecordingButton = document.getElementById('dashboard-start-recording');
  if (dashboardStartRecordingButton) dashboardStartRecordingButton.addEventListener('click', startRecording);
  const dashboardStopRecordingButton = document.getElementById('dashboard-stop-recording');
  if (dashboardStopRecordingButton) dashboardStopRecordingButton.addEventListener('click', () => stopRecording('Manual stop'));
  document.querySelectorAll('.install-pvphelper-addon').forEach((button) => button.addEventListener('click', installPvPHelperAddon));
  document.querySelectorAll('.refresh-pvphelper-addon').forEach((button) => button.addEventListener('click', () => refreshPvPHelperAddonInstallStatus(false)));
  document.querySelectorAll('[data-reveal-pvphelper-addon]').forEach((button) => button.addEventListener('click', () => api && api.revealPath(button.dataset.revealPvphelperAddon)));
  const settingsPickLogFolderAddon = document.getElementById('settings-pick-log-folder-addon');
  if (settingsPickLogFolderAddon) settingsPickLogFolderAddon.addEventListener('click', pickAndWatchFolder);
  const sidebarFolderButton = document.getElementById('sidebar-recordings-folder');
  if (sidebarFolderButton) sidebarFolderButton.addEventListener('click', chooseRecordingsFolder);
  const sidebarSourceButton = document.getElementById('sidebar-recorder-source');
  if (sidebarSourceButton) sidebarSourceButton.addEventListener('click', () => { state.recorder.statusText = 'Opening source picker…'; state.showSourceQuickPicker = true; render(); window.setTimeout(refreshCaptureSources, 80); });
  const closeSourceQuick = document.getElementById('close-source-quick');
  if (closeSourceQuick) closeSourceQuick.addEventListener('click', () => { state.showSourceQuickPicker = false; render(); });
  const quickSourceDone = document.getElementById('quick-source-done');
  if (quickSourceDone) quickSourceDone.addEventListener('click', async () => {
    if (state.recorder.sourceApprovalRequired && !state.recorder.sourceApproved && state.recorder.selectedSourceId) {
      await selectCaptureSource(state.recorder.selectedSourceId, state.recorder.selectedSourceName, false, true, false, state.recorder.selectedSourceKind);
    }
    state.showSourceQuickPicker = false;
    render();
  });
  const sourceQuickScrim = document.getElementById('source-quick-scrim');
  if (sourceQuickScrim) sourceQuickScrim.addEventListener('click', (event) => { if (event.target === sourceQuickScrim) { state.showSourceQuickPicker = false; render(); } });
  const quickRefreshSources = document.getElementById('quick-refresh-sources');
  if (quickRefreshSources) quickRefreshSources.addEventListener('click', refreshCaptureSources);
  const sidebarStartRecordingButton = document.getElementById('sidebar-start-recording');
  if (sidebarStartRecordingButton) sidebarStartRecordingButton.addEventListener('click', startRecording);
  const sidebarStopRecordingButton = document.getElementById('sidebar-stop-recording');
  if (sidebarStopRecordingButton) sidebarStopRecordingButton.addEventListener('click', () => stopRecording('Manual stop'));
  const performanceMode = document.getElementById('rec-performance-mode');
  if (performanceMode) performanceMode.addEventListener('change', async (event) => { state.recorder.performanceMode = validRecorderPerformanceMode(event.target.value); await saveRecorderSettings(); render(); });
  const audio = document.getElementById('rec-audio');
  if (audio) audio.addEventListener('change', async (event) => { state.recorder.includeAudio = event.target.checked; await saveRecorderSettings(); render(); });
  const dedupeRecordings = document.getElementById('dedupe-recordings');
  if (dedupeRecordings) dedupeRecordings.addEventListener('click', dedupeRecordingHistory);
  document.querySelectorAll('[data-recording-filter]').forEach((button) => button.addEventListener('click', () => { state.recordingHistoryFilter = button.dataset.recordingFilter || 'Recent'; state.selectedRecordingIds = []; state.recordingVisibleLimit = 24; render(); }));
  const recordingHistorySort = document.getElementById('recording-history-sort');
  if (recordingHistorySort) recordingHistorySort.addEventListener('change', () => { state.recordingHistorySort = recordingHistorySort.value === 'Oldest' ? 'Oldest' : 'Newest'; state.selectedRecordingIds = []; state.recordingVisibleLimit = 24; render(); });
  document.querySelectorAll('[data-recording-select]').forEach((box) => box.addEventListener('change', () => {
    const id = box.dataset.recordingSelect || '';
    const set = new Set(state.selectedRecordingIds || []);
    if (box.checked) set.add(id); else set.delete(id);
    state.selectedRecordingIds = Array.from(set).filter(Boolean);
    render();
  }));
  const selectFailedRecordings = document.getElementById('select-failed-recordings');
  if (selectFailedRecordings) selectFailedRecordings.addEventListener('click', () => { state.selectedRecordingIds = (state.recorder.recordings || []).filter((item) => recordingStatusTone(item) === 'failed').map((item) => item.id).filter(Boolean); render(); });
  const selectUnlinkedRecordings = document.getElementById('select-unlinked-recordings');
  if (selectUnlinkedRecordings) selectUnlinkedRecordings.addEventListener('click', () => { state.selectedRecordingIds = (state.recorder.recordings || []).filter((item) => recordingStatusTone(item) === 'unlinked').map((item) => item.id).filter(Boolean); render(); });
  const clearRecordingSelection = document.getElementById('clear-recording-selection');
  if (clearRecordingSelection) clearRecordingSelection.addEventListener('click', () => { state.selectedRecordingIds = []; render(); });
  const attachSelectedRecordingsWindow = document.getElementById('attach-selected-recordings-window');
  if (attachSelectedRecordingsWindow) attachSelectedRecordingsWindow.addEventListener('click', attachSelectedRecordingsInWindow);
  const deleteSelectedHistory = document.getElementById('delete-selected-recordings-history');
  if (deleteSelectedHistory) deleteSelectedHistory.addEventListener('click', () => deleteSelectedRecordings(false));
  const deleteSelectedFiles = document.getElementById('delete-selected-recordings-files');
  if (deleteSelectedFiles) deleteSelectedFiles.addEventListener('click', () => deleteSelectedRecordings(true));
  const recorderDefaultFolderMain = document.getElementById('recorder-default-folder-main');
  if (recorderDefaultFolderMain) recorderDefaultFolderMain.addEventListener('click', useDefaultRecordingsFolder);
  const openSourceMain = document.getElementById('open-source-picker-main');
  if (openSourceMain) openSourceMain.addEventListener('click', () => { state.recorder.statusText = 'Opening source picker…'; state.showSourceQuickPicker = true; render(); window.setTimeout(refreshCaptureSources, 80); });
  const openRecorderSettings = document.getElementById('open-recorder-settings');
  if (openRecorderSettings) openRecorderSettings.addEventListener('click', () => { state.recorder.statusText = 'Opening recorder settings…'; state.showRecorderSettings = true; render(); });
  const closeRecorderSettings = document.getElementById('close-recorder-settings');
  if (closeRecorderSettings) closeRecorderSettings.addEventListener('click', () => { state.showRecorderSettings = false; render(); });
  const recorderSettingsScrim = document.getElementById('recorder-settings-scrim');
  if (recorderSettingsScrim) recorderSettingsScrim.addEventListener('click', (event) => { if (event.target === recorderSettingsScrim) { state.showRecorderSettings = false; render(); } });
  document.querySelectorAll('[data-reveal-recording]').forEach((button) => button.addEventListener('click', () => api && api.revealPath(button.dataset.revealRecording)));
  document.querySelectorAll('[data-delete-recording]').forEach((button) => button.addEventListener('click', () => deleteRecording(button.dataset.deleteRecording, false)));
  document.querySelectorAll('[data-delete-recording-file]').forEach((button) => button.addEventListener('click', () => deleteRecording(button.dataset.deleteRecordingFile, true)));
  document.querySelectorAll('[data-unlink-recording]').forEach((button) => button.addEventListener('click', () => unlinkRecording(button.dataset.unlinkRecording)));
  document.querySelectorAll('[data-hide-player]').forEach((button) => button.addEventListener('click', () => hidePlayer(button.dataset.hidePlayer)));
  document.querySelectorAll('[data-toggle-recording-suggestions]').forEach((button) => button.addEventListener('click', () => {
    const id = button.dataset.toggleRecordingSuggestions || '';
    state.recordingSuggestionOpenId = state.recordingSuggestionOpenId === id ? '' : id;
    render();
  }));
  document.querySelectorAll('[data-recording-open-match]').forEach((button) => button.addEventListener('click', () => {
    const matchId = button.dataset.recordingOpenMatch || '';
    if (!matchId) return;
    state.selectedId = matchId;
    state.player.matchId = matchId;
    state.active = 'Matches';
    state.matchView = 'detail';
    renderKeepingReplay();
  }));
  document.querySelectorAll('[data-recording-apply-recording]').forEach((button) => button.addEventListener('click', async () => {
    const recordingId = button.dataset.recordingApplyRecording || '';
    const matchId = button.dataset.recordingApplyMatch || '';
    await applyRecordingSuggestedMatches(recordingId, [matchId]);
  }));
  document.querySelectorAll('[data-recording-attach-window]').forEach((button) => button.addEventListener('click', async () => {
    const recordingId = button.dataset.recordingAttachWindow || '';
    const recording = (state.recorder.recordings || []).find((item) => item && item.id === recordingId);
    await applyRecordingSuggestedMatches(recordingId, recordingInWindowMatchIds(recording));
  }));
  document.querySelectorAll('[data-recording-attach-selected]').forEach((button) => button.addEventListener('click', async () => {
    const recordingId = button.dataset.recordingAttachSelected || '';
    const ids = Array.from(document.querySelectorAll(`[data-recording-suggestion-select="${cssEscape(recordingId)}"]:checked`)).map((box) => box.value).filter(Boolean);
    await applyRecordingSuggestedMatches(recordingId, ids);
  }));
    }

    return { bindEvents };
  }

  window.LastCallAppEvents = { createAppEvents };
})();
