(function () {
  'use strict';

  function createReplayViewTools(deps = {}) {
    const state = deps.state || { player: {}, recorder: { recordings: [] } };
    const filePathToUrl = deps.filePathToUrl || (() => '');
    const isVideoSectionLink = deps.isVideoSectionLink || (() => false);
    const replayScopeBoundsForMatch = deps.replayScopeBoundsForMatch || (() => ({ mode: 'match', min: 0, max: 1 }));
    const videoSectionKindLabel = deps.videoSectionKindLabel || (() => 'VOD section');
    const vodScopeLabel = deps.vodScopeLabel || (() => 'Match start');
    const exportFolderLabel = deps.exportFolderLabel || (() => '');
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const formatElapsed = deps.formatElapsed || ((value) => String(value || 0));
    const pill = deps.pill || ((text) => `<span>${escapeHtml(text)}</span>`);
    const displayFileName = deps.displayFileName || ((value) => String(value || '').split(/[\/]/).pop() || 'Recording');
    const railFeedForMatch = deps.railFeedForMatch || (() => []);
    const matchResolvedResult = deps.matchResolvedResult || (() => 'Unscored');
    const resultToneForResult = deps.resultToneForResult || (() => 'amber');
    const matchTimestampLabel = deps.matchTimestampLabel || (() => 'Unknown time');
    const displayMatchType = deps.displayMatchType || (() => 'PvP');
    const coloredName = deps.coloredName || ((name) => escapeHtml(name || 'Unknown'));
    const renderDataSourcePills = deps.renderDataSourcePills || (() => '');
    const isBattlegroundMatch = deps.isBattlegroundMatch || (() => false);
    const shortCharacterName = deps.shortCharacterName || ((name) => String(name || '').split('-')[0]);
    const selectedMatch = deps.selectedMatch || (() => null);
    const renderKeepingReplay = deps.renderKeepingReplay || (() => {});
    const prettyNumber = deps.prettyNumber || ((value) => String(value || 0));
    const getRailCache = deps.getRailCache || (() => ({ rows: [], times: [] }));
    const railIndexForTime = deps.railIndexForTime || (() => 0);
    const setLastRailUiUpdateMs = deps.setLastRailUiUpdateMs || (() => {});
    const getLastRailAutoScrollAt = deps.getLastRailAutoScrollAt || (() => -999);
    const setLastRailAutoScrollAt = deps.setLastRailAutoScrollAt || (() => {});
    const setRailAutoScrollUntil = deps.setRailAutoScrollUntil || (() => {});
    let healthSyncRaf = null;

    const healthTimelineTools = (window.LastCallReplayHealthTimeline && typeof window.LastCallReplayHealthTimeline.createReplayHealthTimelineTools === 'function')
      ? window.LastCallReplayHealthTimeline.createReplayHealthTimelineTools({
        state,
        isBattlegroundMatch,
        selectedMatch,
        renderKeepingReplay,
        formatElapsed,
        shortCharacterName,
        escapeHtml
      })
      : null;
    if (!healthTimelineTools) throw new Error('LastCallReplayHealthTimeline module failed to load.');

    function renderSyncedReplay(match) {
      const recordings = state.recorder.recordings || [];
      const linkedRecordings = recordings.filter((item) => item && (item.matchId === match.id || (Array.isArray(item.linkedMatchIds) && item.linkedMatchIds.includes(match.id))));
      const matchPath = match.videoPath || '';
      const rememberedPath = state.player.matchId === match.id ? state.player.videoPath : '';
      const selectedPath = matchPath || (rememberedPath && linkedRecordings.some((item) => item.filePath === rememberedPath)
        ? rememberedPath
        : (linkedRecordings[0] && linkedRecordings[0].filePath) || '');
      const videoSrc = filePathToUrl(selectedPath);
      const rawClipStart = Number(match.videoClipStartSec);
      const rawClipEnd = Number(match.videoClipEndSec);
      const rawMatchStart = Number.isFinite(Number(match.videoMatchStartSec)) ? Number(match.videoMatchStartSec) : rawClipStart;
      const rawMatchEnd = Number.isFinite(Number(match.videoMatchEndSec)) ? Number(match.videoMatchEndSec) : rawClipEnd;
      const rawShuffleStart = Number.isFinite(Number(match.videoShuffleStartSec)) ? Number(match.videoShuffleStartSec) : NaN;
      const rawShuffleEnd = Number.isFinite(Number(match.videoShuffleEndSec)) ? Number(match.videoShuffleEndSec) : NaN;
      const mappedStart = Number.isFinite(rawShuffleStart) ? rawShuffleStart : (Number.isFinite(rawMatchStart) ? rawMatchStart : (Number.isFinite(rawClipStart) ? rawClipStart : 0));
      const mappedEnd = Number.isFinite(rawShuffleEnd) ? rawShuffleEnd : (Number.isFinite(rawMatchEnd) ? rawMatchEnd : (Number.isFinite(rawClipEnd) ? rawClipEnd : mappedStart + 1));
      const trimBoundStart = Math.max(0, Math.min(
        Number.isFinite(rawClipStart) ? rawClipStart : mappedStart,
        mappedStart
      ));
      const trimBoundEnd = Math.max(trimBoundStart + 1, Math.max(
        Number.isFinite(rawClipEnd) ? rawClipEnd : mappedEnd,
        mappedEnd
      ));
      const clipStart = Math.max(trimBoundStart, Math.min(trimBoundEnd - 0.25, Number.isFinite(rawClipStart) ? rawClipStart : trimBoundStart));
      const clipEnd = Math.max(clipStart + 0.25, Math.min(trimBoundEnd, Number.isFinite(rawClipEnd) ? rawClipEnd : trimBoundEnd));
      const hasVodClip = selectedPath && isVideoSectionLink(match) && Number.isFinite(clipStart) && Number.isFinite(clipEnd) && clipEnd > clipStart;
      const replayScope = replayScopeBoundsForMatch(match);
      const scopeStart = Number(replayScope.min || 0);
      const scopeEnd = Math.max(scopeStart + 0.5, Number(replayScope.max || scopeStart + 1));
      const scopeMode = replayScope.mode || 'match';
      const scopeCurrent = Math.max(scopeStart, Math.min(scopeEnd, Number(state.player.currentTime || scopeStart)));
      const scopeToggleHtml = videoSrc
        ? `<div class="vod-scope-toggle" role="group" aria-label="VOD playback scope">
            ${[['match', 'Match start'], ['room', 'Starting room'], ['full', 'Full VOD']].map(([mode, label]) => `<button class="vod-scope-option ${scopeMode === mode ? 'active' : ''}" data-vod-scope="${mode}">${label}</button>`).join('')}
          </div>`
        : '';
      const fullVodNote = scopeMode === 'full' && videoSrc ? '<div class="full-vod-note"><strong>Full VOD unlocked.</strong> Logs and meter are dimmed because they only belong to this selected match.</div>' : '';
      const sectionLabel = videoSectionKindLabel(match);
      const shuffleRoundCount = Number(match.soloShuffleRoundCount || 0) || 0;
      const shuffleRound = Number(match.soloShuffleRound || 0) || 0;
      const shuffleClipNote = shuffleRoundCount > 1 ? `<p class="caption shuffle-clip-note">Solo Shuffle detected: this trim window covers all ${shuffleRoundCount} rounds. This selected row is round ${shuffleRound || '?'} of ${shuffleRoundCount}.</p>` : '';
      const videoMatchStart = Number.isFinite(rawMatchStart) ? rawMatchStart : trimBoundStart;
      const videoMatchEnd = Number.isFinite(rawMatchEnd) ? rawMatchEnd : trimBoundEnd;
      const videoSyncAdjustment = Number(match.videoSyncAdjustmentSec || 0) || 0;
      const clipSliderMin = trimBoundStart;
      const clipSliderMax = trimBoundEnd;
      const exportFolder = exportFolderLabel();
      const exportStatus = state.player && state.player.exportStatus && state.player.exportStatus.matchId === match.id ? state.player.exportStatus : null;
      const exportStatusHtml = exportStatus
        ? `<div class="export-status-card ${exportStatus.ok ? 'ok' : 'bad'}"><strong>${exportStatus.ok ? 'Export ready' : 'Export failed'}</strong><span>${escapeHtml(exportStatus.message || '')}</span>${exportStatus.outputPath ? `<button class="btn tiny" id="reveal-last-export" data-reveal-path="${escapeHtml(exportStatus.outputPath)}">Show File</button>` : ''}</div>`
        : '';
      const exportPanel = hasVodClip && state.player.showExportPanel
        ? `<div class="vod-export-panel ${match.videoLinkMode === 'recording-session' ? 'recording-session-box' : ''}" id="vod-export-panel">
            <div class="vod-export-top">
              <div>
                <span class="pill violet">${escapeHtml(sectionLabel)} · ${escapeHtml(vodScopeLabel(scopeMode))}</span>
                <h3>${match.videoLinkMode === 'recording-session' ? 'Download from long recording' : 'Download this match VOD'}</h3>
                <p class="caption">Download follows the selected VOD scope above. Trim handles below still edit the saved match section.</p>
                ${shuffleClipNote}
              </div>
              <button class="btn small" id="jump-vod-clip-start">Jump to Scope Start</button>
            </div>
            <div class="export-folder-row">
              <div><p class="small-label">Save to</p><p class="value path-value">${escapeHtml(exportFolder)}</p></div>
              <div class="action-row"><button class="btn small violet" id="choose-export-folder">Choose Folder</button>${exportFolder ? `<button class="btn small" id="reveal-export-folder" data-reveal-path="${escapeHtml(exportFolder)}">Open Folder</button>` : ''}</div>
            </div>
            <div class="vod-export-controls">
              <div class="vod-export-meta"><span>Start</span><strong id="clip-start-display">${formatElapsed(clipStart)}</strong></div>
              <div class="vod-export-meta"><span>End</span><strong id="clip-end-display">${formatElapsed(clipEnd)}</strong></div>
              <div class="vod-export-meta"><span>Length</span><strong id="clip-length-display">${formatElapsed(Math.max(1, clipEnd - clipStart))}</strong></div>
              <label class="clip-audio-toggle"><input type="checkbox" id="export-clip-include-audio" checked /> <span>Include sound</span></label>
              <button class="btn emerald" id="export-vod-clip">Download VOD</button>
            </div>
            <div class="clip-range-editor" data-clip-editor data-clip-lock="match" data-clip-min="${Number(clipSliderMin).toFixed(2)}" data-clip-max="${Number(clipSliderMax).toFixed(2)}">
              <div class="clip-range-head"><span>Match trim handles</span><strong id="clip-range-readout">${formatElapsed(clipStart)} → ${formatElapsed(clipEnd)}</strong></div>
              <div class="clip-range-stack">
                <input id="match-video-clip-start-range" class="clip-range-input clip-start" type="range" min="${Number(clipSliderMin).toFixed(2)}" max="${Number(clipSliderMax).toFixed(2)}" step="0.1" value="${Number(clipStart).toFixed(2)}" aria-label="VOD start slider" />
                <input id="match-video-clip-end-range" class="clip-range-input clip-end" type="range" min="${Number(clipSliderMin).toFixed(2)}" max="${Number(clipSliderMax).toFixed(2)}" step="0.1" value="${Number(clipEnd).toFixed(2)}" aria-label="VOD end slider" />
              </div>
              <div class="clip-range-scale"><span id="clip-range-min-label">${formatElapsed(clipSliderMin)}</span><span id="clip-range-max-label">${formatElapsed(clipSliderMax)}</span></div>
            </div>
            <div class="vod-section-editor">
              <label><span>VOD start seconds</span><input id="match-video-clip-start" type="number" min="${Number(clipSliderMin).toFixed(2)}" max="${Number(clipSliderMax).toFixed(2)}" step="0.1" value="${Number(clipStart).toFixed(2)}" /><small class="trim-time-hint" id="clip-start-human">video time ${formatElapsed(clipStart)}</small></label>
              <label><span>VOD end seconds</span><input id="match-video-clip-end" type="number" min="${Number(clipSliderMin).toFixed(2)}" max="${Number(clipSliderMax).toFixed(2)}" step="0.1" value="${Number(clipEnd).toFixed(2)}" /><small class="trim-time-hint" id="clip-end-human">video time ${formatElapsed(clipEnd)}</small></label>
              <label><span>${shuffleRoundCount > 1 ? 'Round start' : 'Match start'}</span><input id="match-video-match-start" type="number" min="0" step="0.1" value="${Number(videoMatchStart).toFixed(2)}" /><small class="trim-time-hint">video time ${formatElapsed(videoMatchStart)}</small></label>
              <label><span>Sync adjust</span><input id="match-video-sync-adjust" type="number" step="0.1" value="${Number(videoSyncAdjustment).toFixed(2)}" /></label>
              <button class="btn small violet" id="save-match-video-section">Save Trim Changes</button>
            </div>
            ${exportStatusHtml}
          </div>`
        : '';
      const videoSyncPanel = videoSrc && state.player.showVideoSyncPanel
        ? `<div class="video-sync-panel">
            <div class="video-sync-panel-head"><div><p class="small-label">Video sync</p><h3>Linked video and timing tools</h3><p class="caption">Use this when the match needs a different recording or timing nudge. Export now has its own button beside the player.</p></div>${selectedPath ? pill('Video linked', 'emerald') : pill('No video linked', 'amber')}</div>
            <div class="video-sync-controls">
              <label class="filter-control video-select-control"><span>Linked recording</span><select id="video-select" ${linkedRecordings.length ? '' : 'disabled'}>
                <option value="">${selectedPath ? 'Choose linked video' : 'No linked video'}</option>
                ${selectedPath && !linkedRecordings.some((item) => item.filePath === selectedPath) ? `<option value="${escapeHtml(selectedPath)}" selected>${escapeHtml(selectedPath.split(/[\\/]/).pop() || 'Linked video')}</option>` : ''}
                ${linkedRecordings.map((item) => `<option value="${escapeHtml(item.filePath)}" ${item.filePath === selectedPath ? 'selected' : ''}>${escapeHtml(item.label || item.sourceName || displayFileName(item.filePath) || 'Recording')}</option>`).join('')}
              </select></label>
              <div class="action-row video-sync-actions">
                <button class="btn violet" id="link-video-file">${selectedPath ? 'Link Different Video' : 'Link Video'}</button>
                ${selectedPath ? '<button class="btn" id="unlink-selected-video">Unlink Video</button>' : ''}
    
              </div>
            </div>
          </div>`
        : '';
      const feed = railFeedForMatch(match);
      const hasCombatLog = Boolean(match.createdFromRealLog) || (match.dataSources || []).some((source) => /combat|log|tail/i.test(String(source || '')));
      const logSyncDisabled = state.selectedLogSyncBusy ? 'disabled' : '';
      const logSyncButton = (!hasCombatLog || !feed.length)
        ? `<button class="btn tiny violet" id="sync-logs-from-replay" ${logSyncDisabled}>${state.selectedLogSyncBusy ? 'Syncing…' : 'Sync Logs'}</button>`
        : `<button class="btn tiny" id="sync-logs-from-replay" ${logSyncDisabled}>${state.selectedLogSyncBusy ? 'Syncing…' : 'Re-sync Logs'}</button>`;
      const resolvedResult = matchResolvedResult(match);
      const resolvedTone = resultToneForResult(resolvedResult);
      const detailBits = [matchTimestampLabel(match), displayMatchType(match), match.duration, match.spec].filter(Boolean).join(' · ');
      return `
        <div class="card replay-card ${state.player.theaterMode ? 'theater' : ''} ${state.player.showRail ? '' : 'rail-hidden'} ${isBattlegroundMatch(match) ? 'bg-health-hidden' : ''}">
          <div class="card-title-row replay-match-title-row">
            <div class="replay-match-title">
              <p class="small-label">Replay</p>
              <h2>${escapeHtml(match.map || 'Unknown map')}</h2>
              <p class="caption">${detailBits ? escapeHtml(detailBits) : ''}${detailBits ? ' · ' : ''}${coloredName(match.alt || 'Unknown Player', match)}</p>
              <div class="tag-row replay-match-pills">${pill(resolvedResult, resolvedTone)}${renderDataSourcePills(match)}</div>
            </div>
            <div class="icon-bubble">🎞️</div>
          </div>
          <div class="replay-grid">
            <div class="replay-main-column">
              <div class="video-frame">
                ${videoSrc ? `<video id="replay-video" preload="auto" ${state.player.videoMuted ? 'muted' : ''} src="${escapeHtml(videoSrc)}"></video><div class="replay-video-loading active" id="replay-video-loading"><strong>Loading video…</strong><span>Preparing smooth playback before the first jump.</span></div>` : '<div class="empty video-empty">No video linked.</div>'}
              </div>
              ${videoSrc ? `<div class="replay-transport">
                <button class="btn small replay-play-btn" id="replay-play-toggle">Play</button>
                <span class="replay-seek-shell" id="replay-seek-shell"><input id="replay-seek-range" class="replay-seek-range" type="range" min="${Number(scopeStart).toFixed(2)}" max="${Number(scopeEnd).toFixed(2)}" step="0.1" value="${Number(scopeCurrent).toFixed(2)}" aria-label="Replay timeline" /></span>
                <span class="pill cyan replay-time-pill" id="video-clock">${formatElapsed(scopeCurrent)}</span>
                <button class="btn small replay-sound-btn replay-icon-btn ${state.player.videoMuted ? '' : 'emerald'}" id="replay-sound-toggle" title="${state.player.videoMuted ? 'Sound off' : 'Sound on'}" aria-label="${state.player.videoMuted ? 'Sound off' : 'Sound on'}">${state.player.videoMuted ? '🔇' : '🔊'}</button>
                <label class="replay-volume-control" title="Playback volume"><span>Vol</span><span class="replay-volume-slider-shell"><input id="replay-volume-range" type="range" min="0" max="1" step="0.01" value="${Number(state.player.videoMuted ? 0 : (state.player.videoVolume ?? 0)).toFixed(2)}" /></span></label>
                <button class="btn small replay-icon-btn replay-fullscreen-btn" id="replay-fullscreen-toggle" title="${state.player.theaterMode ? 'Exit full view' : 'Full view'}" aria-label="${state.player.theaterMode ? 'Exit full view' : 'Full view'}">${state.player.theaterMode ? '↙' : '⛶'}</button>
              </div>` : ''}
              <div class="action-row replay-controls">
                ${selectedPath ? '<span class="pill emerald replay-linked-pill">Video linked</span>' : '<button class="btn violet" id="link-video-file">Link Video</button>'}
                ${scopeToggleHtml}
                ${hasVodClip ? `<button class="btn emerald" id="toggle-export-panel">${state.player.showExportPanel ? 'Hide Download' : '↓ VOD'}</button>` : ''}
                ${videoSrc ? `<button class="btn subtle" id="toggle-video-sync-panel">${state.player.showVideoSyncPanel ? 'Hide Timing' : 'Timing Tools'}</button>` : ''}
                <button class="btn" id="replay-rail-toggle">${state.player.showRail ? 'Hide Rail' : 'Show Rail'}</button>
              </div>
              ${fullVodNote}
              ${exportPanel}
              ${videoSyncPanel}
              ${isBattlegroundMatch(match) ? '' : renderHealthTimeline(match)}
            </div>
            <div class="replay-rail-panel">
              <div class="feed-header">
                <div><p class="small-label">Log Data</p><h3>Synced actions</h3></div>
                <div class="feed-header-actions"><p class="caption">${feed.length.toLocaleString()} actions</p>${logSyncButton}</div>
              </div>
              <div class="rail-filters">
                ${['Important', 'Cooldowns', 'CC + Kicks', 'Damage + Healing', 'All'].map((item) => `<button class="rail-filter ${state.railFilter === item ? 'active' : ''}" data-rail-filter="${escapeHtml(item)}">${escapeHtml(item)}</button>`).join('')}
              </div>
              <div class="feed-tools"><button class="btn live-follow-toggle ${state.player.railLiveFollow ? 'violet active' : ''}" id="toggle-rail-follow">${state.player.railLiveFollow ? 'Live Follow On' : 'Live Follow Off'}</button><span class="caption">Shift + scroll the Log Data rail to scrub the video.</span></div>
              <div class="feed-wrap">
                <div class="now-line"><span>NOW</span><strong id="now-line-clock">${formatElapsed(state.player.currentTime)}</strong></div>
                <div class="combat-feed" id="combat-feed">
                  ${feed.map(renderFeedEvent).join('') || '<div class="empty">No actions found for this filter.</div>'}
                </div>
              </div>
            </div>
          </div>
        </div>
      `;
    }
    
    
    function healthTimelineModeForMatch(match) { return healthTimelineTools.healthTimelineModeForMatch(match); }
    function healthDeathsForMatch(match) { return healthTimelineTools.healthDeathsForMatch(match); }
    function nextDeathWindowForMatch(match, currentMatchTime = 0, preferredDeathTime = null) { return healthTimelineTools.nextDeathWindowForMatch(match, currentMatchTime, preferredDeathTime); }
    function pointsForHealthWindow(points = [], start = 0, end = 10) { return healthTimelineTools.pointsForHealthWindow(points, start, end); }
    function healthMarkerPriority(point) { return healthTimelineTools.healthMarkerPriority(point); }
    function clusterHealthMarkerPoints(points = [], spacingSec = 2.5) { return healthTimelineTools.clusterHealthMarkerPoints(points, spacingSec); }
    function healthWindowStats(points = []) { return healthTimelineTools.healthWindowStats(points); }
    function maybeRefreshDeathWindowHealth(currentMatchTime) { return healthTimelineTools.maybeRefreshDeathWindowHealth(currentMatchTime); }
    function renderHealthTimeline(match) { return healthTimelineTools.renderHealthTimeline(match); }
    function updateHealthTimelineCursor(current) { return healthTimelineTools.updateHealthTimelineCursor(current); }


    function stopReplayHealthSyncLoop() {
      if (healthSyncRaf) cancelAnimationFrame(healthSyncRaf);
      healthSyncRaf = null;
    }
    
    function replayVideoTime(video = null) {
      const source = video || document.getElementById('replay-video');
      const raw = source ? Number(source.currentTime || 0) : Number(state.player.currentTime || 0);
      return Number.isFinite(raw) ? Math.max(0, raw) : 0;
    }
    
    function replayMatchTimeFromVideoTime(videoTime) {
      const raw = Number(videoTime || 0) - (Number(state.player.syncOffsetSec) || 0);
      return Number.isFinite(raw) ? Math.max(0, raw) : 0;
    }
    
    function replayTransportBounds(match = selectedMatch(), video = null) {
      return replayScopeBoundsForMatch(match, video);
    }
    
    function updateReplayTransport(videoTime = null) {
      const video = document.getElementById('replay-video');
      const playButton = document.getElementById('replay-play-toggle');
      const seekRange = document.getElementById('replay-seek-range');
      const clock = document.getElementById('video-clock');
      const current = Number.isFinite(Number(videoTime)) ? Math.max(0, Number(videoTime)) : replayVideoTime(video);
      const { min, max } = replayTransportBounds(selectedMatch(), video);
      if (playButton) {
        const waitingForVideo = Boolean(video && video.readyState < 2 && !video.error);
        playButton.textContent = waitingForVideo ? 'Loading' : (video && !video.paused && !video.ended ? 'Pause' : 'Play');
        playButton.disabled = waitingForVideo;
      }
      if (seekRange) {
        seekRange.min = Number(min).toFixed(2);
        seekRange.max = Number(max).toFixed(2);
        seekRange.value = Number(Math.max(min, Math.min(max, current))).toFixed(2);
        const progress = max > min ? ((Math.max(min, Math.min(max, current)) - min) / (max - min)) * 100 : 0;
        const progressText = `${Math.max(0, Math.min(100, progress)).toFixed(2)}%`;
        seekRange.style.setProperty('--seek-progress', progressText);
        const shell = document.getElementById('replay-seek-shell') || seekRange.closest('.replay-seek-shell');
        if (shell) shell.style.setProperty('--seek-progress', progressText);
      }
      if (clock) clock.textContent = `${formatElapsed(current)} / ${formatElapsed(max)}`;
    }
    
    function updateReplayAudioControls(video = document.getElementById('replay-video')) {
      const soundButton = document.getElementById('replay-sound-toggle');
      const volumeRange = document.getElementById('replay-volume-range');
      const muted = Boolean(state.player.videoMuted || (video && video.muted));
      const rawVolume = muted ? 0 : Math.max(0, Math.min(1, Number(state.player.videoVolume ?? (video ? video.volume : 0)) || 0));
      const volume = rawVolume <= 0.005 ? 0 : rawVolume;
      if (soundButton) {
        const soundIsOff = muted || volume <= 0;
        soundButton.textContent = soundIsOff ? '🔇' : '🔊';
        soundButton.title = soundIsOff ? 'Sound off' : 'Sound on';
        soundButton.setAttribute('aria-label', soundIsOff ? 'Sound off' : 'Sound on');
        soundButton.classList.toggle('emerald', !soundIsOff);
      }
      if (volumeRange) {
        const value = muted ? 0 : volume;
        const progressText = `${Math.round(value * 100)}%`;
        volumeRange.value = Number(value).toFixed(2);
        volumeRange.style.setProperty('--volume-progress', progressText);
        const shell = volumeRange.closest('.replay-volume-slider-shell');
        if (shell) shell.style.setProperty('--volume-progress', progressText);
      }
    }
    
    function updateReplayClockAndHealth(videoTime = null) {
      const currentVideoTime = Number.isFinite(Number(videoTime)) ? Math.max(0, Number(videoTime)) : replayVideoTime();
      const currentMatchTime = replayMatchTimeFromVideoTime(currentVideoTime);
      const nowClock = document.getElementById('now-line-clock');
      if (nowClock) nowClock.textContent = formatElapsed(currentMatchTime);
      updateReplayTransport(currentVideoTime);
      updateHealthTimelineCursor(currentMatchTime);
      return currentMatchTime;
    }
    
    function startReplayHealthSyncLoop() {
      if (healthSyncRaf) return;
      const tick = () => {
        healthSyncRaf = null;
        const video = document.getElementById('replay-video');
        if (!video) return;
        state.player.currentTime = replayVideoTime(video);
        updateReplayClockAndHealth(state.player.currentTime);
        if (!video.paused && !video.ended) {
          healthSyncRaf = requestAnimationFrame(tick);
        }
      };
      healthSyncRaf = requestAnimationFrame(tick);
    }
    
    function renderFeedEvent(ev) {
      const count = Number(ev.comboCount || 1);
      const total = Number(ev.totalAmount || ev.amount || 0);
      const amount = total ? prettyNumber(total) : '';
      const countText = count > 1 ? ` ×${count}` : '';
      const critCount = Number(ev.critCount || 0);
      const critText = critCount > 0 ? ` ${critCount > 1 ? `${critCount}x ` : ''}CRIT` : '';
      const targets = ev.targets && ev.targets.length ? ev.targets : [ev.target || 'Unknown'];
      const targetSummary = count > 1 ? `${targets.length} target${targets.length === 1 ? '' : 's'}` : (ev.target || 'Unknown');
      const amountClass = critCount > 0 ? 'feed-amount crit' : 'feed-amount';
      const detailTitle = (ev.groupedEvents || [ev]).map((item) => `${item.time || ev.time} ${item.actor || 'Unknown'} → ${item.target || 'Unknown'} ${item.ability || item.event || 'Event'} ${item.amount ? prettyNumber(item.amount) : ''}${item.isCritical ? ' CRIT' : ''}`).join('\\n');
      return `
        <button
          class="feed-event ${escapeHtml(ev.category || 'other')} ${count > 1 ? 'grouped' : ''}"
          data-seek-time="${Number(ev.relativeSec || 0)}"
          title="${escapeHtml(detailTitle)}"
        >
          <span class="feed-time"><strong>${escapeHtml(ev.time || '0:00')}</strong><small class="feed-delta"></small></span>
          <span class="feed-main">
            <span class="feed-title-line"><strong>${escapeHtml(ev.ability || ev.event || 'Event')}${escapeHtml(countText)}</strong>${amount ? `<span class="${amountClass}"><b>${escapeHtml(amount)}</b>${critText ? `<small>${escapeHtml(critText)}</small>` : ''}</span>` : ''}</span>
            <em>${coloredName(ev.actor || 'Unknown')} → ${count > 1 ? escapeHtml(targetSummary) : coloredName(targetSummary)}</em>
          </span>
        </button>
      `;
    }
    
    function updateVideoEventRail(force = false) {
      const video = document.getElementById('replay-video');
      const feedBox = document.getElementById('combat-feed');
      const currentVideoTime = video ? video.currentTime : state.player.currentTime;
      const current = updateReplayClockAndHealth(currentVideoTime);
      setLastRailUiUpdateMs(performance.now());
    
      if (!feedBox) return;
      const cache = getRailCache(feedBox);
      const rows = cache.rows || [];
      const times = cache.times || [];
      if (!rows.length) return;
    
      const anchorIndex = Math.max(0, railIndexForTime(times, current));
      const startIndex = Math.max(0, anchorIndex - 8);
      const endIndex = Math.min(rows.length - 1, anchorIndex + 18);
      const activeNow = new Set();
      for (let i = startIndex; i <= endIndex; i += 1) activeNow.add(i);
      activeNow.add(anchorIndex);
    
      const previouslyActive = cache.activeIndices || new Set();
      const toTouch = new Set([...previouslyActive, ...activeNow]);
      for (const index of toTouch) {
        const row = rows[index];
        if (!row) continue;
        const time = Number(times[index] || 0);
        const isLive = Math.abs(time - current) <= 0.35;
        const isIncoming = time > current && time <= current + 3;
        const isWindow = isLive || isIncoming || (time >= Math.max(0, current - 1.5) && time <= current + 3);
        row.classList.toggle('past', time < current - 0.35 && activeNow.has(index));
        row.classList.toggle('live-now', isLive);
        row.classList.toggle('incoming', isIncoming);
        row.classList.toggle('in-window', isWindow);
        row.classList.toggle('now-anchor', index === anchorIndex);
        const delta = row.querySelector('.feed-delta');
        if (delta && activeNow.has(index)) {
          if (isLive) delta.textContent = 'NOW';
          else if (time > current) delta.textContent = `in ${Math.max(0, time - current).toFixed(1)}s`;
          else delta.textContent = `${Math.max(0, current - time).toFixed(1)}s ago`;
        } else if (delta && !activeNow.has(index)) {
          delta.textContent = '';
        }
      }
      cache.activeIndices = activeNow;
    
      const anchor = rows[anchorIndex] || rows[0] || null;
      const liveToggle = document.getElementById('toggle-rail-follow');
      if (liveToggle) {
        liveToggle.classList.toggle('active', Boolean(state.player.railLiveFollow));
        liveToggle.textContent = state.player.railLiveFollow ? 'Live Follow On' : 'Live Follow Off';
      }
    
      if (anchor && state.player.railLiveFollow && Math.abs(current - getLastRailAutoScrollAt()) > 0.7) {
        const top = anchor.offsetTop - feedBox.offsetTop - 44;
        setRailAutoScrollUntil(Date.now() + 450);
        feedBox.scrollTo({ top: Math.max(0, top), behavior: 'auto' });
        setLastRailAutoScrollAt(current);
      }
    }
    
    function syncVideoToRailPosition(feedBox) {
      const video = document.getElementById('replay-video');
      if (!feedBox || !video) return;
      const rows = Array.from(feedBox.querySelectorAll('.feed-event[data-seek-time]'));
      if (!rows.length) return;
      const targetTop = feedBox.scrollTop + 44;
      let best = rows[0];
      let bestDistance = Infinity;
      for (const row of rows) {
        const distance = Math.abs((row.offsetTop - feedBox.offsetTop) - targetTop);
        if (distance < bestDistance) { best = row; bestDistance = distance; }
      }
      const seekTime = Number(best.dataset.seekTime || 0) + (Number(state.player.syncOffsetSec) || 0);
      const wasPlaying = !video.paused && !video.ended;
      try { video.currentTime = Math.max(0, seekTime); } catch (_) {}
      if (!wasPlaying) video.pause();
      state.player.currentTime = video.currentTime;
      updateVideoEventRail();
    }
    


    return {
      renderSyncedReplay,
      healthTimelineModeForMatch,
      healthDeathsForMatch,
      nextDeathWindowForMatch,
      pointsForHealthWindow,
      healthMarkerPriority,
      clusterHealthMarkerPoints,
      healthWindowStats,
      maybeRefreshDeathWindowHealth,
      renderHealthTimeline,
      stopReplayHealthSyncLoop,
      replayVideoTime,
      replayMatchTimeFromVideoTime,
      replayTransportBounds,
      updateReplayTransport,
      updateReplayAudioControls,
      updateReplayClockAndHealth,
      startReplayHealthSyncLoop,
      updateHealthTimelineCursor,
      renderFeedEvent,
      updateVideoEventRail,
      syncVideoToRailPosition
    };
  }

  window.LastCallReplayView = { createReplayViewTools };
})();
