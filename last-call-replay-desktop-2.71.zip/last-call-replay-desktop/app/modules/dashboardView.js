(function () {
  'use strict';

  function createDashboardViewTools(deps = {}) {
    const state = deps.state || {};
    const buildCharacterProfiles = deps.buildCharacterProfiles || (() => []);
    const characterPrettyName = deps.characterPrettyName || ((key) => String(key || 'Unknown'));
    const visibleLibraryMatch = deps.visibleLibraryMatch || (() => true);
    const matchCharacterKey = deps.matchCharacterKey || (() => '');
    const matchTypeMatchesFilter = deps.matchTypeMatchesFilter || (() => true);
    const matchResolvedResult = deps.matchResolvedResult || (() => 'Unscored');
    const effectiveMatchType = deps.effectiveMatchType || ((match) => match && (match.matchType || match.bracket || 'PvP Match') || 'PvP Match');
    const escapeHtml = deps.escapeHtml || ((value) => String(value ?? ''));
    const recorderSetupSummary = deps.recorderSetupSummary || (() => ({}));
    const formatElapsed = deps.formatElapsed || ((value) => String(value || '0:00'));
    const dashboardAddonStatusSummary = deps.dashboardAddonStatusSummary || (() => ({ install: {} }));
    const renderAddonInstallActions = deps.renderAddonInstallActions || (() => '');
    const latestCombatLogImport = deps.latestCombatLogImport || (() => null);
    const displayPathTail = deps.displayPathTail || ((value) => String(value || ''));
    const formatSyncDateTime = deps.formatSyncDateTime || ((value) => String(value || ''));
    const enemyIdentityKey = deps.enemyIdentityKey || ((value) => String(value || '').toLowerCase().trim());
    const isPendingScoreboardSnapshot = deps.isPendingScoreboardSnapshot || (() => false);
    const ownNameSetForMatch = deps.ownNameSetForMatch || (() => new Set());
    const matchSortTime = deps.matchSortTime || ((match) => Number((match && (match.startedAtMs || match.endedAtMs)) || 0));
    const classMetaAcrossMatches = deps.classMetaAcrossMatches || (() => ({}));
    const matchTimestampLabel = deps.matchTimestampLabel || (() => '');
    const displayMatchType = deps.displayMatchType || ((match) => match && (match.matchType || match.bracket || 'PvP Match') || 'PvP Match');
    const displayMatchTypeLabel = deps.displayMatchTypeLabel || ((value) => value || 'PvP Match');
    const shortCharacterName = deps.shortCharacterName || ((value) => String(value || '').split('-')[0] || 'Unknown');
    const coloredShortName = deps.coloredShortName || ((name) => escapeHtml(shortCharacterName(name)));
    const fullRosterTitle = deps.fullRosterTitle || ((names = []) => names.filter(Boolean).join(', '));
    const matchVideoPath = deps.matchVideoPath || (() => '');
    const isFavoriteMatch = deps.isFavoriteMatch || (() => false);
    const isSoloShuffleLobbyUiMatch = deps.isSoloShuffleLobbyUiMatch || (() => false);
    const renderSoloShuffleLobbyPlayers = deps.renderSoloShuffleLobbyPlayers || (() => '');
    const renderSoloShuffleInlineSummary = deps.renderSoloShuffleInlineSummary || (() => '');
    const matchClock = deps.matchClock || (() => '');
    const matchDay = deps.matchDay || (() => '');
    const pill = deps.pill || ((text) => `<span class="pill">${escapeHtml(text)}</span>`);
    const matchTeamSizePill = deps.matchTeamSizePill || (() => '');
    const renderNoDataBox = deps.renderNoDataBox || (() => '<div class="empty">No PvP matches yet.</div>');
    const computeMostSeenEnemy = deps.computeMostSeenEnemy || (() => null);
    const uniqueValues = deps.uniqueValues || ((items = []) => Array.from(new Set(items.filter(Boolean))));

    function dashboardCharacterOptions() {
      const options = new Map();
      for (const profile of buildCharacterProfiles()) options.set(profile.key, characterPrettyName(profile.key));
      return Array.from(options.entries()).sort((a, b) => a[1].localeCompare(b[1]));
    }

    function dashboardScopedMatches() {
      const baseMatches = (state.matches || []).filter(visibleLibraryMatch);
      if (!state.dashboardCharacterKey || state.dashboardCharacterKey === 'All') return baseMatches.slice();
      return baseMatches.filter((match) => matchCharacterKey(match) === state.dashboardCharacterKey);
    }

    function dashboardHistoryMatches() {
      return dashboardScopedMatches().filter((match) => {
        const typeOkay = matchTypeMatchesFilter(match, state.dashboardHistoryTypeFilter);
        const result = matchResolvedResult(match);
        const resultOkay = state.dashboardHistoryResultFilter === 'All' || result === state.dashboardHistoryResultFilter;
        return typeOkay && resultOkay;
      });
    }

    function knownResultsFrom(matches) {
      return (matches || []).filter((m) => ['Win', 'Loss'].includes(matchResolvedResult(m)));
    }

    function winRateBreakdownHtml(matches = dashboardScopedMatches()) {
      const groups = new Map();
      for (const match of knownResultsFrom(matches)) {
        const type = effectiveMatchType(match);
        const current = groups.get(type) || { wins: 0, losses: 0, total: 0 };
        current.total += 1;
        if (matchResolvedResult(match) === 'Win') current.wins += 1;
        if (matchResolvedResult(match) === 'Loss') current.losses += 1;
        groups.set(type, current);
      }
      if (!groups.size) return '<div class="mini-row"><span>No scored games yet</span><b>0W / 0L</b></div>';
      return Array.from(groups.entries())
        .sort((a, b) => b[1].total - a[1].total)
        .map(([type, item]) => `<div class="mini-row"><span>${escapeHtml(type)}</span><b>${Math.round((item.wins / item.total) * 100)}% · ${item.wins}W / ${item.losses}L</b></div>`)
        .join('');
    }

    function dashboardSelectedCharacterLabel() {
      if (!state.dashboardCharacterKey || state.dashboardCharacterKey === 'All') return 'All Characters';
      return characterPrettyName(state.dashboardCharacterKey);
    }

    function renderDashboardScopeInline(matches) {
      const options = dashboardCharacterOptions();
      return `<section class="dashboard-scope-inline"><p class="small-label">Viewed Character</p><div class="dashboard-scope-row"><strong>${escapeHtml(dashboardSelectedCharacterLabel())}</strong><span>${matches.length} match${matches.length === 1 ? '' : 'es'}</span></div><select id="dashboard-character-select" class="compact-select"><option value="All" ${state.dashboardCharacterKey === 'All' ? 'selected' : ''}>All Characters</option>${options.map(([key, label]) => `<option value="${escapeHtml(key)}" ${state.dashboardCharacterKey === key ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select></section>`;
    }

    function renderWinRateInline(matches) {
      const results = knownResultsFrom(matches);
      const wins = results.filter((m) => matchResolvedResult(m) === 'Win').length;
      const losses = results.filter((m) => matchResolvedResult(m) === 'Loss').length;
      const winRate = results.length ? `${Math.round((wins / results.length) * 100)}%` : 'Unknown';
      return `<section class="dashboard-win-inline winrate-card"><p class="small-label">Win Rate</p><div class="dashboard-win-row"><strong>${escapeHtml(winRate)}</strong><span>${wins}W / ${losses}L</span></div><div class="hover-panel"><p class="small-label">By Match Type</p>${winRateBreakdownHtml(matches)}</div></section>`;
    }

    function dashboardRecorderSetupButton(setup) {
      if (setup.isRecording) return `<button class="btn small rose stop-recording-btn" id="dashboard-stop-recording">Stop</button>`;
      if (setup.ready) {
        return `<button class="btn small dashboard-recorder-source-btn" id="dashboard-recorder-source">Change Source</button><button class="btn small primary start-recording-btn" id="dashboard-start-recording">Start Recording</button>`;
      }
      if (!setup.hasFolder) return `<button class="btn small primary" id="dashboard-recorder-setup-hint">Choose Recording Folder</button>`;
      if (setup.approvalNeeded && setup.hasSource) return `<button class="btn small primary" id="dashboard-approve-source">Approve Source</button>`;
      if (setup.savedSourceMissing) return `<button class="btn small primary dashboard-recorder-source-btn" id="dashboard-recorder-source">Choose New Source</button>`;
      return `<button class="btn small primary dashboard-recorder-source-btn" id="dashboard-recorder-source">Pick Source</button>`;
    }

    function renderDashboardRecorderCompact() {
      const rec = state.recorder || {};
      const setup = recorderSetupSummary();
      const statusTitle = setup.isRecording ? formatElapsed(rec.elapsed || 0) : setup.title;
      const statusText = setup.isRecording ? 'Recording locally' : setup.hint;
      const sourceLine = setup.hasSource ? `Source: ${setup.sourceText}` : 'No source selected yet';
      return `<section class="dashboard-recorder-inline dashboard-recorder-focus ${setup.isRecording ? 'recording' : setup.ready ? 'ready' : 'needs-setup'}"><div><p class="small-label">Quick Recording</p><div class="dashboard-record-row"><strong>${escapeHtml(statusTitle)}</strong><span>${escapeHtml(statusText)}</span></div><p class="caption dashboard-source-caption" title="${escapeHtml(setup.sourceText)}">${escapeHtml(sourceLine)}</p></div><div class="dashboard-recorder-actions compact-actions">${dashboardRecorderSetupButton(setup)}</div></section>`;
    }

    function renderDashboardAddonCompact() {
      const addon = dashboardAddonStatusSummary();
      const install = addon.install || {};
      const installLabel = addon.installed ? (install.needsUpdate ? 'Update Ready' : 'Installed') : (install.canInstall ? 'Install Addon' : (!install.wowRoot ? 'Needs WoW Path' : 'Needs Package'));
      return `<section class="dashboard-addon-inline"><p class="small-label">PvPHelper bridge</p><div class="dashboard-addon-row"><strong>${escapeHtml(addon.installed ? 'Addon Installed' : 'Addon Needed')}</strong><span class="utility-pill ${addon.installed ? (install.needsUpdate ? 'warn' : 'good') : 'warn'}">${escapeHtml(installLabel)}</span></div><p class="caption">${escapeHtml(addon.versionText)}</p><p class="caption path-value"${addon.mappingTitle}>Mapping: ${escapeHtml(addon.mappingText)}</p><div class="dashboard-addon-counts"><span>${addon.scoreboardCount} scoreboards</span><span>${addon.linkedCount} linked</span><span>${addon.pendingCount} pending</span></div>${renderAddonInstallActions(addon, 'dashboard')}</section>`;
    }


    function renderDashboardLogCompact() {
      const connectedPath = state.settings.logFilePath || state.watchPath || '';
      const connectedFolder = state.settings.logFolderPath || (connectedPath ? connectedPath.replace(/[\/][^\/]*$/, '') : '');
      const latestLog = latestCombatLogImport();
      const label = connectedPath ? 'Logs Connected' : 'Logs Not Connected';
      const detail = connectedFolder ? displayPathTail(connectedFolder, 2) : 'Choose WoW Logs folder in Settings';
      const title = connectedFolder ? ` title="${escapeHtml(connectedFolder)}"` : '';
      return `<section class="dashboard-log-inline"><p class="small-label">Combat log status</p><div class="dashboard-addon-row"><strong>${escapeHtml(label)}</strong><span class="utility-pill ${connectedPath ? 'good' : 'warn'}">${connectedPath ? 'Active' : 'Setup'}</span></div><p class="caption path-value"${title}>${escapeHtml(detail)}</p><p class="caption">${escapeHtml(latestLog ? `Last import ${formatSyncDateTime(latestLog.importedAt)}` : 'No combat log imports yet')}</p></section>`;
    }

    function renderDashboardHero(matches) {
      return `<div class="card dashboard-hero-card dashboard-recorder-only">${renderDashboardRecorderCompact()}</div>`;
    }

    function dashboardEnemySummary(name, matches = state.matches) {
      const targetKey = enemyIdentityKey(name);
      const related = (matches || []).filter((match) => {
        if (!match || isPendingScoreboardSnapshot(match)) return false;
        const ownNames = ownNameSetForMatch(match);
        const ownKeys = new Set(Array.from(ownNames).map(enemyIdentityKey));
        const enemies = Array.isArray(match.enemies) ? match.enemies : [];
        return enemies.some((enemy) => enemyIdentityKey(enemy) === targetKey) && !ownNames.has(name) && !ownKeys.has(targetKey);
      });
      const known = related.filter((match) => ['Win', 'Loss'].includes(matchResolvedResult(match)));
      const wins = known.filter((match) => matchResolvedResult(match) === 'Win').length;
      const losses = known.filter((match) => matchResolvedResult(match) === 'Loss').length;
      const latest = related.slice().sort((a, b) => matchSortTime(b) - matchSortTime(a))[0] || null;
      const topValue = (getter) => {
        const counts = new Map();
        for (const match of related) {
          const value = getter(match);
          if (!value) continue;
          counts.set(value, (counts.get(value) || 0) + 1);
        }
        return Array.from(counts.entries()).sort((a, b) => b[1] - a[1])[0] || null;
      };
      const topMode = topValue((match) => effectiveMatchType(match));
      const topMap = topValue((match) => match.map || 'Unknown map');
      const meta = classMetaAcrossMatches(name);
      const classTitle = meta && meta.className ? `${meta.specName || ''} ${meta.className}`.trim() : '';
      const lastLine = latest ? `${matchTimestampLabel(latest)} · ${displayMatchType(latest)} · ${latest.map || 'Unknown map'}` : 'No recent meeting found';
      return {
        related,
        count: related.length,
        wins,
        losses,
        record: known.length ? `${wins}W / ${losses}L` : 'Unknown',
        topMode,
        topMap,
        classTitle,
        lastLine
      };
    }

    function renderMostSeenEnemyCard(mostSeen, matches = state.matches) {
      if (!mostSeen) {
        return `<div class="card dashboard-enemy-card empty-enemy-card"><div class="enemy-card-top"><div><p class="small-label">Most Seen Enemy</p><h3>None yet</h3><p class="caption">Import matches with enemy rosters and this will show record, class, last seen, and common map.</p></div><div class="icon">👤</div></div></div>`;
      }
      const name = mostSeen[0];
      const shortName = shortCharacterName(name);
      const summary = dashboardEnemySummary(name, matches);
      const meta = classMetaAcrossMatches(name);
      const color = meta && meta.classColor ? meta.classColor : '';
      const classTitle = summary.classTitle || 'Class unknown';
      const topModeLabel = summary.topMode ? `${displayMatchTypeLabel(summary.topMode[0])} · ${summary.topMode[1]}x` : 'Mode unknown';
      const topMapLabel = summary.topMap ? `${summary.topMap[0]} · ${summary.topMap[1]}x` : 'Map unknown';
      const title = [name, classTitle, `${summary.count || mostSeen[1]} meetings`].filter(Boolean).join(' · ');
      return `<button class="card dashboard-enemy-card clickable most-seen-card" data-most-seen-enemy="${escapeHtml(name)}" title="${escapeHtml(title)}"><div class="enemy-card-top"><div><p class="small-label">Most Seen Enemy</p><p class="big-value enemy-name-value" ${color ? `style="color:${escapeHtml(color)}"` : ''}>${escapeHtml(shortName)}</p><p class="caption">${escapeHtml(classTitle)} · click for player card</p></div><div class="icon">👤</div></div><div class="enemy-info-grid"><span><b>${summary.count || mostSeen[1]}</b><small>Seen</small></span><span><b>${escapeHtml(summary.record)}</b><small>Record vs them</small></span><span><b>${escapeHtml(topModeLabel)}</b><small>Most common mode</small></span><span><b>${escapeHtml(topMapLabel)}</b><small>Most common map</small></span></div><p class="caption enemy-last-seen">Last seen: ${escapeHtml(summary.lastLine)}</p></button>`;
    }

    function renderDashboardTeamCompact(label, names, match, side) {
      const list = (names || []).filter(Boolean);
      const shown = list.slice(0, 3).map((name) => coloredShortName(name, match)).join('');
      const more = list.length > 3 ? `<span class="team-more">+${list.length - 3}</span>` : '';
      return `<div class="dashboard-team-compact ${escapeHtml(side || '')}" title="${escapeHtml(fullRosterTitle(list, match))}"><span>${escapeHtml(label)}</span><div>${shown || '<em>Unknown</em>'}${more}</div></div>`;
    }

    function resultCardClass(match) {
      const result = matchResolvedResult(match);
      if (result === 'Win') return 'result-win';
      if (result === 'Loss') return 'result-loss';
      return 'result-unknown';
    }

    function renderDashboardVideoThumb(match) {
      const videoPath = matchVideoPath(match);
      const favoriteClass = isFavoriteMatch(match) ? ' favorite-video-thumb' : '';
      const favoriteTitle = isFavoriteMatch(match) ? ' title="Favorited match"' : '';
      return `<div class="match-video-thumb dashboard-video-thumb ${videoPath ? 'has-video' : 'no-video'}${favoriteClass}"${favoriteTitle}>${videoPath ? '<span>▶</span><small>Video</small>' : '<span>◇</span><small>No video</small>'}</div>`;
    }

    function renderDashboardMatchCard(match) {
      const videoPath = matchVideoPath(match);
      const isLobby = isSoloShuffleLobbyUiMatch(match);
      const friendlyNames = Array.isArray(match.myComp) && match.myComp.length ? match.myComp : (match.alt ? [match.alt] : []);
      const enemyNames = Array.isArray(match.enemyComp) && match.enemyComp.length ? match.enemyComp : [];
      const stamp = matchTimestampLabel(match);
      const teamMarkup = isLobby
        ? `${renderSoloShuffleLobbyPlayers(match)}${renderSoloShuffleInlineSummary(match)}`
        : `${renderDashboardTeamCompact('Your team', friendlyNames, match, 'friendly')}<div class="match-vs-pill">vs</div>${renderDashboardTeamCompact('Enemy team', enemyNames, match, 'enemy')}`;
      return `<button class="dashboard-match-card ${resultCardClass(match)} ${isLobby ? 'solo-shuffle-lobby-card' : ''}" data-match="${escapeHtml(match.id)}">${renderDashboardVideoThumb(match)}<div class="dash-match-core"><div class="dash-match-time"><strong>${escapeHtml(matchClock(match) || '')}</strong><span>${escapeHtml(matchDay(match))}</span></div><div class="dash-match-meta"><div class="tag-row">${pill(displayMatchType(match), 'cyan')}${isLobby ? '' : matchTeamSizePill(match)}</div><h3>${escapeHtml(match.map || 'Unknown map')}</h3><small>${escapeHtml(match.duration || '')}${stamp ? ` · ${escapeHtml(stamp)}` : ''}</small></div></div><div class="dash-match-teams ${isLobby ? 'solo-lobby-dashboard-area' : ''}">${teamMarkup}</div></button>`;
    }

    function renderDashboardCharacterCard(matches) {
      const options = dashboardCharacterOptions();
      return `<div class="card stat-card dashboard-character-card"><div class="stat-card-main"><p class="small-label">Viewed Character</p><p class="big-value character-scope-title">${escapeHtml(dashboardSelectedCharacterLabel())}</p><p class="caption">${matches.length} match${matches.length === 1 ? '' : 'es'} in this view</p><select id="dashboard-character-select" class="compact-select"><option value="All" ${state.dashboardCharacterKey === 'All' ? 'selected' : ''}>All Characters</option>${options.map(([key, label]) => `<option value="${escapeHtml(key)}" ${state.dashboardCharacterKey === key ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select></div><div class="icon">🧙</div></div>`;
    }

    function renderWinRateCard(matches) {
      const results = knownResultsFrom(matches);
      const wins = results.filter((m) => matchResolvedResult(m) === 'Win').length;
      const losses = results.filter((m) => matchResolvedResult(m) === 'Loss').length;
      const winRate = results.length ? `${Math.round((wins / results.length) * 100)}%` : 'Unknown';
      return `<div class="card stat-card winrate-card"><div><p class="small-label">Win Rate</p><p class="big-value">${escapeHtml(winRate)}</p><p class="caption">${wins}W / ${losses}L for ${escapeHtml(dashboardSelectedCharacterLabel())}</p></div><div class="icon">🏆</div><div class="hover-panel"><p class="small-label">By Match Type</p>${winRateBreakdownHtml(matches)}</div></div>`;
    }

    function renderDashboardRecorderCard() {
      const rec = state.recorder || {};
      const setup = recorderSetupSummary();
      return `<div class="card stat-card dashboard-recorder-card ${setup.isRecording ? 'recording' : ''}"><div class="stat-card-main"><p class="small-label">Quick Recording</p><p class="big-value">${setup.isRecording ? formatElapsed(rec.elapsed || 0) : escapeHtml(setup.title)}</p><p class="caption" title="${escapeHtml(setup.sourceText)}">${escapeHtml(setup.hint)}</p><div class="dashboard-recorder-actions">${dashboardRecorderSetupButton(setup)}</div></div><div class="icon">🎥</div></div>`;
    }

    function dashboardMatchTypeOptions(matches) {
      return uniqueValues((matches || []).map(effectiveMatchType));
    }

    function dashboardFunStats(matches) {
      const results = knownResultsFrom(matches);
      const wins = results.filter((m) => matchResolvedResult(m) === 'Win');
      const losses = results.filter((m) => matchResolvedResult(m) === 'Loss');
      const avg = matches.length ? formatElapsed(matches.reduce((sum, m) => sum + (Number(m.durationSec) || 0), 0) / matches.length) : '0:00';
      const fastestWin = wins.length ? wins.slice().sort((a, b) => (Number(a.durationSec) || 999999) - (Number(b.durationSec) || 999999))[0] : null;
      const longest = matches.length ? matches.slice().sort((a, b) => (Number(b.durationSec) || 0) - (Number(a.durationSec) || 0))[0] : null;
      const closeCalls = matches.reduce((sum, match) => sum + (((match.healthTimeline || {}).players || []).some((p) => Number(p.lowestPct) > 0 && Number(p.lowestPct) <= 20) ? 1 : 0), 0);
      return [
        { label: 'Avg Game', value: avg, caption: `${matches.length} viewed` },
        { label: 'Fastest Win', value: fastestWin ? formatElapsed(fastestWin.durationSec || 0) : 'n/a', caption: fastestWin ? (fastestWin.map || 'Match') : 'No wins yet' },
        { label: 'Longest Scrap', value: longest ? formatElapsed(longest.durationSec || 0) : 'n/a', caption: longest ? (longest.map || 'Match') : 'No games yet' },
        { label: 'Near Deaths', value: String(closeCalls), caption: 'Games with a player under 20% HP' }
      ];
    }

    function renderDashboardHistoryFilters(scopeMatches) {
      const types = dashboardMatchTypeOptions(scopeMatches);
      const resultOptions = ['All', 'Win', 'Loss', 'Unscored'];
      const options = dashboardCharacterOptions();
      return `<div class="dashboard-history-tools"><div class="dashboard-history-filters dashboard-history-filters-with-character"><label class="filter-control dashboard-character-filter"><span>Character</span><select id="dashboard-character-select"><option value="All" ${state.dashboardCharacterKey === 'All' ? 'selected' : ''}>All Characters</option>${options.map(([key, label]) => `<option value="${escapeHtml(key)}" ${state.dashboardCharacterKey === key ? 'selected' : ''}>${escapeHtml(label)}</option>`).join('')}</select></label><label class="filter-control"><span>Match Type</span><select id="dashboard-history-type-filter"><option value="All">All</option>${types.map((type) => `<option value="${escapeHtml(type)}" ${state.dashboardHistoryTypeFilter === type ? 'selected' : ''}>${escapeHtml(displayMatchTypeLabel(type))}</option>`).join('')}</select></label><label class="filter-control"><span>Result</span><select id="dashboard-history-result-filter">${resultOptions.map((item) => `<option value="${escapeHtml(item)}" ${state.dashboardHistoryResultFilter === item ? 'selected' : ''}>${escapeHtml(item)}</option>`).join('')}</select></label></div></div>`;
    }

    function renderDashboard() {
      const scopeMatches = dashboardScopedMatches();
      const mostSeen = computeMostSeenEnemy(scopeMatches);
      const shown = dashboardHistoryMatches();
      return `
        <div class="grid dashboard-view refreshed-dashboard">
          <div class="dashboard-top-grid">
            ${renderDashboardHero(scopeMatches)}
            ${renderMostSeenEnemyCard(mostSeen, scopeMatches)}
          </div>
          <div class="card dashboard-history-card">
            <div class="card-title-row"><div><p class="small-label">Recent matches</p><h2>${escapeHtml(dashboardSelectedCharacterLabel())}</h2><p class="caption">Character filtering lives here so the top dashboard stays global and clean.</p></div><div class="icon-bubble">🔥</div></div>
            ${renderDashboardHistoryFilters(scopeMatches)}
            <div class="dashboard-match-list-v2">${shown.slice(0, 5).map(renderDashboardMatchCard).join('') || renderNoDataBox()}</div>
          </div>
        </div>
      `;
    }

    return {
      dashboardCharacterOptions,
      dashboardScopedMatches,
      dashboardHistoryMatches,
      knownResultsFrom,
      winRateBreakdownHtml,
      dashboardSelectedCharacterLabel,
      renderDashboardScopeInline,
      renderWinRateInline,
      dashboardRecorderSetupButton,
      renderDashboardRecorderCompact,
      renderDashboardAddonCompact,
      renderDashboardLogCompact,
      renderDashboardHero,
      dashboardEnemySummary,
      renderMostSeenEnemyCard,
      renderDashboardTeamCompact,
      resultCardClass,
      renderDashboardVideoThumb,
      renderDashboardMatchCard,
      renderDashboardCharacterCard,
      renderWinRateCard,
      renderDashboardRecorderCard,
      dashboardMatchTypeOptions,
      dashboardFunStats,
      renderDashboardHistoryFilters,
      renderDashboard
    };
  }

  window.LastCallDashboardView = { createDashboardViewTools };
})();
