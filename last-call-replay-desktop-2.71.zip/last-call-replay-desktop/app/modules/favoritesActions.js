(function () {
  'use strict';

  function createFavoritesActions(deps = {}) {
    if (!deps || !deps.state) throw new Error('LastCallFavoritesActions requires app state.');
    const state = deps.state;
    const api = deps.api || null;
    const alert = deps.alert || ((message) => window.alert(message));
    const confirm = deps.confirm || ((message) => window.confirm(message));
    const render = deps.render || (() => {});
    const renderKeepingReplay = deps.renderKeepingReplay || render;
    const selectedMatch = deps.selectedMatch || (() => null);
    const isFavoriteMatch = deps.isFavoriteMatch || ((match) => Boolean(match && (match.favorite || match.favorited)));
    const favoriteFolders = deps.favoriteFolders || (() => []);
    const favoriteMatches = deps.favoriteMatches || (() => []);
    const favoriteFolderId = deps.favoriteFolderId || ((match) => String((match && match.favoriteFolderId) || ''));
    const applyBackendCollectionDeltas = deps.applyBackendCollectionDeltas || (() => {});

    async function updateFavoriteMeta(matchId, updates = {}) {
      if (!matchId) return;
      const cleanUpdates = {
        ...(Object.prototype.hasOwnProperty.call(updates, 'favorite') ? { favorite: Boolean(updates.favorite) } : {}),
        ...(Object.prototype.hasOwnProperty.call(updates, 'folderId') ? { folderId: String(updates.folderId || '') } : {}),
        ...(Object.prototype.hasOwnProperty.call(updates, 'comment') ? { comment: String(updates.comment || '').slice(0, 180) } : {})
      };
      if (api && api.updateFavoriteMeta) {
        const result = await api.updateFavoriteMeta({ matchId, ...cleanUpdates });
        if (!result || !result.ok) return alert((result && result.reason) || 'Could not update favorite.');
        applyBackendCollectionDeltas(result || {});
        state.matches = result.matches || state.matches;
        state.favoriteFolders = result.favoriteFolders || state.favoriteFolders || [];
      } else {
        state.matches = (state.matches || []).map((item) => {
          if (!item || item.id !== matchId) return item;
          const next = { ...item };
          if (Object.prototype.hasOwnProperty.call(cleanUpdates, 'favorite')) next.favorite = cleanUpdates.favorite;
          if (Object.prototype.hasOwnProperty.call(cleanUpdates, 'folderId')) next.favoriteFolderId = cleanUpdates.folderId;
          if (Object.prototype.hasOwnProperty.call(cleanUpdates, 'comment')) next.favoriteComment = cleanUpdates.comment;
          return next;
        });
      }
      if (state.active === 'Matches' && state.matchView === 'detail') renderKeepingReplay();
      else render();
    }

    async function createFavoriteFolderPrompt() {
      const input = document.getElementById('favorite-folder-name');
      const rawName = input ? input.value : state.favoriteFolderDraft;
      const name = String(rawName || '').trim();
      if (!name) {
        if (input) input.focus();
        return;
      }
      if (api && api.createFavoriteFolder) {
        const result = await api.createFavoriteFolder({ name });
        if (!result || !result.ok) return alert((result && result.reason) || 'Could not create folder.');
        state.favoriteFolders = result.favoriteFolders || state.favoriteFolders || [];
        state.selectedFavoriteFolderId = result.folder && result.folder.id ? result.folder.id : state.selectedFavoriteFolderId;
      } else {
        const id = `folder-${Date.now().toString(36)}`;
        state.favoriteFolders = [...favoriteFolders(), { id, name, createdAt: new Date().toISOString() }];
        state.selectedFavoriteFolderId = id;
      }
      state.favoriteFolderDraft = '';
      render();
    }

    async function deleteFavoriteFolder(folderId) {
      if (!folderId) return;
      const folder = favoriteFolders().find((item) => item && item.id === folderId);
      if (!folder) return alert('Favorite folder not found.');
      const count = favoriteMatches().filter((match) => favoriteFolderId(match) === folderId).length;
      if (count > 0) {
        return alert(`Move or remove ${count} favorite${count === 1 ? '' : 's'} from "${folder.name}" before deleting the folder.`);
      }
      const confirmed = confirm(`Delete empty favorite folder "${folder.name}"?`);
      if (!confirmed) return;
      if (api && api.deleteFavoriteFolder) {
        const result = await api.deleteFavoriteFolder({ folderId });
        if (!result || !result.ok) return alert((result && result.reason) || 'Could not delete folder.');
        applyBackendCollectionDeltas(result || {});
        state.favoriteFolders = result.favoriteFolders || [];
        state.matches = result.matches || state.matches;
      } else {
        state.favoriteFolders = favoriteFolders().filter((item) => item && item.id !== folderId);
      }
      if (state.selectedFavoriteFolderId === folderId) state.selectedFavoriteFolderId = 'all';
      render();
    }

    async function toggleSelectedMatchFavorite() {
      const match = selectedMatch();
      if (!match) return;
      const nextFavorite = !isFavoriteMatch(match);
      await updateFavoriteMeta(match.id, { favorite: nextFavorite });
    }

    return {
      updateFavoriteMeta,
      createFavoriteFolderPrompt,
      deleteFavoriteFolder,
      toggleSelectedMatchFavorite
    };
  }

  window.LastCallFavoritesActions = { createFavoritesActions };
})();
