(function () {
  'use strict';

  const DEFAULT_UPDATE_MANIFEST_URL = 'https://raw.githubusercontent.com/darkstavern-code/last-call-replay/main/latest.json';
  const DEFAULT_UPDATE_RELEASE_URL = 'https://github.com/darkstavern-code/last-call-replay/releases';

  function createDefaultState(appVersion = '2.25') {
    return {
      active: 'Dashboard',
      matches: [],
      characterSnapshots: [],
      selectedCharacterKey: '',
      dashboardCharacterKey: 'All',
      dashboardHistoryTypeFilter: 'All',
      dashboardHistoryResultFilter: 'All',
      characterBracketFilter: 'All',
      characterTimeframe: 'Season',
      importedFiles: [],
      logFileRegistry: {},
      addonImports: [],
      pvpHelperImportPreview: null,
      scoreboardModalMode: '',
      favoriteFolders: [],
      selectedFavoriteFolderId: 'all',
      favoriteFolderDraft: '',
      favoriteVisibleLimit: 20,
      pvpHelperSyncBusy: false,
      matchRefreshBusy: false,
      logSyncBusy: false,
      selectedLogSyncBusy: false,
      logRepairBusy: false,
      selectedId: null,
      query: '',
      resultFilter: 'All',
      toonFilter: 'All',
      dayFilter: 'All',
      matchTypeFilter: 'All',
      matchClassFilter: 'All',
      matchSort: 'newest',
      playerFilter: 'Enemies',
      playerMatchTypeFilter: 'All',
      playerClassFilter: 'All',
      playerRecordFilter: 'All',
      playerSort: 'mostSeen',
      focusPlayer: '',
      playerMeetingHistoryName: '',
      meter: 'Damage',
      meterTargetFilter: 'Players',
      selectedMetricActor: '',
      selectedMetricAbility: '',
      soloShuffleSelectedRounds: {},
      soloShuffleStatsMode: 'round',
      railFilter: 'Important',
      watchStatus: 'Ready',
      watchPath: 'No file selected',
      defaultLogCandidates: [],
      logSuggestion: {},
      hiddenPlayers: [],
      appPaths: {},
      pvpHelperInstallStatus: {},
      pvpHelperSavedVariablesDiscovery: {},
      addonInstallBusy: false,
      performanceAudit: {},
      importJobStatus: { active: null, queued: 0, recent: [] },
      performanceProgress: null,
      heavyWorkBusy: false,
      eventFeedLoadingId: '',
      maintenanceLastRun: null,
      maintenanceStatus: '',
      updateStatus: null,
      settingsCategory: 'logs',
      showAllLogMonitor: false,
      matchVisibleLimit: 80,
      logMonitorVisibleLimit: 60,
      vodLibraryVisibleLimit: 40,
      vodCandidateVisibleLimit: 60,
      recordingVisibleLimit: 24,
      showSourceQuickPicker: false,
      showRecorderSettings: false,
      recordingHistoryFilter: 'Recent',
      recordingHistorySort: 'Newest',
      recordingSuggestionOpenId: '',
      selectedRecordingIds: [],
      matchView: 'list',
      matchListScrollY: 0,
      appVersion,
      settings: {
        logFilePath: '',
        logFolderPath: '',
        recordingsDir: '',
        recordingsDirConfirmed: false,
        archiveDir: '',
        clipExportDir: '',
        autoLinkWindowMinutes: 0,
        pvpHelperSavedVariablesPath: '',
        updateReleaseUrl: DEFAULT_UPDATE_RELEASE_URL,
        updateManifestUrl: DEFAULT_UPDATE_MANIFEST_URL,
        updateLastCheckedAt: '',
        updateLatestVersion: '',
        updateReleasedAt: '',
        updateInstallerUrl: '',
        updateZipUrl: '',
        updateReleaseNotes: [],
        pvpHelperAutoSync: true,
        pvpHelperLastSyncMtimeMs: 0
      },
      player: {
        videoPath: '',
        matchId: '',
        currentTime: 0,
        syncOffsetSec: 0,
        theaterMode: false,
        showRail: true,
        railLiveFollow: true,
        videoMuted: true,
        videoVolume: 0,
        lastVideoVolume: 1,
        vodScopeMode: 'match',
        showVideoSyncPanel: false,
        showExportPanel: false,
        exportStatus: null,
        healthTimelineMode: 'match',
        healthDeathFocusTime: null
      },
      vods: [],
      selectedVodId: '',
      showAllVods: false,
      vodPreRollSec: 75,
      vodPostRollSec: 0,
      vodStatus: '',
      recorder: {
        status: 'idle',
        statusText: 'Ready',
        transition: '',
        taskbarRecordingIndicatorActive: false,
        sources: [],
        selectedSourceId: '',
        selectedSourceName: 'No source selected',
        sourceApproved: false,
        sourceApprovalRequired: false,
        selectedSourceKind: '',
        approvedWowSourceNames: [],
        includeAudio: true,
        performanceMode: 'balanced',
        startedAt: 0,
        elapsed: 0,
        outputPath: '',
        recordings: []
      }
    };
  }

  function fallbackMatchKey(match = {}) {
    return String(match.id || match.matchId || match.fingerprint || `${match.startIso || ''}|${match.map || ''}|${match.matchType || match.bracket || ''}`);
  }

  function fallbackDedupeMatches(matches = [], matchKey = fallbackMatchKey) {
    const seen = new Set();
    const out = [];
    for (const match of matches || []) {
      if (!match) continue;
      const key = matchKey(match);
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(match);
    }
    return out;
  }

  function createAppStateManager(options = {}) {
    const state = options.state || createDefaultState(options.appVersion || '2.25');

    function toolsBag(tools = {}) {
      const matchDedupeKey = typeof tools.matchDedupeKey === 'function' ? tools.matchDedupeKey : fallbackMatchKey;
      return {
        clearRailFeedCache: typeof tools.clearRailFeedCache === 'function' ? tools.clearRailFeedCache : function () {},
        matchDedupeKey,
        dedupeMatches: typeof tools.dedupeMatches === 'function' ? tools.dedupeMatches : ((matches) => fallbackDedupeMatches(matches, matchDedupeKey)),
        isPendingScoreboardSnapshot: typeof tools.isPendingScoreboardSnapshot === 'function' ? tools.isPendingScoreboardSnapshot : (() => false),
        isUsableSavedMatch: typeof tools.isUsableSavedMatch === 'function' ? tools.isUsableSavedMatch : (() => true),
        dedupeCharacterSnapshots: typeof tools.dedupeCharacterSnapshots === 'function' ? tools.dedupeCharacterSnapshots : ((items) => items || []),
        validRecorderPerformanceMode: typeof tools.validRecorderPerformanceMode === 'function' ? tools.validRecorderPerformanceMode : ((mode) => mode || 'balanced'),
        rememberedSelectedCharacterKey: typeof tools.rememberedSelectedCharacterKey === 'function' ? tools.rememberedSelectedCharacterKey : (() => '')
      };
    }

    function addMatches(newMatches = [], tools = {}) {
      const t = toolsBag(tools);
      t.clearRailFeedCache();
      state.matches = t.dedupeMatches(state.matches || []);
      const existing = new Set((state.matches || []).map(t.matchDedupeKey));
      const safe = (newMatches || []).filter((match) => match && !existing.has(t.matchDedupeKey(match)));
      state.matches = t.dedupeMatches([...safe, ...(state.matches || [])]);
      const firstVisible = (state.matches || []).find((match) => !t.isPendingScoreboardSnapshot(match));
      const firstNewVisible = safe.find((match) => !t.isPendingScoreboardSnapshot(match));
      if (!state.selectedId && firstVisible) state.selectedId = firstVisible.id;
      if (firstNewVisible) state.selectedId = firstNewVisible.id;
    }

    function mergeBackendMatches(updatedMatches = [], tools = {}) {
      const incoming = (updatedMatches || []).filter(Boolean);
      if (!incoming.length) return;
      const t = toolsBag(tools);
      t.clearRailFeedCache();
      const byId = new Map(incoming.filter((match) => match && match.id).map((match) => [match.id, match]));
      const byKey = new Map(incoming.map((match) => [t.matchDedupeKey(match), match]));
      const replaced = new Set();
      state.matches = (state.matches || []).map((match) => {
        const replacement = (match && match.id && byId.get(match.id)) || byKey.get(t.matchDedupeKey(match));
        if (replacement) {
          if (replacement.id) replaced.add(replacement.id);
          replaced.add(t.matchDedupeKey(replacement));
          return replacement;
        }
        return match;
      });
      const additions = incoming.filter((match) => match && !replaced.has(match.id) && !replaced.has(t.matchDedupeKey(match)));
      if (additions.length) state.matches = [...additions, ...(state.matches || [])];
      state.matches = t.dedupeMatches(state.matches || []);
    }

    function mergeByIdCollection(existing = [], incoming = []) {
      const updates = (incoming || []).filter((item) => item && item.id);
      if (!updates.length) return existing || [];
      const byId = new Map(updates.map((item) => [String(item.id), item]));
      const seen = new Set();
      const merged = (existing || []).map((item) => {
        if (!item || !item.id) return item;
        const replacement = byId.get(String(item.id));
        if (replacement) {
          seen.add(String(item.id));
          return { ...item, ...replacement };
        }
        return item;
      }).filter(Boolean);
      const additions = updates.filter((item) => !seen.has(String(item.id)));
      return [...additions, ...merged];
    }

    function mergeBackendRecordings(updatedRecordings = []) {
      state.recorder.recordings = mergeByIdCollection(state.recorder.recordings || [], updatedRecordings || []);
    }

    function mergeBackendVods(updatedVods = []) {
      state.vods = mergeByIdCollection(state.vods || [], updatedVods || []);
    }

    function applyBackendCollectionDeltas(result = {}, tools = {}) {
      if (!result || typeof result !== 'object') return;
      if (Array.isArray(result.removedMatchIds) && result.removedMatchIds.length) {
        const removed = new Set(result.removedMatchIds.map((id) => String(id || '')));
        state.matches = (state.matches || []).filter((item) => item && !removed.has(String(item.id || '')));
      }
      if (Array.isArray(result.removedRecordingIds) && result.removedRecordingIds.length) {
        const removed = new Set(result.removedRecordingIds.map((id) => String(id || '')));
        state.recorder.recordings = (state.recorder.recordings || []).filter((item) => item && !removed.has(String(item.id || '')));
      }
      if (Array.isArray(result.removedVodIds) && result.removedVodIds.length) {
        const removed = new Set(result.removedVodIds.map((id) => String(id || '')));
        state.vods = (state.vods || []).filter((item) => item && !removed.has(String(item.id || '')));
      }
      if (Array.isArray(result.changedMatches) && result.changedMatches.length) mergeBackendMatches(result.changedMatches, tools);
      if (Array.isArray(result.repairedMatches) && result.repairedMatches.length) mergeBackendMatches(result.repairedMatches, tools);
      if (Array.isArray(result.changedRecordings) && result.changedRecordings.length) mergeBackendRecordings(result.changedRecordings);
      if (Array.isArray(result.changedVods) && result.changedVods.length) mergeBackendVods(result.changedVods);
      if (result.recording && result.recording.id) mergeBackendRecordings([result.recording]);
      if (result.vod && result.vod.id) mergeBackendVods([result.vod]);
      if (Array.isArray(result.imported) && result.imported.length) mergeBackendVods(result.imported);
    }

    function applyImportJobStatus(payload = {}) {
      if (payload && payload.importJobStatus) state.importJobStatus = payload.importJobStatus;
      else if (payload && payload.performanceAudit && payload.performanceAudit.importJobStatus) state.importJobStatus = payload.performanceAudit.importJobStatus;
    }

    function applyDesktopPayload(payload = {}, tools = {}) {
      if (!payload || typeof payload !== 'object') return;
      const t = toolsBag(tools);
      state.defaultLogCandidates = payload.defaultLogCandidates || state.defaultLogCandidates || [];
      state.logSuggestion = payload.logSuggestion || state.logSuggestion || {};
      state.appPaths = payload.appPaths || state.appPaths || {};
      state.performanceAudit = payload.performanceAudit || state.performanceAudit || {};
      state.importJobStatus = payload.importJobStatus || (payload.performanceAudit && payload.performanceAudit.importJobStatus) || state.importJobStatus || {};
      state.maintenanceLastRun = payload.maintenanceLastRun || state.maintenanceLastRun || null;
      state.pvpHelperInstallStatus = payload.pvpHelperInstallStatus || state.pvpHelperInstallStatus || {};
      state.pvpHelperSavedVariablesDiscovery = payload.pvpHelperSavedVariablesDiscovery || (payload.settings && payload.settings.pvpHelperSavedVariablesDiscovery) || state.pvpHelperSavedVariablesDiscovery || {};
      state.updateStatus = payload.updateStatus || state.updateStatus || null;
      state.settings = { ...state.settings, ...(payload.settings || {}) };
      state.importedFiles = payload.importedFiles || state.importedFiles || [];
      state.addonImports = payload.addonImports || state.addonImports || [];
      state.favoriteFolders = payload.favoriteFolders || state.favoriteFolders || [];
      state.vods = payload.vods || state.vods || [];
      state.recorder.recordings = payload.recordings || state.recorder.recordings || [];
      state.characterSnapshots = t.dedupeCharacterSnapshots(payload.characterSnapshots || state.characterSnapshots || []);
      state.hiddenPlayers = payload.hiddenPlayers || state.hiddenPlayers || [];
      state.matches = [];
      addMatches((payload.matches || []).filter(t.isUsableSavedMatch), tools);
    }

    function applySavedState(saved = {}, tools = {}) {
      const t = toolsBag(tools);
      state.appVersion = saved.appVersion || state.appVersion;
      state.defaultLogCandidates = saved.defaultLogCandidates || [];
      state.logSuggestion = saved.logSuggestion || {};
      state.appPaths = saved.appPaths || {};
      state.performanceAudit = saved.performanceAudit || {};
      state.importJobStatus = saved.importJobStatus || (saved.performanceAudit && saved.performanceAudit.importJobStatus) || state.importJobStatus || {};
      state.pvpHelperInstallStatus = saved.pvpHelperInstallStatus || (saved.settings && saved.settings.pvpHelperAddonInstallStatus) || {};
      state.pvpHelperSavedVariablesDiscovery = saved.pvpHelperSavedVariablesDiscovery || (saved.settings && saved.settings.pvpHelperSavedVariablesDiscovery) || {};
      state.updateStatus = saved.updateStatus || state.updateStatus || null;
      state.settings = { ...state.settings, ...(saved.settings || {}) };
      state.importedFiles = saved.importedFiles || [];
      state.addonImports = saved.addonImports || [];
      state.favoriteFolders = saved.favoriteFolders || [];
      state.vods = saved.vods || [];
      state.recorder.recordings = saved.recordings || [];
      state.characterSnapshots = t.dedupeCharacterSnapshots(saved.characterSnapshots || []);
      state.hiddenPlayers = saved.hiddenPlayers || [];
      state.selectedCharacterKey = t.rememberedSelectedCharacterKey() || state.selectedCharacterKey;
      if (saved.recorderSettings) {
        state.recorder.includeAudio = Object.prototype.hasOwnProperty.call(saved.recorderSettings, 'includeAudio') ? Boolean(saved.recorderSettings.includeAudio) : true;
        state.recorder.performanceMode = t.validRecorderPerformanceMode(saved.recorderSettings.performanceMode || state.recorder.performanceMode);
        state.recorder.approvedWowSourceNames = Array.isArray(saved.recorderSettings.approvedWowSourceNames) ? saved.recorderSettings.approvedWowSourceNames : [];
      }
      state.matches = [];
      addMatches((saved.matches || []).filter(t.isUsableSavedMatch), tools);
      const firstCandidate = state.settings.logFilePath || state.defaultLogCandidates[0] || '';
      return { firstCandidate, hasLogCandidate: Boolean(firstCandidate) };
    }

    function applyStartupDiagnostics(diagnostics = {}) {
      if (!diagnostics || diagnostics.ok === false) return;
      state.defaultLogCandidates = diagnostics.defaultLogCandidates || state.defaultLogCandidates || [];
      state.logSuggestion = diagnostics.logSuggestion || state.logSuggestion || {};
      state.performanceAudit = diagnostics.performanceAudit || state.performanceAudit || {};
      state.importJobStatus = diagnostics.importJobStatus || (diagnostics.performanceAudit && diagnostics.performanceAudit.importJobStatus) || state.importJobStatus || {};
      state.pvpHelperInstallStatus = diagnostics.pvpHelperInstallStatus || state.pvpHelperInstallStatus || {};
      state.pvpHelperSavedVariablesDiscovery = diagnostics.pvpHelperSavedVariablesDiscovery || state.pvpHelperSavedVariablesDiscovery || {};
    }

    return {
      state,
      addMatches,
      mergeBackendMatches,
      mergeByIdCollection,
      mergeBackendRecordings,
      mergeBackendVods,
      applyBackendCollectionDeltas,
      applyImportJobStatus,
      applyDesktopPayload,
      applySavedState,
      applyStartupDiagnostics
    };
  }

  window.LastCallAppState = { createAppStateManager, createDefaultState };
}());
