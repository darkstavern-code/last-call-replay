(function () {
  function createImportCenterViewTools(deps = {}) {
    const state = deps.state || {};
    const escapeHtml = deps.escapeHtml || ((value) => String(value ?? ''));
    const pill = deps.pill || ((text) => `<span>${escapeHtml(text)}</span>`);
    const combatLogImportHistory = deps.combatLogImportHistory || (() => []);
    const pvpHelperSyncHelpIcon = deps.pvpHelperSyncHelpIcon || (() => '');
    const pathValueMarkup = deps.pathValueMarkup || ((value, fallback) => `<span>${escapeHtml(value || fallback || '')}</span>`);
    const displayPathTail = deps.displayPathTail || ((value) => String(value || ''));
    const displayMatchTypeLabel = deps.displayMatchTypeLabel || ((value) => String(value || ''));
    const renderPvPHelperInstallStatusCard = deps.renderPvPHelperInstallStatusCard || (() => '');

    function renderImportPanel() {
      const candidate = state.defaultLogCandidates[0] || '';
      const logImports = combatLogImportHistory();
      const connectedPath = state.settings.logFilePath || state.watchPath || '';
      const connectedFolder = state.settings.logFolderPath || (connectedPath ? connectedPath.replace(/[\\/][^\\/]*$/, '') : '');
      const suggested = candidate || (state.logSuggestion && state.logSuggestion.preferredFile) || '';
      const canUseDetected = Boolean(candidate);
      const status = connectedPath ? 'Watching logs' : canUseDetected ? 'Detected Retail Logs folder' : 'Choose your WoW Logs folder';
      return `
        <div class="card log-connection-card">
          <div class="card-title-row"><div><p class="small-label">Combat logs</p><h2>Log Connection</h2><p class="caption">The app watches the active WoWCombatLog file and reads only new tail data. Use Import Previous Log for old/full-file imports.</p></div><div class="icon-bubble gradient-bubble">🗄️</div></div>
          <div class="log-connection-status">
            <div><p class="label">Status</p><strong>${escapeHtml(status)}</strong></div>
            <div><p class="label">Current folder</p><span class="path-value">${escapeHtml(connectedFolder || 'Not selected')}</span></div>
            <div><p class="label">Current file</p><span class="path-value">${escapeHtml(connectedPath || suggested || 'No WoWCombatLog*.txt found yet')}</span></div>
          </div>
          <div class="action-row log-connection-actions">
            <button class="btn emerald" id="auto-connect-local-setup">Auto-Locate Setup</button>
            ${canUseDetected ? '<button class="btn" id="use-detected-log">Use Detected Retail Logs</button>' : ''}
            <button class="btn violet" id="pick-folder">Choose Logs Folder</button>
            <button class="btn" id="import-file">Import Previous Log</button>
          </div>
          <div class="log-list slim-log-list">${logImports.slice(0, 4).map((file) => `<div class="log-item"><span>${escapeHtml(file.filePath || file.name || 'Log file')}</span>${pill(file.state || 'Imported', file.state === 'Duplicate skipped' ? 'amber' : 'emerald')}</div>`).join('')}</div>
        </div>
      `;
    }


    function renderImportLaneHistory(items, emptyText) {
      return items && items.length ? items.join('') : `<div class="empty slim-empty">${escapeHtml(emptyText)}</div>`;
    }


    function formatSyncDateTime(value) {
      if (!value) return 'Never';
      const date = new Date(value);
      if (Number.isNaN(date.getTime())) return String(value || 'Never');
      return date.toLocaleString();
    }

    function latestCombatLogImport() {
      const rows = combatLogImportHistory();
      return rows && rows.length ? rows[0] : null;
    }

    function latestPvPHelperImport() {
      const rows = Array.isArray(state.addonImports) ? state.addonImports : [];
      return rows && rows.length ? rows[0] : null;
    }

    function renderLatestImportSummary(item, emptyText, label = 'Most recent') {
      if (!item) return `<div class="empty slim-empty">${escapeHtml(emptyText)}</div>`;
      const when = formatSyncDateTime(item.importedAt || item.syncedAt || item.createdAt || item.date);
      const rawPrimary = item.filePath || item.name || item.sourceName || 'Unknown file';
      const primary = displayPathTail(rawPrimary, 3);
      const fullTitle = rawPrimary && rawPrimary !== primary ? ` title="${escapeHtml(rawPrimary)}"` : '';
      const parsed = Number(item.parsedCount || item.importedCount || item.matchHistoryCount || 0);
      const stateText = item.state || item.status || (parsed ? `${parsed} parsed` : 'Completed');
      return `<div class="latest-sync-card"><div><p class="label">${escapeHtml(label)}</p><p class="value path-value latest-sync-primary"${fullTitle}>${escapeHtml(primary)}</p><p class="caption">${escapeHtml(when)}</p></div><strong>${escapeHtml(stateText)}</strong></div>`;
    }


    function currentPvPHelperSavedVariablesDiscovery() {
      return state.pvpHelperSavedVariablesDiscovery || (state.settings && state.settings.pvpHelperSavedVariablesDiscovery) || {};
    }

    function renderPvPHelperMappingAssist(mappedPvph = '', context = '') {
      const discovery = currentPvPHelperSavedVariablesDiscovery();
      const best = discovery && discovery.best ? discovery.best : null;
      const candidates = Array.isArray(discovery && discovery.candidates) ? discovery.candidates : [];
      const accountRoot = discovery && discovery.accountRoot ? discovery.accountRoot : '';
      const wowRoot = discovery && discovery.wowRoot ? discovery.wowRoot : '';
      const suffix = context ? ` ${context}` : '';
      const mapped = String(mappedPvph || '').trim();
      const revealPath = mapped || (best && best.filePath) || accountRoot || wowRoot || '';
      const revealLabel = mapped || (best && best.filePath) ? 'Show file' : accountRoot ? 'Open WTF Account' : 'Show WoW folder';
      const modified = best && best.modifiedAt ? new Date(best.modifiedAt).toLocaleString() : '';
      const bestPath = best && best.filePath ? best.filePath : '';
      const candidateLine = candidates.length
        ? `${candidates.length} candidate${candidates.length === 1 ? '' : 's'} found${best && best.accountName ? ` · likely account ${best.accountName}` : ''}${modified ? ` · updated ${modified}` : ''}`
        : (discovery && discovery.reason ? discovery.reason : 'Connect your WoW Logs folder first, then the app can look in WTF\\Account for you.');
      const tone = mapped ? 'emerald' : bestPath ? 'amber' : 'neutral';
      const title = mapped ? 'PvPHelper.lua is mapped' : bestPath ? 'Likely PvPHelper.lua found' : 'Need help finding PvPHelper.lua';
      const mainText = mapped
        ? 'The app will keep syncing this SavedVariables file. If you swapped WoW accounts, use Auto-find again.'
        : bestPath
          ? 'The app found a likely account SavedVariables file. Auto-map it, or choose the folder if this is the wrong account.'
          : 'After logs are connected, PvPHelper.lua usually lives in WTF\\Account\\<AccountName>\\SavedVariables. Log into WoW with PvPHelper enabled, then /reload or log out so the file is written.';
      const candidateMarkup = bestPath ? `<p class="caption path-value" title="${escapeHtml(bestPath)}">${escapeHtml(displayPathTail(bestPath, 5))}</p>` : '';
      const revealButton = revealPath ? `<button class="btn small" data-reveal-pvphelper-savedvars="${escapeHtml(revealPath)}">${escapeHtml(revealLabel)}</button>` : '';
      return `
        <div class="status-callout ${tone} pvphelper-map-assist">
          <strong>${escapeHtml(title)}</strong>
          <span>${escapeHtml(mainText)}</span>
          <div class="pvphelper-path-steps" aria-label="PvPHelper SavedVariables path guide">
            <span>Choose account</span>
            <b>›</b>
            <span>SavedVariables</span>
            <b>›</b>
            <span>PvPHelper.lua</span>
          </div>
          <small>Tip: selecting the Account folder is enough. The app searches the account folders for SavedVariables\PvPHelper.lua.</small>
          ${candidateMarkup}
          <small>${escapeHtml(candidateLine)}</small>
          <div class="action-row compact-actions">
            <button class="btn small emerald auto-preview-pvph-savedvariables">${mapped ? 'Auto-find again' : 'Auto-find PvPHelper.lua'}</button>
            <button class="btn small refresh-pvph-discovery">Rescan folders</button>
            <button class="btn small import-pvph-manual">Choose Account Folder</button>
            ${revealButton}
          </div>
        </div>
      `;
    }

    function renderPvPHelperAddonStatus(mappedPvph, settings = {}) {
      const status = settings.pvpHelperStatus || {};
      if (!mappedPvph) {
        return `<div class="addon-status-grid"><div class="status-callout amber"><strong>Addon not found yet</strong><span>Map the addon SavedVariables file first: WTF/Account/&lt;Account&gt;/SavedVariables/PvPHelper.lua.</span></div></div>`;
      }
      if (settings.pvpHelperFileExists === false || status.missingFile) {
        return `<div class="addon-status-grid"><div class="status-callout rose"><strong>Addon not found</strong><span>The mapped PvPHelper.lua file is missing. Re-map the SavedVariables file after logging into WoW with the addon loaded.</span></div></div>`;
      }
      if (!status || !status.addonFound) {
        return `<div class="addon-status-grid"><div class="status-callout amber"><strong>Waiting for addon data</strong><span>Sync PvPHelper.lua to check addon settings and saved scoreboard/rating data.</span></div></div>`;
      }
      const loggingKnown = status.combatLogConfigFound === true;
      const loggingGood = status.combatLoggingEnabled === true;
      const scoreboardKnown = status.scoreboardCaptureKnown === true;
      const scoreboardGood = status.scoreboardCaptureEnabled === true;
      const advancedKnown = status.advancedCombatLoggingKnown === true;
      const advancedGood = status.advancedCombatLoggingEnabled === true;
      const ratingCount = Number(status.characterSnapshotCount || status.ratingSnapshotCount || (state.characterSnapshots || []).length || 0);
      const enabledModes = Array.isArray(status.enabledModes) && status.enabledModes.length ? status.enabledModes.join(', ') : 'No PvP logging modes enabled';
      const versionGood = status.addonNeedsUpdate === false;
      const versionClass = versionGood ? 'emerald' : 'amber';
      const versionText = status.addonVersionMessage || (status.addonVersion ? `PvPHelper ${status.addonVersion}` : 'Version not detected. Update PvPHelper if sync features look off.');
      const loggingClass = !loggingKnown ? 'amber' : loggingGood ? 'emerald' : 'rose';
      const scoreboardClass = scoreboardGood ? 'emerald' : (scoreboardKnown ? 'rose' : 'amber');
      const advancedClass = advancedGood ? 'emerald' : (advancedKnown ? 'rose' : 'amber');
      const ratingClass = ratingCount ? 'emerald' : 'amber';
      const appBridgeClass = status.appStatusFound ? 'emerald' : 'amber';
      const liveKnown = status.liveCombatLoggingKnown === true;
      const liveActive = status.combatLoggingActive === true;
      const liveClass = !liveKnown ? 'amber' : liveActive ? 'emerald' : 'amber';
      const schemaVersion = Number(status.matchHistorySchemaVersion || settings.pvpHelperMatchHistorySchemaVersion || 0);
      const schemaClass = schemaVersion >= 2 ? 'emerald' : (schemaVersion ? 'amber' : 'amber');
      const schemaText = schemaVersion >= 2
        ? `Bridge schema ${schemaVersion}. matchHistoryMeta ${status.matchHistoryMetaFound ? 'found' : 'not included'}.`
        : schemaVersion
          ? `Older bridge schema ${schemaVersion} detected. Supported, but schema 2 imports are cleaner.`
          : 'Bridge schema not detected yet. Sync after updating PvPHelper if scoreboard linking looks odd.';
      const issues = Array.isArray(status.dataReadinessIssues) ? status.dataReadinessIssues.filter(Boolean) : [];
      const warnings = Array.isArray(status.dataReadinessWarnings) ? status.dataReadinessWarnings.filter(Boolean) : [];
      const readinessClass = issues.length ? 'rose' : warnings.length ? 'amber' : 'emerald';
      const readinessText = issues.length
        ? issues.join(' ')
        : warnings.length
          ? warnings.join(' ')
          : 'Scoreboard capture, logging modes, and verified addon data look ready.';
      const loggingText = !loggingKnown
        ? 'Could not confirm PvPHelper match logging options yet. Sync after opening the addon options in game.'
        : loggingGood
          ? `Enabled for: ${enabledModes}`
          : 'No Arena/BG/RBG logging modes appear enabled in PvPHelper settings.';
      const scoreboardText = scoreboardGood
        ? `Enabled. Final PvP scoreboard snapshots can be saved to matchHistory.${status.scoreboardCaptureSource ? ` Source: ${status.scoreboardCaptureSource}.` : ''}`
        : scoreboardKnown
          ? 'Disabled. Enable “Save scoreboard snapshots” in the addon to capture final scoreboards.'
          : 'Could not verify this setting from SavedVariables. A newer addon bridge should write captureScoreboard into PvPHelperDB.profile.combatLog.';
      const advancedText = advancedGood
        ? `On. Health/resource timeline data should be richer.${status.advancedCombatLoggingSource ? ` Source: ${status.advancedCombatLoggingSource}.` : ''}`
        : advancedKnown
          ? 'Off. Turn on Advanced Combat Logging in WoW settings for richer health/resource timelines.'
          : 'Unknown. Current addon data may only expose this after a scoreboard snapshot; ask the addon to write this setting directly for reliable checks.';
      const appBridgeText = status.appStatusFound
        ? `Top-level PvPHelperDB.appStatus found.${status.appStatusUpdatedAtUTC ? ` Updated ${formatSyncDateTime(status.appStatusUpdatedAtUTC)}.` : ''}${status.appStatusReason ? ` Reason: ${status.appStatusReason}.` : ''}`
        : 'Top-level PvPHelperDB.appStatus not found yet. Sync PvPHelper 0.12.8+ after /reload for cleaner status checks.';
      const context = status.currentContext && typeof status.currentContext === 'object' ? status.currentContext : {};
      const contextText = context.label || context.matchType || context.instanceType || '';
      const liveText = !status.appStatusFound
        ? 'Waiting for the addon appStatus bridge.'
        : !liveKnown
          ? 'Current Blizzard combat logging state was not included in appStatus.'
          : `${liveActive ? 'On' : 'Off or waiting'}.${contextText ? ` Context: ${contextText}.` : ''}${status.loggingStatusText ? ` Addon says: ${status.loggingStatusText}.` : ''}`;
      return `
        <div class="addon-status-grid">
          <div class="status-callout ${readinessClass}"><strong>Data readiness</strong><span>${escapeHtml(readinessText)}</span></div>
          <div class="status-callout ${versionClass}"><strong>${escapeHtml(versionGood ? 'Addon version OK' : 'Addon update recommended')}</strong><span>${escapeHtml(versionText)}</span></div>
          <div class="status-callout ${schemaClass}"><strong>Scoreboard bridge schema</strong><span>${escapeHtml(schemaText)}</span></div>
          <div class="status-callout ${appBridgeClass}"><strong>App status bridge</strong><span>${escapeHtml(appBridgeText)}</span></div>
          <div class="status-callout ${loggingClass}"><strong>Addon logging options</strong><span>${escapeHtml(loggingText)}</span></div>
          <div class="status-callout ${liveClass}"><strong>Live combat log state</strong><span>${escapeHtml(liveText)}</span></div>
          <div class="status-callout ${scoreboardClass}"><strong>Scoreboard snapshots</strong><span>${escapeHtml(scoreboardText)}</span></div>
          <div class="status-callout ${advancedClass}"><strong>Advanced Combat Logging</strong><span>${escapeHtml(advancedText)}</span></div>
          <div class="status-callout ${ratingClass}"><strong>Rating / character data</strong><span>${escapeHtml(ratingCount ? `${ratingCount} character/rating snapshot${ratingCount === 1 ? '' : 's'} found.` : 'No character/rating snapshot data found yet. Enable/add the addon snapshot option if the addon provides one.')}</span></div>
        </div>
      `;
    }

    function renderImportCenter() {
      const settings = state.settings || {};
      const connectedPath = settings.logFilePath || state.watchPath || '';
      const connectedFolder = settings.logFolderPath || (connectedPath ? connectedPath.replace(/[\\/][^\\/]*$/, '') : '');
      const mappedPvph = settings.pvpHelperSavedVariablesPath || '';
      const latestLog = latestCombatLogImport();
      const latestAddon = latestPvPHelperImport();
      const ratingCount = (state.characterSnapshots || []).length;
      const lastSync = settings.pvpHelperLastSyncAt ? new Date(settings.pvpHelperLastSyncAt).toLocaleString() : 'Never';
      const scoreboardCount = Number(settings.pvpHelperLastScoreboardCount || (latestAddon && latestAddon.parsedCount) || 0);
      const pendingCount = Number(settings.pvpHelperLastPendingCount || (latestAddon && latestAddon.createdCount) || 0);
      const linkedCount = Number(settings.pvpHelperLastMergedCount || (latestAddon && latestAddon.mergedCount) || 0);
      const schemaVersion = Number(settings.pvpHelperMatchHistorySchemaVersion || (settings.pvpHelperStatus && settings.pvpHelperStatus.matchHistorySchemaVersion) || 0);
      return `
        <div class="card import-center-card">
          <div class="card-title-row"><div><p class="small-label">Import center</p><h2>Two clean data sources</h2><p class="caption">Combat logs build the replay timeline. PvPHelper.lua is mapped once, then scoreboards attach to matches and rating snapshots attach to characters.</p></div><div class="icon-bubble gradient-bubble">🧭</div></div>
          <div class="import-lane-grid two-lanes">
            <div class="import-lane combat-lane">
              <div class="import-lane-head"><span class="lane-number">1</span><div><h3>Combat Logs</h3><p>Use <strong>WoWCombatLog*.txt</strong> for match timelines, deaths, damage events, CC, kicks, health charts, and video linking.</p></div></div>
              <div class="import-lane-status"><span>Folder</span>${pathValueMarkup(connectedFolder, 'Not selected', 3)}</div>
              <div class="import-lane-status"><span>Last import/scan</span><strong>${escapeHtml(latestLog ? formatSyncDateTime(latestLog.importedAt) : 'Never')}</strong></div>
              <div class="action-row"><button class="btn emerald" id="settings-auto-connect-local-setup">Auto-Locate Setup</button><button class="btn" id="settings-scan-logs" ${state.logSyncBusy ? 'disabled' : ''}>${state.logSyncBusy ? 'Syncing…' : 'Sync Active Log'}</button><button class="btn violet" id="settings-pick-log-folder">Choose Logs Folder</button><button class="btn" id="settings-import-old-log">Import Previous Combat Log</button><button class="btn violet" id="settings-repair-missing-logs" ${state.logRepairBusy ? 'disabled' : ''}>${state.logRepairBusy ? 'Repairing…' : 'Repair Missing Logs'}</button></div>
              ${renderLatestImportSummary(latestLog, 'No combat log imports yet.', 'Most recent combat log')}
              <p class="caption">Use Sync Active Log for the newest file. Use Repair Missing Logs when older matches need their combat-log timeline attached.</p>
            </div>
            <div class="import-lane addon-lane wide-lane">
              <div class="import-lane-head"><span class="lane-number violet">2</span><div><h3>PvPHelper SavedVariables ${pvpHelperSyncHelpIcon()}</h3><p>Map the <strong>SavedVariables folder</strong> once. The app finds PvPHelper.lua inside, then final scoreboards become match attachments and rating snapshots feed the character timeline.</p></div></div>
              <div class="import-lane-status"><span>Mapped file</span>${pathValueMarkup(mappedPvph, 'Not mapped yet', 3)}</div>
              <div class="import-lane-status"><span>Last sync</span><strong>${escapeHtml(lastSync)}</strong></div>
              <div class="sync-count-strip"><span>${scoreboardCount} scoreboards found</span><span>${linkedCount} linked</span><span>${pendingCount} pending</span><span>${ratingCount} rating snapshots</span>${schemaVersion ? `<span>schema ${schemaVersion}</span>` : ''}</div>
              <div class="addon-status-grid addon-install-grid">${renderPvPHelperInstallStatusCard('settings')}</div>
              ${renderPvPHelperMappingAssist(mappedPvph, 'settings')}
              ${renderPvPHelperAddonStatus(mappedPvph, settings)}
              <label class="toggle-row slim-toggle"><input type="checkbox" id="pvphelper-auto-sync" ${settings.pvpHelperAutoSync !== false ? 'checked' : ''}/> <span>Auto-sync this file after startup when it changed</span></label>
              <div class="action-row">${mappedPvph ? `<button class="btn emerald" id="sync-pvph-savedvariables" ${state.pvpHelperSyncBusy ? 'disabled' : ''}>${state.pvpHelperSyncBusy ? 'Syncing…' : 'Sync Now'}</button><button class="btn" id="import-pvph-savedvariables">Change Folder</button><button class="btn" id="clear-pvph-savedvariables">Clear Mapping</button>` : '<button class="btn violet" id="import-pvph-savedvariables">Map PvPHelper.lua</button>'}${pvpHelperSyncHelpIcon('inline-action-help')}</div>
              ${renderLatestImportSummary(latestAddon, 'No PvPHelper syncs yet.', 'Most recent PvPHelper sync')}
              <details class="legacy-details"><summary>Legacy one-off rating export</summary><p class="caption">Only use this if you have an older standalone character/rating export. Normal setup should use the mapped PvPHelper.lua above.</p><div class="action-row"><button class="btn" id="import-character-snapshot">Import Legacy Rating Export</button></div></details>
            </div>
          </div>
        </div>
      `;
    }

    function renderCharacterImportHelpCard(profiles = []) {
      const mappedPvph = state.settings && state.settings.pvpHelperSavedVariablesPath ? state.settings.pvpHelperSavedVariablesPath : '';
      return `
        <div class="card character-import-guide">
          <div class="card-title-row"><div><p class="small-label">Character data</p><h2>${profiles.length ? 'Character sync controls' : 'No character data yet'}</h2><p class="caption">Rating snapshots from the mapped PvPHelper.lua build the character timeline. Scoreboards stay attached to matches.</p></div><div class="icon-bubble">📥</div></div>
          <div class="import-mini-grid">
            <div class="info-box"><p class="label">PvPHelper.lua mapping ${pvpHelperSyncHelpIcon()}</p><p class="value path-value">${escapeHtml(mappedPvph || 'Not mapped yet')}</p><p class="caption">Syncs rating snapshots for this tab. Final scoreboards are viewed from individual matches.</p><div class="addon-status-grid addon-install-grid">${renderPvPHelperInstallStatusCard('characters')}</div>${renderPvPHelperMappingAssist(mappedPvph, 'characters')}${renderPvPHelperAddonStatus(mappedPvph, state.settings || {})}<div class="action-row">${mappedPvph ? `<button class="btn emerald" id="sync-pvph-savedvariables" ${state.pvpHelperSyncBusy ? 'disabled' : ''}>${state.pvpHelperSyncBusy ? 'Syncing…' : 'Sync Now'}</button><button class="btn" id="import-pvph-savedvariables">Change Folder</button>` : '<button class="btn violet" id="import-pvph-savedvariables">Map PvPHelper.lua</button>'}${pvpHelperSyncHelpIcon('inline-action-help')}</div></div>
          </div>
        </div>
      `;
    }

    function renderPvPHelperImportPreviewModal() {
      const preview = state.pvpHelperImportPreview;
      if (!preview) return '';
      const rows = preview.previewRows || [];
      const parsed = Number(preview.parsed || preview.scoreboardSnapshots || 0);
      const merged = Number(preview.merged || 0);
      const created = Number(preview.created || 0);
      const skipped = Number(preview.skipped || 0);
      const ratingFound = Number(preview.characterSnapshots || 0);
      const canApply = Boolean(preview.filePath || preview.mappedPath);
      const hasImportableData = parsed > 0 || ratingFound > 0;
      const applyLabel = hasImportableData ? 'Map Folder + Sync' : 'Map Anyway';
      return `
        <div class="modal-scrim import-preview-scrim" id="pvphelper-preview-scrim">
          <div class="quick-source-modal import-preview-modal">
            <div class="modal-head">
              <div><p class="small-label">PvPHelper mapping preview</p><h2>Review before mapping and syncing</h2><p class="caption path-value">${escapeHtml(preview.filePath || preview.sourceName || 'PvPHelper.lua')}</p>${preview.resolvedFromFolder && preview.selectedPath ? `<p class="caption">Found inside selected folder: ${escapeHtml(displayPathTail(preview.selectedPath, 4))}</p>` : ''}</div>
              <button class="modal-close" id="close-pvphelper-preview">×</button>
            </div>
            <div class="preview-stat-grid">
              <div><p>Scoreboard snapshots</p><strong>${parsed}</strong></div>
              <div><p>Merge into logs</p><strong>${merged}</strong></div>
              <div><p>Pending links</p><strong>${created}</strong></div>
              <div><p>Skip / duplicate</p><strong>${skipped}</strong></div>
              <div><p>Rating snapshots found</p><strong>${ratingFound}</strong></div>
            </div>
            <div class="status-callout neutral mapping-ready-callout"><strong>Mapping is allowed now</strong><span>This saves the found PvPHelper.lua path even if the addon has not written scoreboards, rating snapshots, or readiness settings yet. Any missing settings will show in the top PvPHelper status after mapping.</span></div>
            <p class="caption preview-note">Nothing is changed until you click the mapping button. This saves the found PvPHelper.lua path for future syncs. Favorites, folders, comments, and linked videos stay protected.</p>
            <div class="preview-table">
              ${rows.map((row) => `<div class="preview-row"><span>${escapeHtml(row.map || 'Unknown map')}<small>${escapeHtml(displayMatchTypeLabel(row.bracket || ''))}</small></span><span>${escapeHtml(row.capturedAt ? new Date(row.capturedAt).toLocaleString() : '')}</span><span>${Number(row.playerCount || 0)} players</span>${pill(row.action === 'merge' ? `Merge · ${row.confidence}` : row.action === 'create' ? 'Pending scoreboard link' : 'Skip duplicate', row.action === 'merge' ? 'emerald' : row.action === 'create' ? 'violet' : 'amber')}</div>`).join('') || '<div class="empty slim-empty">No PvPHelperDB.matchHistory scoreboard snapshots were found.</div>'}
              ${preview.extraRows ? `<p class="caption">${Number(preview.extraRows)} more preview row${Number(preview.extraRows) === 1 ? '' : 's'} hidden.</p>` : ''}
            </div>
            <div class="action-row preview-actions"><button class="btn primary" id="apply-pvphelper-preview" ${!canApply ? 'disabled' : ''}>${escapeHtml(applyLabel)}</button><button class="btn" id="cancel-pvphelper-preview">Cancel</button></div>
          </div>
        </div>
      `;
    }

    return {
      renderImportPanel,
      renderImportLaneHistory,
      formatSyncDateTime,
      latestCombatLogImport,
      latestPvPHelperImport,
      renderLatestImportSummary,
      currentPvPHelperSavedVariablesDiscovery,
      renderPvPHelperMappingAssist,
      renderPvPHelperAddonStatus,
      renderImportCenter,
      renderCharacterImportHelpCard,
      renderPvPHelperImportPreviewModal
    };
  }

  window.LastCallImportCenterView = { createImportCenterViewTools };
})();
