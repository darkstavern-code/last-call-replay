(function () {
  'use strict';

  function createPlayerMeetingTools(deps = {}) {
    const normalizedMapKey = deps.normalizedMapKey || ((value) => String(value || '').trim().toLowerCase());
    const effectiveMatchType = deps.effectiveMatchType || ((match) => match && (match.matchType || match.bracket || ''));
    const normalizedMatchType = deps.normalizedMatchType || ((match) => match && (match.matchType || match.bracket || ''));
    const enemyIdentityKey = deps.enemyIdentityKey || ((value) => String(value || '').trim().toLowerCase());
    const characterNameKey = deps.characterNameKey || ((value) => String(value || '').trim().toLowerCase());
    const storedEventFeedCount = deps.storedEventFeedCount || (() => 0);

    function playerMeetingTimeMs(match) {
      if (!match) return 0;
      const direct = Number(match.startMs || match.startedAt || 0);
      if (Number.isFinite(direct) && direct > 0) return direct;
      const parsed = Date.parse(match.startIso || match.date || match.capturedAt || 0);
      return Number.isFinite(parsed) ? parsed : 0;
    }

    function playerMeetingDedupeKey(match, playerName = '') {
      if (!match) return '';
      const start = playerMeetingTimeMs(match);
      const startBucket = start ? Math.round(start / 30000) : '';
      const duration = Number(match.durationSec || 0);
      const durationBucket = duration ? Math.round(duration / 15) : '';
      const map = normalizedMapKey(match.map || match.zone || match.subzone || '');
      const type = String(effectiveMatchType(match) || normalizedMatchType(match) || '').toLowerCase().trim();
      const player = enemyIdentityKey(playerName || '');
      const alt = characterNameKey(match.alt || match.character || '');
      if (startBucket && (map || type || player)) return `meeting:${player}:${startBucket}:${durationBucket}:${map}:${type}:${alt}`;
      if (match.rawFingerprint) return `meeting:${player}:raw:${match.rawFingerprint}`;
      if (match.id) return `meeting:${player}:id:${match.id}`;
      return `meeting:${player}:${map}:${type}:${durationBucket}`;
    }

    function meetingDataScore(match) {
      if (!match) return 0;
      return (Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length ? 80 : 0)
        + (match.addonScoreboard ? 45 : 0)
        + (match.metrics && Object.keys(match.metrics).length ? 30 : 0)
        + Math.min(30, storedEventFeedCount(match) / 100)
        + (Array.isArray(match.participants) ? Math.min(20, match.participants.length) : 0)
        + (match.videoPath || match.vodId ? 12 : 0)
        + (match.result === 'Win' || match.result === 'Loss' ? 8 : 0);
    }

    function mergeMeetingMatch(existing, incoming, relationship) {
      if (!existing) return { ...(incoming || {}), relationship };
      const shouldReplace = meetingDataScore(incoming) > meetingDataScore(existing);
      const base = shouldReplace ? { ...(incoming || {}) } : { ...existing };
      const other = shouldReplace ? existing : incoming;
      base.relationship = relationship || existing.relationship || (incoming && incoming.relationship) || 'Observed';
      for (const key of ['scoreboardPlayers', 'addonScoreboard', 'metrics', 'participants', 'teams', 'myComp', 'enemyComp', 'enemies', 'videoPath', 'vodId']) {
        if ((base[key] == null || (Array.isArray(base[key]) && !base[key].length)) && other && other[key] != null) base[key] = other[key];
      }
      base.dataSources = Array.from(new Set([...(base.dataSources || []), ...((other && other.dataSources) || [])]));
      return base;
    }

    return {
      playerMeetingTimeMs,
      playerMeetingDedupeKey,
      meetingDataScore,
      mergeMeetingMatch
    };
  }

  window.LastCallPlayerMeetingHelpers = { createPlayerMeetingTools };
})();
