(function () {
  'use strict';

  function createScoreboardViewTools(deps = {}) {
    const state = deps.state || {};
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const normalizedMatchType = deps.normalizedMatchType || (() => '');
    const shortNameKey = deps.shortNameKey || ((value) => String(value || '').toLowerCase().trim());
    const pvpHelperSyncHelpIcon = deps.pvpHelperSyncHelpIcon || (() => '');
    const prettyNumber = deps.prettyNumber || ((value) => String(value || 0));
    const classMetaForName = deps.classMetaForName || (() => null);
    const classMetaAcrossMatches = deps.classMetaAcrossMatches || (() => null);
    const classColorByName = deps.classColorByName || (() => '');
    const shortCharacterName = deps.shortCharacterName || ((name) => String(name || '').split('-')[0]);
    const isBattlegroundMatch = deps.isBattlegroundMatch || (() => false);
    const pill = deps.pill || ((text) => `<span>${escapeHtml(text)}</span>`);
    const matchTimestampLabel = deps.matchTimestampLabel || (() => 'Unknown time');
    const displayMatchType = deps.displayMatchType || (() => 'PvP');
    const selectedMatch = deps.selectedMatch || (() => null);
    const isFavoriteMatch = deps.isFavoriteMatch || (() => false);

    function matchScoreboardPlayers(match) {
      return Array.isArray(match && match.scoreboardPlayers) ? match.scoreboardPlayers.filter(Boolean) : [];
    }

    function hasLinkedScoreboard(match) {
      return matchScoreboardPlayers(match).length > 0;
    }

    function isPendingScoreboardSnapshot(match) {
      // Hide disposable scoreboard shells only after they have been linked into a real match.
      // Addon-only fallback matches should stay visible so users can review them and map video when combat logs missed the game.
      return Boolean(match && match.createdFromAddon && !match.createdFromRealLog && hasLinkedScoreboard(match) && match.scoreboardLinkedToMatchId && !isFavoriteMatch(match));
    }

    function matchScoreboardAttachmentId(match) {
      return String((match && match.id) || '');
    }

    function scoreboardCandidateScore(target, candidate) {
      if (!target || !candidate) return 0;
      let score = 0;
      const targetTime = target.endIso ? Date.parse(target.endIso) : (target.startIso ? Date.parse(target.startIso) : Number(target.endMs || target.startMs || 0));
      const candidateTime = candidate.capturedAt ? Date.parse(candidate.capturedAt) : (candidate.endIso ? Date.parse(candidate.endIso) : (candidate.startIso ? Date.parse(candidate.startIso) : Number(candidate.endMs || candidate.startMs || 0)));
      if (targetTime && candidateTime) {
        const diff = Math.abs(targetTime - candidateTime);
        if (diff <= 20 * 60 * 1000) score += 50;
        else if (diff <= 60 * 60 * 1000) score += 25;
        else if (new Date(targetTime).toDateString() === new Date(candidateTime).toDateString()) score += 10;
      }
      if (target.map && candidate.map && String(target.map).toLowerCase() === String(candidate.map).toLowerCase()) score += 25;
      if (normalizedMatchType(target) === normalizedMatchType(candidate)) score += 10;
      if (shortNameKey(target.alt) && shortNameKey(target.alt) === shortNameKey(candidate.alt)) score += 15;
      return score;
    }

    function scoreboardsAvailableToLink(match) {
      if (!match) return [];
      return (state.matches || [])
        .filter((item) => item && item.id !== match.id && hasLinkedScoreboard(item))
        .filter((item) => item.createdFromAddon || item.addonScoreboard || !item.createdFromRealLog)
        .filter((item) => !item.scoreboardLinkedToMatchId || item.scoreboardLinkedToMatchId === match.id)
        .map((item) => ({ ...item, _scoreboardLinkScore: scoreboardCandidateScore(match, item) }))
        .sort((a, b) => (b._scoreboardLinkScore || 0) - (a._scoreboardLinkScore || 0) || String(b.capturedAt || b.endIso || b.startIso || '').localeCompare(String(a.capturedAt || a.endIso || a.startIso || '')))
        .slice(0, 30);
    }

    function scoreboardActionButtons(match) {
      if (!match) return '';
      const hasScoreboard = hasLinkedScoreboard(match);
      const candidates = scoreboardsAvailableToLink(match);
      const mapped = Boolean(state.settings && state.settings.pvpHelperSavedVariablesPath);
      const linkButton = candidates.length || hasScoreboard
        ? `<button class="btn" id="open-scoreboard-linker" ${candidates.length ? '' : 'disabled'}>${hasScoreboard ? 'Change Scoreboard Link' : 'Link Scoreboard'}</button>`
        : '';
      const syncButton = !hasScoreboard
        ? (mapped ? '<button class="btn emerald" id="sync-pvph-savedvariables">Sync PvPHelper.lua</button>' : '<button class="btn emerald" id="import-pvph-savedvariables">Map PvPHelper.lua</button>') + pvpHelperSyncHelpIcon('inline-action-help')
        : '';
      return `<div class="action-row scoreboard-actions">${linkButton}${syncButton}</div>`;
    }

    function playerIsSelectedToon(player, match) {
      const own = shortNameKey(match && match.alt);
      const name = shortNameKey(player && (player.name || player.fullName));
      return own && name && own === name;
    }

    function scoreValue(player, field) {
      const value = Number(player && player[field]);
      return Number.isFinite(value) && value !== 0 ? prettyNumber(value) : '0';
    }

    function ratingValue(player) {
      if (!player) return '—';
      const rating = Number(player.rating);
      const change = Number(player.ratingChange);
      const mmr = Number(player.postmatchMMR || player.prematchMMR);
      const bits = [];
      if (Number.isFinite(rating) && rating) bits.push(`${rating}`);
      if (Number.isFinite(change) && change) bits.push(`${change > 0 ? '+' : ''}${change}`);
      if (Number.isFinite(mmr) && mmr) bits.push(`MMR ${mmr}`);
      return bits.length ? bits.join(' · ') : '—';
    }

    function scoreboardPlayerClassColor(player, match) {
      if (!player) return '';
      if (player.classColor) return player.classColor;
      const meta = classMetaForName(player.fullName || player.name, match) || classMetaAcrossMatches(player.fullName || player.name);
      if (meta && meta.classColor) return meta.classColor;
      return classColorByName(player.className || player.classFile || '');
    }

    function scoreboardPlayerNameHtml(player, match) {
      const name = player && (player.fullName || player.name) ? (player.fullName || player.name) : 'Unknown';
      const color = scoreboardPlayerClassColor(player, match);
      const classText = [player && player.specName, player && (player.className || player.classFile)].filter(Boolean).join(' · ') || 'Spec/class unknown';
      return `<span class="scoreboard-player-name" ${color ? `style="--scoreboard-class-color:${escapeHtml(color)}"` : ''} title="${escapeHtml([name, classText].filter(Boolean).join(' · '))}"><b>${escapeHtml(shortCharacterName(name))}</b><small>${escapeHtml(classText)}</small></span>`;
    }

    function scoreboardPlayerTeamKey(player) {
      if (!player) return 'unknown';
      const raw = player.team !== undefined && player.team !== null ? player.team : (player.faction !== undefined && player.faction !== null ? player.faction : 'unknown');
      const text = String(raw).trim();
      return text || 'unknown';
    }

    function scoreboardPlayerRelation(player, match) {
      const name = player && (player.fullName || player.name || '');
      const ownTeam = match && match.ownTeam !== undefined && match.ownTeam !== null ? String(match.ownTeam) : '';
      const key = scoreboardPlayerTeamKey(player);
      if (ownTeam && key !== 'unknown' && key === ownTeam) return 'friendly';
      const mine = new Set([...(match && match.myComp || []), match && match.alt].filter(Boolean).map(shortNameKey));
      const enemies = new Set([...(match && match.enemyComp || []), ...(match && match.enemies || [])].filter(Boolean).map(shortNameKey));
      const nameKey = shortNameKey(name);
      if (mine.has(nameKey)) return 'friendly';
      if (enemies.has(nameKey)) return 'enemy';
      return 'unknown';
    }

    function scoreboardTeamLabel(teamKey, rows, match) {
      const relations = rows.map((player) => scoreboardPlayerRelation(player, match));
      const friendly = relations.filter((item) => item === 'friendly').length;
      const enemy = relations.filter((item) => item === 'enemy').length;
      if (friendly && friendly >= enemy) return 'Your team';
      if (enemy && enemy > friendly) return 'Enemy team';
      if (teamKey === 'unknown') return 'Team unknown';
      return `Team ${teamKey}`;
    }

    function scoreboardTeamTone(label) {
      if (/your/i.test(label)) return 'friendly';
      if (/enemy/i.test(label)) return 'enemy';
      return 'unknown';
    }

    function renderScoreboardTable(match) {
      const players = matchScoreboardPlayers(match);
      if (!players.length) return '<div class="empty slim-empty">No final scoreboard is linked to this match yet.</div>';
      const grouped = new Map();
      for (const player of players) {
        const key = scoreboardPlayerTeamKey(player);
        if (!grouped.has(key)) grouped.set(key, []);
        grouped.get(key).push(player);
      }
      const teams = Array.from(grouped.entries()).map(([key, rows]) => {
        const label = scoreboardTeamLabel(key, rows, match);
        const tone = scoreboardTeamTone(label);
        return {
          key,
          label,
          tone,
          rows: rows.slice().sort((a, b) => (Number(b.damageDone) || 0) - (Number(a.damageDone) || 0))
        };
      }).sort((a, b) => {
        const order = { friendly: 0, enemy: 1, unknown: 2 };
        return (order[a.tone] ?? 3) - (order[b.tone] ?? 3) || String(a.key).localeCompare(String(b.key));
      });
      return `
        <div class="scoreboard-table-wrap">
          <div class="scoreboard-table scoreboard-header">
            <span>Player</span><span>Side</span><span>KB</span><span>Deaths</span><span>Damage</span><span>Healing</span><span>Rating / MMR</span>
          </div>
          ${teams.map((team) => `
            <div class="scoreboard-team-divider ${team.tone}"><span>${escapeHtml(team.label)}</span><small>${team.rows.length} player${team.rows.length === 1 ? '' : 's'}</small></div>
            ${team.rows.map((player) => {
              const relation = scoreboardPlayerRelation(player, match);
              const sideLabel = relation === 'friendly' ? 'Your team' : relation === 'enemy' ? 'Enemy' : (team.label || 'Team');
              return `<div class="scoreboard-table scoreboard-row ${playerIsSelectedToon(player, match) ? 'own-player' : ''} ${relation === 'friendly' ? 'friendly-player' : relation === 'enemy' ? 'enemy-player' : ''}">
                <span>${scoreboardPlayerNameHtml(player, match)}</span>
                <span><em class="scoreboard-side-badge ${relation === 'friendly' ? 'friendly' : relation === 'enemy' ? 'enemy' : 'unknown'}">${escapeHtml(sideLabel)}</em></span>
                <span>${scoreValue(player, 'killingBlows')}</span>
                <span>${scoreValue(player, 'deaths')}</span>
                <span>${scoreValue(player, 'damageDone')}</span>
                <span>${scoreValue(player, 'healingDone')}</span>
                <span>${escapeHtml(ratingValue(player))}</span>
              </div>`;
            }).join('')}
          `).join('')}
        </div>
      `;
    }

    function renderInlineScoreboardPanel(match) {
      const hasScoreboard = hasLinkedScoreboard(match);
      const isBg = isBattlegroundMatch(match);
      const caption = hasScoreboard
        ? 'Final PvPHelper scoreboard data sits beside the Meter so damage, healing, rating, and result checks are easy to compare.'
        : 'No final scoreboard is linked yet. Sync PvPHelper.lua after /reload or logout, then link the best scoreboard snapshot to this match.';
      return `
        <div class="card scoreboard-inline-card">
          <div class="card-title-row scoreboard-inline-head">
            <div>
              <p class="small-label">Scoreboard</p>
              <h2>${hasScoreboard ? 'Final Scoreboard near the Meter' : 'Final Scoreboard not linked yet'}</h2>
              <p class="caption">${escapeHtml(caption)}</p>
            </div>
            <div class="tag-row">${pill(hasScoreboard ? `${matchScoreboardPlayers(match).length} players` : 'Waiting for PvPHelper', hasScoreboard ? 'violet' : 'amber')}${isBg ? pill('BG final totals source', 'cyan') : ''}</div>
          </div>
          ${hasScoreboard ? renderScoreboardTable(match) : '<div class="empty slim-empty">Import or sync PvPHelper.lua for final scoreboard data.</div>'}
          ${scoreboardActionButtons(match)}
        </div>
      `;
    }

    function renderScoreboardLinkRows(match) {
      const candidates = scoreboardsAvailableToLink(match);
      if (!candidates.length) {
        return `<div class="empty slim-empty">No unlinked scoreboard snapshots are available yet. Sync PvPHelper.lua after a match ends, then come back here.</div>`;
      }
      return candidates.map((candidate) => {
        const score = Number(candidate._scoreboardLinkScore || 0);
        const tone = score >= 75 ? 'emerald' : score >= 45 ? 'cyan' : 'amber';
        return `<div class="scoreboard-link-row">
          <div><strong>${escapeHtml(candidate.map || 'Unknown map')}</strong><small>${escapeHtml(matchTimestampLabel(candidate))} · ${escapeHtml(displayMatchType(candidate))} · ${matchScoreboardPlayers(candidate).length} players</small></div>
          ${pill(score ? `${score} confidence` : 'manual link', tone)}
          <button class="btn violet" data-link-scoreboard-match="${escapeHtml(candidate.id)}">Link to this match</button>
        </div>`;
      }).join('');
    }

    function renderScoreboardModal() {
      if (!state.scoreboardModalMode) return '';
      const match = selectedMatch();
      if (!match) return '';
      const isLinkMode = state.scoreboardModalMode === 'link';
      return `
        <div class="modal-scrim scoreboard-scrim" id="scoreboard-modal-scrim">
          <div class="quick-source-modal scoreboard-modal">
            <div class="modal-head">
              <div><p class="small-label">${isLinkMode ? 'Link final scoreboard' : 'Final scoreboard'}</p><h2>${escapeHtml(match.map || 'Unknown map')}</h2><p class="caption">${escapeHtml(matchTimestampLabel(match))} · ${escapeHtml(displayMatchType(match))}</p></div>
              <button class="modal-close" id="close-scoreboard-modal">×</button>
            </div>
            ${isLinkMode ? `<p class="caption preview-note">Scoreboard snapshots come from the mapped PvPHelper.lua file. Linking attaches the final scoreboard to this replay match; rating snapshots still go to the Characters tab.</p>${renderScoreboardLinkRows(match)}` : `<p class="caption preview-note">Pulled from the end-of-game PvPHelper scoreboard snapshot so you can compare your stats to theirs.</p>${renderScoreboardTable(match)}`}
            <div class="action-row preview-actions"><button class="btn" id="close-scoreboard-modal-bottom">Close</button></div>
          </div>
        </div>
      `;
    }

    return {
      matchScoreboardPlayers,
      hasLinkedScoreboard,
      isPendingScoreboardSnapshot,
      matchScoreboardAttachmentId,
      scoreboardCandidateScore,
      scoreboardsAvailableToLink,
      scoreboardActionButtons,
      playerIsSelectedToon,
      scoreValue,
      ratingValue,
      scoreboardPlayerClassColor,
      scoreboardPlayerNameHtml,
      scoreboardPlayerTeamKey,
      scoreboardPlayerRelation,
      scoreboardTeamLabel,
      scoreboardTeamTone,
      renderScoreboardTable,
      renderInlineScoreboardPanel,
      renderScoreboardLinkRows,
      renderScoreboardModal
    };
  }

  window.LastCallScoreboardView = { createScoreboardViewTools };
})();
