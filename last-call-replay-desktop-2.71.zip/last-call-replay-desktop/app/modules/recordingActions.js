(function () {
  'use strict';

  function createRecordingActions(deps = {}) {
    if (!deps || !deps.state) throw new Error('LastCallRecordingActions requires app state.');
    const state = deps.state;
    const api = deps.api || null;
    const alert = deps.alert || ((message) => window.alert(message));
    const confirm = deps.confirm || ((message) => window.confirm(message));
    const render = deps.render || (() => {});
    const renderKeepingReplay = deps.renderKeepingReplay || render;
    const selectedMatch = deps.selectedMatch || (() => null);
    const applyBackendCollectionDeltas = deps.applyBackendCollectionDeltas || (() => {});
    const applyImportJobStatus = deps.applyImportJobStatus || (() => {});
    const recordingSessionVodFor = deps.recordingSessionVodFor || (() => null);
    const recordingTitleForItem = deps.recordingTitleForItem || (() => 'Recording');
    const vodSuggestedStart = deps.vodSuggestedStart || (() => null);
    const linkVodMatches = deps.linkVodMatches || (async () => {});
    const recordingInWindowMatchIds = deps.recordingInWindowMatchIds || (() => []);
    const openRecorderSetupFromDashboard = deps.openRecorderSetupFromDashboard || (() => {});
    const formatElapsed = deps.formatElapsed || ((seconds) => String(seconds || 0));
    const allowedCaptureSources = deps.allowedCaptureSources || ((sources) => sources || []);
    const sourceSort = deps.sourceSort || ((a, b) => String((a && a.name) || '').localeCompare(String((b && b.name) || '')));
    const preferredWowSource = deps.preferredWowSource || (() => null);
    const isSourceApproved = deps.isSourceApproved || (() => false);
    const captureSourceKind = deps.captureSourceKind || (() => 'program');
    const sourceLooksLikeWow = deps.sourceLooksLikeWow || (() => false);
    const recorderPerformanceProfile = deps.recorderPerformanceProfile || (() => ({
      frameRate: 30,
      maxFrameRate: 30,
      videoBitsPerSecond: 6000000,
      chunkMs: 2000,
      mimePreference: ['video/webm;codecs=vp8,opus', 'video/webm']
    }));
    const recorderChunkMs = deps.recorderChunkMs || (() => 2000);
    const saveRecorderSettings = deps.saveRecorderSettings || (async () => {});

    let activeMediaRecorder = null;
    let activeRecordingStream = null;
    let activeRecordingId = null;
    let activeStopReason = 'Manual stop';
    let activeRecordingAudioTrackCount = 0;
    let recordingTimer = null;
    let recordingStartPending = false;
    let recordingStopPending = false;

    async function setRecordingTaskbarIndicator(active) {
      if (api && typeof api.setRecordingTaskbarIndicator === 'function') {
        try {
          await api.setRecordingTaskbarIndicator({ active: Boolean(active) });
          if (state.recorder) state.recorder.taskbarRecordingIndicatorActive = Boolean(active);
        } catch (error) {
          console.warn('[Last Call Replay] Could not update taskbar recording indicator.', error);
        }
      }
    }

    function setRecorderTransition(status, text) {
      if (!state.recorder) state.recorder = {};
      state.recorder.status = status || 'idle';
      state.recorder.transition = status === 'starting' || status === 'stopping' ? status : '';
      if (text) state.recorder.statusText = text;
    }

    async function resetRecorderAfterFailure(text) {
      await setRecordingTaskbarIndicator(false);
      recordingStartPending = false;
      recordingStopPending = false;
      setRecorderTransition('idle', text || 'Recorder idle');
      state.recorder.startedAt = 0;
      state.recorder.elapsed = 0;
    }

    function safeRecordings() {
      if (!state.recorder) state.recorder = {};
      if (!Array.isArray(state.recorder.recordings)) state.recorder.recordings = [];
      return state.recorder.recordings;
    }

    function normalizeRecorderRuntime() {
      const rec = state.recorder || {};
      const staleRecordingState = (rec.status === 'recording' || rec.status === 'stopping' || (rec.status === 'starting' && !recordingStartPending)) && !activeMediaRecorder;
      if (staleRecordingState) {
        clearInterval(recordingTimer);
        recordingTimer = null;
        rec.status = 'idle';
        rec.transition = '';
        rec.statusText = 'Ready';
        rec.startedAt = 0;
        rec.elapsed = 0;
        recordingStartPending = false;
        recordingStopPending = false;
        setRecordingTaskbarIndicator(false);
      }
    }

    function recorderIsActive() {
      const status = state.recorder && state.recorder.status;
      return Boolean(activeMediaRecorder) && (status === 'recording' || status === 'stopping');
    }

    async function linkVideoToSelectedMatch() {
      if (!api || !api.selectVideoFile || !api.linkVideoFileToMatch) return alert('Video linking is only available in the desktop app.');
      const match = selectedMatch();
      if (!match) return alert('Select a match first.');
      const filePath = await api.selectVideoFile({ matchId: match.id, matchStartIso: match.startIso });
      if (!filePath) return;
      const result = await api.linkVideoFileToMatch({ matchId: match.id, filePath });
      if (!result || !result.ok) return alert((result && result.reason) || 'Could not link video.');
      applyBackendCollectionDeltas(result || {});
      const recordings = safeRecordings();
      state.recorder.recordings = result.recordings || recordings || [result.recording, ...recordings.filter((item) => item.id !== result.recording.id)];
      if (result.matches) state.matches = result.matches;
      if (result.vods) state.vods = result.vods;
      if (result.recording && result.recording.filePath) {
        state.player.videoPath = result.recording.filePath;
        state.player.matchId = match.id;
      }
      state.active = 'Matches';
      renderKeepingReplay();
    }

    async function unlinkVideoFromSelectedMatch() {
      if (!api || !api.unlinkVideoFromMatch) return alert('Unlinking is only available in the desktop app.');
      const match = selectedMatch();
      if (!match) return;
      const result = await api.unlinkVideoFromMatch({ matchId: match.id, filePath: state.player.videoPath });
      if (!result || !result.ok) return alert((result && result.reason) || 'Could not unlink video.');
      applyBackendCollectionDeltas(result || {});
      state.recorder.recordings = result.recordings || safeRecordings().map((rec) => rec.matchId === match.id && (!state.player.videoPath || rec.filePath === state.player.videoPath) ? { ...rec, matchId: '' } : rec);
      if (result.matches) state.matches = result.matches;
      if (result.vods) state.vods = result.vods;
      state.player.videoPath = '';
      state.player.matchId = '';
      renderKeepingReplay();
    }

    async function unlinkRecording(recordingId) {
      if (!api || !api.unlinkRecording) return alert('Unlinking is only available in the desktop app.');
      const result = await api.unlinkRecording({ recordingId });
      if (!result || !result.ok) return alert((result && result.reason) || 'Could not unlink recording.');
      applyBackendCollectionDeltas(result || {});
      state.recorder.recordings = result.recordings || safeRecordings().map((rec) => rec.id === recordingId ? { ...rec, matchId: '' } : rec);
      if (result.matches) state.matches = result.matches;
      if (result.vods) state.vods = result.vods;
      renderKeepingReplay();
    }

    async function deleteRecording(recordingId, deleteFile) {
      if (!api || !api.deleteRecording) return alert('Deleting recordings is only available in the desktop app.');
      const message = deleteFile ? 'Delete this recording file from your computer too?' : 'Remove this recording from app history?';
      if (!confirm(message)) return;
      const result = await api.deleteRecording({ recordingId, deleteFile });
      if (!result || !result.ok) return alert((result && result.reason) || 'Could not delete recording.');
      applyBackendCollectionDeltas(result || {});
      state.recorder.recordings = result.recordings || safeRecordings() || [];
      if (result.matches) state.matches = result.matches;
      if (result.vods) state.vods = result.vods;
      if (result.deletedFile && state.player.videoPath === result.deletedFile) { state.player.videoPath = ''; state.player.matchId = ''; }
      render();
    }

    async function deleteSelectedRecordings(deleteFiles) {
      if (!api || !api.deleteRecording) return alert('Deleting recordings is only available in the desktop app.');
      const ids = Array.from(new Set(state.selectedRecordingIds || [])).filter(Boolean);
      if (!ids.length) return;
      const message = deleteFiles
        ? `Delete ${ids.length} recording entr${ids.length === 1 ? 'y' : 'ies'} and their video file${ids.length === 1 ? '' : 's'} from your computer?`
        : `Remove ${ids.length} recording entr${ids.length === 1 ? 'y' : 'ies'} from app history?`;
      if (!confirm(message)) return;
      let latestRecordings = safeRecordings();
      let latestMatches = state.matches;
      let latestVods = state.vods;
      for (const id of ids) {
        const result = await api.deleteRecording({ recordingId: id, deleteFile: deleteFiles });
        if (result && result.ok) {
          applyBackendCollectionDeltas(result || {});
          latestRecordings = result.recordings || state.recorder.recordings || latestRecordings;
          latestMatches = result.matches || state.matches || latestMatches;
          latestVods = result.vods || state.vods || latestVods;
          if (result.deletedFile && state.player.videoPath === result.deletedFile) { state.player.videoPath = ''; state.player.matchId = ''; }
        }
      }
      state.recorder.recordings = latestRecordings || [];
      state.matches = latestMatches || state.matches;
      state.vods = latestVods || state.vods;
      state.selectedRecordingIds = [];
      render();
    }

    async function scanRecordingsFolder(options = {}) {
      const silent = Boolean(options && options.silent === true);
      if (!api || !api.scanRecordingsFolder) {
        if (!silent) alert('Video scanning is only available in the desktop app.');
        return null;
      }
      const result = await api.scanRecordingsFolder();
      applyImportJobStatus(result || {});
      if (!result || !result.ok) {
        if (!silent) alert((result && result.reason) || 'Could not scan recordings folder.');
        return result || null;
      }
      applyBackendCollectionDeltas(result || {});
      state.recorder.recordings = result.recordings || safeRecordings() || [];
      state.matches = result.matches || state.matches || [];
      state.vods = result.vods || state.vods || [];
      if (result.settings) state.settings = { ...state.settings, ...result.settings };
      if (!silent) {
        render();
        alert(`Found ${result.found || 0} video file${result.found === 1 ? '' : 's'}. Added ${result.added || 0} new entr${result.added === 1 ? 'y' : 'ies'} to local history.`);
      }
      return result;
    }

    async function applyRecordingSuggestedMatches(recordingId, matchIds = [], options = {}) {
      const ids = Array.from(new Set((Array.isArray(matchIds) ? matchIds : [matchIds]).map((id) => String(id || '')).filter(Boolean)));
      const recording = safeRecordings().find((item) => item && item.id === recordingId);
      if (!recording || !ids.length) return;
      if (!api || !api.importVodFile || !api.linkVodToMatches) return alert('Recording mapping is only available in the desktop app.');
      const normPath = recording.filePath ? String(recording.filePath).toLowerCase().replace(/\\/g, '/') : '';
      let vod = recordingSessionVodFor(recording) || (state.vods || []).find((item) => item && normPath && item.filePath && String(item.filePath).toLowerCase().replace(/\\/g, '/') === normPath) || null;
      if (!vod) {
        const imported = await api.importVodFile({ filePaths: [recording.filePath], source: 'recording-history' });
        if (!imported || !imported.ok) return alert((imported && imported.reason) || 'Could not prepare this video for mapping.');
        applyBackendCollectionDeltas(imported || {});
        state.vods = imported.vods || state.vods || [];
        vod = imported.vod || (imported.imported && imported.imported[0]) || (state.vods || []).find((item) => item && normPath && item.filePath && String(item.filePath).toLowerCase().replace(/\\/g, '/') === normPath) || null;
      }
      if (!vod || !vod.id) return alert('Could not prepare this video for mapping.');
      const startIso = recording.startedAt || vod.startIso || (vodSuggestedStart(vod) && vodSuggestedStart(vod).iso) || '';
      if (api.updateVodMeta && startIso) {
        const updated = await api.updateVodMeta({ vodId: vod.id, label: recordingTitleForItem(recording), startIso, syncOffsetSec: Number(vod.syncOffsetSec || 0) || 0 });
        if (updated && updated.ok) {
          applyBackendCollectionDeltas(updated || {});
          state.vods = updated.vods || state.vods || [];
        }
      }
      state.selectedVodId = vod.id;
      await linkVodMatches(ids, { renderAfter: false });
      state.active = 'Recorder';
      state.recordingSuggestionOpenId = recordingId;
      state.vodStatus = `Attached ${ids.length} match${ids.length === 1 ? '' : 'es'} to this recording.`;
      if (options.renderAfter !== false) render();
    }

    async function applyRecordingSuggestedMatch(recordingId, matchId) {
      return applyRecordingSuggestedMatches(recordingId, [matchId]);
    }

    async function attachSelectedRecordingsInWindow() {
      const ids = Array.from(new Set(state.selectedRecordingIds || [])).filter(Boolean);
      if (!ids.length) return;
      let attached = 0;
      for (const recordingId of ids) {
        const recording = safeRecordings().find((item) => item && item.id === recordingId);
        const matchIds = recordingInWindowMatchIds(recording);
        if (!matchIds.length) continue;
        await applyRecordingSuggestedMatches(recordingId, matchIds, { renderAfter: false });
        attached += matchIds.length;
      }
      state.selectedRecordingIds = [];
      state.recordingSuggestionOpenId = '';
      state.vodStatus = attached ? `Attached ${attached} in-window match${attached === 1 ? '' : 'es'} from selected recordings.` : 'No in-window matches found for selected recordings.';
      render();
    }

    async function refreshCaptureSources() {
      if (!api || !api.listCaptureSources) return alert('Desktop capture API unavailable. Run through Electron.');
      state.recorder.statusText = 'Loading capture sources';
      render();
      const sources = await api.listCaptureSources();
      const usableSources = allowedCaptureSources((sources || []).filter((source) => source && source.id)).sort(sourceSort);
      state.recorder.sources = usableSources;
      if (state.recorder.selectedSourceId && !state.recorder.sources.some((source) => source.id === state.recorder.selectedSourceId)) {
        state.recorder.selectedSourceId = '';
        state.recorder.selectedSourceName = 'No source selected';
        state.recorder.selectedSourceKind = '';
        state.recorder.sourceApproved = false;
        state.recorder.sourceApprovalRequired = false;
      }
      const sourceError = (sources || []).find((source) => source && source.error);
      if (sourceError) {
        state.recorder.statusText = `Capture source scan failed: ${sourceError.error}`;
      } else if (state.recorder.sources.length) {
        const current = state.recorder.sources.find((source) => source.id === state.recorder.selectedSourceId);
        const wow = preferredWowSource(state.recorder.sources);
        if (!current && wow) {
          const approved = isSourceApproved(wow);
          await selectCaptureSource(wow.id, wow.name, false, approved, !approved, captureSourceKind(wow));
          state.recorder.statusText = approved
            ? 'World of Warcraft detected and ready.'
            : 'World of Warcraft detected. Approve it once to use it as your default source.';
        } else if (current) {
          state.recorder.selectedSourceKind = captureSourceKind(current);
          state.recorder.statusText = captureSourceKind(current) === 'program'
            ? 'World of Warcraft window selected. Windowed WoW is supported.'
            : 'Screen source selected.';
        } else {
          state.recorder.statusText = 'Choose a capture source';
        }
      } else {
        state.recorder.statusText = 'No capture sources found';
      }
      render();
    }

    async function rememberApprovedCaptureSource(source) {
      if (!source || !sourceLooksLikeWow(source)) return;
      const name = source.name || source.id || '';
      const existing = state.recorder.approvedWowSourceNames || [];
      const normalizedSourceName = (value) => String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
      if (!existing.some((item) => normalizedSourceName(item) === normalizedSourceName(name))) {
        state.recorder.approvedWowSourceNames = [...existing, name];
      }
      await saveRecorderSettings();
    }

    async function selectCaptureSource(sourceId, sourceName, shouldRender = true, approved = true, approvalRequired = false, sourceKind = '') {
      state.recorder.selectedSourceId = sourceId || '';
      state.recorder.selectedSourceName = sourceName || 'Selected source';
      const selected = state.recorder.sources.find((source) => source.id === sourceId);
      state.recorder.selectedSourceKind = sourceKind || (selected ? captureSourceKind(selected) : '');
      state.recorder.sourceApprovalRequired = Boolean(approvalRequired && sourceId);
      state.recorder.sourceApproved = state.recorder.sourceApprovalRequired ? Boolean(approved) : Boolean(sourceId);
      if (state.recorder.sourceApprovalRequired && !state.recorder.sourceApproved) {
        state.recorder.statusText = 'World of Warcraft suggested. Approve it or choose another source.';
      } else if (sourceId) {
        state.recorder.statusText = state.recorder.selectedSourceKind === 'program'
          ? 'World of Warcraft window selected. Windowed WoW is supported.'
          : 'Screen source selected.';
      }
      if (state.recorder.sourceApproved && api && api.setCaptureSource) await api.setCaptureSource({ sourceId, includeAudio: state.recorder.includeAudio });
      if (state.recorder.sourceApproved && selected && sourceLooksLikeWow(selected)) await rememberApprovedCaptureSource(selected);
      if (shouldRender) render();
    }

    async function applyCapturePreferences(stream) {
      try {
        const track = stream && stream.getVideoTracks ? stream.getVideoTracks()[0] : null;
        const profile = recorderPerformanceProfile();
        if (track && track.applyConstraints) {
          await track.applyConstraints({ frameRate: { ideal: profile.frameRate, max: profile.maxFrameRate } });
        }
      } catch (error) {
        // Frame-rate preferences should never block recording. Some Windows capture
        // paths reject constraints even after a valid picker selection.
        console.warn('[Last Call Replay] Capture preference ignored.', error);
      }
      return stream;
    }

    async function getSelectedCaptureStream() {
      const selected = state.recorder.sources.find((source) => source.id === state.recorder.selectedSourceId);
      const isScreen = selected && captureSourceKind(selected) === 'screen';
      const errors = [];

      const wantsAudio = Boolean(state.recorder.includeAudio);
      const pickerRequests = wantsAudio
        ? [
            { video: true, audio: true },
            { video: true, audio: { systemAudio: 'include' } },
            { video: true, audio: false },
            { video: true }
          ]
        : [
            { video: true, audio: false },
            { video: true }
          ];

      for (const request of pickerRequests) {
        try {
          const stream = await navigator.mediaDevices.getDisplayMedia(request);
          return await applyCapturePreferences(stream);
        } catch (error) {
          errors.push(error);
          console.warn('[Last Call Replay] Selected-source capture failed.', error);
        }
      }

      if (isScreen && selected && selected.id) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
              mandatory: {
                chromeMediaSource: 'desktop',
                chromeMediaSourceId: selected.id
              }
            }
          });
          return await applyCapturePreferences(stream);
        } catch (error) {
          errors.push(error);
          console.warn('[Last Call Replay] Direct screen fallback failed.', error);
        }
      }

      const finalError = errors[errors.length - 1] || new Error('Capture failed');
      finalError.captureAttempts = errors.map(captureErrorMessage).filter(Boolean);
      throw finalError;
    }

    function captureErrorMessage(error) {
      const parts = [];
      if (error && error.name) parts.push(error.name);
      if (error && error.message) parts.push(error.message);
      if (error && error.primaryCaptureError && error.primaryCaptureError.message) parts.push(`First try: ${error.primaryCaptureError.message}`);
      if (Array.isArray(error && error.captureAttempts) && error.captureAttempts.length) parts.push(`Attempts: ${error.captureAttempts.join(' | ')}`);
      return parts.join(' · ') || 'Capture failed';
    }

    function chooseMimeType() {
      const profile = recorderPerformanceProfile();
      const options = profile.mimePreference || ['video/webm;codecs=vp8,opus', 'video/webm'];
      return options.find((type) => window.MediaRecorder && MediaRecorder.isTypeSupported(type)) || '';
    }

    function createMediaRecorder(stream, mimeType) {
      const profile = recorderPerformanceProfile();
      const options = { videoBitsPerSecond: profile.videoBitsPerSecond };
      if (mimeType) options.mimeType = mimeType;
      try {
        return new MediaRecorder(stream, options);
      } catch (error) {
        console.warn('[Last Call Replay] Performance recorder options rejected. Falling back to browser defaults.', error);
        return new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
      }
    }

    async function startRecording() {
      if (!api) return alert('Desktop API unavailable. Run through Electron.');
      if (activeMediaRecorder || recordingStartPending || recordingStopPending) return;
      if (!state.settings.recordingsDir || !state.settings.recordingsDirConfirmed) {
        state.active = 'Recorder';
        render();
        return alert('Choose a storage folder before starting a recording.');
      }
      if (!state.recorder.selectedSourceId) {
        openRecorderSetupFromDashboard();
        return alert('Pick a capture source first. Use World of Warcraft if it appears, or choose a screen if window capture acts cursed.');
      }
      if (state.recorder.sourceApprovalRequired && !state.recorder.sourceApproved) {
        openRecorderSetupFromDashboard();
        return alert('Approve the suggested World of Warcraft source, or choose another source manually.');
      }
      recordingStartPending = true;
      setRecorderTransition('starting', 'Starting recorder…');
      state.recorder.elapsed = 0;
      render();
      const selected = state.recorder.sources.find((source) => source.id === state.recorder.selectedSourceId);
      const label = selected ? selected.name : 'World of Warcraft';
      try {
        await api.setCaptureSource({ sourceId: state.recorder.selectedSourceId, includeAudio: state.recorder.includeAudio });
        const created = await api.createRecording({ label, sourceName: label, matchId: '', includeAudio: state.recorder.includeAudio });
        if (!created || !created.ok) {
          await resetRecorderAfterFailure((created && created.reason) || 'Could not create recording file.');
          render();
          return alert((created && created.reason) || 'Could not create recording file.');
        }
        activeRecordingId = created.recordingId;
        activeStopReason = 'Manual stop';
        activeRecordingStream = await getSelectedCaptureStream();
        activeRecordingAudioTrackCount = activeRecordingStream && activeRecordingStream.getAudioTracks ? activeRecordingStream.getAudioTracks().length : 0;
        state.recorder.outputPath = created.filePath;
      } catch (error) {
        if (activeRecordingId && api && api.finishRecording) await api.finishRecording({ recordingId: activeRecordingId, reason: 'Capture failed' });
        activeRecordingStream?.getTracks().forEach((track) => track.stop());
        activeRecordingStream = null;
        activeRecordingId = null;
        activeRecordingAudioTrackCount = 0;
        await resetRecorderAfterFailure('Capture failed. Try choosing a Screen source instead of a window source.');
        render();
        alert(`Capture failed. Try choosing a Screen/Monitor source instead of the World of Warcraft window. Window capture can be blocked by WoW, overlays, GPU settings, or Windows capture permissions.\n\n${captureErrorMessage(error)}`);
        return;
      }
      const mimeType = chooseMimeType();
      activeMediaRecorder = createMediaRecorder(activeRecordingStream, mimeType);
      activeMediaRecorder.ondataavailable = async (event) => {
        if (!event.data || event.data.size <= 0 || !activeRecordingId) return;
        const chunk = await event.data.arrayBuffer();
        await api.appendRecordingChunk({ recordingId: activeRecordingId, chunk });
      };
      activeMediaRecorder.onstop = async () => {
        const finishedId = activeRecordingId;
        const reason = activeStopReason;
        const finalAudioTrackCount = activeRecordingAudioTrackCount;
        activeRecordingStream?.getTracks().forEach((track) => track.stop());
        activeRecordingStream = null;
        activeMediaRecorder = null;
        activeRecordingId = null;
        activeRecordingAudioTrackCount = 0;
        clearInterval(recordingTimer);
        recordingTimer = null;
        await setRecordingTaskbarIndicator(false);
        recordingStartPending = false;
        recordingStopPending = false;
        let result = null;
        if (finishedId) result = await api.finishRecording({ recordingId: finishedId, reason, audioTrackCount: finalAudioTrackCount });
        if (result && result.recording) {
          applyBackendCollectionDeltas(result || {});
          const recordings = safeRecordings();
          state.recorder.recordings = result.recordings || recordings || [result.recording, ...recordings.filter((item) => item.id !== result.recording.id)];
          if (result.matches) state.matches = result.matches;
          if (result.vods) state.vods = result.vods;
          state.recorder.outputPath = result.recording.filePath;
          const linkedIds = Array.isArray(result.recording.linkedMatchIds) ? result.recording.linkedMatchIds : (result.recording.matchId ? [result.recording.matchId] : []);
          if (linkedIds.length) {
            state.player.videoPath = result.recording.filePath;
            state.player.matchId = linkedIds[0];
          }
        }
        setRecorderTransition('idle', `Saved: ${reason}`);
        state.recorder.startedAt = 0;
        state.recorder.elapsed = 0;
        render();
      };
      try {
        activeMediaRecorder.start(recorderChunkMs());
      } catch (error) {
        activeRecordingStream?.getTracks().forEach((track) => track.stop());
        activeRecordingStream = null;
        activeMediaRecorder = null;
        if (activeRecordingId && api && api.finishRecording) await api.finishRecording({ recordingId: activeRecordingId, reason: 'Recording failed to start' });
        activeRecordingId = null;
        activeRecordingAudioTrackCount = 0;
        await resetRecorderAfterFailure('Recording failed to start. Try another source.');
        render();
        alert(`Recording failed to start. Try choosing another capture source.\n\n${captureErrorMessage(error)}`);
        return;
      }
      recordingStartPending = false;
      setRecorderTransition('recording', 'Recording locally');
      state.recorder.startedAt = Date.now();
      state.recorder.elapsed = 0;
      await setRecordingTaskbarIndicator(true);
      recordingTimer = setInterval(() => {
        state.recorder.elapsed = Math.floor((Date.now() - state.recorder.startedAt) / 1000);
        const elapsedNode = document.querySelector('.recorder-status-grid .info-box:nth-child(2) .value');
        if (elapsedNode) elapsedNode.textContent = formatElapsed(state.recorder.elapsed);
        const sidebarNode = document.getElementById('sidebar-recorder-time');
        if (sidebarNode) sidebarNode.textContent = `Recording ${formatElapsed(state.recorder.elapsed)}`;
      }, 1000);
      render();
    }

    async function stopRecording(reason) {
      if (recordingStopPending) return;
      if (!activeMediaRecorder) {
        normalizeRecorderRuntime();
        await setRecordingTaskbarIndicator(false);
        render();
        return;
      }
      if (activeMediaRecorder.state === 'inactive') {
        normalizeRecorderRuntime();
        await setRecordingTaskbarIndicator(false);
        render();
        return;
      }
      recordingStopPending = true;
      activeStopReason = reason || 'Manual stop';
      setRecorderTransition('stopping', 'Stopping and saving…');
      render();
      try {
        if (activeMediaRecorder.state === 'recording') {
          try { activeMediaRecorder.requestData(); } catch (_chunkError) {}
          setTimeout(() => {
            try {
              if (activeMediaRecorder && activeMediaRecorder.state !== 'inactive') activeMediaRecorder.stop();
            } catch (_stopError) {
              activeRecordingStream?.getTracks().forEach((track) => track.stop());
            }
          }, 250);
        }
      } catch (_error) {
        activeRecordingStream?.getTracks().forEach((track) => track.stop());
        await setRecordingTaskbarIndicator(false);
        recordingStopPending = false;
        setRecorderTransition('idle', 'Recording stopped with an error.');
        render();
      }
    }

    return {
      normalizeRecorderRuntime,
      recorderIsActive,
      linkVideoToSelectedMatch,
      unlinkVideoFromSelectedMatch,
      unlinkRecording,
      deleteRecording,
      deleteSelectedRecordings,
      scanRecordingsFolder,
      applyRecordingSuggestedMatches,
      applyRecordingSuggestedMatch,
      attachSelectedRecordingsInWindow,
      refreshCaptureSources,
      selectCaptureSource,
      applyCapturePreferences,
      getSelectedCaptureStream,
      captureErrorMessage,
      chooseMimeType,
      createMediaRecorder,
      startRecording,
      stopRecording
    };
  }

  window.LastCallRecordingActions = { createRecordingActions };
})();
