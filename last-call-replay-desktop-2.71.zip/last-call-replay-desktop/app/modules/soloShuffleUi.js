(function () {
  'use strict';

  function createSoloShuffleUiTools(deps = {}) {
    const state = deps.state || {};
    const escapeHtml = deps.escapeHtml || ((value) => String(value ?? ''));
    const shortNameKey = deps.shortNameKey || ((value) => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, ''));
    const normalizedMatchType = deps.normalizedMatchType || ((match) => (match && (match.matchType || match.bracket)) || '');
    const normalizedMapKey = deps.normalizedMapKey || ((value) => String(value || '').trim().toLowerCase());
    const isPendingScoreboardSnapshot = deps.isPendingScoreboardSnapshot || (() => false);
    const displayResult = deps.displayResult || ((value) => String(value || 'Unscored'));
    const selectedMatch = deps.selectedMatch || (() => null);

    function ownNameSetForMatch(match) {
      const names = new Set(((match && match.ownNames) || []).filter(Boolean));
      if (match && match.alt) names.add(match.alt);
      return names;
    }

    function enemyIdentityKey(name) {
      const key = shortNameKey(name);
      return key || String(name || '').trim().toLowerCase();
    }

    function namesShareEnemyIdentity(left, right) {
      return Boolean(left && right && enemyIdentityKey(left) === enemyIdentityKey(right));
    }

    function isSoloShuffleUiMatch(match = {}) {
      return Boolean(match && (match.isSoloShuffle || /shuffle/i.test(normalizedMatchType(match) || match.matchType || match.bracket || '')));
    }

    function isSoloShuffleLobbyUiMatch(match = {}) {
      return Boolean(match && match.isSoloShuffleLobby && Array.isArray(match.soloRounds));
    }

    function isSoloShuffleRoundChildUiMatch(match = {}) {
      return Boolean(match && match.isSoloShuffleRoundChild);
    }

    function matchStartMs(match = {}) {
      return Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0) || Number(match.gameStartMs) || (match.gameStartIso ? Date.parse(match.gameStartIso) : 0) || 0;
    }

    function matchEndMs(match = {}) {
      return Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0) || (matchStartMs(match) ? matchStartMs(match) + Math.max(1, Number(match.durationSec || 0)) * 1000 : 0);
    }

    function soloPlayerKeys(match = {}) {
      return new Set([...(match.participants || []), ...(match.ownNames || []), ...(match.myComp || []), ...(match.enemyComp || []), ...(match.enemies || [])]
        .map(enemyIdentityKey)
        .filter(Boolean));
    }

    function soloPlayerOverlap(left = {}, right = {}) {
      const a = soloPlayerKeys(left);
      const b = soloPlayerKeys(right);
      if (!a.size || !b.size) return 999;
      let count = 0;
      a.forEach((key) => { if (b.has(key)) count += 1; });
      return count;
    }

    function soloMapCompatible(left = {}, right = {}) {
      const a = normalizedMapKey(left.map || left.zone || left.subzone || '');
      const b = normalizedMapKey(right.map || right.zone || right.subzone || '');
      return !a || !b || a === b;
    }

    function soloTimeOverlaps(match = {}, lobby = {}, padMs = 6 * 60 * 1000) {
      const start = matchStartMs(match);
      const end = matchEndMs(match) || start;
      const lobbyStart = Number(lobby.soloShuffleSessionStartMs) || matchStartMs(lobby);
      const lobbyEnd = Number(lobby.soloShuffleSessionEndMs) || matchEndMs(lobby) || lobbyStart;
      if (!start || !lobbyStart || !lobbyEnd) return false;
      return start <= lobbyEnd + padMs && end >= lobbyStart - padMs;
    }

    function isOneRoundSoloShell(match = {}) {
      if (!isSoloShuffleUiMatch(match)) return false;
      if (isSoloShuffleRoundChildUiMatch(match) || match.hideFromMatchLibrary) return true;
      const rounds = soloShuffleRounds(match);
      const detected = Number(match.soloShuffleDetectedRoundCount || 0) || rounds.length || Number(match.soloShuffleRoundCount || 0) || 0;
      const duration = Number(match.durationSec || 0) || Math.round(Math.max(0, matchEndMs(match) - matchStartMs(match)) / 1000);
      return detected <= 1 || rounds.length <= 1 || duration <= 5 * 60;
    }

    function findSoloShuffleParentForMatch(match = {}) {
      if (!match || !isSoloShuffleUiMatch(match)) return null;
      if (isSoloShuffleLobbyUiMatch(match) && !match.hideFromMatchLibrary && !isOneRoundSoloShell(match)) return match;
      const matches = Array.isArray(state.matches) ? state.matches : [];
      const parentId = String(match.parentLobbyMatchId || '');
      if (parentId) {
        const direct = matches.find((item) => item && String(item.id || '') === parentId && isSoloShuffleLobbyUiMatch(item));
        if (direct) return direct;
      }
      const matchId = String(match.id || match.roundMatchId || '');
      if (matchId) {
        const byRoundId = matches.find((item) => item && isSoloShuffleLobbyUiMatch(item) && soloShuffleRounds(item).some((round) => String(round.roundMatchId || round.id || '') === matchId));
        if (byRoundId) return byRoundId;
      }
      const sessionKey = String(match.soloShuffleSessionKey || '');
      if (sessionKey) {
        const bySession = matches.find((item) => item && isSoloShuffleLobbyUiMatch(item) && String(item.soloShuffleSessionKey || '') === sessionKey);
        if (bySession) return bySession;
      }
      if (!isOneRoundSoloShell(match)) return null;
      return matches.find((item) => item && isSoloShuffleLobbyUiMatch(item)
        && String(item.id || '') !== String(match.id || '')
        && soloMapCompatible(match, item)
        && soloTimeOverlaps(match, item)
        && soloPlayerOverlap(match, item) >= 3) || null;
    }

    function visibleLibraryMatch(match = {}) {
      if (!match || isPendingScoreboardSnapshot(match)) return false;
      if (match.hideFromMatchLibrary || isSoloShuffleRoundChildUiMatch(match)) return false;
      if (isSoloShuffleUiMatch(match) && !isSoloShuffleLobbyUiMatch(match) && findSoloShuffleParentForMatch(match)) return false;
      if (isSoloShuffleLobbyUiMatch(match) && isOneRoundSoloShell(match)) {
        const parent = findSoloShuffleParentForMatch(match);
        if (parent && String(parent.id || '') !== String(match.id || '')) return false;
      }
      return true;
    }

    function soloShuffleSummaryText(match = {}) {
      const wins = Number(match.soloShuffleWins || 0) || 0;
      const losses = Number(match.soloShuffleLosses || 0) || 0;
      return `${wins}W - ${losses}L`;
    }

    function soloShuffleRounds(match = {}) {
      return Array.isArray(match && match.soloRounds)
        ? match.soloRounds.filter(Boolean).sort((a, b) => (Number(a.roundNumber) || 0) - (Number(b.roundNumber) || 0))
        : [];
    }

    function selectedSoloShuffleRoundNumber(match = {}) {
      const rounds = soloShuffleRounds(match);
      const first = rounds[0] ? Number(rounds[0].roundNumber || 1) : 1;
      const stored = state.soloShuffleSelectedRounds && state.soloShuffleSelectedRounds[match.id]
        ? Number(state.soloShuffleSelectedRounds[match.id])
        : first;
      return rounds.some((round) => Number(round.roundNumber) === stored) ? stored : first;
    }

    function selectedSoloShuffleRound(match = {}) {
      const target = selectedSoloShuffleRoundNumber(match);
      return soloShuffleRounds(match).find((round) => Number(round.roundNumber) === target) || soloShuffleRounds(match)[0] || null;
    }

    function soloShuffleRoundTone(result = '') {
      const value = displayResult(result);
      if (value === 'Win') return 'win';
      if (value === 'Loss') return 'loss';
      if (/incomplete|unclear/i.test(String(result || ''))) return 'unclear';
      return 'unknown';
    }

    function renderSoloShuffleRoundDots(match = {}, clickable = false, extraClass = '') {
      if (!isSoloShuffleLobbyUiMatch(match)) return '';
      const rounds = soloShuffleRounds(match);
      const active = selectedSoloShuffleRoundNumber(match);
      const byNum = new Map(rounds.map((round) => [Number(round.roundNumber || 0), round]));
      const buttons = [];
      for (let i = 1; i <= 6; i += 1) {
        const round = byNum.get(i);
        const result = round ? displayResult(round.result) : 'Unknown';
        const tone = round ? soloShuffleRoundTone(round.result) : 'missing';
        const label = round ? `${result === 'Unscored' ? 'Unknown' : result} · Round ${i}` : `Missing · Round ${i}`;
        const text = round ? (result === 'Win' ? 'W' : result === 'Loss' ? 'L' : '?') : '';
        const cls = `solo-round-dot ${tone} ${Number(active) === i ? 'active' : ''} ${round ? '' : 'empty'}`;
        buttons.push(clickable && round
          ? `<button class="${cls}" data-solo-round="${i}" title="${escapeHtml(label)}"><span>${escapeHtml(text)}</span></button>`
          : `<span class="${cls}" title="${escapeHtml(label)}"><span>${escapeHtml(text)}</span></span>`);
      }
      const rowClass = ['solo-round-dot-row', extraClass].filter(Boolean).join(' ');
      return `<div class="${escapeHtml(rowClass)}" aria-label="Solo Shuffle rounds">${buttons.join('')}</div>`;
    }

    function soloShuffleRoundOffsets(parent = {}, round = {}) {
      const parentStart = Number(parent.soloShuffleSessionStartMs || parent.startMs || 0) || 0;
      const roundStart = Number(round.startMs || 0) || 0;
      const roundEnd = Number(round.endMs || 0) || 0;
      const startOffset = parentStart && roundStart ? Math.max(0, (roundStart - parentStart) / 1000) : Number(round.startOffsetSec || 0) || 0;
      const endOffset = parentStart && roundEnd ? Math.max(startOffset + 1, (roundEnd - parentStart) / 1000) : Number(round.endOffsetSec || startOffset + Number(round.durationSec || 60)) || startOffset + 60;
      return { startOffset, endOffset };
    }

    function soloShuffleRoundVideoBounds(parent = {}, round = {}) {
      const lobbyVideoStart = Number.isFinite(Number(parent.videoShuffleStartSec))
        ? Number(parent.videoShuffleStartSec)
        : (Number.isFinite(Number(parent.videoMatchStartSec))
          ? Number(parent.videoMatchStartSec)
          : (Number.isFinite(Number(parent.videoClipStartSec)) ? Number(parent.videoClipStartSec) : 0));
      const { startOffset, endOffset } = soloShuffleRoundOffsets(parent, round);
      const rawStart = Math.max(0, Math.round((lobbyVideoStart + startOffset) * 10) / 10);
      const rawEnd = Math.max(rawStart + 1, Math.round((lobbyVideoStart + endOffset) * 10) / 10);
      return { rawStart, rawEnd };
    }

    function soloShuffleRoundScopedEvents(parent = {}, round = {}, fieldName = 'eventFeed') {
      const roundSource = Array.isArray(round[fieldName]) ? round[fieldName] : [];
      const parentSource = Array.isArray(parent[fieldName]) ? parent[fieldName] : [];
      const { startOffset, endOffset } = soloShuffleRoundOffsets(parent, round);
      const duration = Math.max(1, endOffset - startOffset);
      const source = roundSource.length ? roundSource : parentSource;
      if (!source.length) return [];
      const times = source.map((ev) => Number(ev && ev.relativeSec)).filter(Number.isFinite);
      const min = times.length ? Math.min(...times) : 0;
      const max = times.length ? Math.max(...times) : 0;
      const alreadyRoundRelative = roundSource.length && min >= -0.25 && max <= duration + 8;
      if (alreadyRoundRelative) return roundSource;
      const scoped = source.filter((ev) => {
        const rel = Number(ev && ev.relativeSec);
        if (!Number.isFinite(rel)) return false;
        return rel >= startOffset - 0.35 && rel <= endOffset + 0.35;
      }).map((ev) => {
        const rel = Number(ev && ev.relativeSec);
        return {
          ...ev,
          lobbyRelativeSec: Number.isFinite(rel) ? rel : undefined,
          relativeSec: Number.isFinite(rel) ? Math.max(0, Math.round((rel - startOffset) * 10) / 10) : ev.relativeSec
        };
      });
      return scoped;
    }

    function soloShuffleScopedTimelineRows(parent = {}, round = {}, fieldName = '') {
      const roundSource = Array.isArray(round[fieldName]) ? round[fieldName] : [];
      if (roundSource.length) return roundSource;
      const parentSource = Array.isArray(parent[fieldName]) ? parent[fieldName] : [];
      if (!parentSource.length) return [];
      const { startOffset, endOffset } = soloShuffleRoundOffsets(parent, round);
      return parentSource.filter((item) => {
        const rel = Number(item && (item.relativeSec ?? item.timeSec ?? item.sec));
        if (!Number.isFinite(rel)) return false;
        return rel >= startOffset - 0.35 && rel <= endOffset + 0.35;
      }).map((item) => {
        const rel = Number(item && (item.relativeSec ?? item.timeSec ?? item.sec));
        if (!Number.isFinite(rel)) return { ...item };
        return {
          ...item,
          lobbyRelativeSec: item.lobbyRelativeSec ?? rel,
          relativeSec: Math.max(0, Math.round((rel - startOffset) * 10) / 10)
        };
      });
    }

    function soloShuffleRoundEventRowCount(round = {}, eventFeed = [], rawEvents = []) {
      return Math.max(
        Array.isArray(eventFeed) ? eventFeed.length : 0,
        Array.isArray(rawEvents) ? rawEvents.length : 0,
        Array.isArray(round.eventFeed) ? round.eventFeed.length : 0,
        Array.isArray(round.rawEvents) ? round.rawEvents.length : 0,
        Number(round.eventFeedRows || 0) || 0,
        Number(round.eventFeedCachedRows || 0) || 0
      );
    }

    function soloShuffleRoundFeedSource(parent = {}, round = {}, eventFeed = []) {
      if (Array.isArray(round.eventFeed) && round.eventFeed.length) return 'round data';
      if (Array.isArray(round.rawEvents) && round.rawEvents.length) return 'round raw events';
      if (round.eventFeedCacheRef) return eventFeed.length ? 'round cache preview' : 'round cache hydration pending';
      if (Array.isArray(parent.eventFeed) && parent.eventFeed.length && eventFeed.length) return 'parent scoped data';
      if (Array.isArray(parent.rawEvents) && parent.rawEvents.length && eventFeed.length) return 'parent scoped raw events';
      return 'empty';
    }

    function soloShuffleRoundContextMatch(parent = {}) {
      if (!isSoloShuffleLobbyUiMatch(parent)) return parent;
      const round = selectedSoloShuffleRound(parent) || {};
      const bounds = soloShuffleRoundVideoBounds(parent, round);
      const offsets = soloShuffleRoundOffsets(parent, round);
      const mergedMetrics = round.metrics || {};
      const roundEventFeed = soloShuffleRoundScopedEvents(parent, round, 'eventFeed');
      const roundRawEvents = soloShuffleRoundScopedEvents(parent, round, 'rawEvents');
      const roundFeedRows = soloShuffleRoundEventRowCount(round, roundEventFeed, roundRawEvents);
      const selectedRoundNumber = Number(round.roundNumber || 1);
      const deathVictim = (round.death && round.death.victim && round.death.victim !== 'No death detected')
        ? round.death.victim
        : (round.endVictim || round.firstDeath || '');
      const feedSource = soloShuffleRoundFeedSource(parent, round, roundEventFeed);
      const roundCacheRef = round.eventFeedCacheRef || '';
      return {
        ...parent,
        ...round,
        id: parent.id,
        parentLobbyMatchId: parent.id,
        isSoloShuffle: true,
        isSoloShuffleLobbyContext: true,
        isSoloShuffleLobby: false,
        matchType: 'Solo Shuffle',
        bracket: 'Solo Shuffle',
        map: round.map || parent.map || 'Unknown arena',
        alt: parent.alt || round.alt || '',
        participants: parent.participants || [],
        classByName: parent.classByName || {},
        specByName: parent.specByName || {},
        videoPath: parent.videoPath || '',
        videoLabel: parent.videoLabel || '',
        videoLinkedAt: parent.videoLinkedAt || '',
        videoLinkMode: parent.videoLinkMode || '',
        vodId: parent.vodId || '',
        vodLinkedAt: parent.vodLinkedAt || '',
        videoSessionId: parent.videoSessionId || '',
        videoClipStartSec: Number.isFinite(Number(parent.videoClipStartSec)) ? Math.max(0, Math.min(Number(parent.videoClipStartSec), bounds.rawStart)) : Math.max(0, bounds.rawStart),
        videoClipEndSec: bounds.rawEnd,
        videoMatchStartSec: bounds.rawStart,
        videoMatchEndSec: bounds.rawEnd,
        videoShuffleStartSec: undefined,
        videoShuffleEndSec: undefined,
        videoClipPreRollSec: parent.videoClipPreRollSec,
        videoClipPostRollSec: parent.videoClipPostRollSec,
        videoSyncAdjustmentSec: parent.videoSyncAdjustmentSec,
        metrics: mergedMetrics,
        damage: round.damage || mergedMetrics.Damage || [],
        healing: round.healing || mergedMetrics.Healing || [],
        taken: round.taken || mergedMetrics.Taken || [],
        cooldowns: soloShuffleScopedTimelineRows(parent, round, 'cooldowns'),
        ccChains: soloShuffleScopedTimelineRows(parent, round, 'ccChains'),
        interrupts: soloShuffleScopedTimelineRows(parent, round, 'interrupts'),
        chart: soloShuffleScopedTimelineRows(parent, round, 'chart'),
        eventFeed: roundEventFeed,
        rawEvents: roundRawEvents.length ? roundRawEvents : roundEventFeed,
        eventFeedRows: roundFeedRows || roundEventFeed.length,
        eventFeedCachedRows: Number(round.eventFeedCachedRows || 0) || roundFeedRows || roundEventFeed.length,
        eventFeedCacheRef: roundCacheRef,
        eventFeedHydrated: Boolean(round.eventFeedHydrated) || Boolean(roundFeedRows && roundFeedRows <= roundEventFeed.length),
        eventFeedCachedAt: round.eventFeedCachedAt || '',
        eventFeedCacheError: round.eventFeedCacheError || '',
        healthTimeline: round.healthTimeline || null,
        death: round.death || null,
        deaths: Array.isArray(round.deaths) ? round.deaths : [],
        selectedRoundNumber,
        soloRoundContextKey: `${parent.id || ''}:round:${selectedRoundNumber}:${Math.round(offsets.startOffset * 10) / 10}:${Math.round(offsets.endOffset * 10) / 10}:${roundFeedRows}:${roundCacheRef}`,
        roundStartOffsetSec: offsets.startOffset,
        roundEndOffsetSec: offsets.endOffset,
        soloShuffleParentSummary: soloShuffleSummaryText(parent),
        soloRoundDiagnostics: {
          roundNumber: selectedRoundNumber,
          startOffsetSec: offsets.startOffset,
          endOffsetSec: offsets.endOffset,
          eventFeedCount: roundEventFeed.length,
          rawEventsCount: roundRawEvents.length,
          selectedDeathVictim: deathVictim,
          feedSource
        }
      };
    }

    function soloShuffleStatsMatch(parent = {}) {
      if (!isSoloShuffleLobbyUiMatch(parent)) return parent;
      return state.soloShuffleStatsMode === 'full' ? parent : soloShuffleRoundContextMatch(parent);
    }

    function currentReplayMatch() {
      const match = selectedMatch();
      return isSoloShuffleLobbyUiMatch(match) ? soloShuffleRoundContextMatch(match) : match;
    }

    function soloShuffleSessionIdentity(match = {}) {
      if (!match || !isSoloShuffleUiMatch(match)) return '';
      if (match.soloShuffleSessionKey) return String(match.soloShuffleSessionKey);
      const sessionStart = Number(match.soloShuffleSessionStartMs) || Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0) || 0;
      const bucket = sessionStart ? Math.round(sessionStart / (8 * 60 * 1000)) : '';
      const map = normalizedMapKey(match.map || match.zone || match.subzone || '');
      const players = Array.from(new Set([...(match.participants || []), ...(match.ownNames || []), ...(match.myComp || []), ...(match.enemyComp || []), ...(match.enemies || [])].map(enemyIdentityKey).filter(Boolean))).sort().join('|');
      return `solo-session:${bucket}:${map}:${players || match.id || ''}`;
    }

    function soloShufflePlayerSeenKey(match = {}, playerName = '') {
      if (!isSoloShuffleUiMatch(match)) return '';
      return `solo-seen:${soloShuffleSessionIdentity(match)}:${enemyIdentityKey(playerName)}`;
    }

    function soloShufflePlayerRoundKey(match = {}, playerName = '') {
      if (!isSoloShuffleUiMatch(match)) return '';
      const round = Number(match.soloShuffleRound || 0);
      const start = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0) || 0;
      const roundPart = round ? `round-${round}` : (start ? `start-${Math.round(start / 1000)}` : (match.id || 'round'));
      return `solo-round:${soloShuffleSessionIdentity(match)}:${roundPart}:${enemyIdentityKey(playerName)}`;
    }

    return {
      ownNameSetForMatch,
      enemyIdentityKey,
      namesShareEnemyIdentity,
      isSoloShuffleUiMatch,
      isSoloShuffleLobbyUiMatch,
      isSoloShuffleRoundChildUiMatch,
      findSoloShuffleParentForMatch,
      visibleLibraryMatch,
      soloShuffleSummaryText,
      soloShuffleRounds,
      selectedSoloShuffleRoundNumber,
      selectedSoloShuffleRound,
      soloShuffleRoundTone,
      renderSoloShuffleRoundDots,
      soloShuffleRoundVideoBounds,
      soloShuffleRoundContextMatch,
      soloShuffleStatsMatch,
      currentReplayMatch,
      soloShuffleSessionIdentity,
      soloShufflePlayerSeenKey,
      soloShufflePlayerRoundKey
    };
  }

  window.LastCallSoloShuffleUi = { createSoloShuffleUiTools };
})();
