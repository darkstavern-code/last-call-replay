(function () {
  'use strict';

  function createReplayHealthTimelineTools(deps = {}) {
    const state = deps.state || { player: {} };
    const isBattlegroundMatch = deps.isBattlegroundMatch || (() => false);
    const selectedMatch = deps.selectedMatch || (() => null);
    const renderKeepingReplay = deps.renderKeepingReplay || (() => {});
    const formatElapsed = deps.formatElapsed || ((value) => String(value || 0));
    const shortCharacterName = deps.shortCharacterName || ((name) => String(name || '').split('-')[0]);
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const perfCache = window.LastCallPerformanceCache && typeof window.LastCallPerformanceCache.createPerformanceCacheTools === 'function'
      ? window.LastCallPerformanceCache.createPerformanceCacheTools({ maxEntries: 120 })
      : null;
    let healthWindowRenderTimer = null;

    function healthTimelineModeForMatch(match) {
      if (isBattlegroundMatch(match)) return 'deathWindow';
      return state.player.healthTimelineMode === 'deathWindow' ? 'deathWindow' : 'match';
    }

    function healthDeathsCacheKey(match = {}) {
      const rawDeaths = Array.isArray((match.healthTimeline || {}).deaths) ? (match.healthTimeline || {}).deaths : [];
      const first = rawDeaths[0] || {};
      const last = rawDeaths[rawDeaths.length - 1] || {};
      return [match.id || match.rawFingerprint || '', match.rawFingerprint || '', match.parserVersion || '', rawDeaths.length, first.time || first.relativeSec || '', last.time || last.relativeSec || '', last.victim || last.name || ''].join('::');
    }

    function buildHealthDeathsForMatch(match) {
      const timelineDeaths = Array.isArray((match.healthTimeline || {}).deaths) ? (match.healthTimeline || {}).deaths : [];
      const deaths = timelineDeaths.map((death) => ({
        time: Number(death.time || death.relativeSec || 0),
        label: death.label || formatElapsed(Number(death.time || death.relativeSec || 0)),
        victim: death.victim || death.name || 'Unknown',
        className: death.className || '',
        classColor: death.classColor || ''
      })).filter((death) => Number.isFinite(death.time) && death.time >= 0);
      return deaths.sort((a, b) => Number(a.time) - Number(b.time));
    }

    function healthDeathsForMatch(match) {
      if (!match || !perfCache) return buildHealthDeathsForMatch(match || {});
      return perfCache.memo('healthDeaths', healthDeathsCacheKey(match), () => buildHealthDeathsForMatch(match), { maxEntries: 160 });
    }

    function nextDeathWindowForMatch(match, currentMatchTime = 0, preferredDeathTime = null) {
      const deaths = healthDeathsForMatch(match);
      if (!deaths.length) return null;
      const current = Math.max(0, Number(currentMatchTime) || 0);
      const preferred = Number(preferredDeathTime);
      let deathIndex = -1;
      let next = null;
      if (Number.isFinite(preferred) && preferred >= 0) {
        deathIndex = deaths.findIndex((death) => Math.abs(Number(death.time || 0) - preferred) <= 0.35);
        if (deathIndex < 0) {
          let bestDistance = Infinity;
          deaths.forEach((death, index) => {
            const distance = Math.abs(Number(death.time || 0) - preferred);
            if (distance < bestDistance) {
              bestDistance = distance;
              deathIndex = index;
            }
          });
        }
        next = deaths[deathIndex] || null;
      }
      if (!next) {
        deathIndex = deaths.findIndex((death) => Number(death.time) >= current - 0.25);
        if (deathIndex < 0) deathIndex = deaths.length - 1;
        next = deaths[deathIndex];
      }
      const end = Math.max(0, Number(next.time) || 0);
      const start = Math.max(0, end - 10);
      return { start, end, duration: Math.max(1, end - start || 10), death: next, deaths, index: deathIndex };
    }

    function pointsForHealthWindow(points = [], start = 0, end = 10) {
      const sorted = (points || []).filter((point) => Number.isFinite(Number(point.time))).sort((a, b) => Number(a.time) - Number(b.time));
      const inside = sorted.filter((point) => Number(point.time) >= start && Number(point.time) <= end);
      const before = [...sorted].reverse().find((point) => Number(point.time) < start);
      const after = sorted.find((point) => Number(point.time) > end);
      const out = [];
      if (before && inside.length) out.push({ ...before, time: start, label: formatElapsed(start), syntheticWindowAnchor: true });
      out.push(...inside);
      if (after && inside.length) out.push({ ...after, time: end, label: formatElapsed(end), syntheticWindowAnchor: true });
      if (!inside.length && before && after) {
        out.push({ ...before, time: start, label: formatElapsed(start), syntheticWindowAnchor: true });
        out.push({ ...after, time: end, label: formatElapsed(end), syntheticWindowAnchor: true });
      } else if (!inside.length && before) {
        out.push({ ...before, time: start, label: formatElapsed(start), syntheticWindowAnchor: true });
        out.push({ ...before, time: end, label: formatElapsed(end), syntheticWindowAnchor: true });
      } else if (out.length === 1) {
        const only = out[0];
        const onlyTime = Number(only.time) || start;
        const anchorTime = Math.abs(onlyTime - start) <= 0.05 ? end : start;
        const anchorPct = only.syntheticDeath || Number(only.pct) <= 1 ? 100 : Number(only.pct);
        out.push({ ...only, time: anchorTime, label: formatElapsed(anchorTime), pct: anchorPct, syntheticWindowAnchor: true, ability: only.syntheticDeath ? 'Window start estimate' : (only.ability || 'Window anchor') });
      }
      return out.sort((a, b) => Number(a.time) - Number(b.time));
    }

    function healthMarkerPriority(point) {
      const pct = Number(point && point.pct);
      const amount = Number(point && point.amount) || 0;
      const kind = String(point && point.kind || '').toLowerCase();
      let score = Number.isFinite(pct) ? (100 - pct) * 10 : 0;
      if (point && point.syntheticDeath) score += 5000;
      if (kind === 'damage') score += 60;
      if (kind === 'healing') score -= 20;
      if (point && point.isCritical) score += 40;
      score += Math.min(90, amount / 1200);
      return score;
    }

    function clusterHealthMarkerPoints(points = [], spacingSec = 2.5) {
      const sorted = (points || []).filter((point) => Number.isFinite(Number(point.time))).sort((a, b) => Number(a.time) - Number(b.time));
      const clusters = [];
      for (const point of sorted) {
        const time = Number(point.time) || 0;
        const last = clusters[clusters.length - 1];
        if (last && time - Number(last.end || last.start || 0) <= spacingSec) {
          last.items.push(point);
          last.end = Math.max(Number(last.end || time), time);
        } else {
          clusters.push({ start: time, end: time, items: [point] });
        }
      }
      return clusters.map((cluster) => {
        const items = cluster.items || [];
        const best = items.slice().sort((a, b) => healthMarkerPriority(b) - healthMarkerPriority(a) || Number(a.time) - Number(b.time))[0] || items[0];
        const lowest = items.reduce((min, item) => Math.min(min, Number(item.pct) || 100), 100);
        const summary = items
          .slice()
          .sort((a, b) => healthMarkerPriority(b) - healthMarkerPriority(a))
          .slice(0, 4)
          .map((item) => `${formatElapsed(Number(item.time) || 0)} · ${Math.round(Number(item.pct) || 0)}% · ${item.ability || item.event || 'Health event'}${item.source ? ` from ${shortCharacterName(item.source)}` : ''}`)
          .join('\n');
        return { ...best, clusterCount: items.length, clusterLowestPct: lowest, clusterSummary: summary };
      });
    }

    function healthWindowStats(points = []) {
      const values = (points || []).map((point) => Number(point.pct)).filter((pct) => Number.isFinite(pct));
      if (!values.length) return { min: 100, max: 100, delta: 0 };
      const min = Math.min(...values);
      const max = Math.max(...values);
      return { min, max, delta: Math.abs(max - min) };
    }

    function maybeRefreshDeathWindowHealth(currentMatchTime) {
      const match = selectedMatch();
      if (!match || state.active !== 'Matches' || state.matchView !== 'detail') return;
      if (healthTimelineModeForMatch(match) !== 'deathWindow') return;
      const current = Math.max(0, Number(currentMatchTime) || 0);
      const focus = Number(state.player.healthDeathFocusTime);
      if (Number.isFinite(focus) && current >= Math.max(0, focus - 10.25) && current <= focus + 0.35) return;
      const nextWindow = nextDeathWindowForMatch(match, current, null);
      const nextFocus = nextWindow && nextWindow.death ? Number(nextWindow.death.time || 0) : null;
      if (nextFocus == null || Number(state.player.healthDeathFocusTime) === Number(nextFocus)) return;
      state.player.healthDeathFocusTime = nextFocus;
      clearTimeout(healthWindowRenderTimer);
      healthWindowRenderTimer = setTimeout(() => renderKeepingReplay(), 60);
    }

    function renderHealthTimeline(match) {
      const timeline = match.healthTimeline || {};
      const allPlayers = Array.isArray(timeline.players) ? timeline.players.filter((p) => p && p.points && p.points.length) : [];
      const allDeaths = healthDeathsForMatch(match);
      const mode = healthTimelineModeForMatch(match);
      const isBg = isBattlegroundMatch(match);
      const currentMatchTime = Math.max(0, Number(state.player.currentTime || 0) - (Number(state.player.syncOffsetSec) || 0));
      const preferredDeathTime = Number(state.player.healthDeathFocusTime);
      const deathWindow = mode === 'deathWindow' ? nextDeathWindowForMatch(match, currentMatchTime, Number.isFinite(preferredDeathTime) ? preferredDeathTime : null) : null;
      const windowStart = deathWindow ? deathWindow.start : 0;
      const windowEnd = deathWindow ? deathWindow.end : Math.max(1, Number(timeline.durationSec || match.durationSec || 1));
      const duration = deathWindow ? deathWindow.duration : Math.max(1, Number(timeline.durationSec || match.durationSec || 1));
      const focusDeath = deathWindow ? deathWindow.death : null;
      if (focusDeath) state.player.healthDeathFocusTime = Number(focusDeath.time || 0);

      let players = allPlayers;
      if (mode === 'deathWindow') {
        const victim = shortCharacterName(focusDeath && focusDeath.victim ? focusDeath.victim : '').toLowerCase();
        const windowed = allPlayers.map((player) => {
          const points = pointsForHealthWindow(player.points || [], windowStart, windowEnd);
          const stats = healthWindowStats(points);
          const isVictim = victim && shortCharacterName(player.name).toLowerCase() === victim;
          return { ...player, points, windowMinPct: stats.min, windowDeltaPct: stats.delta, isDeathTarget: Boolean(isVictim) };
        }).filter((player) => player.points.length || player.isDeathTarget);
        const victimRows = windowed.filter((player) => player.isDeathTarget);
        // Death-window mode should stay focused. Showing every nearby player made BG
        // reviews look like four random health bars instead of a death recap.
        players = victimRows;
      }

      const width = 1000;
      const height = 220;
      const topPad = 16;
      const bottomPad = 24;
      const plotHeight = height - topPad - bottomPad;
      const x = (sec) => Math.max(0, Math.min(width, ((Number(sec) || 0) - windowStart) / duration * width));
      const yFor = (pct = 100) => topPad + (100 - Math.max(0, Math.min(100, Number(pct) || 0))) / 100 * plotHeight;
      const colorFor = (player) => player.classColor || (String(player.team) === String(match.ownTeam) ? '#67e8f9' : '#fb7185');

      const modeControls = isBg
        ? `<span class="pill cyan">BG death-window mode</span>`
        : `<div class="health-mode-toggle"><button class="health-mode-btn ${mode === 'match' ? 'active' : ''}" data-health-mode="match">Full match</button><button class="health-mode-btn ${mode === 'deathWindow' ? 'active' : ''}" data-health-mode="deathWindow">Last 10s before death</button></div>`;
      const title = mode === 'deathWindow' ? 'Last 10s Before Death' : 'Health over match';
      const subtitle = mode === 'deathWindow'
        ? (focusDeath ? `${shortCharacterName(focusDeath.victim || 'Unknown')} dies at ${formatElapsed(Number(focusDeath.time || 0))}` : 'No deaths found in this match yet')
        : 'Full-match health trace';

      if (!players.length && mode !== 'deathWindow') return '';

      const axisValues = [100, 75, 50, 25, 0];
      const axisHtml = axisValues.map((pct) => `<div class="health-axis-label" style="top:${yFor(pct)}px">${pct}%</div>`).join('');
      const gridLines = axisValues.map((pct) => `<line x1="0" x2="${width}" y1="${yFor(pct).toFixed(1)}" y2="${yFor(pct).toFixed(1)}" class="health-grid-line ${pct === 0 || pct === 100 ? 'strong' : ''}" />`).join('');

      const legendHtml = mode === 'deathWindow' ? '' : players.map((player) => {
        const color = colorFor(player);
        const low = Math.round(Number(player.lowestPct || 100));
        const isVictim = focusDeath && shortCharacterName(player.name).toLowerCase() === shortCharacterName(focusDeath.victim || '').toLowerCase();
        return `<span class="health-player-chip ${isVictim ? 'victim-chip' : ''}" title="${escapeHtml(player.name)}" style="--chip-color:${escapeHtml(color)}"><i></i><b>${escapeHtml(shortCharacterName(player.name))}</b><small>${isVictim ? 'death target' : `${low}% low`}</small></span>`;
      }).join('');
      const deathIndex = deathWindow && Number.isFinite(Number(deathWindow.index)) ? Number(deathWindow.index) : -1;
      const prevDeath = deathIndex > 0 ? allDeaths[deathIndex - 1] : null;
      const nextDeath = deathIndex >= 0 && deathIndex < allDeaths.length - 1 ? allDeaths[deathIndex + 1] : null;
      const deathJumpButton = (death, label, disabled = false) => {
        const deathTime = death ? Number(death.time || 0) : 0;
        const startTime = Math.max(0, deathTime - 10);
        return `<button class="health-death-nav-btn" data-health-death-jump="${deathTime}" data-health-death-start="${startTime}" ${disabled ? 'disabled' : ''}>${escapeHtml(label)}</button>`;
      };
      const deathFocusHtml = mode === 'deathWindow' && focusDeath
        ? `<div class="health-death-focus"><div class="health-death-focus-main"><span>Tracking death target</span><strong>${escapeHtml(shortCharacterName(focusDeath.victim || 'Unknown'))}</strong><small>${escapeHtml(formatElapsed(Number(focusDeath.time || 0)))} death${deathIndex >= 0 ? ` · ${deathIndex + 1}/${allDeaths.length}` : ''}</small></div><div class="health-death-nav">${deathJumpButton(prevDeath, '← Previous death', !prevDeath)}${deathJumpButton(focusDeath, 'Jump to 10s', false)}${deathJumpButton(nextDeath, 'Next death →', !nextDeath)}</div></div>`
        : '';

      const linesSvg = players.map((player) => {
        const color = colorFor(player);
        const points = player.points || [];
        const reduced = points.filter((point, i) => i === 0 || i === points.length - 1 || Math.abs((Number(point.pct) || 0) - (Number(points[i - 1].pct) || 0)) >= 1 || (Number(point.pct) || 100) <= 35).slice(-650);
        const poly = reduced.map((point) => `${x(point.time).toFixed(1)},${yFor(point.pct).toFixed(1)}`).join(' ');
        if (!poly) return '';
        const relationClass = String(player.team) === String(match.ownTeam) ? 'friendly-line' : 'enemy-line';
        return `<polyline class="health-line ${relationClass}" points="${poly}" style="--line-color:${escapeHtml(color)}" />`;
      }).join('');

      const lowDots = players.map((player) => {
        const points = player.points || [];
        const candidates = points.filter((point, i) => {
          const pct = Number(point.pct);
          if (pct > 35 && !point.syntheticDeath) return false;
          const prev = points[Math.max(0, i - 1)];
          const next = points[Math.min(points.length - 1, i + 1)];
          const isLocalLow = (!prev || pct <= Number(prev.pct) + 2) && (!next || pct <= Number(next.pct) + 2);
          const isVeryLow = pct <= 20;
          return point.syntheticDeath || isVeryLow || isLocalLow;
        });
        const lows = clusterHealthMarkerPoints(candidates, mode === 'deathWindow' ? 1.1 : 2.4).slice(-28);
        return lows.map((point) => {
          const count = Number(point.clusterCount || 1);
          const pct = Math.round(Number(point.clusterLowestPct || point.pct || 0));
          const countText = count > 1 ? ` · ${count} nearby events` : '';
          const summary = point.clusterSummary ? `\n${point.clusterSummary}` : '';
          const title = `${shortCharacterName(player.name)}: ${pct}% at ${point.label || formatElapsed(Number(point.time) || 0)} · ${point.ability || point.event || 'Health event'}${point.source ? ` from ${shortCharacterName(point.source)}` : ''}${countText}${summary}`;
          return `<button class="health-dot danger-dot ${count > 1 ? 'clustered' : ''}" data-seek-time="${Number(point.time || 0)}" data-count="${count > 1 ? count : ''}" style="left:${(x(point.time) / width) * 100}%; top:${yFor(point.pct)}px" title="${escapeHtml(title)}">${count > 1 ? `<span>${Math.min(99, count)}</span>` : ''}</button>`;
        }).join('');
      }).join('');

      const deathLines = allDeaths.filter((death) => Number(death.time) >= windowStart && Number(death.time) <= windowEnd).map((death) => {
        const dx = x(death.time);
        return `<button class="health-death-marker" data-seek-time="${Number(death.time || 0)}" style="left:${(dx / width) * 100}%" title="Death: ${escapeHtml(shortCharacterName(death.victim || 'Unknown'))} at ${escapeHtml(death.label || formatElapsed(death.time))}"><span></span></button>`;
      }).join('');

      const emptyPlot = mode === 'deathWindow' && (!players.length || !linesSvg.trim())
        ? `<div class="health-window-empty"><strong>${focusDeath ? 'Death found, but no reliable health samples in this 10s window.' : 'No deaths found yet.'}</strong><span>${isBg ? 'BGs can be noisy, so this view only shows death-window data when the combat log has usable health snapshots.' : 'Try importing a fuller combat log.'}</span></div>`
        : '';

      return `
        <div class="health-timeline-card aligned-health-card ${mode === 'deathWindow' ? 'death-window-card' : ''}">
          <div class="health-timeline-head">
            <div><p class="small-label">Health Timeline</p><h3>${escapeHtml(title)}</h3><p class="caption">${escapeHtml(subtitle)}</p></div>
            <div class="health-head-actions"><div class="health-legend"><span><i></i> low-health moment</span><span class="death-key"><i></i> death</span><span>Click anywhere to seek</span></div>${modeControls}</div>
          </div>
          ${deathFocusHtml}
          ${legendHtml ? `<div class="health-player-legend">${legendHtml}</div>` : ''}
          <div class="health-timeline aligned-health" data-health-duration="${duration}" data-health-start="${windowStart}" data-health-mode="${escapeHtml(mode)}" style="min-height:${height}px">
            <div class="health-axis" style="min-height:${height}px">${axisHtml}</div>
            <div class="health-plot" data-health-click="true" style="min-height:${height}px">
              <svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none">
                ${gridLines}
                ${linesSvg}
              </svg>
              ${lowDots}
              ${deathLines}
              ${emptyPlot}
              <div class="health-now" id="health-now-line"><span>${formatElapsed(Math.max(0, state.player.currentTime - (Number(state.player.syncOffsetSec) || 0)))}</span></div>
            </div>
          </div>
        </div>
      `;
    }

    function updateHealthTimelineCursor(current) {
      const timeline = document.querySelector('.health-timeline');
      const cursor = document.getElementById('health-now-line');
      if (!timeline || !cursor) return;
      const duration = Math.max(1, Number(timeline.dataset.healthDuration || 1));
      const start = Math.max(0, Number(timeline.dataset.healthStart || 0));
      const left = Math.max(0, Math.min(100, ((Number(current) || 0) - start) / duration * 100));
      cursor.style.left = `${left}%`;
      const label = cursor.querySelector('span');
      if (label) label.textContent = formatElapsed(current);
      maybeRefreshDeathWindowHealth(current);
    }

    return {
      healthTimelineModeForMatch,
      healthDeathsForMatch,
      nextDeathWindowForMatch,
      pointsForHealthWindow,
      healthMarkerPriority,
      clusterHealthMarkerPoints,
      healthWindowStats,
      maybeRefreshDeathWindowHealth,
      renderHealthTimeline,
      updateHealthTimelineCursor
    };
  }

  window.LastCallReplayHealthTimeline = { createReplayHealthTimelineTools };
})();
