(function () {
  'use strict';

  function createFavoritesViewTools(deps = {}) {
    const state = deps.state || { matches: [], favoriteFolders: [] };
    const escapeHtml = deps.escapeHtml || ((value) => String(value ?? ''));
    const isFavoriteMatch = deps.isFavoriteMatch || ((match) => Boolean(match && (match.favorite || match.favorited)));
    const visibleLibraryMatch = deps.visibleLibraryMatch || (() => true);
    const sortMatchesForLibrary = deps.sortMatchesForLibrary || ((matches) => (matches || []).slice());
    const matchResolvedResult = deps.matchResolvedResult || (() => 'Unknown');
    const resultToneForResult = deps.resultToneForResult || (() => 'amber');
    const pill = deps.pill || ((text) => `<span class="pill">${escapeHtml(text)}</span>`);
    const displayMatchType = deps.displayMatchType || ((match) => match && (match.matchType || match.bracket || 'PvP') || 'PvP');
    const matchTimestampLabel = deps.matchTimestampLabel || (() => 'Unknown time');
    const coloredShortName = deps.coloredShortName || ((name) => escapeHtml(String(name || '').split('-')[0] || 'Unknown'));

    function favoriteComment(match) {
      return String((match && (match.favoriteComment || match.userNotes || match.notes)) || '');
    }

    function favoriteFolderId(match) {
      return String((match && match.favoriteFolderId) || '');
    }

    function favoriteFolders() {
      return Array.isArray(state.favoriteFolders) ? state.favoriteFolders.filter((folder) => folder && folder.id && folder.name) : [];
    }

    function favoriteFolderName(folderId) {
      if (!folderId) return 'Unsorted';
      const folder = favoriteFolders().find((item) => item.id === folderId);
      return folder ? folder.name : 'Unsorted';
    }

    function favoriteMark(match) {
      if (!isFavoriteMatch(match)) return '';
      const folder = favoriteFolderName(favoriteFolderId(match));
      const comment = favoriteComment(match).trim();
      const title = [comment, folder].filter(Boolean).join(' · ') || 'Favorited';
      return `<span class="favorite-star" title="${escapeHtml(title)}" aria-label="Favorited">★</span>`;
    }

    function favoriteFolderOptions(selectedId = '') {
      const folders = favoriteFolders();
      return `
        <option value="" ${!selectedId ? 'selected' : ''}>Unsorted</option>
        ${folders.map((folder) => `<option value="${escapeHtml(folder.id)}" ${selectedId === folder.id ? 'selected' : ''}>${escapeHtml(folder.name)}</option>`).join('')}
      `;
    }

    function favoriteMatches() {
      return sortMatchesForLibrary((state.matches || []).filter((match) => isFavoriteMatch(match) && visibleLibraryMatch(match)));
    }

    function favoritesForSelectedFolder() {
      const folderId = state.selectedFavoriteFolderId || 'all';
      const all = favoriteMatches();
      if (folderId === 'all') return all;
      if (folderId === 'unsorted') return all.filter((match) => !favoriteFolderId(match));
      return all.filter((match) => favoriteFolderId(match) === folderId);
    }

    function renderFavoriteFolderRail() {
      const folders = favoriteFolders();
      const allFavorites = favoriteMatches();
      const unsortedCount = allFavorites.filter((match) => !favoriteFolderId(match)).length;
      const favoriteCountForFolder = (folderId) => allFavorites.filter((match) => favoriteFolderId(match) === folderId).length;
      const folderButton = (id, label, count, icon = '★') => `
        <button class="favorite-folder-btn ${state.selectedFavoriteFolderId === id ? 'active' : ''}" data-favorite-folder="${escapeHtml(id)}">
          <span>${icon}</span><strong>${escapeHtml(label)}</strong><em>${count}</em>
        </button>
      `;
      const userFolderRow = (folder) => {
        const count = favoriteCountForFolder(folder.id);
        const disabled = count > 0 ? 'disabled' : '';
        const title = count > 0 ? 'Move or remove favorites from this folder before deleting it.' : 'Delete this empty folder.';
        return `
          <div class="favorite-folder-row">
            ${folderButton(folder.id, folder.name, count, '📁')}
            <button class="favorite-folder-delete" data-delete-favorite-folder="${escapeHtml(folder.id)}" ${disabled} title="${escapeHtml(title)}" aria-label="Delete ${escapeHtml(folder.name)} folder">🗑</button>
          </div>
        `;
      };
      return `
        <div class="card favorite-folder-card">
          <div class="card-title-row"><div><p class="small-label">Favorite vault</p><h2>Folders</h2><p class="caption">Make tiny shelves for matches worth reviewing. Empty user folders can be deleted.</p></div><div class="icon-bubble">★</div></div>
          <div class="favorite-folder-list">
            ${folderButton('all', 'All favorites', allFavorites.length, '★')}
            ${folderButton('unsorted', 'Unsorted', unsortedCount, '◇')}
            ${folders.map(userFolderRow).join('')}
          </div>
          <form class="favorite-folder-form" id="favorite-folder-form">
            <input id="favorite-folder-name" maxlength="48" placeholder="New folder name" value="${escapeHtml(state.favoriteFolderDraft || '')}" />
            <button class="btn violet" id="create-favorite-folder" type="submit">Create</button>
          </form>
        </div>
      `;
    }

    function renderFavoriteCard(match) {
      const comment = favoriteComment(match);
      const folderId = favoriteFolderId(match);
      const result = matchResolvedResult(match);
      const resultTone = resultToneForResult(result);
      return `
        <article class="favorite-card">
          <div class="favorite-card-main">
            <div class="match-head">
              <div>
                <div class="tag-row">${pill(result, resultTone)}${pill(displayMatchType(match), 'violet')}${match.teamSizeLabel ? pill(match.teamSizeLabel, 'cyan') : ''}</div>
                <h3 class="match-title">${escapeHtml(match.map || 'Unknown map')}</h3>
                <p class="match-sub">${escapeHtml(matchTimestampLabel(match))} · ${escapeHtml(match.alt || 'Unknown toon')}</p>
              </div>
              <div class="match-meta"><span>Folder</span><strong>${escapeHtml(favoriteFolderName(folderId))}</strong></div>
            </div>
            <div class="favorite-mini-teams">
              <div><span>Your team</span><strong>${(match.myComp || match.ownNames || []).slice(0, 5).map((name) => coloredShortName(name, match)).join(', ') || 'Unknown'}</strong></div>
              <div><span>Enemy team</span><strong>${(match.enemyComp || match.enemies || []).slice(0, 5).map((name) => coloredShortName(name, match)).join(', ') || 'Unknown'}</strong></div>
            </div>
          </div>
          <div class="favorite-card-edit">
            <label class="field-label">Folder</label>
            <select class="favorite-folder-select" data-favorite-folder-match="${escapeHtml(match.id)}">${favoriteFolderOptions(folderId)}</select>
            <label class="field-label">Short comment</label>
            <textarea class="favorite-comment-box" maxlength="180" data-favorite-comment-match="${escapeHtml(match.id)}" placeholder="Example: bad opener, clutch peel, target call review">${escapeHtml(comment)}</textarea>
            <div class="action-row">
              <button class="btn primary" data-match="${escapeHtml(match.id)}">Open Replay</button>
              <button class="btn rose" data-unfavorite-match="${escapeHtml(match.id)}">Unfavorite</button>
            </div>
          </div>
        </article>
      `;
    }

    function renderFavorites() {
      const shown = favoritesForSelectedFolder();
      const total = favoriteMatches().length;
      const limit = Math.max(10, Number(state.favoriteVisibleLimit) || 20);
      const visible = shown.slice(0, limit);
      const hiddenCount = Math.max(0, shown.length - visible.length);
      return `
        <div class="favorites-page grid">
          <div class="card favorites-hero">
            <div class="card-title-row">
              <div><p class="small-label">Favorites</p><h2>Favorite Matches</h2><p class="caption">Collect the replays worth studying, sort them into folders, and leave quick notes for future-you.</p></div>
              <div class="tag-row">${pill(`${total} favorite${total === 1 ? '' : 's'}`, 'amber')}${shown.length !== total ? pill(`${shown.length} in folder`, 'cyan') : ''}${hiddenCount ? pill(`${visible.length} loaded`, 'violet') : ''}</div>
            </div>
          </div>
          <div class="favorites-layout">
            ${renderFavoriteFolderRail()}
            <div class="favorites-list">
              ${visible.length ? visible.map(renderFavoriteCard).join('') : `<div class="card empty"><h3>No favorites here yet</h3><p class="caption">Star matches from the match list or replay view, then organize them here.</p></div>`}
              ${hiddenCount ? `<button class="btn load-more-favorites" id="load-more-favorites">Show ${Math.min(20, hiddenCount)} more favorites</button>` : ''}
            </div>
          </div>
        </div>
      `;
    }

    return {
      favoriteComment,
      favoriteFolderId,
      favoriteFolders,
      favoriteFolderName,
      favoriteMark,
      favoriteFolderOptions,
      favoriteMatches,
      favoritesForSelectedFolder,
      renderFavoriteFolderRail,
      renderFavoriteCard,
      renderFavorites
    };
  }

  window.LastCallFavoritesView = { createFavoritesViewTools };
})();
