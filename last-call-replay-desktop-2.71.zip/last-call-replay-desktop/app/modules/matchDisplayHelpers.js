(function () {
  function createMatchDisplayHelpers(deps = {}) {
    const state = deps.state || {};
    const pill = typeof deps.pill === 'function' ? deps.pill : ((text) => `<span>${text}</span>`);
    const characterNameKey = typeof deps.characterNameKey === 'function'
      ? deps.characterNameKey
      : ((value = '') => String(value || '').toLowerCase().replace(/[^a-z0-9]/g, ''));


    const KNOWN_ARENA_MAP_KEYS = new Set([
      'nagrand arena', 'black rook hold arena', 'mugambala', 'nokhudon proving grounds', "tol'viron arena",
      'tol’viron arena', 'maldraxxus coliseum', 'empyrean domain', 'ruins of lordaeron', "tiger's peak",
      'tiger’s peak', "blade's edge arena", 'blade’s edge arena', 'dalaran sewers', 'enigma arena',
      'enigma crucible', 'the robodrome', 'cage of carnage', "ashamane's fall", 'ashamane’s fall',
      'hook point', 'the hook point', 'the ring of valor'
    ]);

    function normalizedMapKey(value) {
      return String(value || '').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim();
    }

    function isKnownArenaMap(match) {
      const key = normalizedMapKey(match && (match.map || match.zone || match.subzone || ''));
      if (!key) return false;
      return KNOWN_ARENA_MAP_KEYS.has(key) || /arena|mugambala|nokhudon|maldraxxus|empyrean|lordaeron|tiger'?s peak|tiger’s peak|robodrome|cage of carnage|ashamane|hook point|dalaran sewers|ring of valor/i.test(String(match && (match.map || match.zone || match.subzone || '') || ''));
    }

    function isArenaTypeLabel(value) {
      const type = canonicalMatchTypeLabel(value);
      return type === '2v2' || type === '3v3' || type === 'Skirmish' || type === 'Solo Shuffle';
    }

    function isBattlegroundTypeLabel(value) {
      const type = canonicalMatchTypeLabel(value);
      return type === 'Random Battleground' || type === 'Rated Battleground' || type === 'Battleground Blitz';
    }

    function isStaleBattlegroundTag(value) {
      const raw = String(value || '').trim();
      if (!raw) return true;
      return /^(random\s*bg'?s?|random\s*battleground|battleground|rated\s*battleground|rbg'?s?|battleground\s*blitz|blitz|isBattleground)$/i.test(raw)
        || /^bg\s*\d*\s*\/\s*\d+$/i.test(raw)
        || /^rbg\s*\d*\s*\/\s*\d+$/i.test(raw);
    }

    function displayMatchTags(match = {}) {
      const tags = Array.isArray(match && match.tags) ? match.tags : [];
      if (!tags.length) return [];
      const effective = effectiveMatchType(match);
      if (!isArenaTypeLabel(effective)) return tags;
      return tags.filter((tag) => !isStaleBattlegroundTag(tag));
    }

    function compactArenaSizeEvidence(match = {}) {
      const expected = Number(match.expectedTeamSize || 0) || 0;
      return expected === 2 || expected === 3;
    }

    function arenaTypeFromMatchEvidence(match, baseType) {
      const canonical = canonicalMatchTypeLabel(baseType || normalizedMatchType(match));
      if (isArenaTypeLabel(canonical)) return canonical;
      const actual = Number(match && match.actualTeamSize) || 0;
      const expected = Number(match && match.expectedTeamSize) || 0;
      const participants = Array.isArray(match && match.participants) ? match.participants.filter(Boolean).length : 0;
      if (expected === 3 || actual === 3 || participants >= 5) return '3v3';
      if (expected === 2 || actual === 2) return '2v2';
      return isKnownArenaMap(match) ? '3v3' : '';
    }

    function displayResult(value) {
      const raw = String(value || '').trim();
      if (!raw || /^parsed$/i.test(raw) || /^unscored$/i.test(raw)) return 'Unscored';
      if (/^(win|won|winner|victory|victorious|success)$/i.test(raw) || /\b(win|won|victory)\b/i.test(raw)) return 'Win';
      if (/^(loss|lost|lose|loser|defeat|defeated|failure)$/i.test(raw) || /\b(loss|lost|defeat)\b/i.test(raw)) return 'Loss';
      return raw;
    }

    function firstNonEmptyValue(...values) {
      for (const value of values) {
        if (value !== undefined && value !== null && String(value).trim() !== '' && String(value).trim() !== 'Unknown') return value;
      }
      return '';
    }

    function addonScoreboardResult(match) {
      const sb = match && match.addonScoreboard ? match.addonScoreboard : null;
      if (!sb) return '';
      const scalar = sb.rawFields && sb.rawFields.scalarFields ? sb.rawFields.scalarFields : {};
      const explicit = firstNonEmptyValue(sb.result, sb.winnerResult, sb.outcome, scalar.result, scalar.winnerResult, scalar.outcome);
      const normalizedExplicit = explicit ? displayResult(explicit) : '';
      if (normalizedExplicit === 'Win' || normalizedExplicit === 'Loss') return normalizedExplicit;
      const winner = firstNonEmptyValue(sb.winnerTeam, sb.winner, sb.winnerRaw, scalar.winnerTeam, scalar.winningTeam, scalar.winner);
      const playerTeam = firstNonEmptyValue(sb.playerTeam, scalar.playerTeam, match && match.ownTeam);
      if (winner !== '' && playerTeam !== '') return String(winner) === String(playerTeam) ? 'Win' : 'Loss';
      return '';
    }

    function combatLogResultForMatch(match) {
      if (!match || typeof match !== 'object') return '';
      const explicit = displayResult(match.combatLogResult || '');
      if (explicit === 'Win' || explicit === 'Loss') return explicit;
      const sources = Array.isArray(match.dataSources) ? match.dataSources : [];
      const hasCombat = Boolean(match.createdFromRealLog || match.parserVersion || match.isBracketMatch || sources.some((source) => /combat|log|tail/i.test(String(source || ''))));
      const ownTeam = firstNonEmptyValue(match.ownTeam, match.combatLogOwnTeam, match.playerTeam);
      const winnerTeam = firstNonEmptyValue(match.winnerTeam, match.combatLogWinnerTeam, match.winner);
      if (hasCombat && ownTeam !== '' && winnerTeam !== '') return String(winnerTeam) === String(ownTeam) ? 'Win' : 'Loss';
      const sourced = /combat/i.test(String(match.resultSource || match.resultAuthority || '')) ? displayResult(match.result) : '';
      return sourced === 'Win' || sourced === 'Loss' ? sourced : '';
    }

    function hasResultConflict(match) {
      return Boolean(match && (match.resultConflictNeedsReview || (match.resultConflict && match.resultConflict.combatLogResult && match.resultConflict.addonResult && match.resultConflict.combatLogResult !== match.resultConflict.addonResult)));
    }

    function matchResolvedResult(match) {
      const combatResult = combatLogResultForMatch(match);
      if (combatResult === 'Win' || combatResult === 'Loss') return combatResult;
      const addonResult = addonScoreboardResult(match);
      if (addonResult === 'Win' || addonResult === 'Loss') return addonResult;
      return displayResult(match && match.result);
    }

    function resultToneForResult(result) {
      const normalized = displayResult(result);
      if (normalized === 'Win') return 'emerald';
      if (normalized === 'Loss') return 'rose';
      return 'amber';
    }

    function resultMatchesFilter(match) {
      const result = matchResolvedResult(match);
      if (state.resultFilter === 'All') return true;
      if (state.resultFilter === 'Unscored') return result === 'Unscored';
      return result === state.resultFilter;
    }

    function normalizedMatchType(match) {
      return match.matchType || match.bracket || 'PvP Match';
    }

    function scoreboardMatchType(match) {
      const sb = match && match.addonScoreboard ? match.addonScoreboard : null;
      const scalar = sb && sb.rawFields && sb.rawFields.scalarFields ? sb.rawFields.scalarFields : {};
      return firstNonEmptyValue(
        sb && sb.matchType,
        sb && sb.bracket,
        sb && sb.label,
        scalar.matchType,
        scalar.bracket,
        scalar.matchLabel,
        scalar.label
      );
    }

    function canonicalMatchTypeLabel(value) {
      const raw = String(value || '').trim();
      const lower = raw.toLowerCase();
      if (!raw) return 'PvP Match';
      if (lower.includes('2v2') || lower === '2s' || lower === '2' || /^2['’]?s$/.test(lower)) return '2v2';
      if (lower.includes('3v3') || lower === '3s' || lower === '3' || /^3['’]?s$/.test(lower)) return '3v3';
      if (lower.includes('shuffle')) return 'Solo Shuffle';
      if (lower.includes('skirm')) return 'Skirmish';
      if (lower.includes('blitz')) return 'Battleground Blitz';
      if (/rated\s*(battle|bg)|\brbg\b/.test(lower)) return 'Rated Battleground';
      if (lower.includes('random battleground') || lower === 'battleground' || lower === 'bg' || lower.includes('battleground')) return 'Random Battleground';
      return raw;
    }

    function displayMatchTypeLabel(value) {
      const raw = String(value || '').trim();
      if (!raw) return '';
      const canonical = canonicalMatchTypeLabel(raw);
      if (canonical === 'Rated Battleground') return "RBG's";
      if (canonical === 'Random Battleground') return "Random BG's";
      return canonical;
    }

    function displayBracketLabel(value) {
      const parts = String(value || '').split(' · ');
      const first = parts.shift() || '';
      const label = first === 'Blitz' ? 'Blitz' : displayMatchTypeLabel(first);
      return [label, ...parts].filter(Boolean).join(' · ');
    }

    function displayMatchType(match) {
      const effective = effectiveMatchType(match);
      if (effective === 'Solo Shuffle') return 'Solo';
      return displayMatchTypeLabel(effective);
    }

    function effectiveMatchType(match) {
      if (!match) return 'PvP Match';
      const rawBase = String(normalizedMatchType(match) || match.matchType || match.bracket || '');
      if (match.isSoloShuffle || match.isSoloShuffleLobby || match.isSoloShuffleRoundChild || /shuffle/i.test(rawBase)) return 'Solo Shuffle';
      const addonType = canonicalMatchTypeLabel(scoreboardMatchType(match));
      const baseType = canonicalMatchTypeLabel(rawBase);
      const arenaType = arenaTypeFromMatchEvidence(match, baseType);
      const combatLogArenaEvidence = Boolean(match.createdFromRealLog || match.parserVersion || match.isBracketMatch || /arena/i.test(String(match.instanceType || match.captureReason || '')));
      const compactArenaSize = compactArenaSizeEvidence(match);
      if (arenaType && (isKnownArenaMap(match) || isArenaTypeLabel(baseType) || isArenaTypeLabel(addonType) || (combatLogArenaEvidence && compactArenaSize && !isBattlegroundTypeLabel(arenaType)))) return arenaType;
      if (baseType === 'Battleground Blitz' || addonType === 'Battleground Blitz') return 'Battleground Blitz';
      if (baseType === 'Rated Battleground' || addonType === 'Rated Battleground' || match.isRatedBattleground) return 'Rated Battleground';
      if (baseType === 'Random Battleground' || addonType === 'Random Battleground' || match.isBattleground) return 'Random Battleground';
      return baseType;
    }

    function matchTypeMatchesFilter(match, filterValue) {
      if (!filterValue || filterValue === 'All') return true;
      const selected = canonicalMatchTypeLabel(filterValue);
      const effective = effectiveMatchType(match);
      if (selected === effective) return true;
      if (selected === 'Random Battleground') return effective === 'Random Battleground';
      if (selected === 'Rated Battleground') return effective === 'Rated Battleground';
      return false;
    }

    function isRatedBattlegroundMatch(match) {
      return Boolean(match && effectiveMatchType(match) === 'Rated Battleground');
    }

    function isBattlegroundMatch(match) {
      if (!match) return false;
      const effective = effectiveMatchType(match);
      if (effective === '2v2' || effective === '3v3' || effective === 'Skirmish' || effective === 'Solo Shuffle' || isKnownArenaMap(match)) return false;
      const lower = String(normalizedMatchType(match) || '').toLowerCase();
      const participants = Array.isArray(match && match.participants) ? match.participants.length : 0;
      return Boolean(effective === 'Rated Battleground' || effective === 'Random Battleground' || effective === 'Battleground Blitz' || match.isBattleground || /battlefield|battleground|\bbg\b|blitz/.test(lower) || participants >= 12);
    }

    function matchTeamSizePill(match) {
      if (match && effectiveMatchType(match) === 'Solo Shuffle') return '';
      if (!isBattlegroundMatch(match)) return '';
      const actual = Number(match && match.actualTeamSize) || 0;
      const expected = Number(match && match.expectedTeamSize) || (isRatedBattlegroundMatch(match) ? 10 : /blitz/i.test(normalizedMatchType(match)) ? 8 : 0);
      const text = isRatedBattlegroundMatch(match) ? `RBG ${actual || '?'}${expected ? `/${expected}` : ''}` : expected ? `BG ${actual || '?'}${expected ? `/${expected}` : ''}` : 'BG';
      return pill(text, isRatedBattlegroundMatch(match) ? 'violet' : 'cyan');
    }

    function combatLogImportHistory() {
      return (state.importedFiles || []).filter((file) => {
        const type = String((file && file.type) || '').toLowerCase();
        if (file && file.hiddenFromCombatLogHistory) return false;
        return !type.includes('pvph') && !type.includes('savedvariable') && !type.includes('scoreboard');
      });
    }

    function matchDay(match) {
      if (match.startIso) {
        const date = new Date(match.startIso);
        if (!Number.isNaN(date.getTime())) return date.toLocaleDateString();
      }
      return match.date || 'Unknown day';
    }

    function matchClock(match) {
      if (match && match.startIso) {
        const date = new Date(match.startIso);
        if (!Number.isNaN(date.getTime())) return date.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
      }
      const raw = String((match && match.time) || '');
      if (raw && raw !== 'Imported') return raw.split(' to ')[0] || raw;
      return '';
    }

    function matchTimestampLabel(match) {
      const day = matchDay(match);
      const clock = matchClock(match);
      return clock ? `${day} ${clock}` : day;
    }

    function matchSortTime(match) {
      if (!match) return 0;
      const direct = Number(match.startMs || match.startedAt || match.createdAt || 0);
      if (Number.isFinite(direct) && direct > 0) return direct;
      const iso = match.startIso || match.endIso || match.capturedAt || '';
      if (iso) {
        const parsed = Date.parse(iso);
        if (Number.isFinite(parsed)) return parsed;
      }
      const label = [match.date, match.time].filter(Boolean).join(' ');
      if (label) {
        const parsed = Date.parse(label);
        if (Number.isFinite(parsed)) return parsed;
      }
      return 0;
    }

    const DISPLAY_INSTANCE_MAP_NAMES = {
      '30': 'Alterac Valley',
      '489': 'Warsong Gulch',
      '529': 'Arathi Basin',
      '566': 'Eye of the Storm',
      '572': 'Ruins of Lordaeron',
      '607': 'Strand of the Ancients',
      '617': 'Dalaran Sewers',
      '618': 'The Ring of Valor',
      '628': 'Isle of Conquest',
      '726': 'Twin Peaks',
      '727': 'Silvershard Mines',
      '761': 'The Battle for Gilneas',
      '968': 'Eye of the Storm',
      '980': "Tol'Viron Arena",
      '998': 'Temple of Kotmogu',
      '1105': 'Deepwind Gorge',
      '1134': "Tiger's Peak",
      '1504': 'Black Rook Hold Arena',
      '1505': 'Nagrand Arena',
      '1672': "Blade's Edge Arena",
      '1681': 'Arathi Basin',
      '1803': 'Seething Shore',
      '2106': 'Warsong Gulch',
      '2107': 'Arathi Basin',
      '2167': 'The Robodrome',
      '2177': 'Arathi Basin Comp Stomp',
      '2245': 'Deepwind Gorge',
      '2373': 'Empyrean Domain',
      '2509': 'Maldraxxus Coliseum',
      '2511': 'Enigma Arena',
      '2547': 'Enigma Crucible',
      '2563': 'Nokhudon Proving Grounds',
      '2656': 'Deephaul Ravine',
      '2759': 'Cage of Carnage'
    };

    function displayInstanceMapName(value = '') {
      const match = String(value || '').match(/\d+/);
      return match ? DISPLAY_INSTANCE_MAP_NAMES[match[0]] || '' : '';
    }

    function normalizedMapKey(value = '') {
      return String(value || '').toLowerCase().replace(/[’']/g, "'").replace(/[^a-z0-9]+/g, ' ').replace(/\s+/g, ' ').trim();
    }

    function displayBattlegroundMapName(value = '') {
      const key = String(value || '').toLowerCase().replace(/[’']/g, "'").replace(/\s+/g, ' ').trim();
      if (!key) return '';
      if (/warsong|silverwing/.test(key)) return 'Warsong Gulch';
      if (/twin peaks|wildhammer|dragonmaw/.test(key)) return 'Twin Peaks';
      if (/arathi|blacksmith|stables|gold mine|lumber\s*mill|farm|trollbane|defiler/.test(key)) return 'Arathi Basin';
      if (/gilneas|waterworks|lighthouse/.test(key)) return 'The Battle for Gilneas';
      if (/eye of the storm|draenei ruins|fel reaver|mage tower|blood elf tower/.test(key)) return 'Eye of the Storm';
      if (/silvershard/.test(key)) return 'Silvershard Mines';
      if (/kotmogu/.test(key)) return 'Temple of Kotmogu';
      if (/seething shore/.test(key)) return 'Seething Shore';
      if (/deepwind/.test(key)) return 'Deepwind Gorge';
      if (/deephaul/.test(key)) return 'Deephaul Ravine';
      return '';
    }

    function cleanDisplayMapName(value = '', match = {}) {
      const raw = String(value || '').trim();
      const instanceFromField = displayInstanceMapName(match && (match.mapID || match.mapId || match.instanceID || match.instanceId || match.zoneID || match.zoneId));
      const rawLooksLikeId = /^\d+$/.test(raw) || /^instance\s+\d+$/i.test(raw);
      if (rawLooksLikeId) return displayInstanceMapName(raw) || instanceFromField || raw;
      const bgName = displayBattlegroundMapName(raw);
      if (bgName) return bgName;
      return raw || instanceFromField || 'Unknown map';
    }

    function normalizeMatchMapForDisplay(match) {
      if (!match || typeof match !== 'object') return match;
      const cleaned = cleanDisplayMapName(match.map || match.zone || match.subzone || match.subZone || '', match);
      if (cleaned) match.map = cleaned;
      return match;
    }

    function isUsableSavedMatch(match) {
      if (!match || typeof match !== 'object') return false;
      if (match.sample || match.demo || match.placeholder || match.isSample || match.isDemo || match.isPlaceholder) return false;
      const id = String(match.id || '').toLowerCase();
      if (/^(sample|demo|placeholder)/.test(id)) return false;
      return Boolean(
        match.id ||
        match.rawFingerprint ||
        match.createdFromRealLog ||
        match.createdFromAddon ||
        match.addonScoreboard ||
        match.startIso ||
        match.startMs ||
        match.map ||
        (Array.isArray(match.scoreboardPlayers) && match.scoreboardPlayers.length)
      );
    }

    function matchDedupeKey(match) {
      if (!match) return '';
      const map = String(match.map || '').toLowerCase().trim();
      const type = String(normalizedMatchType(match) || '').toLowerCase().trim();
      const alt = String(match.alt || '').toLowerCase().trim();
      const participants = Array.isArray(match.participants) ? match.participants : [];
      const participantKey = participants.map((name) => String(name || '').toLowerCase().trim()).filter(Boolean).sort().join('|');
      const start = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0);
      const end = Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0);
      const startBucket = start ? Math.round(start / 1000) : '';
      const endBucket = end ? Math.round(end / 1000) : '';
      if (startBucket && endBucket && (map || type || participantKey)) return `time:${startBucket}:${endBucket}:${map}:${type}:${alt}:${participantKey}`;
      if (match.rawFingerprint) return `raw:${match.rawFingerprint}`;
      return `id:${match.id || ''}`;
    }

    function matchLooseDedupeKey(match) {
      if (!match) return '';
      const start = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0);
      if (!Number.isFinite(start) || start <= 0) return '';
      const map = normalizedMapKey(match.map || match.zone || match.subzone || '');
      const type = String(normalizedMatchType(match) || '').toLowerCase().trim();
      const alt = characterNameKey(match.alt || match.character || '');
      const duration = Number(match.durationSec || 0);
      const startBucket = Math.round(start / 30000);
      const durationBucket = duration > 0 ? Math.round(duration / 15) : '';
      if (!map && !type) return '';
      return `loose:${startBucket}:${durationBucket}:${map}:${type}:${alt}`;
    }

    function dedupeMatches(matches) {
      const keep = new Map();
      const result = [];
      for (const match of matches || []) {
        if (!match) continue;
        const normalizedMatch = normalizeMatchMapForDisplay(match);
        const keys = [matchDedupeKey(normalizedMatch), matchLooseDedupeKey(normalizedMatch)].filter(Boolean);
        if (!keys.length) continue;
        if (keys.some((key) => keep.has(key))) continue;
        for (const key of keys) keep.set(key, normalizedMatch);
        result.push(normalizedMatch);
      }
      return result;
    }

    return {
      displayResult,
      firstNonEmptyValue,
      addonScoreboardResult,
      combatLogResultForMatch,
      hasResultConflict,
      matchResolvedResult,
      resultToneForResult,
      resultMatchesFilter,
      normalizedMatchType,
      scoreboardMatchType,
      canonicalMatchTypeLabel,
      displayMatchTypeLabel,
      displayBracketLabel,
      displayMatchType,
      effectiveMatchType,
      displayMatchTags,
      matchTypeMatchesFilter,
      isRatedBattlegroundMatch,
      isBattlegroundMatch,
      matchTeamSizePill,
      combatLogImportHistory,
      matchDay,
      matchClock,
      matchTimestampLabel,
      matchSortTime,
      displayInstanceMapName,
      normalizedMapKey,
      displayBattlegroundMapName,
      cleanDisplayMapName,
      normalizeMatchMapForDisplay,
      isUsableSavedMatch,
      matchDedupeKey,
      matchLooseDedupeKey,
      dedupeMatches
    };
  }

  window.LastCallMatchDisplayHelpers = { createMatchDisplayHelpers };
})();
