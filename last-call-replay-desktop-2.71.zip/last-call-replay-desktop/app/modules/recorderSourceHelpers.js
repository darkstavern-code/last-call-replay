(function () {
  'use strict';

  function createRecorderSourceTools(deps = {}) {
    const state = deps.state || {};
    const formatElapsed = typeof deps.formatElapsed === 'function' ? deps.formatElapsed : ((seconds) => String(seconds || 0));
    const saveRecorderSettings = typeof deps.saveRecorderSettings === 'function' ? deps.saveRecorderSettings : (async () => {});
    const recorderIsActive = typeof deps.recorderIsActive === 'function' ? deps.recorderIsActive : (() => false);
    const render = typeof deps.render === 'function' ? deps.render : (() => {});
    const refreshCaptureSources = typeof deps.refreshCaptureSources === 'function' ? deps.refreshCaptureSources : (() => {});

    function captureSourceKind(source) {
      const id = String((source && source.id) || '').toLowerCase();
      if (id.startsWith('screen:')) return 'screen';
      return 'program';
    }

    function sourceLooksLikeWow(source) {
      return /world of warcraft|warcraft/i.test(String((source && source.name) || ''));
    }

    function normalizedSourceName(value) {
      return String(value || '').trim().toLowerCase().replace(/\s+/g, ' ');
    }

    function isSourceApproved(source) {
      if (!source) return false;
      const approved = (state.recorder && state.recorder.approvedWowSourceNames) || [];
      const name = normalizedSourceName(source.name || source.id || '');
      return approved.some((item) => normalizedSourceName(item) === name);
    }

    function preferredWowSource(sources = (state.recorder && state.recorder.sources) || []) {
      const wowSources = (sources || []).filter(sourceLooksLikeWow);
      if (!wowSources.length) return null;
      return wowSources.find((source) => /world of warcraft/i.test(String(source.name || ''))) || wowSources[0];
    }

    async function rememberApprovedCaptureSource(source) {
      if (!source || !sourceLooksLikeWow(source)) return;
      if (!state.recorder) state.recorder = {};
      const name = source.name || source.id || '';
      const existing = state.recorder.approvedWowSourceNames || [];
      if (!existing.some((item) => normalizedSourceName(item) === normalizedSourceName(name))) {
        state.recorder.approvedWowSourceNames = [...existing, name];
      }
      await saveRecorderSettings();
    }

    function allowedCaptureSources(sources = (state.recorder && state.recorder.sources) || []) {
      const safe = (sources || []).filter((source) => source && source.id && !source.error);
      return safe.filter((source) => captureSourceKind(source) === 'screen' || sourceLooksLikeWow(source));
    }

    function sourceSort(a, b) {
      const ak = captureSourceKind(a);
      const bk = captureSourceKind(b);
      if (ak !== bk) return ak === 'program' ? -1 : 1;
      return String(a && a.name || '').localeCompare(String(b && b.name || ''));
    }

    function validRecorderPerformanceMode(value) {
      return ['low', 'balanced', 'quality'].includes(String(value || '')) ? String(value) : 'balanced';
    }

    function recorderPerformanceProfile(mode = state.recorder && state.recorder.performanceMode) {
      const normalized = validRecorderPerformanceMode(mode);
      const profiles = {
        low: {
          label: 'Low impact',
          frameRate: 24,
          maxFrameRate: 30,
          videoBitsPerSecond: 3500000,
          chunkMs: 3000,
          mimePreference: ['video/webm;codecs=vp8,opus', 'video/webm;codecs=vp8', 'video/webm']
        },
        balanced: {
          label: 'Balanced',
          frameRate: 30,
          maxFrameRate: 30,
          videoBitsPerSecond: 6000000,
          chunkMs: 2000,
          mimePreference: ['video/webm;codecs=vp8,opus', 'video/webm;codecs=vp8', 'video/webm;codecs=vp9,opus', 'video/webm']
        },
        quality: {
          label: 'High quality',
          frameRate: 60,
          maxFrameRate: 60,
          videoBitsPerSecond: 10000000,
          chunkMs: 1000,
          mimePreference: ['video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm']
        }
      };
      return profiles[normalized] || profiles.balanced;
    }

    function recorderPerformanceLabel(mode = state.recorder && state.recorder.performanceMode) {
      return recorderPerformanceProfile(mode).label;
    }

    function recorderPerformanceCaption(mode = state.recorder && state.recorder.performanceMode) {
      const normalized = validRecorderPerformanceMode(mode);
      if (normalized === 'low') return 'Lightest load. Best if WoW feels choppy while recording.';
      if (normalized === 'quality') return 'Highest load. Use only if your PC stays smooth.';
      return 'Recommended default. Smoother PC load than the old recorder settings.';
    }

    function recorderChunkMs() {
      return recorderPerformanceProfile().chunkMs || 2000;
    }

    function currentCaptureSource() {
      const recorder = state.recorder || {};
      return (recorder.sources || []).find((source) => source.id === recorder.selectedSourceId) || null;
    }

    function recorderSetupSummary() {
      const rec = state.recorder || {};
      const selected = currentCaptureSource();
      const sources = Array.isArray(rec.sources) ? rec.sources : [];
      const sourcesScanned = sources.length > 0;
      const hasFolder = Boolean(state.settings && state.settings.recordingsDir && state.settings.recordingsDirConfirmed);
      const hasSource = Boolean(rec.selectedSourceId);
      const approvalNeeded = Boolean(rec.sourceApprovalRequired && !rec.sourceApproved);
      const savedSourceMissing = Boolean(hasSource && sourcesScanned && !selected);
      const isStarting = rec.status === 'starting' || rec.transition === 'starting';
      const isStopping = rec.status === 'stopping' || rec.transition === 'stopping';
      const isRecording = recorderIsActive();
      const busy = Boolean(isStarting || isStopping);
      const selectedName = selected
        ? (selected.name || rec.selectedSourceName || 'Selected source')
        : (hasSource ? (rec.selectedSourceName || 'Selected source') : 'No source selected');
      const ready = Boolean(hasFolder && hasSource && !approvalNeeded && !savedSourceMissing);

      let title = 'Ready';
      let hint = selectedName;
      let tone = 'good';
      let setupTarget = 'source';

      if (isStopping) {
        title = 'Stopping and saving…';
        hint = selectedName || 'Saving recording';
        tone = 'recording';
        setupTarget = 'none';
      } else if (isRecording) {
        title = `Recording ${formatElapsed(rec.elapsed || 0)}`;
        hint = selectedName || 'Recording locally';
        tone = 'recording';
        setupTarget = 'none';
      } else if (isStarting) {
        title = 'Starting…';
        hint = selectedName || 'Starting recorder';
        tone = 'recording';
        setupTarget = 'none';
      } else if (!hasFolder) {
        title = 'Needs folder';
        hint = 'Choose a recording folder before starting.';
        tone = 'warn';
        setupTarget = 'folder';
      } else if (!hasSource) {
        title = 'Needs source';
        hint = 'Choose World of Warcraft or a screen to record.';
        tone = 'warn';
        setupTarget = 'source';
      } else if (savedSourceMissing) {
        title = 'Source missing';
        hint = 'The saved source is not available. Scan again or choose another source.';
        tone = 'warn';
        setupTarget = 'source';
      } else if (approvalNeeded) {
        title = 'Approve source';
        hint = 'World of Warcraft was detected. Approve it once or choose another source.';
        tone = 'warn';
        setupTarget = 'source';
      } else {
        title = 'Ready';
        hint = selectedName || 'Ready to record';
        tone = 'good';
        setupTarget = 'source';
      }

      return {
        selected,
        selectedName,
        sourceText: selectedName,
        hasFolder,
        hasSource,
        approvalNeeded,
        savedSourceMissing,
        ready,
        isRecording,
        isStarting,
        isStopping,
        busy,
        title,
        hint,
        tone,
        setupTarget,
        startDisabled: Boolean(isRecording || busy || !ready),
        stopDisabled: Boolean(!isRecording || isStopping)
      };
    }

    function openRecorderSetupFromDashboard() {
      const setup = recorderSetupSummary();
      if (setup.setupTarget === 'folder') {
        state.active = 'Recorder';
        state.showRecorderSettings = true;
        render();
        return;
      }
      state.showSourceQuickPicker = true;
      render();
      window.setTimeout(refreshCaptureSources, 80);
    }

    return {
      captureSourceKind,
      sourceLooksLikeWow,
      normalizedSourceName,
      isSourceApproved,
      preferredWowSource,
      rememberApprovedCaptureSource,
      allowedCaptureSources,
      sourceSort,
      validRecorderPerformanceMode,
      recorderPerformanceProfile,
      recorderPerformanceLabel,
      recorderPerformanceCaption,
      recorderChunkMs,
      currentCaptureSource,
      recorderSetupSummary,
      openRecorderSetupFromDashboard
    };
  }

  window.LastCallRecorderSourceHelpers = { createRecorderSourceTools };
})();
