(function () {
  'use strict';

  function createPvPHelperSetupActions(deps = {}) {
    if (!deps || !deps.state) throw new Error('LastCallPvPHelperSetupActions requires app state.');
    const state = deps.state;
    const api = deps.api || null;
    const alert = deps.alert || ((message) => window.alert(message));
    const confirm = deps.confirm || ((message) => window.confirm(message));
    const render = deps.render || (() => {});
    const dashboardAddonStatusSummary = deps.dashboardAddonStatusSummary || (() => ({}));
    const applyImportJobStatus = deps.applyImportJobStatus || (() => {});
    const clearRailFeedCache = deps.clearRailFeedCache || (() => {});
    const dedupeCharacterSnapshots = deps.dedupeCharacterSnapshots || ((snapshots) => snapshots || []);
    const sortMatchesForLibrary = deps.sortMatchesForLibrary || ((matches) => matches || []);
    const dedupeMatches = deps.dedupeMatches || ((matches) => matches || []);
    const pickAndWatchFolder = deps.pickAndWatchFolder || (async () => null);

    async function refreshPvPHelperAddonInstallStatus(silent = false) {
      if (!api || !api.getPvPHelperAddonStatus) return null;
      try {
        const result = await api.getPvPHelperAddonStatus();
        if (result && result.status) state.pvpHelperInstallStatus = result.status;
        if (result && result.settings) state.settings = { ...state.settings, ...(result.settings || {}) };
        if (!silent) render();
        return result;
      } catch (error) {
        console.warn('[Last Call Replay] PvPHelper addon status failed.', error);
        if (!silent) alert('Could not check PvPHelper install status.');
        return null;
      }
    }


    async function installPvPHelperAddon() {
      if (!api || !api.installPvPHelperAddon) return alert('Addon install is only available in the desktop app.');
      state.addonInstallBusy = true;
      render();
      try {
        const result = await api.installPvPHelperAddon();
        if (result && result.status) state.pvpHelperInstallStatus = result.status;
        if (result && result.settings) state.settings = { ...state.settings, ...(result.settings || {}) };
        state.addonInstallBusy = false;
        if (!result || !result.ok) {
          render();
          return alert((result && result.reason) || 'Could not install PvPHelper.');
        }
        render();
      } catch (error) {
        state.addonInstallBusy = false;
        render();
        alert(error && error.message ? error.message : 'Could not install PvPHelper.');
      }
    }


    async function handleTopbarAddonInstallClick() {
      const addon = dashboardAddonStatusSummary();
      const install = addon.install || {};
      if (install.canInstall && (!install.addonInstalled || install.needsUpdate)) return installPvPHelperAddon();
      if (!install.wowRoot) return pickAndWatchFolder();
      if (!install.packageAvailable && install.packageDropDir && api && api.revealPath) {
        return api.revealPath(install.packageDropDir);
      }
      if (install.installedDir && api && api.revealPath) return api.revealPath(install.installedDir);
      state.active = 'Settings';
      render();
    }


    function applyPvPHelperImportResult(result) {
      clearRailFeedCache();
      if (result && result.matches) state.matches = result.matches;
      if (result && result.characterSnapshots) state.characterSnapshots = dedupeCharacterSnapshots(result.characterSnapshots);
      else if (result && result.snapshots) state.characterSnapshots = dedupeCharacterSnapshots(result.snapshots);
      else state.characterSnapshots = dedupeCharacterSnapshots(state.characterSnapshots || []);
      if (result && result.addonImports) state.addonImports = result.addonImports;
      if (result && result.importedFiles) state.importedFiles = result.importedFiles;
      if (result && result.settings) state.settings = { ...state.settings, ...result.settings };
      state.matches = sortMatchesForLibrary(dedupeMatches(state.matches || []));
    }


    function pvpHelperImportMessage(result, prefix = 'Synced PvPHelper.lua') {
      if (result && result.upToDate) return 'PvPHelper.lua is already up to date.';
      const archiveNote = result && result.archiveEntry ? ` from ${result.archiveEntry}` : '';
      const parsed = Number(result && result.parsed) || 0;
      const merged = Number(result && result.merged) || 0;
      const created = Number(result && result.created) || 0;
      const skipped = Number(result && result.skipped) || 0;
      const ratingImported = Number(result && result.ratingImported) || 0;
      const ratingParsed = Number(result && result.snapshots) || 0;
      const changed = merged + created + ratingImported;
      const ratingText = ratingParsed || ratingImported ? ` ${ratingImported} new rating snapshot${ratingImported === 1 ? '' : 's'}${ratingParsed && ratingParsed !== ratingImported ? ` from ${ratingParsed} found` : ''}.` : '';
      if (parsed && !changed) {
        return `${prefix}${archiveNote}. ${parsed} scoreboard snapshot${parsed === 1 ? '' : 's'} parsed, but no new matches were added.${ratingText} ${skipped ? `${skipped} duplicate/skipped.` : 'They may already be imported.'}`;
      }
      return `${prefix}${archiveNote}. ${parsed} scoreboard snapshot${parsed === 1 ? '' : 's'} parsed, ${merged} merged, ${created} pending scoreboard link${created === 1 ? '' : 's'} created${skipped ? `, ${skipped} skipped` : ''}.${ratingText}`;
    }


    async function refreshPvPHelperSavedVariablesDiscovery(renderAfter = true) {
      if (!api || !api.getPvPHelperSavedVariablesDiscovery) return null;
      try {
        const result = await api.getPvPHelperSavedVariablesDiscovery();
        if (result && result.discovery) state.pvpHelperSavedVariablesDiscovery = result.discovery;
        if (result && result.settings) state.settings = { ...state.settings, ...result.settings };
        if (renderAfter) render();
        return result;
      } catch (error) {
        console.warn('[Last Call Replay] PvPHelper SavedVariables discovery failed.', error);
        return null;
      }
    }


    async function autoPreviewPvPHelperSavedVariables() {
      if (!api || !api.autoPreviewPvPHelperSavedVariables) return importPvPHelperSavedVariables();
      try {
        const result = await api.autoPreviewPvPHelperSavedVariables();
        if (result && result.discovery) state.pvpHelperSavedVariablesDiscovery = result.discovery;
        if (result && result.settings) state.settings = { ...state.settings, ...result.settings };
        if (result && result.ok) {
          state.pvpHelperImportPreview = result;
          render();
          return;
        }
        render();
        alert((result && result.reason) || 'Could not find PvPHelper.lua automatically. Choose the SavedVariables folder under WTF\\Account\\<AccountName>, and the app will find PvPHelper.lua inside.');
      } catch (error) {
        render();
        alert(`PvPHelper auto-find failed: ${error && error.message ? error.message : error}`);
      }
    }


    async function importPvPHelperSavedVariables() {
      if (!api || !api.previewPvPHelperSavedVariables) return alert('PvPHelper SavedVariables mapping is only available in the desktop app.');
      try {
        const result = await api.previewPvPHelperSavedVariables();
        if (result && result.discovery) state.pvpHelperSavedVariablesDiscovery = result.discovery;
        if (result && result.cancelled) return;
        if (result && result.ok) {
          state.pvpHelperImportPreview = result;
          render();
          return;
        }
        render();
        if (result && result.reason) alert(result.reason);
      } catch (error) {
        render();
        alert(`PvPHelper mapping preview failed: ${error && error.message ? error.message : error}`);
      }
    }


    async function applyPvPHelperImportPreview() {
      const preview = state.pvpHelperImportPreview;
      if (!preview || !preview.filePath) return;
      if (!api || !api.applyPvPHelperSavedVariablesPreview) return alert('PvPHelper SavedVariables mapping is only available in the desktop app.');
      try {
        const result = await api.applyPvPHelperSavedVariablesPreview({ filePath: preview.filePath, autoSync: true });
        applyImportJobStatus(result || {});
        applyPvPHelperImportResult(result || {});
        state.pvpHelperImportPreview = null;
        render();
        if (result && result.ok) alert(pvpHelperImportMessage(result, 'Mapped folder and synced PvPHelper.lua'));
        else if (result && result.reason) alert(result.reason);
      } catch (error) {
        render();
        alert(`PvPHelper sync failed: ${error && error.message ? error.message : error}`);
      }
    }


    async function syncMappedPvPHelperSavedVariables({ force = true, silent = false } = {}) {
      if (!api || !api.syncMappedPvPHelperSavedVariables) {
        if (!silent) alert('PvPHelper sync is only available in the desktop app.');
        return;
      }
      if (state.pvpHelperSyncBusy) return;
      state.pvpHelperSyncBusy = true;
      if (!silent) render();
      try {
        const result = await api.syncMappedPvPHelperSavedVariables({ force });
        applyImportJobStatus(result || {});
        applyPvPHelperImportResult(result || {});
        state.pvpHelperSyncBusy = false;
        render();
        if (!silent) {
          if (result && result.ok) alert(pvpHelperImportMessage(result));
          else if (result && result.reason) alert(result.reason);
        }
      } catch (error) {
        state.pvpHelperSyncBusy = false;
        render();
        if (!silent) alert(`PvPHelper sync failed: ${error && error.message ? error.message : error}`);
      }
    }


    async function clearPvPHelperSavedVariablesMapping() {
      if (!confirm('Clear the mapped PvPHelper.lua path? Imported matches and snapshots stay in the app.')) return;
      if (!api || !api.clearPvPHelperSavedVariablesMapping) return alert('Mapping controls are only available in the desktop app.');
      const result = await api.clearPvPHelperSavedVariablesMapping();
      if (result && result.settings) state.settings = { ...state.settings, ...result.settings };
      render();
    }


    async function updatePvPHelperAutoSync(enabled) {
      state.settings.pvpHelperAutoSync = Boolean(enabled);
      if (api && api.saveSettings) state.settings = await api.saveSettings(state.settings);
      render();
    }


    async function importCharacterSnapshot() {
      if (!api || !api.importCharacterSnapshot) return alert('Legacy character snapshot import is only available in the desktop app.');
      try {
        const result = await api.importCharacterSnapshot();
        if (result && result.importedAs === 'pvphelper-preview') {
          state.pvpHelperImportPreview = result;
          render();
          return;
        }
        if (result && result.snapshots) state.characterSnapshots = dedupeCharacterSnapshots(result.snapshots);
        if (result && result.characterSnapshots) state.characterSnapshots = dedupeCharacterSnapshots(result.characterSnapshots);
        render();
        if (result && result.ok) {
          const parsed = Number(result.parsed) || 0;
          const imported = Number(result.imported) || 0;
          alert(imported
            ? `Imported ${imported} legacy rating snapshot entr${imported === 1 ? 'y' : 'ies'}.`
            : `No new legacy rating snapshots were imported.${parsed ? ' They may already be imported.' : ' For normal setup, map PvPHelper.lua instead.'}`);
        } else if (result && result.reason) {
          alert(result.reason);
        }
      } catch (error) {
        render();
        alert(`Legacy snapshot import failed: ${error && error.message ? error.message : error}`);
      }
    }

    return {
      refreshPvPHelperAddonInstallStatus,
      installPvPHelperAddon,
      handleTopbarAddonInstallClick,
      applyPvPHelperImportResult,
      pvpHelperImportMessage,
      refreshPvPHelperSavedVariablesDiscovery,
      autoPreviewPvPHelperSavedVariables,
      importPvPHelperSavedVariables,
      applyPvPHelperImportPreview,
      syncMappedPvPHelperSavedVariables,
      clearPvPHelperSavedVariablesMapping,
      updatePvPHelperAutoSync,
      importCharacterSnapshot
    };
  }

  window.LastCallPvPHelperSetupActions = { createPvPHelperSetupActions };
})();
