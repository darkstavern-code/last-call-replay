(function () {
  'use strict';

  function createVodViewTools(deps = {}) {
    const state = deps.state || { vods: [], matches: [] };
    const escapeHtml = deps.escapeHtml || ((value) => String(value || ''));
    const formatElapsed = deps.formatElapsed || ((value) => String(value || 0));
    const localDateTimeInputValue = deps.localDateTimeInputValue || (() => '');
    const filteredMatches = deps.filteredMatches || (() => []);
    const canonicalMatchTypeLabel = deps.canonicalMatchTypeLabel || ((value) => String(value || ''));
    const normalizedMatchType = deps.normalizedMatchType || ((match) => match && (match.matchType || match.bracket) || '');
    const isBattlegroundMatch = deps.isBattlegroundMatch || (() => false);
    const matchTimestampLabel = deps.matchTimestampLabel || (() => 'Unknown match time');
    const matchClock = deps.matchClock || (() => '');
    const displayMatchType = deps.displayMatchType || (() => 'PvP');
    const isSoloShuffleLobbyUiMatch = deps.isSoloShuffleLobbyUiMatch || (() => false);
    const soloShuffleRounds = deps.soloShuffleRounds || (() => []);
    const soloShuffleSummaryText = deps.soloShuffleSummaryText || (() => '0W - 0L');
    const pill = deps.pill || ((text) => `<span>${escapeHtml(text)}</span>`);
    const renderLoadMoreButton = deps.renderLoadMoreButton || (() => '');

    function parseVodStartFromFilename(filePath = '') {
      const raw = String(filePath || '').split(/[\\/]/).pop() || '';
      const name = raw.replace(/\.[^.]+$/, '');
      const match = name.match(/(20\d{2})[-_. ](\d{2})[-_. ](\d{2})[ T_-]+(\d{2})[-_.:](\d{2})(?:[-_.:](\d{2}))?/);
      if (!match) return null;
      const [, yyyy, mm, dd, hh, min, ss = '00'] = match;
      const date = new Date(Number(yyyy), Number(mm) - 1, Number(dd), Number(hh), Number(min), Number(ss));
      if (Number.isNaN(date.getTime())) return null;
      const label = `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
      return { iso: date.toISOString(), localValue: localDateTimeInputValue(date.toISOString()), label };
    }

    function selectedVod() {
      if (!state.selectedVodId && state.vods && state.vods.length) state.selectedVodId = state.vods[0].id;
      return (state.vods || []).find((item) => item && item.id === state.selectedVodId) || (state.vods || [])[0] || null;
    }

    function vodSuggestedStart(vod = selectedVod()) {
      if (!vod) return null;
      if (vod.suggestedStartIso) {
        const d = new Date(vod.suggestedStartIso);
        if (!Number.isNaN(d.getTime())) return { iso: d.toISOString(), localValue: localDateTimeInputValue(d.toISOString()), label: vod.suggestedStartLabel || d.toLocaleString() };
      }
      return parseVodStartFromFilename(vod.filePath || vod.label || '');
    }

    function isAddonOnlyTimingMatch(match = {}) {
      const sources = Array.isArray(match.dataSources) ? match.dataSources.map((source) => String(source || '').toLowerCase()) : [];
      const hasCombatLog = Boolean(match.createdFromRealLog) || sources.some((source) => /combat|log|tail/.test(source));
      const hasAddonScoreboard = Boolean(match.createdFromAddon || match.addonScoreboard || sources.includes('addonscoreboard'));
      return hasAddonScoreboard && !hasCombatLog;
    }

    function estimatedAddonOnlyDurationSec(match = {}) {
      const known = Number(match.durationSec || 0);
      if (Number.isFinite(known) && known > 5) return known;
      const type = canonicalMatchTypeLabel(match.matchType || match.bracket || '');
      const expectedTeamSize = Number(match.expectedTeamSize || match.actualTeamSize || 0);
      if (isBattlegroundMatch(match) || expectedTeamSize >= 6) return 15 * 60;
      if (/shuffle/i.test(type) || match.isSoloShuffle) return 7 * 60;
      if (/arena|2v2|3v3|skirmish/i.test(type)) return 6 * 60;
      return 5 * 60;
    }

    function matchDurationForDisplay(match = {}) {
      const known = Number(match.durationSec || 0);
      if (Number.isFinite(known) && known > 5) return match.duration || formatElapsed(known);
      if (isAddonOnlyTimingMatch(match)) return `est. ${formatElapsed(estimatedAddonOnlyDurationSec(match))}`;
      return match.duration || formatElapsed(known || 0);
    }

    function matchRangeMsForVod(match = {}) {
      const parsedStart = Number(match.startMs) || (match.startIso ? Date.parse(match.startIso) : 0);
      const gameStart = Number(match.gameStartMs) || parsedStart;
      const enteredStart = Number(match.loadedInMs) || Number(match.enteredAtMs) || Number(match.gameStartMs) || parsedStart || Number(match.videoSegmentStartMs) || (match.videoSegmentStartIso ? Date.parse(match.videoSegmentStartIso) : 0);
      let start = enteredStart || gameStart;
      let end = Number(match.endMs) || (match.endIso ? Date.parse(match.endIso) : 0);
      const duration = Number(match.durationSec) || 0;
      let estimatedFromScoreboard = false;
      if (end && isAddonOnlyTimingMatch(match) && duration <= 5) {
        start = Math.max(0, end - estimatedAddonOnlyDurationSec(match) * 1000);
        estimatedFromScoreboard = true;
      }
      if ((!Number.isFinite(end) || end <= start) && gameStart && duration > 0) end = gameStart + duration * 1000;
      if ((!Number.isFinite(end) || end <= start) && start) end = start + 120000;
      return { start, gameStart, end, estimatedFromScoreboard };
    }

    function boundedMatchRangeMsForVod(match = {}, windowStart = 0, windowEnd = 0) {
      const range = matchRangeMsForVod(match);
      if (!range.estimatedFromScoreboard || !range.end) return range;
      const currentId = String(match.id || '');
      const previousEnd = (state.matches || []).reduce((best, other) => {
        if (!other || String(other.id || '') === currentId) return best;
        const otherRange = matchRangeMsForVod(other);
        const otherEnd = Number(otherRange.end || 0);
        if (!otherEnd || otherEnd >= range.end - 5000) return best;
        if (windowStart && otherEnd < windowStart - 600000) return best;
        if (windowEnd && otherEnd > windowEnd + 600000) return best;
        return Math.max(best, otherEnd);
      }, 0);
      const upperStart = Math.max(0, range.end - 5000);
      let safeStart = Math.max(Number(windowStart || 0), previousEnd ? previousEnd + 5000 : 0, range.start || 0);
      if (safeStart > upperStart) safeStart = Math.max(Number(windowStart || 0), range.start || 0);
      if (safeStart > upperStart) safeStart = upperStart;
      return { ...range, start: safeStart };
    }

    function intervalsOverlapForVod(aStart, aEnd, bStart, bEnd) {
      if (!aStart || !bStart) return false;
      const a2 = aEnd || aStart;
      const b2 = bEnd || bStart;
      return aStart <= b2 && bStart <= a2;
    }

    function confidentVodMatchOverlap(vodStart, vodEnd, matchStart, matchEnd, bufferMs = 90000) {
      if (!vodStart || !vodEnd || !matchStart || !matchEnd || vodEnd <= vodStart || matchEnd <= matchStart) return false;
      const bufferedStart = vodStart - bufferMs;
      const bufferedEnd = vodEnd + bufferMs;
      if (!intervalsOverlapForVod(bufferedStart, bufferedEnd, matchStart, matchEnd)) return false;
      const overlapStart = Math.max(vodStart, matchStart);
      const overlapEnd = Math.min(vodEnd, matchEnd);
      const overlapMs = Math.max(0, overlapEnd - overlapStart);
      const matchMs = Math.max(1, matchEnd - matchStart);
      return overlapMs >= Math.min(45000, matchMs * 0.25) || (matchStart >= bufferedStart && matchStart <= bufferedEnd);
    }

    function defaultVodPreRollSec(match = {}) {
      return isBattlegroundMatch(match) ? 90 : 45;
    }

    function matchReplayStartMsForVod(match = {}, fallbackStart = 0) {
      const candidates = [
        Number(match.loadedInMs),
        Number(match.enteredAtMs),
        Number(match.videoSegmentStartMs),
        match.videoSegmentStartIso ? Date.parse(match.videoSegmentStartIso) : 0,
        Number(match.queueAcceptedMs),
        match.queueAcceptedIso ? Date.parse(match.queueAcceptedIso) : 0,
        fallbackStart
      ];
      const valid = candidates.filter((value) => Number.isFinite(value) && value > 0);
      if (!valid.length) return Number(fallbackStart || 0);
      const earliest = Math.min(...valid);
      const fallback = Number(fallbackStart || 0);
      if (fallback && earliest < fallback - 20 * 60 * 1000) return fallback;
      return earliest;
    }

    function isSoloShuffleVodMatch(match = {}) {
      return canonicalMatchTypeLabel(normalizedMatchType(match)) === 'Solo Shuffle' || Boolean(match.isSoloShuffle);
    }

    function videoGroupRangeForVodMatch(match = {}) {
      if (!isSoloShuffleVodMatch(match)) return null;
      const start = Number(match.soloShuffleSessionStartMs) || 0;
      const end = Number(match.soloShuffleSessionEndMs) || 0;
      return start && end && end > start ? { start, end } : null;
    }

    function formatDateTimeShort(ms) {
      const value = Number(ms) || 0;
      if (!value) return '';
      const d = new Date(value);
      if (Number.isNaN(d.getTime())) return '';
      return d.toLocaleString([], { month: 'numeric', day: 'numeric', year: 'numeric', hour: 'numeric', minute: '2-digit' });
    }

    function formatTimeOnly(ms) {
      const value = Number(ms) || 0;
      if (!value) return '';
      const d = new Date(value);
      if (Number.isNaN(d.getTime())) return '';
      return d.toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
    }

    function vodRealTimeForClipSec(vod = {}, clipSec = 0) {
      const vodStart = vod && vod.startIso ? Date.parse(vod.startIso) : 0;
      if (!vodStart) return 0;
      const offset = Number(vod.syncOffsetSec) || 0;
      return vodStart + (Number(clipSec || 0) - offset) * 1000;
    }

    function vodTimeSummary(vod = {}) {
      if (!vod || !vod.startIso) return 'VOD start time is not set.';
      const startMs = Date.parse(vod.startIso);
      const endMs = vod.endIso ? Date.parse(vod.endIso) : 0;
      const parts = [`Starts ${formatDateTimeShort(startMs) || 'unknown'}`];
      if (Number.isFinite(endMs) && endMs > startMs) parts.push(`Ends ${formatTimeOnly(endMs)}`);
      parts.push(`Offset ${Number(vod.syncOffsetSec || 0)}s`);
      return parts.join(' · ');
    }

    function renderVodCandidateRow(candidate, vod) {
      const { match, clipStart, clipEnd, startMs, endMs, rawStart, rawEnd, groupRange } = candidate || {};
      const matchWindow = startMs ? `${formatDateTimeShort(startMs)}${endMs ? ` → ${formatTimeOnly(endMs)}` : ''}` : (matchTimestampLabel(match) || 'Unknown match time');
      const realStart = vodRealTimeForClipSec(vod, clipStart);
      const realEnd = vodRealTimeForClipSec(vod, clipEnd);
      const vodRealWindow = realStart ? `${formatDateTimeShort(realStart)}${realEnd ? ` → ${formatTimeOnly(realEnd)}` : ''}` : 'Unknown VOD time';
      const sectionLabel = groupRange ? 'Solo Shuffle lobby window' : 'Match window';
      const lobbyLine = isSoloShuffleLobbyUiMatch(match) ? `Solo Shuffle lobby · ${Number(match.soloShuffleDetectedRoundCount || 0) || soloShuffleRounds(match).length} rounds · ${soloShuffleSummaryText(match)}` : displayMatchType(match);
      const rawLabel = `${formatElapsed(rawStart)} → ${formatElapsed(rawEnd)}`;
      return `<div class="vod-preview-row">
        <div>
          <strong>${escapeHtml(matchClock(match) || '')} · ${escapeHtml(match.map || 'Unknown map')}</strong>
          <small>${escapeHtml(lobbyLine)} · ${escapeHtml(matchDurationForDisplay(match))}</small>
          <small class="vod-candidate-detail-line">Match real time: ${escapeHtml(matchWindow)}</small>
          <small class="vod-candidate-detail-line">VOD real time covered: ${escapeHtml(vodRealWindow)}</small>
        </div>
        <span class="vod-candidate-time"><strong>VOD clip</strong>${formatElapsed(clipStart)} → ${formatElapsed(clipEnd)}<small>${escapeHtml(sectionLabel)} ${escapeHtml(rawLabel)}</small></span>
        <div class="vod-preview-actions">${match.vodId === vod.id ? pill('linked', 'emerald') : pill('candidate', 'cyan')}<button class="btn small ${match.vodId === vod.id ? '' : 'violet'}" data-link-vod-match="${escapeHtml(match.id)}">${match.vodId === vod.id ? 'Relink' : 'Apply'}</button></div>
      </div>`;
    }

    function vodCandidates(vod = selectedVod()) {
      if (!vod || !vod.startIso || !vod.filePath) return [];
      const vodStart = Date.parse(vod.startIso);
      const vodEnd = vod.endIso ? Date.parse(vod.endIso) : 0;
      const hasVodEnd = Number.isFinite(vodEnd) && vodEnd > vodStart;
      if (!Number.isFinite(vodStart) || vodStart <= 0) return [];
      const offset = Number(vod.syncOffsetSec) || 0;
      const requestedPre = Number(state.vodPreRollSec);
      const requestedPost = Number(state.vodPostRollSec);
      const preOverride = Number.isFinite(requestedPre) ? requestedPre : NaN;
      const post = Math.max(0, Math.min(240, Number.isFinite(requestedPost) ? requestedPost : 0));
      const maxStreamSeconds = 12 * 3600;
      return filteredMatches().map((match) => {
        if (!match || match.scoreboardPendingLink || match.pendingScoreboardLink) return null;
        const { start, end } = boundedMatchRangeMsForVod(match, vodStart, hasVodEnd ? vodEnd : 0);
        if (!start || !end || end <= start) return null;
        const groupRange = videoGroupRangeForVodMatch(match);
        const replayStart = matchReplayStartMsForVod(match, start);
        const sectionStart = groupRange ? groupRange.start : replayStart;
        const sectionEnd = groupRange ? groupRange.end : end;
        if (hasVodEnd && !confidentVodMatchOverlap(vodStart, vodEnd, sectionStart, sectionEnd, 90000)) return null;
        const roundRawStart = (start - vodStart) / 1000 + offset;
        const roundRawEnd = (end - vodStart) / 1000 + offset;
        const rawStart = (sectionStart - vodStart) / 1000 + offset;
        const rawEnd = (sectionEnd - vodStart) / 1000 + offset;
        const pre = Math.max(0, Math.min(120, Number.isFinite(preOverride) ? preOverride : defaultVodPreRollSec(match)));
        const clipStart = Math.max(0, rawStart - pre);
        const sessionEndSec = hasVodEnd ? Math.max(5, (vodEnd - vodStart) / 1000 + offset) : maxStreamSeconds;
        const clipEnd = Math.min(Math.max(clipStart + 5, rawEnd + post), Math.max(clipStart + 5, sessionEndSec));
        if (clipEnd <= 0 || rawStart > maxStreamSeconds || rawEnd < -300) return null;
        return {
          match,
          clipStart: Math.max(0, Math.round(clipStart * 10) / 10),
          clipEnd: Math.max(0, Math.round(clipEnd * 10) / 10),
          rawStart: Math.round(rawStart * 10) / 10,
          rawEnd: Math.round(rawEnd * 10) / 10,
          roundRawStart: Math.round(roundRawStart * 10) / 10,
          roundRawEnd: Math.round(roundRawEnd * 10) / 10,
          startMs: start,
          endMs: end,
          sectionStartMs: sectionStart,
          sectionEndMs: sectionEnd,
          groupRange
        };
      }).filter(Boolean).sort((a, b) => (Date.parse(a.match.startIso || 0) || 0) - (Date.parse(b.match.startIso || 0) || 0));
    }

    function renderVodCard(vod) {
      const active = selectedVod() && selectedVod().id === vod.id;
      const linkedCount = (state.matches || []).filter((match) => match && match.vodId === vod.id).length || Number(vod.lastLinkedCount || 0);
      return `<div class="vod-item ${active ? 'active' : ''}" data-select-vod="${escapeHtml(vod.id)}" role="button" tabindex="0">
        <div class="vod-item-main">
          <strong>${escapeHtml(vod.label || 'Imported VOD')}</strong>
          <span class="caption path-value">${escapeHtml(vod.filePath || '')}</span>
          <small>${vod.sourceType === 'recording-session' ? 'Recorder session · ' : ''}${vod.startIso ? `Starts ${escapeHtml(new Date(vod.startIso).toLocaleString())}` : 'Start time not set'}${linkedCount ? ` · ${linkedCount} linked` : ''}</small>
        </div>
        <div class="vod-item-actions">
          <button class="btn small danger ghost" data-delete-vod="${escapeHtml(vod.id)}" title="Remove this VOD from the app library">Delete</button>
        </div>
      </div>`;
    }

    function sortedVodsForLibrary() {
      return [...(state.vods || [])].filter(Boolean).sort((a, b) => {
        const bt = Date.parse(b.importedAt || b.lastLinkedAt || 0) || 0;
        const at = Date.parse(a.importedAt || a.lastLinkedAt || 0) || 0;
        return bt - at;
      });
    }

    function renderVodControls() {
      const vod = selectedVod();
      const candidates = vodCandidates(vod);
      const suggestion = vodSuggestedStart(vod);
      const startValue = localDateTimeInputValue(vod && vod.startIso) || (suggestion && suggestion.localValue) || '';
      const linkedMatches = (state.matches || []).filter((match) => match && match.vodId === (vod && vod.id));
      const libraryVods = sortedVodsForLibrary();
      const vodLibraryLimit = state.showAllVods ? Math.max(10, Number(state.vodLibraryVisibleLimit || 40)) : 3;
      const visibleVods = libraryVods.slice(0, vodLibraryLimit);
      const hiddenVodCount = Math.max(0, libraryVods.length - visibleVods.length);
      const vodLibraryBody = visibleVods.length
        ? visibleVods.map(renderVodCard).join('')
        : '<div class="empty slim-empty">No VOD added yet. Drag, drop, paste, or choose local video files to start.</div>';
      return `
        <div class="section-stack vod-page" id="vod-page">
          <div class="page-heading">
            <div><p class="kicker">VOD Controls MVP</p><h2>Match a long VOD to combat logs</h2><p class="body">Import a local VOD or use a long recorder session, set the real start time, then link each combat-log match to its exact video slice.</p></div>
            <button class="btn primary" data-import-vod-file>Choose VOD File</button>
          </div>
          <div class="vod-command-grid">
            <div class="card vod-drop-card">
              <div class="vod-import-drop" id="vod-import-drop" tabindex="0" role="button" aria-label="Add VOD files by dragging, dropping, pasting, or choosing files">
                <div class="drop-icon">🎬</div>
                <h3>Drop VOD files here</h3>
                <p>Drag in a local video, paste copied video files, or choose files manually. MKV, MP4, MOV, WEBM, and AVI are supported for import.</p>
                <div class="action-row center"><button class="btn primary" data-import-vod-file>Choose Video Files</button><span class="caption">Copied files from Explorer can be pasted here.</span></div>
              </div>
            </div>
            <div class="card vod-library-card">
              <div class="vod-library-head card-title-row"><div><p class="small-label">VOD library</p><h2>Imported VODs</h2></div><div class="icon-bubble">🎬</div></div>
              <p class="caption">Showing ${state.showAllVods ? 'more imported VODs' : 'recent VODs'}. Downloaded Twitch VODs and long recorder sessions work here.</p>
              <div class="vod-list">${vodLibraryBody}</div>
              ${libraryVods.length > 3 ? `<div class="vod-library-more"><button class="btn small" id="toggle-vod-library-more">${state.showAllVods ? 'Show Recent Only' : `More (${hiddenVodCount})`}</button>${state.showAllVods ? renderLoadMoreButton('load-more-vods', visibleVods.length, libraryVods.length, 'VODs') : ''}</div>` : ''}
            </div>
            <div class="card vod-alignment-card">
              <div class="card-title-row"><div><p class="small-label">Alignment</p><h2>${vod ? 'VOD timing' : 'Add a VOD to start'}</h2></div><div class="icon-bubble">⏱️</div></div>
              ${vod ? `
                <label class="filter-control wide"><span>Label</span><input id="vod-label" value="${escapeHtml(vod.label || '')}" /></label>
                <label class="filter-control wide"><span>VOD real start time</span><input id="vod-start-time" type="datetime-local" step="1" value="${escapeHtml(startValue)}" /></label>
                ${suggestion ? `<div class="vod-suggest-row"><span class="pill cyan">Suggested from filename</span><code>${escapeHtml(suggestion.label)}</code><button class="btn small" id="use-vod-filename-time">Use Filename Time</button></div>` : `<p class="caption">Tip: filenames like <code>2026-05-10 14-09-46.mkv</code> can auto-fill the exact start time.</p>`}
                <div class="filter-grid three-mini">
                  <label class="filter-control"><span>Sync offset seconds</span><input id="vod-sync-offset" type="number" step="0.25" value="${Number(vod.syncOffsetSec || 0)}" /></label>
                  <label class="filter-control"><span>Pre-roll</span><input id="vod-pre-roll" type="number" min="0" max="120" value="${Number(state.vodPreRollSec || 0)}" /></label>
                  <label class="filter-control"><span>Post-roll</span><input id="vod-post-roll" type="number" min="0" max="240" value="${Number(state.vodPostRollSec || 0)}" /></label>
                </div>
                <div class="action-row"><button class="btn" id="save-vod-meta">Save Timing</button><button class="btn violet" id="link-vod-matches" ${vod.startIso ? '' : 'disabled'}>Link All Candidates</button></div>
                <p class="caption vod-time-summary">${escapeHtml(vodTimeSummary(vod))}</p>
                <p class="caption">Detected candidates: <strong>${candidates.length}</strong>. Already linked from this VOD: <strong>${linkedMatches.length}</strong>.</p>
                ${state.vodStatus ? `<div class="info-box compact-status"><p class="caption">${escapeHtml(state.vodStatus)}</p></div>` : ''}
              ` : '<div class="empty slim-empty">Add a VOD file, then set when the stream/video started.</div>'}
            </div>
          </div>
          ${vod ? `<div class="card vod-preview-card">
            <div class="card-title-row"><div><p class="small-label">Preview</p><h2>Combat-log sections found in this VOD</h2><p class="caption">These are calculated from load-in/start timestamps vs. the VOD start time. Arena VOD sections start from the room load-in when the log exposes it, not just gate open.</p></div><div class="icon-bubble">🧭</div></div>
            <div class="vod-match-preview">
              ${candidates.slice(0, Math.max(20, Number(state.vodCandidateVisibleLimit || 60))).map((candidate) => renderVodCandidateRow(candidate, vod)).join('') || '<div class="empty slim-empty">No matches line up yet. Check the VOD start time and imported combat logs.</div>'}
              ${renderLoadMoreButton('load-more-vod-candidates', Math.min(candidates.length, Math.max(20, Number(state.vodCandidateVisibleLimit || 60))), candidates.length, 'candidate matches')}
            </div>
          </div>` : ''}
        </div>
      `;
    }

    return {
      parseVodStartFromFilename,
      vodSuggestedStart,
      selectedVod,
      isAddonOnlyTimingMatch,
      estimatedAddonOnlyDurationSec,
      matchDurationForDisplay,
      matchRangeMsForVod,
      boundedMatchRangeMsForVod,
      intervalsOverlapForVod,
      confidentVodMatchOverlap,
      defaultVodPreRollSec,
      matchReplayStartMsForVod,
      isSoloShuffleVodMatch,
      videoGroupRangeForVodMatch,
      formatDateTimeShort,
      formatTimeOnly,
      vodRealTimeForClipSec,
      vodTimeSummary,
      renderVodCandidateRow,
      vodCandidates,
      renderVodCard,
      sortedVodsForLibrary,
      renderVodControls
    };
  }

  window.LastCallVodView = { createVodViewTools };
})();
