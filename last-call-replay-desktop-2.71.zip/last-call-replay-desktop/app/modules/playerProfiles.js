(function () {
  'use strict';

  function createPlayerProfileTools(deps = {}) {
    const matchScoreboardPlayers = deps.matchScoreboardPlayers || (() => []);
    const namesShareEnemyIdentity = deps.namesShareEnemyIdentity || ((a, b) => String(a || '').toLowerCase() === String(b || '').toLowerCase());
    const effectiveMatchType = deps.effectiveMatchType || ((match) => match && (match.matchType || match.bracket || 'PvP'));
    const isSoloShuffleLobbyUiMatch = deps.isSoloShuffleLobbyUiMatch || (() => false);
    const matchTypeMatchesFilter = deps.matchTypeMatchesFilter || (() => true);
    const isSoloShuffleUiMatch = deps.isSoloShuffleUiMatch || (() => false);
    const ownNameSetForMatch = deps.ownNameSetForMatch || (() => new Set());
    const enemyIdentityKey = deps.enemyIdentityKey || ((value) => String(value || '').toLowerCase().trim());
    const shortCharacterName = deps.shortCharacterName || ((value) => String(value || '').split('-')[0] || 'Unknown');
    const soloShufflePlayerSeenKey = deps.soloShufflePlayerSeenKey || (() => '');
    const playerMeetingDedupeKey = deps.playerMeetingDedupeKey || (() => '');
    const soloShufflePlayerRoundKey = deps.soloShufflePlayerRoundKey || (() => '');
    const playerMeetingTimeMs = deps.playerMeetingTimeMs || (() => 0);
    const mergeMeetingMatch = deps.mergeMeetingMatch || ((existing, incoming, relationship) => ({ ...(existing || incoming || {}), relationship }));
    const isBattlegroundMatch = deps.isBattlegroundMatch || (() => false);

    function addPlayerRatingSamples(profile, match, name, seenMs) {
      if (!profile || !match) return;
      for (const row of matchScoreboardPlayers(match)) {
        const rowName = row && (row.fullName || row.name || row.playerName);
        if (!namesShareEnemyIdentity(rowName, name)) continue;
        const rating = Number(row.rating);
        const mmr = Number(row.postmatchMMR || row.prematchMMR || row.mmr);
        const ratingChange = Number(row.ratingChange);
        if (Number.isFinite(rating) && rating > 0 || Number.isFinite(mmr) && mmr > 0) {
          const sampleKey = `${match.id || ''}|${rowName || name}|${rating || 0}|${mmr || 0}`;
          if (!profile.ratingSamples.some((sample) => sample.key === sampleKey)) {
            profile.ratingSamples.push({
              key: sampleKey,
              rating: Number.isFinite(rating) && rating > 0 ? rating : null,
              mmr: Number.isFinite(mmr) && mmr > 0 ? mmr : null,
              ratingChange: Number.isFinite(ratingChange) && ratingChange !== 0 ? ratingChange : null,
              bracket: effectiveMatchType(match),
              map: match.map || '',
              matchId: match.id || '',
              seenMs
            });
          }
        }
      }
    }

    function emptyProfile(name) {
      return {
        name,
        seen: 0,
        friendlySeen: 0,
        enemySeen: 0,
        observedSeen: 0,
        winsWith: 0,
        lossesWith: 0,
        winsAgainst: 0,
        lossesAgainst: 0,
        soloWinsAgainst: 0,
        soloLossesAgainst: 0,
        soloWinsWith: 0,
        soloLossesWith: 0,
        related: [],
        comps: new Map(),
        ratingSamples: [],
        lastSeen: '',
        lastSeenMs: 0,
        relationships: new Set(),
        seenMeetingKeys: new Set(),
        relationshipSeenKeys: new Set(),
        roundRecordKeys: new Set()
      };
    }

    function buildPlayerProfiles(appState = {}) {
      const profiles = new Map();
      const hidden = new Set((appState.hiddenPlayers || []).map((name) => String(name || '').toLowerCase()));
      for (const match of appState.matches || []) {
        if (isSoloShuffleLobbyUiMatch(match)) continue;
        if (!matchTypeMatchesFilter(match, appState.playerMatchTypeFilter)) continue;
        const isSoloRound = isSoloShuffleUiMatch(match);
        const ownNames = ownNameSetForMatch(match);
        const friendlySet = new Set(match.teams && match.teams['1'] ? match.teams['1'] : (match.myComp || []));
        const enemySet = new Set(match.enemies || (match.teams && match.teams['0']) || match.enemyComp || []);
        for (const own of ownNames) {
          friendlySet.delete(own);
          enemySet.delete(own);
        }
        const names = new Set([...(match.participants || []), ...friendlySet, ...enemySet]);
        for (const own of ownNames) names.delete(own);
        for (const name of names) {
          if (!name || name === 'Unknown' || /^Player-/.test(name)) continue;
          if (hidden.has(String(name).toLowerCase()) || hidden.has(shortCharacterName(name).toLowerCase())) continue;
          const relationship = enemySet.has(name) ? 'Enemy' : friendlySet.has(name) ? 'Friendly' : 'Observed';
          if (appState.playerFilter === 'Friendlies' && relationship !== 'Friendly') continue;
          if (appState.playerFilter === 'Enemies' && relationship !== 'Enemy') continue;
          const profileKey = enemyIdentityKey(name);
          const profile = profiles.get(profileKey) || emptyProfile(name);
          if (!profile.seenMeetingKeys) profile.seenMeetingKeys = new Set();
          if (!profile.relationshipSeenKeys) profile.relationshipSeenKeys = new Set();
          if (!profile.roundRecordKeys) profile.roundRecordKeys = new Set();
          const seenMs = playerMeetingTimeMs(match);
          const meetingKey = isSoloRound ? soloShufflePlayerSeenKey(match, name) : playerMeetingDedupeKey(match, name);
          const roundKey = isSoloRound ? soloShufflePlayerRoundKey(match, name) : meetingKey;
          const relationshipKey = `${meetingKey || roundKey || match.id || name}|${relationship}`;
          const alreadySeen = meetingKey && profile.seenMeetingKeys.has(meetingKey);
          const alreadyRecordedRound = roundKey && profile.roundRecordKeys.has(roundKey);

          if (!alreadySeen) {
            if (meetingKey) profile.seenMeetingKeys.add(meetingKey);
            profile.seen += 1;
          }

          profile.relationships.add(relationship);
          if (!profile.relationshipSeenKeys.has(relationshipKey)) {
            profile.relationshipSeenKeys.add(relationshipKey);
            if (relationship === 'Friendly') profile.friendlySeen += 1;
            else if (relationship === 'Enemy') profile.enemySeen += 1;
            else profile.observedSeen += 1;
          }

          const relatedMatch = { ...match, relationship };
          const existingIndex = profile.related.findIndex((item) => {
            const itemKey = isSoloRound && isSoloShuffleUiMatch(item) ? soloShufflePlayerSeenKey(item, name) : playerMeetingDedupeKey(item, name);
            return itemKey && meetingKey && itemKey === meetingKey;
          });
          if (existingIndex >= 0) {
            const existing = profile.related[existingIndex];
            const relParts = new Set(String(existing.relationship || '').split(/\s+\/\s+/).filter(Boolean));
            relParts.add(relationship);
            const mergedRelationship = Array.from(relParts).join(' / ') || relationship;
            profile.related[existingIndex] = mergeMeetingMatch(existing, relatedMatch, mergedRelationship);
          } else {
            profile.related.push(relatedMatch);
          }
          addPlayerRatingSamples(profile, match, name, seenMs);

          if (!alreadyRecordedRound) {
            if (roundKey) profile.roundRecordKeys.add(roundKey);
            if (relationship === 'Friendly') {
              if (match.result === 'Win') profile.winsWith += 1;
              if (match.result === 'Loss') profile.lossesWith += 1;
              if (isSoloRound) {
                if (match.result === 'Win') profile.soloWinsWith += 1;
                if (match.result === 'Loss') profile.soloLossesWith += 1;
              }
            }
            if (relationship === 'Enemy') {
              if (match.result === 'Win') profile.winsAgainst += 1;
              if (match.result === 'Loss') profile.lossesAgainst += 1;
              if (isSoloRound) {
                if (match.result === 'Win') profile.soloWinsAgainst += 1;
                if (match.result === 'Loss') profile.soloLossesAgainst += 1;
              }
            }
            if (!isBattlegroundMatch(match)) {
              const compNames = relationship === 'Friendly'
                ? (match.myComp || []).filter((n) => !ownNames.has(n))
                : (match.enemyComp || []);
              const cleanCompNames = compNames.filter(Boolean);
              const compKey = cleanCompNames.length ? cleanCompNames.join(' + ') : (relationship === 'Friendly' ? 'Friendly team' : 'Enemy team');
              const existingComp = profile.comps.get(compKey) || { count: 0, names: cleanCompNames, matchId: match.id };
              existingComp.count += 1;
              if (!existingComp.names.length && cleanCompNames.length) existingComp.names = cleanCompNames;
              if (!existingComp.matchId && match.id) existingComp.matchId = match.id;
              profile.comps.set(compKey, existingComp);
            }
          }

          if (seenMs >= Number(profile.lastSeenMs || 0)) {
            profile.lastSeenMs = seenMs;
            profile.lastSeen = match.date || profile.lastSeen;
          }
          profiles.set(profileKey, profile);
        }
      }
      return Array.from(profiles.values()).sort((a, b) => b.seen - a.seen).slice(0, 120);
    }

    return { addPlayerRatingSamples, buildPlayerProfiles };
  }

  window.LastCallPlayerProfiles = { createPlayerProfileTools };
}());
