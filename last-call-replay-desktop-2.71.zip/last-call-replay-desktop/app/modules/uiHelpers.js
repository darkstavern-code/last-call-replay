(function () {
  'use strict';

  const UI_PREFS_KEY = 'lastCallReplayUiPrefs';
  const RENDERER_CLASS_COLORS = {
    DeathKnight: '#C41E3A',
    DemonHunter: '#A330C9',
    Druid: '#FF7C0A',
    Evoker: '#33937F',
    Hunter: '#AAD372',
    Mage: '#3FC7EB',
    Monk: '#00FF98',
    Paladin: '#F48CBA',
    Priest: '#FFFFFF',
    Rogue: '#FFF468',
    Shaman: '#0070DD',
    Warlock: '#8788EE',
    Warrior: '#C69B6D'
  };

  function createUiHelpers(deps = {}) {
    const storage = deps.storage || window.localStorage;
    const cssApi = deps.css || window.CSS;

    function readUiPrefs() {
      try {
        const raw = storage && storage.getItem(UI_PREFS_KEY);
        return raw ? JSON.parse(raw) || {} : {};
      } catch (_error) {
        return {};
      }
    }

    function writeUiPrefs(patch = {}) {
      try {
        const next = { ...readUiPrefs(), ...(patch || {}) };
        if (storage) storage.setItem(UI_PREFS_KEY, JSON.stringify(next));
      } catch (_error) {}
    }

    function rememberSelectedCharacterKey(key) {
      if (!key || key === 'All') return;
      writeUiPrefs({ selectedCharacterKey: key });
    }

    function rememberedSelectedCharacterKey() {
      const prefs = readUiPrefs();
      const key = String(prefs.selectedCharacterKey || '').trim();
      return key && key !== 'All' ? key : '';
    }

    function escapeHtml(value) {
      return String(value ?? '').replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
    }

    function cssEscape(value = '') {
      if (cssApi && typeof cssApi.escape === 'function') return cssApi.escape(String(value));
      return String(value).replace(/[^a-zA-Z0-9_-]/g, (ch) => `\\${ch}`);
    }

    function prettyNumber(value) {
      const n = Number(value) || 0;
      if (n >= 1000000) return `${(n / 1000000).toFixed(1)}M`;
      if (n >= 1000) return `${Math.round(n / 1000)}K`;
      return `${n}`;
    }

    function displayAppVersion(value) {
      const raw = String(value || '0.26');
      const patchStyle = raw.match(/^(\d+)\.0\.(\d+)$/);
      if (patchStyle) return `${patchStyle[1]}.${String(Number(patchStyle[2]) || 0).padStart(2, '0')}`;
      return raw.replace(/\.0$/, '');
    }

    function formatElapsed(seconds) {
      const total = Math.max(0, Math.floor(Number(seconds) || 0));
      const minutes = Math.floor(total / 60);
      const secs = total % 60;
      return `${minutes}:${String(secs).padStart(2, '0')}`;
    }

    function pad2(value) {
      return String(value).padStart(2, '0');
    }

    function localDateTimeInputValue(iso) {
      if (!iso) return '';
      const d = new Date(iso);
      if (Number.isNaN(d.getTime())) return '';
      return `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}T${pad2(d.getHours())}:${pad2(d.getMinutes())}:${pad2(d.getSeconds())}`;
    }

    function isoFromLocalDateTimeInput(value) {
      if (!value) return '';
      const d = new Date(value);
      return Number.isNaN(d.getTime()) ? '' : d.toISOString();
    }

    function formatBytes(bytes) {
      const n = Number(bytes) || 0;
      if (n > 1024 * 1024 * 1024) return `${(n / (1024 * 1024 * 1024)).toFixed(2)} GB`;
      if (n > 1024 * 1024) return `${(n / (1024 * 1024)).toFixed(1)} MB`;
      if (n > 1024) return `${(n / 1024).toFixed(1)} KB`;
      return `${n} B`;
    }

    function displayFileName(value = '') {
      const raw = String(value || '').trim();
      if (!raw) return '';
      return raw.split(/[\\/]/).pop() || raw;
    }

    function displayPathTail(value = '', segmentCount = 3) {
      const raw = String(value || '').trim();
      if (!raw) return '';
      const normalized = raw.replace(/[\\/]+$/, '');
      const parts = normalized.split(/[\\/]/).filter(Boolean);
      if (parts.length <= segmentCount) return normalized;
      return `…${normalized.includes('\\') ? '\\' : '/'}${parts.slice(-segmentCount).join(normalized.includes('\\') ? '\\' : '/')}`;
    }

    function stripRecordingDatePrefix(value = '') {
      let text = String(value || '').trim();
      if (!text) return '';
      text = text.replace(/^\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}\s*,?\s+\d{1,2}:\d{2}(?::\d{2})?\s*(?:AM|PM)?\s*(?:·|-|__|_)?\s*/i, '');
      text = text.replace(/^20\d{2}[-_. ]\d{2}[-_. ]\d{2}[ T_-]+\d{2}[-_.:]\d{2}(?:[-_.:]\d{2})?\s*(?:·|-|__|_)?\s*/i, '');
      text = text.replace(/\s+/g, ' ').replace(/\s*__\s*/g, ' · ').replace(/\s*[._-]{2,}\s*/g, ' · ').trim();
      return text.replace(/^·\s*/, '').trim();
    }

    function cleanRecordingTitleText(value = '') {
      const text = stripRecordingDatePrefix(value).replace(/\.(webm|mp4|mov|mkv|avi)$/i, '').trim();
      return text || 'Recording';
    }

    function pathValueMarkup(value = '', fallback = 'Not selected', segmentCount = 3) {
      const raw = String(value || '').trim();
      const display = raw ? displayPathTail(raw, segmentCount) : fallback;
      const title = raw && display !== raw ? ` title="${escapeHtml(raw)}"` : '';
      return `<strong class="path-value import-path-tail"${title}>${escapeHtml(display)}</strong>`;
    }

    function filePathToUrl(filePath) {
      if (!filePath) return '';
      let normalized = String(filePath).replace(/\\/g, '/');
      if (/^[A-Za-z]:\//.test(normalized)) normalized = `/${normalized}`;
      return `file://${encodeURI(normalized)}`;
    }

    function pill(text, tone = '') {
      return `<span class="pill ${tone}">${escapeHtml(text)}</span>`;
    }

    function normalizeClassNameForColor(value = '') {
      const raw = String(value || '').replace(/[^a-z]/gi, '').toLowerCase();
      const hit = Object.keys(RENDERER_CLASS_COLORS).find((key) => key.toLowerCase() === raw);
      return hit || '';
    }

    function classColorByName(value = '') {
      const className = normalizeClassNameForColor(value);
      return className ? RENDERER_CLASS_COLORS[className] : '';
    }

    function pvpHelperSyncHelpIcon(extraClass = '') {
      const text = 'WoW usually writes addon SavedVariables when you /reload or log out. Sync PvPHelper.lua after that to pull the latest scoreboard/rating session.';
      return `<span class="sync-help-icon ${escapeHtml(extraClass)}" title="${escapeHtml(text)}" aria-label="${escapeHtml(text)}" tabindex="0">?</span>`;
    }

    return {
      readUiPrefs,
      writeUiPrefs,
      rememberSelectedCharacterKey,
      rememberedSelectedCharacterKey,
      escapeHtml,
      cssEscape,
      prettyNumber,
      displayAppVersion,
      formatElapsed,
      pad2,
      localDateTimeInputValue,
      isoFromLocalDateTimeInput,
      formatBytes,
      displayFileName,
      displayPathTail,
      stripRecordingDatePrefix,
      cleanRecordingTitleText,
      pathValueMarkup,
      filePathToUrl,
      pill,
      normalizeClassNameForColor,
      classColorByName,
      pvpHelperSyncHelpIcon
    };
  }

  window.LastCallUiHelpers = { createUiHelpers };
})();
