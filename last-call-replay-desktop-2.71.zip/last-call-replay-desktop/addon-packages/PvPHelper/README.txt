Drop the unzipped PvPHelper addon files in this folder.

Expected shape:
addon-packages\PvPHelper\PvPHelper.toc
addon-packages\PvPHelper\PvPHelper.lua

If you accidentally end up with addon-packages\PvPHelper\PvPHelper\PvPHelper.toc, the app will still try to detect it.
