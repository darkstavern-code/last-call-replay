Local PvPHelper package slot

Do not keep a stale addon copy here forever.
When you want Last Call Replay to install or update PvPHelper, put the newest unzipped addon folder here:

addon-packages\PvPHelper\PvPHelper.toc

The desktop app reads the version from PvPHelper.toc and compares it against the user's installed WoW copy:

World of Warcraft\_retail_\Interface\AddOns\PvPHelper\PvPHelper.toc

If the local package is newer, the app can show Update Addon.
If WoW is missing the addon, the app can show Install Addon.
